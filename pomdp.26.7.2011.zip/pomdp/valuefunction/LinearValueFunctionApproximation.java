package pomdp.valuefunction;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import pomdp.RandomWalkPolicy;
import pomdp.algorithms.AlphaVectorsPolicy;
import pomdp.algorithms.PolicyStrategy;
import pomdp.environments.POMDP;
import pomdp.environments.RandomPOMDP;
import pomdp.utilities.AlphaVector;
import pomdp.utilities.BeliefState;
import pomdp.utilities.BeliefStateFactory;
import pomdp.utilities.ExecutionProperties;
import pomdp.utilities.RandomGenerator;
import pomdp.utilities.TabularAlphaVector;
import pomdp.utilities.concurrent.DotProduct;
import pomdp.utilities.concurrent.ThreadPool;
import pomdp.utilities.datastructures.LinkedList;
import pomdp.utilities.skyline.Equation;
import pomdp.utilities.skyline.EquationMatrix;
import pomdp.utilities.skyline.Skyline;
import pomdp.utilities.skyline.SkylinePruning;

//import lpsolve.*;

public class LinearValueFunctionApproximation implements Serializable{
	//protected Vector<AlphaVector> m_vAlphaVectors;
	//protected ArrayList<AlphaVector> m_vAlphaVectorsRead, m_vAlphaVectorsWrite;
	protected LinkedList<AlphaVector> m_vAlphaVectors;
	protected RandomGenerator m_rndGenerator;
	protected int m_cValueFunctionChanges;
	protected double m_dEpsilon;
	protected boolean m_bCacheValues;
	protected double m_dMaxValue;
	private static boolean g_bUseMultithreadInDotProducts = false;
	private boolean m_bEvaluatingPolicy;
	private boolean m_bPruned;
	private double m_dVarianceFactor = 1;
	
	public LinearValueFunctionApproximation( double dEpsilon, boolean bCacheValues ){
		m_vAlphaVectors = new LinkedList<AlphaVector>();
		m_cValueFunctionChanges = 0;
		m_dEpsilon = dEpsilon;
		m_bCacheValues = true;
		m_dMaxValue = 0.0;
		m_bEvaluatingPolicy = false;
		m_bPruned = false;
		m_rndGenerator = new RandomGenerator( "LinearValueFunctionApproximation" );
	}

	public LinearValueFunctionApproximation(){
		this( 1.0, true );
	}

	public LinearValueFunctionApproximation( LinearValueFunctionApproximation vOtherValueFunction ) {
		copy( vOtherValueFunction );
		m_bCacheValues = vOtherValueFunction.m_bCacheValues;
	}
	
	public void finalize(){
		System.out.println( "LinearValueFunctionApproximation finalized" );
	}
	

	public double valueAt( BeliefState bs ){
		if( m_vAlphaVectors.size() == 0 )
			return Double.NEGATIVE_INFINITY;
		double dValue = bs.getMaxValue();
		int iTime = bs.getMaxValueTime(), cValueFunctionChanges = m_cValueFunctionChanges;
		if( ( iTime < cValueFunctionChanges ) || !m_bCacheValues ){
			AlphaVector avMaxAlpha = getMaxAlpha( bs );
			if( avMaxAlpha == null )
				return Double.NEGATIVE_INFINITY;
			dValue = avMaxAlpha.dotProduct( bs );
			if( m_bCacheValues ){
				bs.setMaxValue( dValue, cValueFunctionChanges );
			}
		}
		
		return dValue;
	}

	public AlphaVector getMaxAlpha( BeliefState bs ){
		int cElements = m_vAlphaVectors.size();
		if( cElements == 0 )
			return null;
		AlphaVector avMaxAlpha = bs.getMaxAlpha();
		double dMaxValue = bs.getMaxValue(), dValue = 0.0;
		int iBeliefStateLastCheckTime = bs.getMaxAlphaTime();
		int iCurrentTime = m_cValueFunctionChanges;
		
		if( !m_vAlphaVectors.contains( avMaxAlpha ) ){
			avMaxAlpha = null;
			dMaxValue = Double.NEGATIVE_INFINITY;
			iBeliefStateLastCheckTime = -1;
		}

		if( g_bUseMultithreadInDotProducts  && ExecutionProperties.useMultiThread() ){
			DotProduct[] m_dpTasks = new DotProduct[m_vAlphaVectors.size()];
			int i = 0;
			for( AlphaVector avCurrent : m_vAlphaVectors ){
				if( !m_bCacheValues || avCurrent.getInsertionTime() > iBeliefStateLastCheckTime ){
					m_dpTasks[i] = new DotProduct( avCurrent, bs );
					ThreadPool.getInstance().addTask( m_dpTasks[i] );
					i++;
				}
			}
			while( i > 0 ){
				i--;
				ThreadPool.getInstance().waitForTask( m_dpTasks[i] );
				dValue = m_dpTasks[i].getResult();
				if( dValue > dMaxValue ){
					dMaxValue = dValue;
					avMaxAlpha = m_dpTasks[i].getAlphaVector();
				}
			}
		}
		
		int iInsertionTime = Integer.MAX_VALUE;
		Iterator<AlphaVector> itBackward = m_vAlphaVectors.backwardIterator();
		boolean bDone = false;
		while( itBackward.hasNext() && !bDone ){
			AlphaVector avCurrent = itBackward.next();
			if( avCurrent != null ){
				iInsertionTime = avCurrent.getInsertionTime();
				if( m_bCacheValues && ( iBeliefStateLastCheckTime >= iInsertionTime ) )
					bDone = true;
				/*
				if( avCurrent.getId() == 1334 ){
					System.out.println( bs );
					System.out.println( avCurrent );
				}
				*/
				dValue = avCurrent.dotProduct( bs );
				if( ( dValue > dMaxValue ) || ( ( dValue == dMaxValue ) && ( avMaxAlpha != null ) && ( iInsertionTime > avMaxAlpha.getInsertionTime() )  ) ){
					dMaxValue = dValue;
					avMaxAlpha = avCurrent;
				}
			}
		}
		
		if( avMaxAlpha != null ){
			if( m_bCacheValues ){
				bs.setMaxAlpha( avMaxAlpha, iCurrentTime );
				bs.setMaxValue( dMaxValue, iCurrentTime );
			}
			
			avMaxAlpha.incrementHitCount();
		}
		return avMaxAlpha;
	}

	public int getBestAction( BeliefState bs ){
		AlphaVector avMaxAlpha = getMaxAlpha( bs );
		if( avMaxAlpha == null )
			return -1;
		return avMaxAlpha.getAction();
	}

	public Iterator<AlphaVector> iterator(){
		return m_vAlphaVectors.iterator();
	}

	public AlphaVector elementAt(int iElement ){
		return (AlphaVector) m_vAlphaVectors.get( iElement );
	}
	
	public void startEvaluation(){
		m_bEvaluatingPolicy = true;
	}
	public void endEvaluation(){
		m_bEvaluatingPolicy = false;
	}
	
	private int m_iLastPrunePoint = 50;
	
	private Skyline m_sSkyline; 
	
	public void addPruneSkyline( AlphaVector avNew ){
		if( m_sSkyline == null && m_vAlphaVectors.size() < 50 ){
			addPrunePointwiseDominated( avNew );
		}
		else{
			Vector<AlphaVector> vDominated = null;
			if( m_sSkyline == null ){
				m_sSkyline = new Skyline( avNew.getStateCount() );
				vDominated = m_sSkyline.init( m_vAlphaVectors );
			}
			else{
				if( !m_vAlphaVectors.contains( avNew ) ){
					m_vAlphaVectors.add( avNew );
					vDominated = m_sSkyline.addNewVector( avNew );
				}
			}
			if( vDominated != null ){
				for( AlphaVector av : vDominated ){
					m_vAlphaVectors.remove( av );
				}
			}
			if( m_vAlphaVectors.size() != m_sSkyline.getSkylineSize() )
				System.out.println( "BUGBUG" );
		}
	}
	
	public boolean addPrunePointwiseDominated( AlphaVector avNew ){
		BeliefState bsWitness = null;
		double dNewValue = 0.0;
		
		while( m_bEvaluatingPolicy ){
			try {
				wait( 100 );
			} 
			catch (Exception e) {
			}
		}

		Iterator<AlphaVector> it = m_vAlphaVectors.iterator();
		AlphaVector avExisting = null;
		while( it.hasNext() ){
			avExisting = it.next();
			if( avExisting.equals( avNew ) || avExisting.dominates( avNew ) ){
				return false;
			}
			else if( avNew.dominates( avExisting ) ){
				it.remove();
			}
		}		
		
		m_bPruned = false;
		
		m_cValueFunctionChanges++;
		addVector( avNew );
		if( m_bCacheValues ){		
			avNew.setInsertionTime( m_cValueFunctionChanges );
			bsWitness = avNew.getWitness();
			if( bsWitness != null ){
				dNewValue = avNew.dotProduct( bsWitness );
				bsWitness.setMaxAlpha( avNew, m_cValueFunctionChanges );
				bsWitness.setMaxValue( dNewValue, m_cValueFunctionChanges );
			}
		}
		
		if( avNew.getMaxValue() > m_dMaxValue )
			m_dMaxValue = avNew.getMaxValue();
		/*
		if( m_iLastPrunePoint + 20 < size() ){
			pruneIterativeSkylineII( null );
			m_iLastPrunePoint = size();
		}
		*/
		return true;
	}
	
	private void addVector( AlphaVector avNew ){
		m_vAlphaVectors.add( avNew );
	}
		
	public void initHitCounts(){
		try{
			for( AlphaVector av : m_vAlphaVectors ){
				av.initHitCount();
			}
		}
		catch( Exception e )
		{
			System.err.println( e + " retrying" );
			initHitCounts();
		}
	}
	
	public void pruneLowHitCountVectors( int cMinimalHitCount ){
		pruneLowHitCountVectors( cMinimalHitCount, Integer.MAX_VALUE );
	}
	
	public void pruneLowHitCountVectors( int cMinimalHitCount, int iMaximalTimeStamp ){
		while( m_bEvaluatingPolicy ){
			try {
				wait( 100 );
			} catch (Exception e) {
			}
		}
		int cPruned = 0, cNew = 0;
		LinkedList<AlphaVector> vAlphaVectorsWrite = new LinkedList<AlphaVector>();
		for( AlphaVector av : m_vAlphaVectors ){
			if( av.getInsertionTime() > iMaximalTimeStamp || av.getHitCount() > cMinimalHitCount ){
				vAlphaVectorsWrite.add( av );
			}
			if( av.getInsertionTime() > iMaximalTimeStamp ){
				cNew++;
			}
			if( av.getHitCount() <= cMinimalHitCount ){
				cPruned++;
			}
		}
		if( vAlphaVectorsWrite.size() > 0 ){
			//System.out.println( "Pruned from " + m_vAlphaVectors.size() + " to " + vAlphaVectorsWrite.size() + ". pruned " + cPruned + ", new vectors " + cNew );
			m_bPruned = true;
			m_vAlphaVectors = vAlphaVectorsWrite;
		}
	}
	
	public boolean wasPruned(){
		return m_bPruned;
	}
	
	public void addBounded( AlphaVector avNew, int cMaxVectors ){
		
		addPrunePointwiseDominated( avNew );
		
		if( m_vAlphaVectors.size() > cMaxVectors ){
			int i = m_rndGenerator.nextInt( m_vAlphaVectors.size() );
			m_vAlphaVectors.remove( i );
		}
	}
	
	public void add( AlphaVector avNew, boolean bPruneDominated ){
		AlphaVector avExisting = null;
		BeliefState bsWitness = null;
		boolean bDominated = false;
		double dPreviousValue = 0.0, dNewValue = 0.0;
		
		m_cValueFunctionChanges++;
		if( bPruneDominated ){
			int iVector = 0;
			for( iVector = 0 ; iVector < m_vAlphaVectors.size() && !bDominated ; iVector++ ){
				avExisting = m_vAlphaVectors.get( iVector );
				if( avNew.dominates( avExisting ) ){
					m_vAlphaVectors.remove( avExisting );
				}
				else if( avExisting.dominates( avNew ) ){
					bDominated = true;
				}
			}
		}
		
		if( !bDominated ){
			m_vAlphaVectors.add( avNew );
		
			if( m_bCacheValues ){		
				avNew.setInsertionTime( m_cValueFunctionChanges );
				bsWitness = avNew.getWitness();
				if( bsWitness != null ){
					dNewValue = avNew.dotProduct( bsWitness );
					bsWitness.setMaxAlpha( avNew, m_cValueFunctionChanges );
					bsWitness.setMaxValue( dNewValue, m_cValueFunctionChanges );
				}
			}
	
			if( avNew.getMaxValue() > m_dMaxValue )
				m_dMaxValue = avNew.getMaxValue();
		}
		
	}


	public void clear() {
		for( AlphaVector av : m_vAlphaVectors ){
			av.release();
		}
		m_vAlphaVectors.clear();
		m_cValueFunctionChanges = 0;
		
	}

	public void addAll( LinearValueFunctionApproximation vOtherValueFunction ){
		m_vAlphaVectors.addAll( vOtherValueFunction.m_vAlphaVectors );
	}

	public int size(){
		return m_vAlphaVectors.count();
	}
	
	public boolean equals( LinearValueFunctionApproximation vOther ){
		return vOther.m_vAlphaVectors.containsAll( m_vAlphaVectors ) && 
			m_vAlphaVectors.containsAll( vOther.m_vAlphaVectors );
	}

	public void copy( LinearValueFunctionApproximation vOtherValueFunction ){
		while( m_bEvaluatingPolicy ){
			try {
				wait( 100 );
			} catch (Exception e) {
			}
		}
		m_vAlphaVectors = new LinkedList<AlphaVector>( vOtherValueFunction.m_vAlphaVectors );
		//m_cValueFunctionChanges = vOtherValueFunction.m_cValueFunctionChanges;
		m_dEpsilon = vOtherValueFunction.m_dEpsilon;
		m_rndGenerator = vOtherValueFunction.m_rndGenerator;
		m_cValueFunctionChanges = vOtherValueFunction.m_cValueFunctionChanges;
		m_dEpsilon = vOtherValueFunction.m_dEpsilon;
		m_bCacheValues = vOtherValueFunction.m_bCacheValues;
		m_dMaxValue = vOtherValueFunction.m_dMaxValue;
		m_bEvaluatingPolicy = vOtherValueFunction.m_bEvaluatingPolicy;
	}

	public void add( AlphaVector avNew ){
		add( avNew, false );
	}

	public void remove( AlphaVector av ){
		m_vAlphaVectors.remove( av );
	}

	public double approximateValueAt( BeliefState bs ){
		if( m_vAlphaVectors.size() == 0 )
			return -1 * Double.MAX_VALUE;
		int iBeliefStateMaxAlphaTime = bs.getApproximateValueTime();
		double dMaxValue = bs.getApproximateValue(), dValue = 0.0;
		AlphaVector avCurrent = null;
		
		if( iBeliefStateMaxAlphaTime < m_cValueFunctionChanges ){
			int iVector = 0;
			for( iVector = 0 ; iVector < m_vAlphaVectors.size() ; iVector++ ){
				avCurrent = m_vAlphaVectors.get( iVector );
				if( avCurrent.getInsertionTime() > iBeliefStateMaxAlphaTime ){
					dValue = avCurrent.approximateDotProduct( bs );
					if( dValue > dMaxValue ){
						dMaxValue = dValue;
					}
				}
			}
			bs.setApproximateValue( dMaxValue, m_cValueFunctionChanges );
		}
		
		return dMaxValue;
	}

	public int getChangesCount() {
		return m_cValueFunctionChanges;
	}
	
	public void setCaching( boolean bCache ){
		m_bCacheValues = bCache;
	}

	public boolean contains( AlphaVector av ){
		return m_vAlphaVectors.contains( av );
	}
	
	public String toString(){
		String sRetVal = "<";
		
		for( AlphaVector av : m_vAlphaVectors ){
			sRetVal += av.toString() + "\n";
		}
		
		return sRetVal;
	}
	
	public double getMaxValue(){
		return m_dMaxValue;
	}

	public AlphaVector getFirst() {
		return m_vAlphaVectors.getFirst();
	}

	public AlphaVector getLast() {
		return m_vAlphaVectors.getLast();
	}
	
	public Element getDOM( Document doc ) throws Exception{
		Element eValueFunction = doc.createElement( "ValueFunction" ), eAlphaVector = null;
		AlphaVector avCurrent = null;
		
		eValueFunction = doc.createElement( "ValueFunction" );
		eValueFunction.setAttribute( "AlphaVectorCount", m_vAlphaVectors.size() + "" );
		eValueFunction.setAttribute( "Epsilon", m_dEpsilon + "" );
		eValueFunction.setAttribute( "CacheValue", m_bCacheValues + "" );
		eValueFunction.setAttribute( "MaxValue", m_dMaxValue + "" );		
		doc.appendChild( eValueFunction );
		
		int iVector = 0;
		for( iVector = 0 ; iVector < m_vAlphaVectors.size() ; iVector++ ){
			avCurrent = m_vAlphaVectors.get( iVector );
			eAlphaVector = avCurrent.getDOM( doc );
			eValueFunction.appendChild( eAlphaVector );
		}
		
		return eValueFunction;
	}
	
	public void save( String sFileName ) throws Exception{
		Document docValueFunction = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
		Element eValueFunction = getDOM( docValueFunction );
		
		// Use a Transformer for output
		TransformerFactory tFactory = TransformerFactory.newInstance();
		Transformer transformer = tFactory.newTransformer();
		
		DOMSource source = new DOMSource( eValueFunction );
		StreamResult result = new StreamResult( new FileOutputStream( sFileName ) );
		transformer.transform( source, result );
	}
	
	public void parseDOM( Element eValueFunction, POMDP pomdp ) throws Exception{
		Element eVector = null;
		NodeList nlVectors = null;
		int cVectors = 0, iVector = 0;
		AlphaVector avNew = null;
		
		cVectors = Integer.parseInt( eValueFunction.getAttribute( "AlphaVectorCount" ) );
		nlVectors = eValueFunction.getChildNodes();
		
		m_dEpsilon = Double.parseDouble( eValueFunction.getAttribute( "Epsilon" ) );
		m_bCacheValues = Boolean.parseBoolean( eValueFunction.getAttribute( "CacheValue" ) );
		m_dMaxValue = Double.parseDouble( eValueFunction.getAttribute( "MaxValue" ) );

		for( iVector = 0 ; iVector < cVectors ; iVector++ ){
			eVector = (Element)nlVectors.item( iVector );
			avNew = AlphaVector.parseDOM( eVector, pomdp );
			m_vAlphaVectors.add( avNew );
		}
	}
	
	public void load( String sFileName, POMDP pomdp ) throws Exception{
		DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		Document docValueFunction = builder.parse( new FileInputStream( sFileName ) );
		Element eValueFunction = (Element)docValueFunction.getChildNodes().item( 0 );
		
		parseDOM( eValueFunction, pomdp );
	}

	
	public void removeFirst() {
		m_vAlphaVectors.remove( 0 );
	}

	public Collection<AlphaVector> getVectors() {
		return m_vAlphaVectors;
	}

	public void setVectors( Vector<AlphaVector> v ) {
		m_vAlphaVectors = new LinkedList<AlphaVector>( v );		
	}

	public int countEntries() {
		AlphaVector avCurrent = null;
		int cEntries = 0;
		
		int iVector = 0;
		for( iVector = 0 ; iVector < m_vAlphaVectors.size() ; iVector++ ){
			avCurrent = m_vAlphaVectors.get( iVector );
			cEntries += avCurrent.countEntries();
		}
		return cEntries;
	}

	public double getAvgAlphaVectorSize() {
		double cNodes = 0;
		for( AlphaVector av : m_vAlphaVectors )
			cNodes += av.countEntries();
		return cNodes / m_vAlphaVectors.size();
	}
	
	public void skylinePruning( BeliefState bsStart, int cStates ){
		BeliefState bs = bsStart.copy();
		AlphaVector av0 = null, av1 = null;
		double dMax = Double.NEGATIVE_INFINITY;
		double dValue = 0.0;
		for( AlphaVector avCurrent : m_vAlphaVectors ){
			dValue = avCurrent.dotProduct( bs );
			if( dValue > dMax ){
				dMax = dValue;
				av0 = avCurrent;
			}
		}
		
		int iState = av0.getNonZeroEntries().next().getKey();
		double dT = 0.0, dMinT = Double.POSITIVE_INFINITY;
		double dStateValue = av0.valueAt( iState );
		for( AlphaVector avCurrent : m_vAlphaVectors ){
			if( avCurrent != av0 ){
				dT = ( avCurrent.dotProduct( bs ) - dMax ) / ( dStateValue - avCurrent.valueAt( iState ) );
				if( dT < dMinT ){
					dMinT = dT;
					av1 = avCurrent;
				}
			}
		}
		
		
		
		
	}

/*
	public AlphaVector getMaxAlphaRiskAware( BeliefState bs ) {
		int cElements = m_vAlphaVectors.size();
		if( cElements == 0 )
			return null;
		AlphaVector avMaxAlpha = bs.getMaxAlpha();
		double dMaxValue = bs.getMaxValue(), dValue = 0.0;
		int iBeliefStateLastCheckTime = bs.getMaxAlphaTime();
		int iCurrentTime = m_cValueFunctionChanges;
		
		if( !m_vAlphaVectors.contains( avMaxAlpha ) ){
			avMaxAlpha = null;
			dMaxValue = Double.NEGATIVE_INFINITY;
			iBeliefStateLastCheckTime = -1;
		}
		
		int iInsertionTime = Integer.MAX_VALUE;
		Iterator<AlphaVector> itBackward = m_vAlphaVectors.backwardIterator();
		boolean bDone = false;
		while( itBackward.hasNext() && !bDone ){
			AlphaVector avCurrent = itBackward.next();
			if( avCurrent != null ){
				iInsertionTime = avCurrent.getInsertionTime();
				if( m_bCacheValues && ( iBeliefStateLastCheckTime >= iInsertionTime ) )
					bDone = true;
				dValue = avCurrent.computeRiskAwareValue( bs );
				if( ( dValue > dMaxValue ) || ( ( dValue == dMaxValue ) && ( avMaxAlpha != null ) && ( iInsertionTime > avMaxAlpha.getInsertionTime() )  ) ){
					dMaxValue = dValue;
					avMaxAlpha = avCurrent;
				}
			}
		}
		
		if( avMaxAlpha != null ){
			if( m_bCacheValues ){
				bs.setMaxAlpha( avMaxAlpha, iCurrentTime );
				bs.setMaxValue( dMaxValue, iCurrentTime );
			}
			
			avMaxAlpha.incrementHitCount();
		}
		return avMaxAlpha;
	}
*/
	
	private long m_cLPIterations = 0;
/*	
  
  BUGBUG - need to enable LpSolve for using this code
	static{
		try{
			
			//String sLibraryPath = System.getProperty("java.library.path");
			//System.setProperty("java.library.path", sLibraryPath + ";" + "C:\\Windows\\System32\\lpsolve");
			//sLibraryPath = System.getProperty("java.library.path");
			//System.out.println( sLibraryPath );
			
			System.loadLibrary( "lpsolve55j" );
			System.out.println( "lpsolve loaded" );
		}
		catch( UnsatisfiedLinkError err ){
			System.out.println( "unable to load dll " + err );
		}
	}
	private double[] dominateLP( AlphaVector avCurrent, LinkedList<AlphaVector> vAlphaVectors, int cStates ){
		
		try {
			// Create a problem with 4 variables and 0 constraints
			//cStates++;
			LpSolve solver = LpSolve.makeLp( 0, cStates + 1 );
			double[] adConstraint = new double[cStates + 1]; //states + delta
			int iState = 0;
			String sConstraint = "";
			
			//constraints for finding a witness for avCurrent
			adConstraint[cStates] = -1;//-delta
			for( AlphaVector av : vAlphaVectors ){
				if( ( av != avCurrent ) && ( !av.isDominated() ) ){
					sConstraint = "";
					for( iState = 0 ; iState < cStates ; iState++ ){
						adConstraint[iState] = avCurrent.valueAt( iState ) - av.valueAt( iState );
						sConstraint += adConstraint[iState] + " ";
					}
					//x*a >= delta + x*a'  ==> x*a - x*a' - delta >= 0
					sConstraint += "-1";
					//solver.addConstraint( adConstraint, LpSolve.GE, 0.0 );
					solver.strAddConstraint( sConstraint, LpSolve.GE, 0.0 );
				}
			}
			
			//add belief constraints
			adConstraint[cStates] = 0;//delta
			sConstraint = "";
			for( iState = 0 ; iState < cStates ; iState++ ){
				adConstraint[iState] = 1;
				sConstraint += "1 ";
			}
			sConstraint += "0";
			//solver.addConstraint( adConstraint, LpSolve.EQ, 1.0 );
			solver.strAddConstraint( sConstraint, LpSolve.EQ, 1.0 );
			
			//set objective function - maximize delta
			adConstraint[cStates] = 1;//delta
			sConstraint = "";
			for( iState = 0 ; iState < cStates ; iState++ ){
				adConstraint[iState] = 0;
				sConstraint += "0 ";
			}
			sConstraint += "1";
			//solver.setObjFn( adConstraint );
			solver.strSetObjFn( sConstraint );
			solver.setMaxim();
			
			//solver.setLowbo( cStates + 1, -1 * solver.getInfinite() ); //we are interested only in delta greater than 0.0
			//solver.setLowbo( cStates, 0 ); //we are interested only in delta greater than 0.0
			
			for( iState = 1 ; iState <= cStates ; iState++ ){
				solver.setUpbo( iState, 1.0 );
				solver.setLowbo( iState, 0.0 );
			}			
			
			
			// solve the problem
			solver.setOutputfile( "" );
			//solver.printLp();
			int iResult = solver.solve();
			double[] adSolution = null;
			double dMaxDelta = solver.getObjective();
			m_cLPIterations += solver.getTotalIter();
			if( dMaxDelta > 0.0001 ){
				adSolution = solver.getPtrVariables();
			}
			
			// delete the problem and free memory
			solver.deleteLp();
			return adSolution;
		}
		catch (LpSolveException e) {
			e.printStackTrace();
			System.exit( 0 );
		}
		
		return null;
	}
	public void pruneLP1( POMDP pPOMDP ) {
		if( m_vAlphaVectors.size() < 2 )
			return;
		long lTimeBefore = System.currentTimeMillis();
		LinkedList<AlphaVector> vDirtyList = new LinkedList<AlphaVector>( m_vAlphaVectors );
		LinkedList<AlphaVector> vCleanList = new LinkedList<AlphaVector>();
		
		double[] adBelief = null;
		m_cLPIterations = 0;
		for( AlphaVector av : vDirtyList ){
			av.setDominated( false );
		}
		int iVector = 0;
		AlphaVector av = null;
		while( iVector < vDirtyList.size() ){
			av = vDirtyList.get( iVector );
			adBelief = dominateLP( av, vDirtyList, pPOMDP.getStateCount() );

			if( adBelief == null ){
				av.setDominated( true );
				vDirtyList.remove( av );
			}
			else{
				iVector++;
				av.setWitness( pPOMDP.getBeliefStateFactory().newBeliefState( adBelief ) ); 
				vCleanList.add( av );
			}
		}
		long lTimeAfter = System.currentTimeMillis();
		PrintStream fw = null;
		try{
			fw = new PrintStream( new FileOutputStream( pPOMDP.getName() + ".PruningResults.txt", true ) );
			fw.println( "LP1, |V| " + m_vAlphaVectors.size() + "|V'| " + vCleanList.size() + ", iterations " + m_cLPIterations + ", time " + ( lTimeAfter - lTimeBefore ) );
		}
		catch( Exception e ){
			e.printStackTrace();
		}
		
		System.out.println( "LP1: Pruned the lower bound from " + m_vAlphaVectors.size() + " to " + vCleanList.size() + ", iterations = " + m_cLPIterations + " time " + ( lTimeAfter - lTimeBefore ) );
		m_vAlphaVectors = vCleanList;
	}
	public void pruneLPIterative1( POMDP pPOMDP ) {
		if( m_vAlphaVectors.size() < 2 )
			return;
		long lTimeBefore = System.currentTimeMillis();
		LinkedList<AlphaVector> vDirtyList = new LinkedList<AlphaVector>( m_vAlphaVectors );
		LinkedList<AlphaVector> vCleanList = new LinkedList<AlphaVector>();
		
		int iState = 0;
		BeliefState bsCurrent = null;
		double[] adBelief = null;
		AlphaVector avCurrent = null, avMax = null;
		double dValue = 0.0, dMax = 0.0;
		m_cLPIterations = 0;

		for( iState = 0 ; iState < pPOMDP.getStateCount() ; iState++ ){
			bsCurrent = pPOMDP.getBeliefStateFactory().getDeterministicBeliefState( iState );
			avMax = getMaxAlpha( bsCurrent );
			if( !vCleanList.contains( avMax ) ){
				//avMax.setWitness( bsCurrent );
				vDirtyList.remove( avMax );
				vCleanList.add( avMax );
			}
		}
		
		while( vDirtyList.size() > 0 ){
			avCurrent = vDirtyList.getFirst();
			adBelief = dominateLP( avCurrent, vCleanList, pPOMDP.getStateCount() );
				
			if( adBelief != null ){
				
				dMax = Double.NEGATIVE_INFINITY;
				for( AlphaVector av : vDirtyList ){
					dValue = av.dotProduct( adBelief );
					if( dValue > dMax ){
						dMax = dValue;
						avMax = av;
					}						
				}
				//avMax.setWitness( pPOMDP.getBeliefStateFactory().newBeliefState( adBelief ) );
				vDirtyList.remove( avMax );
				vCleanList.add( avMax );
			}
			else{
				//avCurrent.setWitness( null );
				vDirtyList.remove( avCurrent );
			}
		}

		long lTimeAfter = System.currentTimeMillis();
		PrintStream fw = null;
		try{
			fw = new PrintStream( new FileOutputStream( pPOMDP.getName() + ".PruningResults.txt", true ) );
			fw.println( "LPIterative1, |V| " + m_vAlphaVectors.size() + "|V'| " + vCleanList.size() + ", iterations " + m_cLPIterations + ", time " + ( lTimeAfter - lTimeBefore ) );
		}
		catch( Exception e ){
			e.printStackTrace();
		}
		
		System.out.println( "LPIterative1: Pruned the lower bound from " + m_vAlphaVectors.size() + " to " + vCleanList.size() + ", iterations = " + m_cLPIterations + " time " + ( lTimeAfter - lTimeBefore ) );
		m_vAlphaVectors = vCleanList;
	}
*/
	public void pruneLP2( POMDP pPOMDP ) {
		if( m_vAlphaVectors.size() < 2 )
			return;
		long lTimeBefore = System.currentTimeMillis();
		LinkedList<AlphaVector> vDirtyList = new LinkedList<AlphaVector>( m_vAlphaVectors );
		LinkedList<AlphaVector> vCleanList = new LinkedList<AlphaVector>();
		SkylinePruning sp = new SkylinePruning( this, pPOMDP.getStateCount() );
		
		double[] adBelief = null;
		m_cLPIterations = 0;
		for( AlphaVector av : vDirtyList ){
			av.setDominated( false );
		}
		int iVector = 0;
		AlphaVector av = null;
		while( iVector < vDirtyList.size() ){
			av = vDirtyList.get( iVector );
			
			adBelief = sp.findWitness( vDirtyList, av );
			m_cLPIterations = sp.getEquationsCount();
			if( adBelief == null ){
				av.setDominated( true );
				vDirtyList.remove( av );
			}
			else{
				iVector++;
				vCleanList.add( av );
			}
		}
		long lTimeAfter = System.currentTimeMillis();
		
		PrintStream fw = null;
		try{
			fw = new PrintStream( new FileOutputStream( pPOMDP.getName() + ".PruningResults.txt", true ) );
			fw.println( "LP2, |V| " + m_vAlphaVectors.size() + "|V'| " + vCleanList.size() + ", iterations " + sp.getEquationsCount() + ", time " + ( lTimeAfter - lTimeBefore ) );
		}
		catch( Exception e ){
			e.printStackTrace();
		}
		
		System.out.println( "LP2: Pruned the lower bound from " + m_vAlphaVectors.size() + " to " + vCleanList.size() + ", iterations = " + m_cLPIterations + " time " + ( lTimeAfter - lTimeBefore ) );
		m_vAlphaVectors = vCleanList;
	}
	
	public void pruneLPIterative2( POMDP pPOMDP ) {
		if( m_vAlphaVectors.size() < 2 )
			return;
		long lTimeBefore = System.currentTimeMillis();
		LinkedList<AlphaVector> vDirtyList = new LinkedList<AlphaVector>( m_vAlphaVectors );
		LinkedList<AlphaVector> vCleanList = new LinkedList<AlphaVector>();
		SkylinePruning sp = new SkylinePruning( this, pPOMDP.getStateCount() );
		
		int iState = 0;
		BeliefState bsCurrent = null;
		double[] adBelief = null;
		AlphaVector avCurrent = null, avMax = null;
		double dValue = 0.0, dMax = 0.0;
		m_cLPIterations = 0;

		for( iState = 0 ; iState < pPOMDP.getStateCount() ; iState++ ){
			bsCurrent = pPOMDP.getBeliefStateFactory().getDeterministicBeliefState( iState );
			avMax = getMaxAlpha( bsCurrent );
			if( !vCleanList.contains( avMax ) ){
				avMax.setWitness( bsCurrent );
				vDirtyList.remove( avMax );
				vCleanList.add( avMax );
			}
		}
		
		while( vDirtyList.size() > 0 ){
			avCurrent = vDirtyList.getFirst();
			adBelief = sp.findWitness( vCleanList, avCurrent );
			m_cLPIterations = sp.getEquationsCount();
				
			if( adBelief != null ){
				
				dMax = Double.NEGATIVE_INFINITY;
				for( AlphaVector av : vDirtyList ){
					dValue = av.dotProduct( adBelief );
					if( dValue > dMax ){
						dMax = dValue;
						avMax = av;
					}						
				}
				avMax.setWitness( pPOMDP.getBeliefStateFactory().newBeliefState( adBelief ) );
				vDirtyList.remove( avMax );
				vCleanList.add( avMax );
			}
			else{
				avCurrent.setWitness( null );
				vDirtyList.remove( avCurrent );
			}
			if( vDirtyList.size() % 10 == 0 )
				System.out.print( "." );
		}

		System.out.println( "Delta = " + Equation.m_cDeltaComputations + " Time in next " + EquationMatrix.m_cTimeInNextVertex );
		
		long lTimeAfter = System.currentTimeMillis();
		PrintStream fw = null;
		try{
			fw = new PrintStream( new FileOutputStream( pPOMDP.getName() + ".PruningResults.txt", true ) );
			fw.println( "LPIterative2, |V| " + m_vAlphaVectors.size() + "|V'| " + vCleanList.size() + ", iterations " + m_cLPIterations + ", time " + ( lTimeAfter - lTimeBefore ) );
		}
		catch( Exception e ){
			e.printStackTrace();
		}
		
		System.out.println( "LPIterative2: Pruned the lower bound from " + m_vAlphaVectors.size() + " to " + vCleanList.size() +
				", matrixes " + sp.getMatrixCount() + 
				", iterations = " + sp.getEquationsCount() + " time " + ( lTimeAfter - lTimeBefore ) );
		m_vAlphaVectors = vCleanList;
	}
	

	public void pruneRandomSampling( BeliefStateFactory bsf, int cSamples ) {
		if( m_vAlphaVectors.size() < 2 )
			return;
		LinkedList<AlphaVector> vDirtyList = new LinkedList<AlphaVector>( m_vAlphaVectors );
		LinkedList<AlphaVector> vCleanList = new LinkedList<AlphaVector>();
		int iSample = 0;
		BeliefState bsCurrent = null;
		AlphaVector avMax = null;
		double dValue = 0.0, dMax = 0.0, dSum = 0.0;
	
		for( iSample = 0 ; ( iSample < cSamples ) && ( vDirtyList.size() > 0.0 ) ; iSample++ ){
			dSum = 0.0;
			bsCurrent = bsf.getRandomBeliefState();
			
			dMax = Double.NEGATIVE_INFINITY;
			
			for( AlphaVector av : vDirtyList ){
				dValue = av.dotProduct( bsCurrent );
				if( dValue > dMax ){
					dMax = dValue;
					avMax = av;
				}						
			}
			
			for( AlphaVector av : vCleanList ){
				dValue = av.dotProduct( bsCurrent );
				if( dValue > dMax ){
					avMax = null;
					break;
				}						
			}
			
			if( avMax != null ){
				vCleanList.add( avMax );
				vDirtyList.remove( avMax );
			}
		}
		System.out.println( "Pruned the lower bound from " + m_vAlphaVectors.size() + " to " + vCleanList.size() );
		m_vAlphaVectors = vCleanList;
	}
	public void pruneRandomSampling( POMDP pPOMDP, int cSamples ) {
		if( m_vAlphaVectors.size() < 2 )
			return;
		LinkedList<AlphaVector> vDirtyList = new LinkedList<AlphaVector>( m_vAlphaVectors );
		LinkedList<AlphaVector> vCleanList = new LinkedList<AlphaVector>();
		int iState = 0, iSample = 0, cStates = pPOMDP.getStateCount();
		BeliefState bsCurrent = null;
		double[] adBelief = new double[cStates];
		AlphaVector avMax = null;
		double dValue = 0.0, dMax = 0.0, dSum = 0.0;
		for( iState = 0 ; iState < cStates ; iState++ ){
			bsCurrent = pPOMDP.getBeliefStateFactory().getDeterministicBeliefState( iState );
			avMax = getMaxAlpha( bsCurrent );
			if( !vCleanList.contains( avMax ) ){
				vCleanList.add( avMax );
				vDirtyList.remove( avMax );
			}
		}
	
		for( iSample = 0 ; ( iSample < cSamples ) && ( vDirtyList.size() > 0.0 ) ; iSample++ ){
			dSum = 0.0;
			for( iState = 0 ; iState < cStates ; iState++ ){
				adBelief[iState] = m_rndGenerator.nextDouble();
				dSum += adBelief[iState];
			}
			for( iState = 0 ; iState < cStates ; iState++ ){
				adBelief[iState] /= dSum;
			}
			
			for( AlphaVector av : vDirtyList ){
				dValue = av.dotProduct( adBelief );
				if( dValue > dMax ){
					dMax = dValue;
					avMax = av;
				}						
			}
			for( AlphaVector av : vCleanList ){
				dValue = av.dotProduct( adBelief );
				if( dValue > dMax ){
					avMax = null;
					break;
				}						
			}
			
			if( avMax != null ){
				vCleanList.add( avMax );
				vDirtyList.remove( avMax );
			}
		}
		System.out.println( "Pruned the lower bound from " + m_vAlphaVectors.size() + " to " + vCleanList.size() );
		m_vAlphaVectors = vCleanList;
	}
	public void pruneTrials( POMDP pPOMDP, int cTrials, int cSteps, PolicyStrategy ps ){
		initHitCounts();
		double dSimulatedADR = pPOMDP.computeAverageDiscountedReward( cTrials, cSteps, ps );
		int cBefore = m_vAlphaVectors.size();
		pruneLowHitCountVectors( 1 );
		System.out.println( "Pruned the lower bound from " + cBefore + " to " + m_vAlphaVectors.size() );
	}
	public boolean pruneSkyline( POMDP pPOMDP ){
		long lTimeBefore = System.currentTimeMillis();
		int cBefore = m_vAlphaVectors.size(), cPruned = 0;
		LinkedList<AlphaVector> vCleanList = new LinkedList<AlphaVector>();
		SkylinePruning sp = new SkylinePruning( this, pPOMDP.getStateCount() );
		for( AlphaVector av : m_vAlphaVectors ){
			av.clearWitnesses();
			av.setDominated( true );
		}
		
		sp.runSkylineaCahceNodes();
		m_cLPIterations = sp.getEquationsCount();
		/*
		long lBefore = System.currentTimeMillis();
		sp.runSkyline( false );
		int iOpBetween = sp.getProcessedCount();
		long lBetween = System.currentTimeMillis();
		sp.runSkyline( true );
		int iOpAfter = sp.getProcessedCount();
		long lAfter = System.currentTimeMillis();
		
		//System.out.println( "Nodes: time " + ( lBetween - lBefore ) / 1000 + " ops " + iOpBetween +
		//		" Edges: time " + ( lAfter - lBetween ) / 1000 + " ops " + ( iOpAfter - iOpBetween ) );
		*/		
		
		
		for( AlphaVector av : m_vAlphaVectors ){
			//if( !av.isDominated() && av.countWitnesses() > 1 )
			if( !av.isDominated() )
				vCleanList.add( av );
			else
				cPruned++;
		}
		long lTimeAfter = System.currentTimeMillis();
		m_vAlphaVectors = vCleanList;
		PrintStream fw = null;
		try{
			fw = new PrintStream( new FileOutputStream( pPOMDP.getName() + ".PruningResults.txt", true ) );
			fw.println( "Skyline, |V| " + m_vAlphaVectors.size() + "|V'| " + vCleanList.size() + ", iterations " + sp.getEquationsCount() + ", time " + ( lTimeAfter - lTimeBefore ) );
		}
		catch( Exception e ){
			e.printStackTrace();
		}
		
		System.out.println( "Skyline: Pruned the lower bound from " + cBefore + " to " + m_vAlphaVectors.size()
				+ ", iterations = " + sp.getEquationsCount() + " time " + ( lTimeAfter - lTimeBefore ) );
		return cBefore > m_vAlphaVectors.size();
	}
	
	public boolean pruneIterativeSkylineII( POMDP pPOMDP ){
		long lTimeBefore = System.currentTimeMillis();
		int cBefore = m_vAlphaVectors.size(), cPruned = 0, cProcessed = 0;
		LinkedList<AlphaVector> vCleanList = new LinkedList<AlphaVector>();
		SkylinePruning sp = new SkylinePruning( this, m_vAlphaVectors.getFirst().getStateCount() );
		for( AlphaVector av : m_vAlphaVectors ){
			av.clearWitnesses();
			av.setDominated( true );
		}
		sp.runIterativeSkyline();
		m_cLPIterations = sp.getEquationsCount();
		for( AlphaVector av : m_vAlphaVectors ){
			//if( !av.isDominated() && av.countWitnesses() > 1 )
			if( !av.isDominated() )
				vCleanList.add( av );
			else
				cPruned++;
			cProcessed++;
			if( cProcessed % 10 == 0 )
				System.out.print( "." );
		}
		m_vAlphaVectors = vCleanList;
		long lTimeAfter = System.currentTimeMillis();
		PrintStream fw = null;
		
		try{
			fw = new PrintStream( new FileOutputStream( pPOMDP.getName() + ".PruningResults.txt", true ) );
			fw.println( "IterativeSkylineII, |V| " + m_vAlphaVectors.size() + "|V'| " + vCleanList.size() + ", iterations " + sp.getEquationsCount() + ", time " + ( lTimeAfter - lTimeBefore ) );
		}
		catch( Exception e ){
			e.printStackTrace();
		}
		
		System.out.println( "IterativeSkylineII: Pruned the lower bound from " + cBefore + " to " + m_vAlphaVectors.size() +
				", matrixes " + sp.getMatrixCount() + 
				", iterations = " + sp.getEquationsCount() + " time " + ( lTimeAfter - lTimeBefore ) );
		return cBefore > m_vAlphaVectors.size();
	}
	
	public boolean pruneIterativeSkylineI( POMDP pPOMDP, boolean bSearchForClosestToSurface ){
		long lTimeBefore = System.currentTimeMillis();
		int cBefore = m_vAlphaVectors.size(), cPruned = 0, cProcessed = 0;
		LinkedList<AlphaVector> vCleanList = new LinkedList<AlphaVector>();
		SkylinePruning sp = new SkylinePruning( this, pPOMDP.getStateCount() );
		for( AlphaVector av : m_vAlphaVectors ){
			av.clearWitnesses();
			av.setDominated( true );
		}
		sp.runSkylineWitness( bSearchForClosestToSurface );
		m_cLPIterations = sp.getEquationsCount();
		for( AlphaVector av : m_vAlphaVectors ){
			//if( !av.isDominated() && av.countWitnesses() > 1 )
			if( !av.isDominated() )
				vCleanList.add( av );
			else
				cPruned++;
			cProcessed++;
			if( cProcessed % 10 == 0 )
				System.out.print( "." );
		}
		m_vAlphaVectors = vCleanList;
		long lTimeAfter = System.currentTimeMillis();
		PrintStream fw = null;
		try{
			fw = new PrintStream( new FileOutputStream( pPOMDP.getName() + ".PruningResults.txt", true ) );
			fw.println( "IterativeSkylineI (" + bSearchForClosestToSurface + "), |V| " + m_vAlphaVectors.size() + "|V'| " + vCleanList.size() + ", iterations " + sp.getEquationsCount() + ", time " + ( lTimeAfter - lTimeBefore ) );
		}
		catch( Exception e ){
			e.printStackTrace();
		}
		
		System.out.println( "IterativeSkylineI (" + bSearchForClosestToSurface + ") : Pruned the lower bound from " + cBefore + " to " + m_vAlphaVectors.size() +
				", matrixes " + sp.getMatrixCount() + 
				", iterations = " + sp.getEquationsCount() + " time " + ( lTimeAfter - lTimeBefore ) );
		return cBefore > m_vAlphaVectors.size();
	}
	
	
	public void testAllPruningTechniques( POMDP pomdp, boolean bTestPureSkyline ){
		
		/*
		int cVectors = 20;
		for( int i = 1 ; i < 10 ; i++ ){
			System.out.println( "Random vectors - |V| = " + cVectors );
			clear();
			AlphaVector avRandom = null;
			for( int j = 0 ; j < cVectors ; j++ ){
				avRandom = new TabularAlphaVector( null, 0.0, pomdp );
				for( int k = 0 ; k < pomdp.getStateCount() ; k++ ){
					avRandom.setValue( k, m_rndGenerator.nextDouble() );
				}
				avRandom.finalizeValues();
				add( avRandom );
			}
			cVectors *= 2;
			System.out.println( "Done initializing random vectors" );
			*/

		sort( false );
		LinearValueFunctionApproximation vCopy = null, vLP1 = null, vLP2 = null; 
		LinkedList<AlphaVector> vVectors = m_vAlphaVectors;
		
		/* BUGBUG - need to enable LpSolve to use this code
		vLP1 = vCopy = new LinearValueFunctionApproximation( this );
		vCopy.pruneLP1( pomdp );
		
		if( vCopy.m_vAlphaVectors.size() < vVectors.size() )
			vVectors = vCopy.m_vAlphaVectors;
		
		vCopy = new LinearValueFunctionApproximation( this );
		vCopy.pruneLPIterative1( pomdp );
		
		if( vCopy.m_vAlphaVectors.size() < vVectors.size() )
			vVectors = vCopy.m_vAlphaVectors;
		*/
		
		vLP2 = vCopy = new LinearValueFunctionApproximation( this );
		vCopy.pruneLP2( pomdp );
		if( vCopy.m_vAlphaVectors.size() < vVectors.size() )
			vVectors = vCopy.m_vAlphaVectors;
		
/*
		for( AlphaVector avLP1 : vLP1.m_vAlphaVectors ){
			if( !vLP2.m_vAlphaVectors.contains( avLP1 ) ){
				BeliefState bs = avLP1.getWitness();
				double dLP1Value = avLP1.dotProduct( bs );
				double dLP2Value = Double.NEGATIVE_INFINITY;
				AlphaVector avMaxLP2 = null;
				for( AlphaVector avLP2 : vLP2.m_vAlphaVectors ){
					double d = avLP2.dotProduct( bs );
					if( d > dLP2Value ){
						dLP2Value = d;
						avMaxLP2 = avLP2;
					}
				}
				System.out.println( dLP1Value + ", " + dLP2Value + " " + avLP1 + " " + avMaxLP2 );
			}
		}
*/
		
		
		vCopy = new LinearValueFunctionApproximation( this );
		vCopy.pruneLPIterative2( pomdp );
		
		if( vCopy.m_vAlphaVectors.size() < vVectors.size() )
			vVectors = vCopy.m_vAlphaVectors;
		
		if( bTestPureSkyline ){
			try{
				vCopy = new LinearValueFunctionApproximation( this );
				vCopy.pruneSkyline( pomdp );
				
				if( vCopy.m_vAlphaVectors.size() < vVectors.size() )
					vVectors = vCopy.m_vAlphaVectors;
				
			}
			catch( Error e ){
				System.err.println( e );
			}
		}
		vCopy = new LinearValueFunctionApproximation( this );
		vCopy.pruneIterativeSkylineI( pomdp, true );
		vCopy = new LinearValueFunctionApproximation( this );
		vCopy.pruneIterativeSkylineI( pomdp, false );
		vCopy = new LinearValueFunctionApproximation( this );
		vCopy.pruneIterativeSkylineII( pomdp );
		
		if( vCopy.m_vAlphaVectors.size() < vVectors.size() )
			vVectors = vCopy.m_vAlphaVectors;
		
		//}
		
		//m_vAlphaVectors = vVectors;
	}


	private int m_iLastPruning = 25;
	public void prune(POMDP pomdp) {
		if( size() > m_iLastPruning * 1.5 ){
			//pruneIterativeSkyline( pomdp );
			//pruneLPIterative2(pomdp);
			//pruneTrials( pomdp, 100, 100, new AlphaVectorsPolicy( this ) );
			m_iLastPruning = size();
		}
	}
	
	public void sort( boolean bAscending )
	{
		int i = 0, j = 0;
		boolean bSwitched = true, bSwitchRequired = false;
		AlphaVector vCurrent = null, vNext = null;
		for( i = 1 ; i < m_vAlphaVectors.size() && bSwitched ; i++ ){
			bSwitched = false;
			for( j = 0 ; j < m_vAlphaVectors.size() - i; j++ ){
				vCurrent = m_vAlphaVectors.get( j );
				vNext = m_vAlphaVectors.get( j + 1 );
				if( bAscending )
					bSwitchRequired = (vCurrent.compareTo( vNext ) > 0);
				else
					bSwitchRequired = (vCurrent.compareTo( vNext ) < 0);
				if( bSwitchRequired )
				{
					//m_vAlphaVectors.set( j, vNext );
					//m_vAlphaVectors.set( j + 1, vCurrent );
					m_vAlphaVectors.swap( j, j + 1 );
					if( vNext == vCurrent )
						System.out.println( "BUGBUG ");
					bSwitched = true;
				}
			}
		}
		for( i = 0 ; i < m_vAlphaVectors.size() - 1 ; i++ ){
			int cIdentical = 0;
			for( j = i + 1 ; j < m_vAlphaVectors.size(); j++ ){
				if( m_vAlphaVectors.get(i) == m_vAlphaVectors.get(j) )
					cIdentical++;
			}
			if( cIdentical == 1 )
				System.out.println( "BUGBUG ");
			vCurrent = m_vAlphaVectors.get( i );
			vNext = m_vAlphaVectors.get( i + 1 );
			if( !bAscending && vCurrent.compareTo( vNext ) <= 0 )
				System.out.println( "BUGBUG ");
			if( bAscending && vCurrent.compareTo( vNext ) >= 0 )
				System.out.println( "BUGBUG ");
				
			
		}
	}
	
	public static double[] randomBelief( int cStates, RandomGenerator rnd ){
		int iState = 0;
		double[] adBelief = new double[cStates];
		double dSum = 0.0;
		for( iState = 0 ; iState < cStates ; iState++ ){
			adBelief[iState] = rnd.nextDouble();
			dSum += adBelief[iState];
		}		
		for( iState = 0 ; iState < cStates ; iState++ ){
			adBelief[iState] /= dSum;
		}
		return adBelief;
	}
	
	public static double f( double[] adBelief ){
		double dSum = 0.0, x = 0.0;
		int iState = 0, cStates = adBelief.length;
		for( iState = 0 ; iState < cStates ; iState++ ){
			//v = ( x - 0.5 ) * 2.0;
			x = adBelief[iState];
			dSum += x * x;
		}
		return dSum;
	}
	
	public static double fPrime( double[] adBelief, int iPrimeState ){
		/*
		double dSum = -2.0, v = 0.0;
		int iState = 0, cStates = adBelief.length;
		for( iState = 0 ; iState < cStates - 1 ; iState++ ){
			v = adBelief[iState];
			if( iState != iPrimeState )
				dSum += 2 * v;
			else
				dSum += 4 * v;
		}
		return dSum;
		*/
		return 2 * adBelief[iPrimeState];
	}

	public static double slope( double dDeltaX, double dY1, double dY2 ){
		return ( dY2 - dY1 ) / dDeltaX;
	}
	
	public static double offset( double dX, double dY, double dSlope ){
		return dY - dX * dSlope;
	}
	
	public static double[] computeVector( double[] adBelief ){
		double dScale = 1000.0;
		int iState1 = 0, iState2 = 0, cStates = adBelief.length;
		double dV = dScale * f( adBelief );
		double[] adSlope = new double[cStates];
		double dSum = 0.0;
		double[] adCorners = new double[cStates];
		for( iState1 = 0 ; iState1 < cStates ; iState1++ ){
			adSlope[iState1] =  fPrime( adBelief, iState1 );
		}
		for( iState1 = 0 ; iState1 < cStates ; iState1++ ){
			adCorners[iState1] = -dV + 2 * adBelief[iState1] * dScale;
			/*
			for( iState2 = 0 ; iState2 < cStates ; iState2++ ){
				
				if( iState1 == iState2 ){
					adCorners[iState1] += ( 1 - adBelief[iState2] ) * adSlope[iState2];		
				}
				else{
					adCorners[iState1] = ( 0 - adBelief[iState2] ) * adSlope[iState2];							
				}
				
			}
			*/
		}
		          
		dSum = 0.0;
		for( iState1 = 0 ; iState1 < cStates ; iState1++ ){
			dSum += adCorners[iState1] * adBelief[iState1];
		}
		
		return adCorners;
	}
	/*
	
	public static double[] computeVector( double[] adBelief ){
		double dV = f( adBelief ), dSlope = 0.0, dOffset = 0.0;
		int iState = 0, cStates = adBelief.length;
		double dSum = 0.0;
		double[] adCorners = new double[cStates];
		for( iState = 0 ; iState < cStates - 1 ; iState++ ){
			dSlope =  fPrime( adBelief, iState );
			dOffset = offset( adBelief[iState], dV, dSlope );
			adCorners[iState] = dOffset + dSlope;
			dSum += adCorners[iState] * adBelief[iState];
		}
		if( adBelief[iState] > 0 )
			adCorners[iState] = ( dV - dSum ) / adBelief[iState]; 
		else
			adCorners[iState] = -1;
		          
		dSum = 0.0;
		for( iState = 0 ; iState < cStates ; iState++ ){
			dSum += adCorners[iState] * adBelief[iState];
		}
		
		return adCorners;
	}
	public static double[] computeVector( double[] adBelief ){
		double dV1 = f( adBelief ), dV2 = 0.0, dSlope = 0.0;
		double dDeltaX = 0.01;
		int iState = 0, cStates = adBelief.length;
		double[] adCorners = new double[cStates];
		adBelief[cStates - 1] -= dDeltaX; 
		for( iState = 0 ; iState < cStates - 1 ; iState++ ){
			adBelief[iState] += dDeltaX;
			dV2 = f( adBelief ); 
			adBelief[iState] -= dDeltaX;
			dSlope = slope( dDeltaX, dV1, dV2 );
			adCorners[iState] = offset( adBelief[iState], dV1, dSlope );
		}
		adBelief[cStates - 1] += dDeltaX; 

		adBelief[0] -= dDeltaX;
		adBelief[iState] += dDeltaX;
		dV2 = f( adBelief ); 
		dSlope = slope( dDeltaX, dV1, dV2 );
		adCorners[iState] = offset( adBelief[iState], dV1, dSlope );	
		
		return adCorners;
	}
	*/
	public static double[] getDominatedVector( int cStates, RandomGenerator rnd ){
		double[] adValues = new double[cStates];
		double dMaxValue = Math.pow( 1.0 / cStates, 2.0 ) * cStates;
		for( int iState = 0 ; iState < cStates ; iState++ ){
			adValues[iState] = rnd.nextDouble( dMaxValue );
		}
		return adValues;
	}
	
	public static void main( String[] args ){
		int cStates = 2, iState = 0, iVector = 0, iMaxState = 0;
		int[] acVectors = { 10, 100, 1000 };
		double dMaxValue = 100.0, dMinValue = 0.0, dEpsilon = 0.0;
		double[] adMaxValues = new double[cStates];
		double[] adMinValues = new double[cStates];
		POMDP p = new RandomPOMDP( cStates, 2, 2 );
		RandomGenerator rnd = new RandomGenerator( "Random vectors" );
		boolean bRandomVector = false;
		double[] adDominatedPortion = new double[]{ 1.1, 1.5, 2, 5, 10 };
		
		LinearValueFunctionApproximation v = null;
		AlphaVector av = null;
		Vector<AlphaVector> vVectors = null;
		
		for( int cVectors : acVectors ){
			iVector = cVectors;
			for( iState = 0 ; iState < cStates ; iState++ ){
				adMaxValues[iState] = dMaxValue;
				adMinValues[iState] = dMinValue;
			}
			dEpsilon = ( dMaxValue - dMinValue ) / cVectors; 
			v = new LinearValueFunctionApproximation();
			while( iVector > 0 ){
				av = new TabularAlphaVector( null, 0.0, p );
				double[] adBelief = randomBelief( cStates, rnd );
				//adBelief[0] = ( 1.0 * iVector ) / cVectors;
				//adBelief[1] = 1 - adBelief[0];
				double[] adCorners = computeVector( adBelief );
				for( iState = 0 ; iState < cStates ; iState++ ){
					av.setValue( iState, adCorners[iState] );
				}
				/*
				iMaxState = rnd.nextInt( cStates );
				bRandomVector = false;//rnd.nextDouble() < 0.5;
				for( iState = 0 ; iState < cStates ; iState++ ){
					if( !bRandomVector ){
						if( iState == iMaxState ){
							av.setValue( iState, adMaxValues[iState] );
							adMaxValues[iState] -= rnd.nextDouble( dEpsilon );
						}
						else{
							av.setValue( iState, adMinValues[iState] );
							adMinValues[iState] += rnd.nextDouble( dEpsilon );					
						}
					}
					else{
						av.setValue( iState, rnd.nextDouble( dMaxValue / 2.0 ) );
					}
				}
				*/
				//System.out.println( av );
				//adCorners = computeVector( adBelief );
				if( !v.getVectors().contains( av ) ){
					iVector--;
					v.add( av );
				}
			}
			v.testAllPruningTechniques( p, true );
			
			for( double dPortion : adDominatedPortion ){
				iVector = (int)( cVectors * dPortion );
				while( v.size() < iVector ){
					av = new TabularAlphaVector( null, 0.0, p );
					double[] adCorners = getDominatedVector( cStates, rnd );
					for( iState = 0 ; iState < cStates ; iState++ ){
						av.setValue( iState, adCorners[iState] );
					}
					if( !v.getVectors().contains( av ) ){
						v.add( av );
					}
				}
				v.testAllPruningTechniques( p, true );
			}
			
			System.out.println( "Done |V| = " + cVectors );
		}
	}
}
