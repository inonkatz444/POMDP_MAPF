package pomdp.utilities.concurrent;

public class Lock {
	public Lock(){
		System.out.println( "Lock" );
	}
}
