package pomdp.utilities.skyline;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;
import java.util.Map.Entry;

import pomdp.utilities.AlphaVector;
import pomdp.utilities.ArrayComparator;
import pomdp.utilities.Logger;
import pomdp.utilities.Pair;
import pomdp.utilities.datastructures.LinkedList;
import pomdp.valuefunction.LinearValueFunctionApproximation;

public class SkylinePruning {
	private LinearValueFunctionApproximation m_vValueFunction;
	private LinkedList<EquationMatrixCreator> m_lOpenList;
	private Vector<int[]> m_vObservedNodes;
	private Vector<double[]> m_vObservedBeliefs;
	private int m_cStates;
	private int m_cProcessed;
	private int m_cMatrixes;
	private int m_cEquations;
	
	public SkylinePruning( LinearValueFunctionApproximation vValueFunction, int cStates ){
		//Logger.getInstance().log( "SkylinePruning", 0, "<init>", "Started initializing skyline" );
		m_vValueFunction = vValueFunction;
		m_lOpenList = new LinkedList<EquationMatrixCreator>();
		m_cStates = cStates;
		m_vObservedNodes = new Vector<int[]>();
		m_vObservedBeliefs = new Vector<double[]>();
		
		if( m_vValueFunction != null ){
			for( AlphaVector av : m_vValueFunction.getVectors() ){
				av.setDominated( true );
			}		
		}
		m_cProcessed = 0;
		
		Equation.m_cEquations = 0;
		Equation.m_cDeltaComputations = 0;
		EquationMatrix.m_cTimeInNextVertex = 0;
		EquationMatrix.m_cMatrixes = 0;
		//Logger.getInstance().log( "SkylinePruning", 0, "<init>", "Done initializing skyline" );
	}
	
	private void initCornerBeliefs( Vector<AlphaVector> vClean, Vector<AlphaVector> vDirty ){
		double dMaxValue = 0.0;
		boolean bAdd = false;
		AlphaVector avMax = null;
		for( int iState = 0 ; iState < m_cStates ; iState++ ){
			dMaxValue = Double.NEGATIVE_INFINITY;
			for( AlphaVector av : vDirty ){
				if( av.valueAt( iState ) > dMaxValue ){
					dMaxValue = av.valueAt( iState );
					avMax = av;
				}
			}
			//if( avMax.getId() == 8885 )
			//	System.out.println("***");
			bAdd = true;
			for( AlphaVector av : vClean ){
				if( av.valueAt( iState ) >= dMaxValue )
					bAdd = false;
			}
			if( bAdd ){
				vClean.add( avMax );
				vDirty.remove( avMax );
			}
		}			
	}
	

	private void removeVectorFromSkyline( Vector<EquationMatrix> vCorners, AlphaVector avRemove ){
		//System.out.println("Removing " + avRemove);
		for( EquationMatrix em : vCorners ){
			em.removeFromTreeRoot( avRemove );
		}
	}	
	private void addVectorToSkyline( Vector<EquationMatrix> vCorners, AlphaVector avAdd, 
			Vector<AlphaVector> vClean, Vector<AlphaVector> vDirty, EquationMatrix emLast ){
		//System.out.println("Adding " + avAdd);
		Vector<AlphaVector> vNonDominated = new Vector<AlphaVector>();
		for( EquationMatrix em : vCorners ){
			em.addToTreeRoot( avAdd, vNonDominated, emLast );
		}
		
		if( vNonDominated.size() == 0 ){
			System.out.println( "BUGBUG" );
		}
		
		/* We shouldn't throw anything away, because they have to have solid witness points, even if these points are not in any equation
		Vector<AlphaVector> vFiltered = new Vector<AlphaVector>();
		for( AlphaVector av : vClean ){
			if( vNonDominated.contains( av ) ){
				vFiltered.add( av );
			}
			else{
				vDirty.add( av );
				removeVectorFromSkyline( vCorners, av );
				//System.out.println("Removed " + av);
				if( av == null )
					System.out.println("BUGBUG");
			}
		}
		vClean.clear();
		for( AlphaVector av : vFiltered )
			vClean.add( av );
			*/
	}
	
	private EquationMatrix findMinEquation( int iVectorVariable, Vector<EquationMatrix> vObserved ){
		double dMinValue = Double.POSITIVE_INFINITY, dValue = 0.0;
		EquationMatrix emBest = null;
		Vector<EquationMatrix> vFiltered = new Vector<EquationMatrix>();
		for( EquationMatrix em : vObserved ){
			if( em.validate() ){
				vFiltered.add( em );
				dValue = em.valueOf( iVectorVariable );
				if( dValue < dMinValue ){
					dMinValue = dValue;
					emBest = em;
				}
			}
		}	
		vObserved.clear();
		vObserved.addAll( vFiltered );
		return emBest;
	}

	private EquationMatrix findWitness( int iVectorVariable, Vector<EquationMatrix> vObserved ){
		EquationMatrix emCurrent = findMinEquation( iVectorVariable, vObserved ), emLast = null;
		double dDelta = 0.0;
		while( emCurrent != null ){
			emLast = emCurrent;
			dDelta = emCurrent.valueOf( iVectorVariable );
			if( dDelta > 0.0 )
				emCurrent = emCurrent.nextVertex( iVectorVariable );
			else
				emCurrent = null;
			if( emCurrent != null ){
				m_cProcessed++;
				vObserved.add( emCurrent );
			}
			//double dValue = emCurrent.valueOf( iCurrentVectorVariable );
			if( m_cProcessed % 10000 == 0 )
				Logger.getInstance().logFull( "SkylinePruning", 0, "runIterativeSkyline", 
						"Done " + m_cProcessed + " vertexes. |L|=" + m_lOpenList.size() + 
						" #M=" + EquationMatrix.m_cMatrixes + 
						" #F=" + EquationMatrix.m_cFinalized + 
						" |O|=" + vObserved.size() + 
						//" Interior = " + cInterior + ", Exterior = " + cExterior +
						//" |Zmin| = " + cMinZeroBeleifStates 
						"" );
		}	
		return emLast;
	}
	
	public void runIterativeSkyline( Collection<AlphaVector> cVectors ){
		Logger.getInstance().log( "SkylinePruning", 0, "runIterativeSkyline", "Started running skyline" );
		EquationMatrix emCurrent = null, emLast = null;
		int iCurrentVectorVariable = -1;
		Vector<EquationMatrix> vObserved = new Vector<EquationMatrix>();
		Vector<Integer> vDominatedVectors = new Vector<Integer>();
		Vector<AlphaVector> vClean = new Vector<AlphaVector>(), vDirty = new Vector<AlphaVector>( cVectors );
		Vector<EquationMatrix> vCorners = new Vector<EquationMatrix>();
		Map<double[], EquationMatrix> mWitnesses = new TreeMap<double[], EquationMatrix>( ArrayComparator.getDoubleComparator() );
		for( AlphaVector av : cVectors )
			av.setDominated( true );
		long lStart = System.currentTimeMillis();
		try{
			EquationMatrix.m_cMatrixes = 0;
			EquationMatrix.m_cFinalized = 0;
			int cDominated = 0, cNonDomiated = 0, cIterations = 0;
			int cSteps = 0, cSumDominatedSteps = 0, cSumNonDominatedSteps = 0, iState = 0;
			double dDelta = 0.0;
			double dValue = 0.0, dMinValue = 0.0;
			long cTimeInFindingFirst = 0;
			double dMaxValue = 0.0;
			AlphaVector avMax = null, avCurrent = null;
			boolean bAdd = false;
			
			initCornerBeliefs( vClean, vDirty );
			
			for( iState = 0 ; iState < m_cStates ; iState++ ){				
				emCurrent = new EquationMatrix( vClean, m_cStates, iState, true );
				vObserved.add( emCurrent );
				vCorners.add( emCurrent );
				m_cProcessed++;
			}
			
			while( vDirty.size() > 0 ){
				avCurrent = vDirty.remove( 0 );
				
				if( avCurrent == null )
					System.out.println( "BUGBUG " );
				
				//if(avCurrent.getId() == 8885)
				//	System.out.println("***");
				
				//System.out.println( "Current: " + avCurrent );
				
				cSteps = 0;
				cIterations++;
				iState++;
				
				addVectorToSkyline( vCorners, avCurrent, vClean, vDirty, null );
				
				iCurrentVectorVariable = vCorners.elementAt( 0 ).getVariable( avCurrent );					
					
				emLast = findWitness( iCurrentVectorVariable, vObserved );
				dDelta = emLast.valueOf( iCurrentVectorVariable );
				
				if( dDelta > 0.0 ){
					removeVectorFromSkyline(vCorners, avCurrent );
					vDominatedVectors.add( iCurrentVectorVariable );
					cSumDominatedSteps += cSteps;
					cDominated++;
				}
				else{
					double[] adBelief = emLast.getBeliefState();
					
					if( mWitnesses.containsKey( adBelief ) ){
						EquationMatrix emPrevious = mWitnesses.get( adBelief );
						System.out.println( "BUGBUG" );
					}
					
					mWitnesses.put( adBelief, emLast );
					/*
					System.out.print("Witness point: ");
					for(double d : adBelief)
						System.out.print(d + ",");
					System.out.println();
					*/
					dMaxValue = avCurrent.dotProduct( adBelief );
					
					//System.out.println( "b*v=" + dMaxValue );
					avMax = avCurrent;
					for( AlphaVector av : vDirty ){
						if( av != null ){
							dValue = av.dotProduct( adBelief );
							if( dValue > dMaxValue + 0.001 ){
								dMaxValue = dValue;
								avMax = av;
							}
						}
					}
					//System.out.println( "b*v'=" + dMaxValue );
					
					if( avMax != avCurrent ){
						vDirty.add( avCurrent );
						vDirty.remove( avMax );
						if( avCurrent == null )
							System.out.println("BUGBUG");
						removeVectorFromSkyline( vCorners, avCurrent );
						addVectorToSkyline( vCorners, avMax, vClean, vDirty, emLast );
						if(emLast.validate())
							System.out.println("BUGBUG");
					}
					vClean.add( avMax );
					
					cSumNonDominatedSteps += cSteps;
					cNonDomiated++;
				}
			}
			
			for( AlphaVector av : cVectors ){
				if( vClean.contains( av ) )
					av.setDominated( false );
				else
					av.setDominated( true );
			}
			
			if( cDominated == 0 )
				cDominated = 1;
			if( cNonDomiated == 0 )
				cNonDomiated = 1;
			
			Logger.getInstance().logFull( 
					"SkylinePruning", 0, "runIterativeSkyline", 
					"Done " + m_cProcessed + " vertexes. " + 
					" iters " + cIterations +
					" #M=" + EquationMatrix.m_cMatrixes + 
					" #F=" + EquationMatrix.m_cFinalized + 
					" |O|=" + vObserved.size() + 
					" Delta " + Equation.m_cDeltaComputations +
					" Time in next " + EquationMatrix.m_cTimeInNextVertex +
					" avg dom=" + cSumDominatedSteps / cDominated +
					" avg non-dom=" + cSumNonDominatedSteps / cNonDomiated +
					" Time " + cTimeInFindingFirst +
					"" );
		}
		catch( Error e ){
			e.printStackTrace();
		}		
	}

	public void runSkylineWitness( boolean bSearchForClosestToSurface ){
		runSkylineWitness( m_vValueFunction.getVectors(), bSearchForClosestToSurface );
	}
	
	public void runSkylineWitness( Collection<AlphaVector> cVectors, boolean bSearchForClosestToSurface ){
		Logger.getInstance().log( "SkylinePruning", 0, "runSkylineWitness", "Started running skyline" );
		EquationMatrix emCurrent = null;
		int iCurrentVectorVariable = -1;
		Vector<EquationMatrix> vObserved = new Vector<EquationMatrix>(), vCorners = new Vector<EquationMatrix>();
		Vector<Integer> vDominatedVectors = new Vector<Integer>();
		Vector<AlphaVector> vDirty = new Vector<AlphaVector>();
		Map<AlphaVector,Pair<Double,EquationMatrix>> mBestMatrixes = new HashMap<AlphaVector,Pair<Double,EquationMatrix>>();
		for( AlphaVector av : cVectors )
			av.setDominated( true );
		long lStart = System.currentTimeMillis();
		try{
			EquationMatrix.m_cMatrixes = 0;
			EquationMatrix.m_cFinalized = 0;
			int cDominated = 0, cNonDomiated = 0, cIterations = 0;
			int cSteps = 0, cSumDominatedSteps = 0, cSumNonDominatedSteps = 0, iState = 0;
			double dDelta = 0.0;
			double dValue = 0.0, dBestValue = 0.0;
			long cTimeInFindingFirst = 0;
			Pair<Double,EquationMatrix> p = null;
			AlphaVector avCurrent = null;
						
			for( AlphaVector av : cVectors ){
				mBestMatrixes.put( av, new Pair<Double,EquationMatrix>( Double.POSITIVE_INFINITY, null ) );
			}
			
			for( iState = 0 ; iState < m_cStates ; iState++ ){
				emCurrent = new EquationMatrix( cVectors, m_cStates, iState, false );
				vObserved.add( emCurrent );
				vCorners.add ( emCurrent );
				for( AlphaVector av : cVectors ){
					dValue = emCurrent.valueOf( av );
					if( dValue == 0.0 ){
						mBestMatrixes.remove( av );
					}
					else{
						p = mBestMatrixes.get( av );
						if( p != null ){
							dBestValue = p.first();
							if( dValue < dBestValue ){
								p.setFirst( dValue );
								p.setSecond( emCurrent );
							}
						}
					}
				}
				m_cProcessed++;
			}
			
			while( mBestMatrixes.size() > 0 ){
				if( bSearchForClosestToSurface )
					dBestValue = Double.POSITIVE_INFINITY;
				else
					dBestValue = Double.NEGATIVE_INFINITY;
				for( Entry<AlphaVector, Pair<Double, EquationMatrix>> e : mBestMatrixes.entrySet() ){
					if( ( bSearchForClosestToSurface && ( e.getValue().first() < dBestValue ) ) ||
							( !bSearchForClosestToSurface && ( e.getValue().first() > dBestValue ) ) ){
						avCurrent = e.getKey();
						emCurrent = e.getValue().second();
						dBestValue = e.getValue().first();
					}
				}
				
				mBestMatrixes.remove( avCurrent );
				
					//System.out.println( emCurrent );
				iCurrentVectorVariable = emCurrent.getVariable( avCurrent );					
					
				dDelta = dBestValue;
				while( emCurrent != null && dDelta > 0.0 ){
					emCurrent = emCurrent.nextVertex( iCurrentVectorVariable );
					if( emCurrent != null ){
						dDelta = emCurrent.valueOf( iCurrentVectorVariable );
						m_cProcessed++;
						//vObserved.add( emCurrent );
						vDirty = new Vector<AlphaVector>( mBestMatrixes.keySet() );
						for( AlphaVector av : vDirty ){
							dValue = emCurrent.valueOf( av );
							if( dValue == 0.0 ){
								mBestMatrixes.remove( av );
							}
							else{
								p = mBestMatrixes.get( av );
								dBestValue = p.first();
								if( dValue < dBestValue ){
									p.setFirst( dValue );
									p.setSecond( emCurrent );
								}							
							}
						}							
					}
					//double dValue = emCurrent.valueOf( iCurrentVectorVariable );
					if( m_cProcessed % 10000 == 0 )
						Logger.getInstance().logFull( "SkylinePruning", 0, "runSkylineWitness", 
								"Done " + m_cProcessed + " vertexes. " + 
								" #M=" + EquationMatrix.m_cMatrixes + 
								" #F=" + EquationMatrix.m_cFinalized + 
								" |O|=" + vObserved.size() + 
								//" Interior = " + cInterior + ", Exterior = " + cExterior +
								//" |Zmin| = " + cMinZeroBeleifStates 
								"" );
				}
				if( dDelta > 0.0 ){
					//m_vValueFunction.remove( av );
					vDominatedVectors.add( iCurrentVectorVariable );
					cSumDominatedSteps += cSteps;
					cDominated++;
					avCurrent.setDominated( true );
					//for( EquationMatrix em : vCorners )
					//	em.removeFromTreeRoot( avCurrent );
				}
				else{					
					avCurrent.setDominated( false );
					cSumNonDominatedSteps += cSteps;
					cNonDomiated++;
				}
			}
			
			Logger.getInstance().logFull( 
					"SkylinePruning", 0, "runSkylineWitness", 
					"Done " + m_cProcessed + " vertexes. " + 
					" iters " + Equation.m_cEquations +
					" #M=" + EquationMatrix.m_cMatrixes + 
					//" avg dom=" + cSumDominatedSteps / cDominated +
					//" avg non-dom=" + cSumNonDominatedSteps / cNonDomiated +
					" Time " + cTimeInFindingFirst +
					"" );
		}
		catch( Error e ){
			e.printStackTrace();
		}		
	}

	
	
	public void runSkylineWitnessIV( Collection<AlphaVector> cVectors ){
		Logger.getInstance().log( "SkylinePruning", 0, "runSkylineWitness", "Started running skyline" );
		EquationMatrix emCurrent = null;
		int iCurrentVectorVariable = -1;
		Vector<EquationMatrix> vObserved = new Vector<EquationMatrix>(), vCorners = new Vector<EquationMatrix>();
		Vector<Integer> vDominatedVectors = new Vector<Integer>();
		for( AlphaVector av : cVectors )
			av.setDominated( true );
		long lStart = System.currentTimeMillis();
		try{
			EquationMatrix.m_cMatrixes = 0;
			EquationMatrix.m_cFinalized = 0;
			int cDominated = 0, cNonDomiated = 0, cIterations = 0;
			int cSteps = 0, cSumDominatedSteps = 0, cSumNonDominatedSteps = 0, iState = 0;
			double dDelta = 0.0;
			double dValue = 0.0, dMinValue = 0.0;
			long cTimeInFindingFirst = 0;
			
			for( iState = 0 ; iState < m_cStates ; iState++ ){
				emCurrent = new EquationMatrix( cVectors, m_cStates, iState, true );
				vObserved.add( emCurrent );
				vCorners.add ( emCurrent );
				m_cProcessed++;
			}
			
			for( AlphaVector av : cVectors ){
				if( av.isDominated() ){
					cSteps = 0;
					cIterations++;
					iState++;
					//System.out.println( emCurrent );
					iCurrentVectorVariable = vObserved.elementAt( 0 ).getVariable( av );					
					
					long lBefore = System.currentTimeMillis();
					dMinValue = Double.POSITIVE_INFINITY;
					for( EquationMatrix em : vObserved ){
						dValue = em.valueOf( iCurrentVectorVariable );
						if( dValue < dMinValue ){
							dMinValue = dValue;
							emCurrent = em;
						}
					}
					cTimeInFindingFirst += System.currentTimeMillis() - lBefore;
					
					//emCurrent.pruneEquations( vDominatedVectors );
					
					while( emCurrent != null ){
						dDelta = emCurrent.valueOf( iCurrentVectorVariable );
						if( dDelta > 0.0 )
							emCurrent = emCurrent.nextVertex( iCurrentVectorVariable );
						else
							emCurrent = null;
						if( emCurrent != null ){
							m_cProcessed++;
							vObserved.add( emCurrent );
						}
						cSteps++;
						//double dValue = emCurrent.valueOf( iCurrentVectorVariable );
						if( m_cProcessed % 10000 == 0 )
							Logger.getInstance().logFull( "SkylinePruning", 0, "runSkylineWitness", 
									"Done " + m_cProcessed + " vertexes. |L|=" + m_lOpenList.size() + 
									" #M=" + EquationMatrix.m_cMatrixes + 
									" #F=" + EquationMatrix.m_cFinalized + 
									" |O|=" + vObserved.size() + 
									//" Interior = " + cInterior + ", Exterior = " + cExterior +
									//" |Zmin| = " + cMinZeroBeleifStates 
									"" );
					}
					if( dDelta > 0.0 ){
						//m_vValueFunction.remove( av );
						vDominatedVectors.add( iCurrentVectorVariable );
						cSumDominatedSteps += cSteps;
						cDominated++;
						av.setDominated( true );
						for( EquationMatrix em : vCorners )
							em.removeFromTreeRoot( av );
					}
					else{
						av.setDominated( false );
						cSumNonDominatedSteps += cSteps;
						cNonDomiated++;
					}
				}
			}
			
			if( cDominated == 0 )
				cDominated = 1;
			if( cNonDomiated == 0 )
				cNonDomiated = 1;
			
			Logger.getInstance().logFull( 
					"SkylinePruning", 0, "runSkylineWitness", 
					"Done " + m_cProcessed + " vertexes. " + 
					" iters " + cIterations +
					" #M=" + EquationMatrix.m_cMatrixes + 
					" #F=" + EquationMatrix.m_cFinalized + 
					" |O|=" + vObserved.size() + 
					" Delta " + Equation.m_cDeltaComputations +
					" Time in next " + EquationMatrix.m_cTimeInNextVertex +
					" avg dom=" + cSumDominatedSteps / cDominated +
					" avg non-dom=" + cSumNonDominatedSteps / cNonDomiated +
					" Time " + cTimeInFindingFirst +
					"" );
		}
		catch( Error e ){
			e.printStackTrace();
		}		
	}

	
	
	public void runIterativeSkyline(){
		runIterativeSkyline( m_vValueFunction.getVectors() );
	}

	
	public void runSkylineWitnessIII(){
		Logger.getInstance().log( "SkylinePruning", 0, "runSkylineWitness", "Started running skyline" );
		EquationMatrix emCurrent = null, emPrevious = null;;
		int iCurrentVectorVariable = -1;
		try{
			EquationMatrix.m_cMatrixes = 0;
			EquationMatrix.m_cFinalized = 0;
			int cDominated = 0, cNonDomiated = 0, cIterations = 0;
			int cSteps = 0, cSumDominatedSteps = 0, cSumNonDominatedSteps = 0, iState = 0;
			double dDelta = 0.0;
			
			EquationMatrix emRoot = new EquationMatrix( m_vValueFunction.getVectors(), m_cStates, iState, true );
			m_vObservedNodes.add( emRoot.getRHSVariables() );
			
			for( AlphaVector av : m_vValueFunction.getVectors() ){
				if( av.isDominated() ){
					cSteps = 0;
					cIterations++;
					emCurrent = emRoot;
					iState++;
					//System.out.println( emCurrent );
					iCurrentVectorVariable = emCurrent.getVariable( av );
					while( emCurrent != null ){
						m_cProcessed++;
						dDelta = emCurrent.valueOf( iCurrentVectorVariable );
						emPrevious = emCurrent;
						emCurrent = emCurrent.nextVertex( iCurrentVectorVariable );
						if( emCurrent != null ){
							int[] aFunctions = emCurrent.getRHSVariables();
							if( !EquationMatrix.exists( aFunctions, m_vObservedNodes ) ){
								m_vObservedNodes.add( aFunctions );
								//m_vObservedBeliefs.add( emCurrent.getBeliefState() );
							}
						}
						cSteps++;
						//double dValue = emCurrent.valueOf( iCurrentVectorVariable );
						if( m_cProcessed % 1000 == 0 )
							Logger.getInstance().logFull( "SkylinePruning", 0, "runSkylineWitness", 
									"Done " + m_cProcessed + " vertexes. |L|=" + m_lOpenList.size() + 
									" #M=" + EquationMatrix.m_cMatrixes + 
									" #F=" + EquationMatrix.m_cFinalized + 
									" |O|=" + m_vObservedNodes.size() + 
									//" Interior = " + cInterior + ", Exterior = " + cExterior +
									//" |Zmin| = " + cMinZeroBeleifStates 
									"" );
					}
					if( dDelta > 0.0 ){
						m_vValueFunction.remove( av );
						cSumDominatedSteps += cSteps;
						cDominated++;
					}
					else{
						av.setDominated( false );
						cSumNonDominatedSteps += cSteps;
						cNonDomiated++;
					}
				}
			}
			
			if( cDominated == 0 )
				cDominated = 1;
			if( cNonDomiated == 0 )
				cNonDomiated = 1;
			
			Logger.getInstance().logFull( 
					"SkylinePruning", 0, "runSkylineWitness", 
					"Done " + m_cProcessed + " vertexes. " + 
					" iters " + cIterations +
					" #M=" + EquationMatrix.m_cMatrixes + 
					" #F=" + EquationMatrix.m_cFinalized + 
					" |O|=" + m_vObservedNodes.size() + 
					" avg dom=" + cSumDominatedSteps / cDominated +
					" avg non-dom=" + cSumNonDominatedSteps / cNonDomiated +
					"" );
		}
		catch( Error e ){
			e.printStackTrace();
		}
		
	}
	
	public void runSkylineWitnessII(){
		Logger.getInstance().log( "SkylinePruning", 0, "runSkylineWitness", "Started running skyline" );
		EquationMatrix emCurrent = null, emPrevious = null;;
		int iCurrentVectorVariable = -1;
		try{
			EquationMatrix.m_cMatrixes = 0;
			EquationMatrix.m_cFinalized = 0;
			int cDominated = 0, cNonDomiated = 0, cIterations = 0;
			int cSteps = 0, cSumDominatedSteps = 0, cSumNonDominatedSteps = 0, iState = 0;
			double dDelta = 0.0;
			for( AlphaVector av : m_vValueFunction.getVectors() ){
				if( av.isDominated() ){
					cSteps = 0;
					cIterations++;
					emCurrent = new EquationMatrix( m_vValueFunction.getVectors(), m_cStates, iState );
					iState++;
					//System.out.println( emCurrent );
					iCurrentVectorVariable = emCurrent.getVariable( av );
					m_vObservedNodes.add( emCurrent.getIntersectingFunctions() );
					m_vObservedBeliefs.add( emCurrent.getBeliefState() );
					while( emCurrent != null ){
						m_cProcessed++;
						dDelta = emCurrent.valueOf( iCurrentVectorVariable );
						emPrevious = emCurrent;
						emCurrent = emCurrent.nextVertex( iCurrentVectorVariable );
						cSteps++;
						//double dValue = emCurrent.valueOf( iCurrentVectorVariable );
						if( m_cProcessed % 1000 == 0 )
							Logger.getInstance().logFull( "SkylinePruning", 0, "runSkylineWitness", 
									"Done " + m_cProcessed + " vertexes. |L|=" + m_lOpenList.size() + 
									" #M=" + EquationMatrix.m_cMatrixes + 
									" #F=" + EquationMatrix.m_cFinalized + 
									" |O|=" + m_vObservedNodes.size() + 
									//" Interior = " + cInterior + ", Exterior = " + cExterior +
									//" |Zmin| = " + cMinZeroBeleifStates 
									"" );
					}
					if( dDelta > 0.0 ){
						m_vValueFunction.remove( av );
						cSumDominatedSteps += cSteps;
						cDominated++;
					}
					else{
						av.setDominated( false );
						cSumNonDominatedSteps += cSteps;
						cNonDomiated++;
					}
				}
			}
			
			if( cDominated == 0 )
				cDominated = 1;
			if( cNonDomiated == 0 )
				cNonDomiated = 1;
			
			Logger.getInstance().logFull( 
					"SkylinePruning", 0, "runSkylineWitness", 
					"Done " + m_cProcessed + " vertexes. " + 
					" iters " + cIterations +
					" avg dom=" + cSumDominatedSteps / cDominated +
					" avg non-dom=" + cSumNonDominatedSteps / cNonDomiated +
					"" );
		}
		catch( Error e ){
			e.printStackTrace();
		}
		
	}
	
	public void runWitness(){
		Logger.getInstance().log( "SkylinePruning", 0, "runWitness", "Started running skyline" );
		EquationMatrix emCurrent = null;
		int iCurrentVectorVariable = -1;
		try{
			EquationMatrix.m_cMatrixes = 0;
			EquationMatrix.m_cFinalized = 0;
			int cDominated = 0, cNonDomiated = 0, cIterations = 0;
			int cSteps = 0, cSumDominatedSteps = 0, cSumNonDominatedSteps = 0, iState = 0, iDeterministicState = -1;
			double dDelta = 0.0;
			double dMaxDifference = 0.0, dDifference = 0.0;
			for( AlphaVector av : m_vValueFunction.getVectors() ){
				if( true ){
					dMaxDifference = 0.0;
					for( AlphaVector avTag : m_vValueFunction.getVectors() ){
						if( av != avTag ){
							for( iState = 0 ; iState < m_cStates ; iState++ ){
								dDifference = av.valueAt( iState ) - avTag.valueAt( iState );
								//dDifference = avTag.valueAt( iState ) - av.valueAt( iState );
								if( dDifference > dMaxDifference ){
									dMaxDifference = dDifference;
									iDeterministicState = iState;
								}
							}
						}
					}	
					//dMaxDifference = 0.0;
					cSteps = 0;
					cIterations++;
					emCurrent = new EquationMatrix( m_vValueFunction.getVectors(), m_cStates, iDeterministicState, av, dMaxDifference );
					//System.out.println( emCurrent );
					iCurrentVectorVariable = emCurrent.getVariable( av );
					m_vObservedNodes.add( emCurrent.getIntersectingFunctions() );
					m_vObservedBeliefs.add( emCurrent.getBeliefState() );
					while( emCurrent != null ){
						m_cProcessed++;
						dDelta = emCurrent.valueOf( iCurrentVectorVariable );
						emCurrent = emCurrent.nextVertex( iCurrentVectorVariable );
						cSteps++;
						//double dValue = emCurrent.valueOf( iCurrentVectorVariable );
						if( m_cProcessed % 1000 == 0 )
							Logger.getInstance().logFull( "SkylinePruning", 0, "runWitness", 
									"Done " + m_cProcessed + " vertexes. |L|=" + m_lOpenList.size() + 
									" #M=" + EquationMatrix.m_cMatrixes + 
									" #F=" + EquationMatrix.m_cFinalized + 
									" |O|=" + m_vObservedNodes.size() + 
									//" Interior = " + cInterior + ", Exterior = " + cExterior +
									//" |Zmin| = " + cMinZeroBeleifStates 
									"" );
					}
					if( dDelta > dMaxDifference ){
						//m_vValueFunction.remove( av );
						av.setDominated( true );
						cSumDominatedSteps += cSteps;
						cDominated++;
					}
					else{
						av.setDominated( false );
						cSumNonDominatedSteps += cSteps;
						cNonDomiated++;
					}
				}
			}
			
			if( cDominated == 0 )
				cDominated = 1;
			if( cNonDomiated == 0 )
				cNonDomiated = 1;
			
			Logger.getInstance().logFull( 
					"SkylinePruning", 0, "runWitness", 
					"Done " + m_cProcessed + " vertexes. " + 
					" iters " + cIterations +
					" avg dom=" + cSumDominatedSteps / cDominated +
					" avg non-dom=" + cSumNonDominatedSteps / cNonDomiated +
					"" );
		}
		catch( Error e ){
			e.printStackTrace();
		}
		
	}
	
	public double[] findWitness( Collection<AlphaVector> cVectors, AlphaVector avSearchVector ){
		EquationMatrix emCurrent = null;
		int iCurrentVectorVariable = -1;

		int cSteps = 0, iState = 0, iDeterministicState = -1;
		double dDelta = 0.0;
		double dMaxDifference = 0.0, dDifference = 0.0;
		double[] adBeliefState = null;
		dMaxDifference = Double.NEGATIVE_INFINITY;
		for( AlphaVector avTag : cVectors ){
			if( avSearchVector != avTag ){
				for( iState = 0 ; iState < m_cStates ; iState++ ){
					dDifference = avSearchVector.valueAt( iState ) - avTag.valueAt( iState );
					if( dDifference > dMaxDifference ){
						dMaxDifference = dDifference;
						iDeterministicState = iState;
					}
				}
			}
		}	
		cSteps = 0;
		emCurrent = new EquationMatrix( cVectors, m_cStates, iDeterministicState, avSearchVector, dMaxDifference );
		//System.out.println( emCurrent );
		iCurrentVectorVariable = emCurrent.getVariable( avSearchVector );
		m_vObservedNodes.add( emCurrent.getIntersectingFunctions() );
		m_vObservedBeliefs.add( emCurrent.getBeliefState() );
		while( emCurrent != null ){
			dDelta = emCurrent.valueOf( iCurrentVectorVariable );
			adBeliefState = emCurrent.getBeliefState();
			emCurrent = emCurrent.nextVertex( iCurrentVectorVariable );
			m_cProcessed++;
			cSteps++;
		}
		/*
		if( avSearchVector.getId() == 693 ){
			findWitness( cVectors, avSearchVector );
		}
		*/
		
		//not sure about this, but it seems that a negative or zero delta means that the vector never breaks the skyline
		if( dDelta <= 0.0 )
			return null;

		if( dDelta > dMaxDifference ){
			return null;
		}
		else{
			return adBeliefState;
		}
	}
	
	public void runSkylineaCahceNodes(){
		Logger.getInstance().log( "SkylinePruning", 0, "run", "Started running skyline" );
		EquationMatrixCreator emcCurrent = null;
		EquationMatrix emCurrent = null;
		LinkedList<EquationMatrix> lStartMatrixes = new LinkedList<EquationMatrix>();
		int cProcessed = 0, cInterior = 0, cExterior = 0, cMinZeroBeleifStates = 10000, iState = 0;
		boolean bDone = false;
		try{
			EquationMatrix.m_cMatrixes = 0;
			EquationMatrix.m_cFinalized = 0;
			for( iState = 0 ; iState < m_cStates ; iState++ ){
				emCurrent = new EquationMatrix( m_vValueFunction.getVectors(), m_cStates, iState );
				m_vObservedNodes.add( emCurrent.getIntersectingFunctions() );
				m_vObservedBeliefs.add( emCurrent.getBeliefState() );
				lStartMatrixes.add( emCurrent );
				cProcessed++;
			}
			for( EquationMatrix em : lStartMatrixes ){
				for( EquationMatrixCreator emc : em.lazyNeighbors( m_vObservedNodes, m_vObservedBeliefs ) )
					m_lOpenList.addSorted( emc, EquationMatrixCreatorComparator.getInstance() );				
			}
			while( m_lOpenList.size() > 0 && !bDone ){
				emcCurrent = m_lOpenList.removeFirst();
				if( emcCurrent.getZeroBeliefStates() < cMinZeroBeleifStates )
					cMinZeroBeleifStates = emcCurrent.getZeroBeliefStates();
				emCurrent = emcCurrent.getMatrix();
				if( emCurrent != null ){
					if( emCurrent.isInteriorPoint() )
						cInterior++;
					else
						cExterior++;
					cProcessed++;
					for( EquationMatrixCreator emcNeighbor : emCurrent.lazyNeighbors( m_vObservedNodes, m_vObservedBeliefs ) ){
						m_lOpenList.addSorted( emcNeighbor, EquationMatrixCreatorComparator.getInstance() );
					}
					if( cProcessed % 1000 == 0 ){
						Logger.getInstance().logFull( "SkylinePruning", 0, "run", 
								"Done " + cProcessed + " vertexes. |L|=" + m_lOpenList.size() + 
								" #M=" + EquationMatrix.m_cMatrixes + 
								" #F=" + EquationMatrix.m_cFinalized + 
								" |O|=" + m_vObservedNodes.size() + 
								//" Interior = " + cInterior + ", Exterior = " + cExterior +
								//" |Zmin| = " + cMinZeroBeleifStates 
								"" );
						bDone = true;
						for( AlphaVector av : m_vValueFunction.getVectors() ){
							if( !av.isDominated() ){
								bDone = false;
							}
						}

					}
				}
			}
			int cSumVertexes = 0, cMaxVertexes = 0, cVectors = 0;
			for( AlphaVector av : m_vValueFunction.getVectors() ){
				if( !av.isDominated() ){
					cVectors++;
					cSumVertexes += av.getWitnesses().size();
					if( av.getWitnesses().size()  > cMaxVertexes ){
						cMaxVertexes = av.getWitnesses().size();
					}
				}
			}
			
			Logger.getInstance().logFull( "SkylinePruning", 0, "run", 
					"Done " + cProcessed + " vertexes. " + 
					" #M=" + EquationMatrix.m_cMatrixes + 
					" |O|=" + m_vObservedNodes.size() + 
					" avg(|W|)=" + cSumVertexes / ( 1.0 * cVectors ) +
					" max(|W|)=" + cMaxVertexes +
					"");
		}
		catch(Error e){
			e.printStackTrace();
		}
	}
	
	
	public void runSkyline( boolean bPruneEdges ){
		Logger.getInstance().log( "SkylinePruning", 0, "run", "Started running skyline" );
		EquationMatrix emCurrent = null;
		LinkedList<EquationMatrix> lOpenList = new LinkedList<EquationMatrix>();
		SortedSet<int[]> sObservedEdges = null;
		SortedSet<int[]> sObservedNodes = new TreeSet<int[]>( ArrayComparator.getIntComparator() );
		if( bPruneEdges )
			sObservedEdges = new TreeSet<int[]>( ArrayComparator.getIntComparator() );

		int cProcessed = 0, iState = 0;
		try{
			EquationMatrix.m_cMatrixes = 0;
			EquationMatrix.m_cFinalized = 0;
			
			for( iState = 0 ; iState < m_cStates ; iState++ ){
				emCurrent = new EquationMatrix( m_vValueFunction.getVectors(), m_cStates, iState );
				emCurrent.initOutgoingEdges( sObservedEdges );
				if( sObservedEdges != null )
					sObservedNodes.add( emCurrent.getRHSVariables() );
				lOpenList.add( emCurrent );
				cProcessed++;
			}
			
			while( lOpenList.size() > 0 ){
				emCurrent = lOpenList.removeFirst();
				//System.out.println( emCurrent );
				if( emCurrent != null ){
					cProcessed++;
					for( EquationMatrix emNeighbor : emCurrent.getNeighbors( sObservedEdges, sObservedNodes ) ){
						lOpenList.add( emNeighbor );
					}
					if( cProcessed % 1000 == 0 )
						Logger.getInstance().logFull( "SkylinePruning", 0, "run", 
								"Done " + cProcessed + " vertexes. |L|=" + lOpenList.size() + 
								" #M=" + EquationMatrix.m_cMatrixes + 
								" #F=" + EquationMatrix.m_cFinalized + 
								" |E|=" + ( sObservedEdges == null ? 0 : sObservedEdges.size() ) + 
								" |N|=" + sObservedNodes.size() + 
								//" Interior = " + cInterior + ", Exterior = " + cExterior +
								//" |Zmin| = " + cMinZeroBeleifStates 
								"" );
				}
			}
			int cSumVertexes = 0, cMaxVertexes = 0, cVectors = 0;
			for( AlphaVector av : m_vValueFunction.getVectors() ){
				if( !av.isDominated() ){
					cVectors++;
					cSumVertexes += av.getWitnesses().size();
					if( av.getWitnesses().size()  > cMaxVertexes ){
						cMaxVertexes = av.getWitnesses().size();
					}
				}
			}
			
			Logger.getInstance().logFull( "SkylinePruning", 0, "run", 
					"Done " + cProcessed + " vertexes. " + 
					" #M=" + EquationMatrix.m_cMatrixes + 
					" |O|=" + m_vObservedNodes.size() + 
					" avg(|W|)=" + cSumVertexes / ( 1.0 * cVectors ) +
					" max(|W|)=" + cMaxVertexes +
					"");
		}
		catch(Error e){
			e.printStackTrace();
		}
	}
	
	public int getMatrixCount(){
		return EquationMatrix.m_cMatrixes;
	}
	
	public int getEquationsCount(){
		return Equation.m_cEquations;
	}
	
}
