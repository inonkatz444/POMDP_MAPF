package pomdp.utilities.skyline;

import java.util.*;

import pomdp.utilities.AlphaVector;
import pomdp.utilities.Logger;

public class Skyline {
	private Vector<EquationMatrix> m_vObserved;
	private EquationMatrix[] m_aCorners;
	private int m_cStates;
	private boolean m_bReinsertedRemovedVectors = true, m_bSingleCorner = false;
	private Vector<AlphaVector> m_vSkylineVectors;
	
	public Skyline( int cStates ){
		m_cStates = cStates;
	}
	
	public int getSkylineSize(){
		return m_vSkylineVectors.size();
	}
	
	public Vector<AlphaVector> init( Collection<AlphaVector> cVectors ){
		Logger.getInstance().log( "Skyline", 0, "init", "Initializing the Skyline with " + cVectors.size() + " vectors" );
		m_aCorners = new EquationMatrix[m_cStates];
		m_vObserved = new Vector<EquationMatrix>();
		int iState = 0, iCurrentVectorVariable = 0;
		EquationMatrix emCorner = null, emCurrent = null;
		Vector<AlphaVector> vDominated = new Vector<AlphaVector>();
		for( iState = 0 ; iState < m_cStates ; iState++ ){
			emCorner = new EquationMatrix( cVectors, m_cStates, iState, true );
			m_aCorners[iState] = emCorner;
			m_vObserved.add( emCorner );
			if( m_bSingleCorner )
				break;
		}
		m_vSkylineVectors = new Vector<AlphaVector>();
		for( AlphaVector avCurrent : cVectors ){
			emCurrent = findWitness( avCurrent );
			if( emCurrent == null ){
				removeVectorFromSkyline( avCurrent );
				vDominated.add( avCurrent );
			}
			else{
				m_vSkylineVectors.add( avCurrent );
			}
		}
		return vDominated;
	}

	public boolean isNonDominated( AlphaVector av ){
		return m_vSkylineVectors.contains( av );
	}
	
	private Vector<AlphaVector> updateCorners( AlphaVector avNew ){
		int iState = 0;
		double dMaxValue = 0.0;
		Vector<Integer> vCorners = new Vector<Integer>();
		for( iState = 0 ; iState < m_cStates ; iState++ ){
			dMaxValue = Double.NEGATIVE_INFINITY;
			for( AlphaVector av : m_vSkylineVectors ){
				if( av.valueAt( iState ) > dMaxValue ){
					dMaxValue = av.valueAt( iState );
				}
			}
			if( avNew.valueAt( iState ) > dMaxValue ){
				vCorners.add( iState );
			}
			if( m_bSingleCorner )
				break;
		}
		if( vCorners.size() > 0 ){
			boolean bAllNull = true;
			for( iState = 0 ; iState < m_cStates ; iState++ ){
				if( m_aCorners[iState] != null ){
					if( vCorners.contains( iState ) )
						m_aCorners[iState] = null;
					else
						bAllNull = false;
				}
			}			
			if( bAllNull ){
				//TODO: fix corners gracefully. Problem - need to maintain slack variables mapping across matrixes
				System.out.println( "Need to initialize with corners " + vCorners );
				m_vSkylineVectors.add( avNew );
				return init( m_vSkylineVectors );
			}
		}
		return null;
	}
	
	private Vector<AlphaVector> prunePointwiseDominated( AlphaVector avNew ){
		Vector<AlphaVector> vDominated = new Vector<AlphaVector>();
		for( AlphaVector av : m_vSkylineVectors ){
			if( avNew.dominates( av ) ){
				vDominated.add( av );
				removeVectorFromSkyline( av );
			}
		}
		for( AlphaVector av : vDominated )
			m_vSkylineVectors.remove( av );
		return vDominated;
	}
	
	public Vector<AlphaVector> addNewVector( AlphaVector avNew ){
		Vector<AlphaVector> vDominated = updateCorners( avNew );
		if( vDominated == null ){
			vDominated = prunePointwiseDominated( avNew );
			Vector<AlphaVector> vNonDominated = addVectorToSkyline( avNew );
			Vector<AlphaVector> vInsert = new Vector<AlphaVector>();
			
			EquationMatrix em = null;
			vInsert.add( avNew );
			for( AlphaVector av : m_vSkylineVectors ){
				if( !vNonDominated.contains( av ) ){
					if( m_bReinsertedRemovedVectors )
						vInsert.add( av );			
					else{
						vDominated.add( av );
						removeVectorFromSkyline( av );
					}
				}				
			}
			m_vSkylineVectors.add( avNew );
			for( AlphaVector av : vInsert ){
				em = findWitness( av );
				if( em == null ){
					m_vSkylineVectors.remove( av );
					vDominated.add( av );
					removeVectorFromSkyline( av );
				}
			}
		}
		return vDominated;
	}
	
	private void removeVectorFromSkyline( AlphaVector avRemove ){
		for( EquationMatrix em : m_aCorners ){
			if( em != null )
				em.removeFromTreeRoot( avRemove );
		}
	}	
	
	private void cleanObserved(){
		Vector<EquationMatrix> vClean = new Vector<EquationMatrix>();
		for( EquationMatrix em : m_vObserved ){
			if( em.validate() )
				vClean.add( em );
		}
		m_vObserved = vClean;
	}
	
	private Vector<AlphaVector> addVectorToSkyline( AlphaVector avAdd ){
		Vector<AlphaVector> vNonDominated = new Vector<AlphaVector>();
		for( EquationMatrix em : m_aCorners ){
			if( em != null )
				em.addToTreeRoot( avAdd, vNonDominated, null );
		}

		cleanObserved();
		
		if( vNonDominated.size() == 0 ){
			System.out.println( "BUGBUG" );
		}
		
		return vNonDominated;
	}
	
	private EquationMatrix findMinEquation( int iVectorVariable ){
		double dMinValue = Double.POSITIVE_INFINITY, dValue = 0.0;
		EquationMatrix emBest = null;
		for( EquationMatrix em : m_vObserved ){
			if( em.validate() ){
				dValue = em.valueOf( iVectorVariable );
				if( dValue < dMinValue ){
					dMinValue = dValue;
					emBest = em;
				}
			}
		}	
		return emBest;
	}
	

	private EquationMatrix findWitness( AlphaVector av ){
		int iVectorVariable = -1; 
		for( EquationMatrix em : m_aCorners ){
			if( em != null )
				iVectorVariable = em.getVariable( av );	
		}
		EquationMatrix emCurrent = findMinEquation( iVectorVariable ), emLast = null;
		double dDelta = 0.0;

		while( emCurrent != null ){
			emLast = emCurrent;
			dDelta = emCurrent.valueOf( iVectorVariable );
			if( dDelta > 0.0 )
				emCurrent = emCurrent.nextVertex( iVectorVariable );
			else
				emCurrent = null;
			if( emCurrent != null ){
				m_vObserved.add( emCurrent );
			}
		}	
		dDelta = emLast.valueOf( iVectorVariable );
		if( dDelta == 0.0 )
			return emLast;
		return null;
	}
	


}
