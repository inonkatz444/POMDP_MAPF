package pomdp.environments;

import pomdp.utilities.BeliefStateFactory;
import pomdp.utilities.SparseTabularFunction;
import pomdp.utilities.datastructures.Function;
import pomdp.utilities.datastructures.TabularFunction;

public class RandomPOMDP extends POMDP {
	public RandomPOMDP( int cStates, int cActions, int cObservations ){
		super();
		m_cStates = cStates;
		m_cActions = cActions;
		m_cObservations = cObservations;
		init();
		m_bsFactory = new BeliefStateFactory( this );
	}

	private void init() {
		m_rndGenerator.init( 0 );
		
		m_fTransition = new SparseTabularFunction(new int[]{m_cStates, m_cActions, m_cStates});
		m_fObservation = new SparseTabularFunction(new int[]{m_cActions, m_cStates, m_cObservations});
		m_fReward = new SparseTabularFunction(new int[]{m_cStates, m_cActions});
		m_adMinActionRewards = new double[m_cActions];
		
		int iStartState = 0, iAction = 0, iEndState = 0, iOffset = 0, iObservation = 0;
		double dProb = 0.0, dRemainingProb = 0.0, dReward = 0.0;
		
		for( iAction = 0 ; iAction < m_cActions ; iAction++ ){
			m_adMinActionRewards[iAction] = Double.POSITIVE_INFINITY;
		}
		
		for( iStartState = 0 ; iStartState < m_cStates ; iStartState++ ){
			for( iAction = 0 ; iAction < m_cActions ; iAction++ ){
				dRemainingProb = 1.0;
				iOffset = m_rndGenerator.nextInt( m_cStates );
				dReward = m_rndGenerator.nextInt( m_cStates );
				setReward( iStartState, iAction, dReward );
				if( m_adMinActionRewards[iAction] > dReward ){
					m_adMinActionRewards[iAction] = dReward;
				}
				for( iEndState = 0 ; iEndState < m_cStates - 1 ; iEndState++ ){
					dProb = m_rndGenerator.nextDouble( dRemainingProb );
					dRemainingProb = dRemainingProb - dProb;
					setTransition( iStartState, iAction, ( iOffset + iEndState ) % m_cStates, dProb );
				}
				setTransition( iStartState, iAction, ( iOffset + iEndState ) % m_cStates, dRemainingProb );
			}
		}
		for( iAction = 0 ; iAction < m_cActions ; iAction++ ){
			for( iEndState = 0 ; iEndState < m_cStates ; iEndState++ ){
				dRemainingProb = 1.0;
				iOffset = m_rndGenerator.nextInt( m_cObservations );
				for( iObservation = 0 ; iObservation < m_cObservations - 1 ; iObservation++ ){				
					dProb = m_rndGenerator.nextDouble( dRemainingProb );
					dRemainingProb = dRemainingProb - dProb;
					setObservation( iAction, iEndState, ( iOffset + iObservation ) % m_cObservations, dProb );
				}
				setObservation( iAction, iEndState, ( iOffset + iObservation ) % m_cObservations, dRemainingProb );
			}
		}
	}
	
	public boolean isTerminalState( int iState ){
		return false;
	}
	public boolean terminalStatesDefined(){
		return true;
	}
	
	public double probStartState( int iState ){
		return 1.0 / m_cStates;
	}
	
	public String getName(){
		return "RandomPOMDP" + m_cStates + "X" + m_cActions + "X" + m_cObservations;
	}

}
