package pomdp.environments;

import pomdp.utilities.BeliefStateFactory;
import pomdp.utilities.SparseTabularFunction;

public class FloatReset extends POMDP {
	
	public FloatReset( int cStates ){
		super();
		m_cStates = cStates;
		m_cActions = 3;
		m_cObservations = m_cStates;
		init();
		m_bsFactory = new BeliefStateFactory( this );
	}

	public String getName(){
		return "FloatReset" + m_cStates;
	}
	
	private void init() {
		m_rndGenerator.init( 0 );
		
		m_fTransition = new SparseTabularFunction(new int[]{m_cStates, m_cActions, m_cStates});
		m_fObservation = new SparseTabularFunction(new int[]{m_cActions, m_cStates, m_cObservations});
		m_fReward = new SparseTabularFunction(new int[]{m_cStates, m_cActions});
		m_adMinActionRewards = new double[m_cActions];
		
		int iStartState = 0, iAction = 0, iEndState = 0, iObservation = 0;
		double dLeftProb = 0.0, dRightProb = 0.0;
		
		m_adMinActionRewards[0] = 0.0;
		m_adMinActionRewards[1] = 0.0;
		m_adMinActionRewards[2] = -10.0;
		
		setTransition( iStartState, 0, 0 , 1.0 );
		for( iStartState = 0 ; iStartState < m_cStates ; iStartState++ ){
			dLeftProb = 1.0;
			dRightProb = 1.0;
			if( iStartState > 0 ){
				setTransition( iStartState, 0, iStartState - 1 , 0.25 );
				dLeftProb -= .25;
				setTransition( iStartState, 1, iStartState - 1 , 0.45 );
				dRightProb -= .45;
			}
			if( iStartState < m_cStates - 1 ){
				setTransition( iStartState, 0, iStartState + 1 , 0.45 );
				dLeftProb -= .45;
				setTransition( iStartState, 1, iStartState + 1 , 0.25 );
				dRightProb -= .25;
			}
			setTransition( iStartState, 0, iStartState , dLeftProb );
			setTransition( iStartState, 1, iStartState , dRightProb );
			setReward( iStartState, 0, 0.0 );
			setReward( iStartState, 1, 0.0 );
			
			setTransition( iStartState, 2, 0 , 0.5 );
			setTransition( iStartState, 2, m_cStates - 1 , 0.5 );
			setReward( iStartState, 1, -25.0 );
		}
		setReward( m_cStates / 2, 1, 100.0 );
		
		double[] adObservations = new double[m_cObservations];
		double dNormalizationFactor = 0.0;
		for( iAction = 0 ; iAction < m_cActions ; iAction++ ){
			for( iEndState = 0 ; iEndState < m_cStates ; iEndState++ ){
				dNormalizationFactor = 0.0;
				for( iObservation = 0 ; iObservation < m_cObservations ; iObservation++ ){		
					adObservations[iObservation] = m_cStates - Math.abs( iEndState - iObservation );
					dNormalizationFactor += adObservations[iObservation];
				}
				for( iObservation = 0 ; iObservation < m_cObservations ; iObservation++ ){				
					setObservation( iAction, iEndState, iObservation, adObservations[iObservation] / dNormalizationFactor );
				}
			}
		}
	}
	
	public boolean isTerminalState( int iState ){
		return false;
	}
	public boolean terminalStatesDefined(){
		return true;
	}
	
	public double probStartState( int iState ){
		if( iState == 0 || iState == m_cStates - 1 )
			return 0.5;
		return 0.0;
		//return 1.0 / m_cStates;
	}
}
