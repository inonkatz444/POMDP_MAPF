package pomdp.utilities;

import java.io.Serializable;

public interface VariableTranslator extends Serializable{
	public int translate( int iVar );
	public int translateVariableCount( int cVariables );
}
