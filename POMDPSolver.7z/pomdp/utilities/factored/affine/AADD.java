//////////////////////////////////////////////////////////////////////
//
// Algebraic Decision Diagram Package (Affine ADD - AADD)
//
// Author: Scott Sanner (ssanner@cs.toronto.edu)
// Date:   6/1/04
//
// Notes:
// ------
// - Int appended to a method name can mean either the 'internal'
//   version or the version using integers... need to disambiguate
//   this sometime.
//
// TODO:
// -----
// 
//////////////////////////////////////////////////////////////////////

package pomdp.utilities.factored.affine;

import java.math.*;
import java.text.*;
import java.util.*;

/**
 * General class for implementation of AADD data structure
 **/
public class AADD 
    extends DD {

    // Precision setting (1e-10 currently)
    public static final double PRECISION = 1e-10d;

    // Perform node merging?
    public static final boolean USE_NODE_MERGING = false;

    // Print warning info?
    public static final boolean WARNING      = false;

    // Print debug info?  (Should compile out otherwise.)
    public static final boolean PRINT_DEBUG  = false;
    public static final boolean PRINT_REDUCE = false;
    public static final boolean PRINT_APPLY  = false;

    // Internal statistics
    public static long APPLY_CALLS        = 0;
    public static int  TERM_PRUNE_CNT     = 0;
    public static int  PROD_PRUNE_CNT     = 0;
    public static int  MIN_PRUNE_CNT      = 0;
    public static int  MAX_PRUNE_CNT      = 0;
    public static int  SUM_CACHE_HITS     = 0;
    public static int  MAX_CACHE_HITS     = 0;
    public static int  PROD_CACHE_HITS    = 0;
    public static int  PRUNE_CACHE_HITS   = 0;
    public static int  REDUCE_CACHE_HITS  = 0;
    public static int  APPLY_CACHE_HITS   = 0;
    public static int  PRECISION_PRUNES   = 0;
    public static int  IDENT_PRUNES       = 0;

    // Local data for AADD 
    public AADDRNode  _pRoot;         // local id of root node
    public int        _nINodeIDCnt;   // counter for local ids
    public int        _nRNodeIDCnt;   // counter for local ids

    // Static node caches (id for ADDNode, 
    public HashMap    _hmNodes;       // maps ADDRNode(id) -> ADDNode (AADDINode or ADDDNode if id==0)
    public Map        _hmINodeCache;  // <gid, low rid, high rid> -> AADDINode
    public HashMap    _hmRNodes;      // maps ADDRNode(rid)       -> AADDRNode
    public ADDDNode   _zeroDNode;     // the terminal dnode (zero)

    // Reduce/apply/prune/special caches
    public Map        _hmApplyCache;  // cache for apply operation
    public HashMap    _hmReduceMap;   // maps <id> -> ADDNode (Reduce cache)
    public HashMap    _hmPruneMap;    // maps <id> -> ADDNode (Prune cache)

    public HashMap    _hmNewNodes      = null;
    public Map        _hmNewINodeCache = null;
    public HashMap    _hmNewRNodes     = null;

    // Temp data
    public SAINodeIndex _tmpSAINode1   = new SAINodeIndex(INVALID, INVALID, INVALID, 
							  -1, -1, -1, -1);
    public SAINodeIndex _tmpSAINode2   = new SAINodeIndex(INVALID, INVALID, INVALID, 
							  -1, -1, -1, -1);
    public ADDRNode     _tmpADDRNode   = new ADDRNode(INVALID);

    //public int        _nWhich;      // For range-keeping 1 = min, 2 = max

    ///////////////////////////////////////////////////////////////////
    //                    Basic and copy constructors
    ///////////////////////////////////////////////////////////////////

    public AADD(ArrayList order) {
	
	_pRoot          = null;
	_nINodeIDCnt    = 1;
	_nRNodeIDCnt    = 1;
	_alOrder        = (ArrayList)order.clone();
	_hmGVarToLevel  = new HashMap();

	// Caches
	_hmNodes        = new HashMap();
	_hmRNodes       = new HashMap();
	_hmPruneMap     = new HashMap();
	_hmReduceMap    = new HashMap();
	_hmApplyCache   = USE_NODE_MERGING ? (Map)new TreeMap() : (Map)new HashMap();
	_hmINodeCache   = USE_NODE_MERGING ? (Map)new TreeMap() : (Map)new HashMap();

	// Initialize zero node
	_zeroDNode     = new ADDDNode(0,0d,0d);
	ADDRNode zero_ref = new ADDRNode(0);
	_hmNodes.put( zero_ref, _zeroDNode);
	//_nWhich         = 0;

	// Build map from global var to order level
	_hmGVarToLevel.clear();
	for (int i = 0; i < _alOrder.size(); i++) {
	    _hmGVarToLevel.put((Integer)_alOrder.get(i), new Integer(i));
	}	
    }

    public AADD(AADD src) {

	_nINodeIDCnt    = 1;
	_nRNodeIDCnt    = 1;

	// Caches
	_hmNodes        = new HashMap();
	_hmRNodes       = new HashMap();
	_hmPruneMap     = new HashMap();
	_hmReduceMap    = new HashMap();
	_hmApplyCache   = USE_NODE_MERGING ? (Map)new TreeMap() : (Map)new HashMap();
	_hmINodeCache   = USE_NODE_MERGING ? (Map)new TreeMap() : (Map)new HashMap();

	// Initialize zero node
	_zeroDNode     = new ADDDNode(0,0d,0d);
	ADDRNode zero_ref = new ADDRNode(0);
	_hmNodes.put( zero_ref, _zeroDNode);
	//_nWhich      = 0;

	// Takes care of root, order, gvar_map, nodeLevel
	_alOrder = (ArrayList)src._alOrder.clone();
	_hmGVarToLevel = (HashMap)src._hmGVarToLevel.clone();

	// Copy over the node structure and load the caches
	setRoot(reduceRestrict(src._pRoot, src, -1, -1 /* Don't perform any op! */));
    }
    //////////////////////////////////////////////////////////////////
    //             Flushing and special node maintenance
    //////////////////////////////////////////////////////////////////

    // Flush caches but save special nodes.  Maybe could avoid
    // ADDRNode allocation with factory allocator?  Not sure how much
    // it would save.
    public void flushCaches(boolean print_info) {

	// Print starting info
	if (print_info) {
	    System.out.print("[FLUSHING CACHES... ");
	    //showCacheSize();
	    ResetTimer();
	}

	// Can always clear these
	_hmApplyCache = USE_NODE_MERGING ? (Map)new TreeMap() : (Map)new HashMap();
	_hmReduceMap  = new HashMap();
	_hmPruneMap   = new HashMap();

	// Set up temporary alternates to these HashMaps
	_hmNewNodes      = new HashMap();
	_hmNewRNodes     = new HashMap();
	_hmNewINodeCache = USE_NODE_MERGING ? (Map)new TreeMap() : (Map)new HashMap();

	// Copy over 'special' nodes then set new maps
	Iterator i = _hsSpecialNodes.iterator();
	while (i.hasNext()) {
	    cacheRNode((ADDRNode)i.next());
	}	
	_hmNodes      = _hmNewNodes;
	_hmRNodes     = _hmNewRNodes;
	_hmINodeCache = _hmNewINodeCache;

	// Copy over the special zero ADDDNode
	ADDRNode zero_ref = new ADDRNode(0);
	_hmNodes.put( zero_ref, _zeroDNode);

	// Print results
	if (GC_DURING_FLUSH) {
	    RUNTIME.gc();
	}
	if (print_info) {
	    System.out.print(" TIME: " + GetElapsedTime());
	    System.out.print("  RESULT: " + _df.format(((double)RUNTIME.freeMemory() / 
							(double)RUNTIME.totalMemory())));
	    System.out.print("  CACHE: " + getCacheSize()  + "] ");
	}	// Print starting info
    }
    
    public void cacheINode(ADDRNode r) {
	if (r._lid == 0 || _hmNewNodes.containsKey(r) ) { 
	    return; 
	}
	AADDINode ni = (AADDINode)_hmNodes.get(r);
	_hmNewNodes.put(r, ni);
	_hmNewINodeCache.put(new SAINodeIndex(ni._nGlobalID, 
					      ni._nLow, ni._nHigh,
					      ni._dLowOffset, ni._dLowMult,
					      ni._dHighOffset, ni._dHighMult), r);
	cacheINode(new ADDRNode(ni._nLow));
	cacheINode(new ADDRNode(ni._nHigh));
    }
    
    public void cacheRNode(ADDRNode r) {
	AADDRNode n = (AADDRNode)_hmRNodes.get(r);
	_hmNewRNodes.put(r, n);
	cacheINode(new ADDRNode(n._nRefID));
    }

    //////////////////////////////////////////////////////////////////
    //              Internal data structure maintenance
    //////////////////////////////////////////////////////////////////

    // Quick cache snapshot
    public void showCacheSize() {
	System.out.println("APPLY CACHE:  " + _hmApplyCache.size());
	System.out.println("REDUCE CACHE: " + _hmReduceMap.size());
	System.out.println("INODE CACHE:  " + _hmINodeCache.size());	
	System.out.println("RNODE CACHE:  " + _hmRNodes.size() + "\n");	
    }

    // Total cache snapshot
    public long getCacheSize() {
	return _hmApplyCache.size() + _hmReduceMap.size() + 
	       _hmINodeCache.size() + _hmRNodes.size();
    }

    // An exact count for the AADD rooted at _pRoot
    public long countExactNodes(int rid) {
		HashSet cset = new HashSet();
		countExactNodesInt(cset, getRNode(rid)._nRefID);
		return cset.size();
    }
    // An exact count for the AADD rooted at _pRoot
    public long countExactNodes() {
		HashSet cset = new HashSet();
		countExactNodesInt(cset, _pRoot._nRefID);
		return cset.size();
    }

    public Set getExactNodes(int rid) {
	HashSet cset = new HashSet();
	countExactNodesInt(cset, getRNode(rid)._nRefID);
	return cset;
    }

    public void countExactNodesInt(HashSet cset, int id) {
	Integer iid = new Integer(id);
	if (cset.contains(iid)) {
	    return;
	}
	cset.add(iid);
	ADDNode n = getNode(id);
	if (n instanceof AADDINode) {
	    countExactNodesInt(cset, ((AADDINode)n)._nLow);
	    countExactNodesInt(cset, ((AADDINode)n)._nHigh);
	}
    }

    public Set getGIDs(int id) {
	HashSet cset = new HashSet();
	HashSet gset = new HashSet();
	collectGIDsInt(cset, gset, getRNode(id)._nRefID);
	return gset;
    }

    public void collectGIDsInt(HashSet cset, HashSet gset, int id) {
	Integer iid = new Integer(id);
	if (cset.contains(iid)) {
	    return;
	}
	cset.add(iid);
	ADDNode n = getNode(id);
	if (n instanceof AADDINode) {
	    gset.add( new Integer(((AADDINode)n)._nGlobalID) );
	    collectGIDsInt(cset, gset, ((AADDINode)n)._nLow );
	    collectGIDsInt(cset, gset, ((AADDINode)n)._nHigh );
	} 
    }

    //////////////////////////////////////////////////////////////////
    //                         Node retrieval
    //////////////////////////////////////////////////////////////////

    // Set the root node and update ref counts
    public void setRoot(AADDRNode r) {
	_pRoot = r;
    }

    // The only way to retrieve an AADDINode from an ID (returns ADDDNode if 0)
    public ADDNode getNode(int local_id) {
	if (local_id >= 0 && local_id < _nINodeIDCnt) {
	    _tmpADDRNode.set(local_id);
	    return (ADDNode)_hmNodes.get(_tmpADDRNode);
	} else {
	    System.out.println("AADD.getINode: Error invalid local id: " + 
			       local_id + ", >= " + _nINodeIDCnt);
	    System.exit(1);
	    return null;
	}
    }

    // Returns rid for node
    public int addRNodeRef(AADDRNode r) {

	int       rid = _nRNodeIDCnt++;
	ADDRNode  ref = new ADDRNode(rid);
	_hmRNodes.put(ref, r);
	
	return rid;
    }

    // The only way to retrieve an AADDRNode from an ID 
    // Note: Different id space!
    public AADDRNode getRNode(int rid) {
	if (rid >= 0 && rid < _nRNodeIDCnt) {
	    _tmpADDRNode.set(rid);
	    return (AADDRNode)_hmRNodes.get(_tmpADDRNode);
	} else {
	    System.out.println("AADD.getRNode: Error invalid local id" + 
			       rid + ", >= " + _nRNodeIDCnt);
	    System.exit(1);
	    return null;
	}
    }

    // Returns local id for inode
    public int createINode(int gid, int low, int high, 
			   double o_l, double m_l, double o_h, double m_h) {

	//System.out.println("Create: <" + gid + "," + low + "," + high + ">  ->  " + _nRefIDCnt);
	int      lid  = _nINodeIDCnt++;
	ADDRNode ref = new ADDRNode(lid);
	AADDINode n    = new AADDINode(lid, gid, low, high, o_l, m_l, o_h, m_h);

	_hmNodes.put(ref, n);
	_hmINodeCache.put(new SAINodeIndex(gid, low, high, o_l, m_l, o_h, m_h), ref);
	
	return lid;
    }

    // This actually does low==high simplification in place... very
    // important to ensure ref counts ok since double linking screws
    // things up.  WARNING: May not return INode if low==high.  
    //
    // This method does normalization in place.
    public AADDRNode getINode(int gid, int low, int high, 
			      double o_l, double m_l, double o_h, double m_h,
			      boolean create) {

	AADDRNode ret = null;

	// First remove 0.0 multipliers and replace with the zero node
	if (m_l <= PRECISION) {
	    low = 0;
	}
	if (m_h <= PRECISION) {
	    high = 0;
	}

	// First check if low == high... in this case, just perform the
	// obvious equivalent reduction 
	if (low == high && Math.abs(o_l - o_h) <= PRECISION && 
	    Math.abs(m_l - m_h) <= PRECISION) {

	    ret = new AADDRNode(low, o_l, m_l); 

	    // **Must deal with numerical precision error**
	    if ((ret != null)  && (ret._nRefID != 0) && (ret._dMult <= PRECISION)) {
		//System.out.println(ret.toString(this, 0));
		if (WARNING) {
		    System.out.println("WARNING: Mult near 0 in getINode()");
		}
		//System.out.println("WARNING: Mult near 0 in getINode()");
		//System.exit(1);
		ret = new AADDRNode(0, ret._dOffset, 0.0d);
	    }

	} else {

	    // Now compute normalization
	    double r_min   = Math.min(o_l, o_h);
	    double r_max   = Math.max(o_l + m_l, o_h + m_h);
	    double r_range = r_max - r_min;
	    o_l = (o_l - r_min) / r_range;
	    o_h = (o_h - r_min) / r_range;
	    m_l = m_l / r_range;
	    m_h = m_h / r_range;

	    // **Must deal with numerical precision error**
	    if (r_range <= PRECISION) {

		// Don't need to make an INode here...
		if (WARNING) {
		    System.out.println("WARNING: Mult near 0 in getINode()");
		}
		//System.exit(1);
		ret = new AADDRNode(0, r_min, 0.0d);

	    } else {

		if (USE_NODE_MERGING) {
		    
		    // We're trying to index R, want to see if it has a nearest neighbor

		    // Get a submap from the node cache
		    _tmpSAINode1 = new SAINodeIndex(gid, low, high, 
						    o_l, m_l, o_h, m_h, -2d*PRECISION);
		    _tmpSAINode2 = new SAINodeIndex(gid, low, high, 
						    o_l, m_l, o_h, m_h, 2d*PRECISION);
		    Map submap = ((TreeMap)_hmINodeCache).subMap(_tmpSAINode1, 
								 _tmpSAINode2);

		    Iterator i = submap.entrySet().iterator();
		    while (i.hasNext()) {
			Map.Entry me = (Map.Entry)i.next();
			SAINodeIndex s = (SAINodeIndex)me.getKey();

			// Do actual range comparison to see if nearest neighbor
			if (Math.abs(o_l - s._dOffset1)  <= PRECISION &&
			    Math.abs(m_l - s._dMult1)    <= PRECISION &&
			    Math.abs(o_h - s._dOffset2)  <= PRECISION &&
			    Math.abs(m_h - s._dMult2)    <= PRECISION) {

			    // Match found!!!
			    ret = new AADDRNode(((ADDRNode)me.getValue())._lid, 
						r_min, r_range);
			    break;
			}
		    }
		    
		    // No match found so have to create a new INode
		    if (ret == null) {
			//System.out.println("Match not found...");
			ret = new AADDRNode(createINode(gid, low, high,o_l, m_l, o_h, m_h), 
					    r_min, r_range);
		    }

		} else {	
		    _tmpSAINode1.set(gid, low, high, o_l, m_l, o_h, m_h);
		    ADDRNode ref = (ADDRNode)_hmINodeCache.get(_tmpSAINode1);
		    if (ref != null) {
			ret = new AADDRNode(ref._lid, r_min, r_range);
		    } else if (create) {
			ret = new AADDRNode(createINode(gid, low, high,
							o_l, m_l, o_h, m_h), 
					    r_min, r_range);
		    } 
		} 
	    }
	}

	return ret;
    }

    public AADDRNode getDNode(double val, boolean create) {
	return new AADDRNode(0,val,0.0d);
    }

    /////////////////////////////////////////////////////////////////
    //                 General ADD / Unary Operations
    /////////////////////////////////////////////////////////////////

    public double getMaxValue() { 
	return _pRoot._dOffset + _pRoot._dMult;
    }

    public double getMinValue() { 
	return _pRoot._dOffset;
    }

    public double getMaxValue(int id) {
	AADDRNode r = getRNode(id);
	return r._dOffset + r._dMult;
    }

    public double getMinValue(int id) {
	AADDRNode r = getRNode(id);
	return r._dOffset;
    }

    // Gets *canonical* AADDRNode ref to return
    public int scalarMultiply(int id, double val) {
	AADDRNode r = getRNode(id);
	AADDRNode ret = scalarMultiply(r, val);
	return addRNodeRef(ret);
    }

    // Produces new AADD.
    public AADD scalarMultiply(double val) { 
	AADD a1 = new AADD(_alOrder);
	AADDRNode aval = a1.getDNode(val, true);
	a1.setRoot(aval);
	return Apply(a1, this, ARITH_PROD);
    }

    // Within current AADD.
    public AADDRNode scalarMultiply(AADDRNode r, double val) {
	
	if (r._nRefID == 0) {
	    return getDNode(r._dOffset * val, true);
	} else if (val == 0d) { 
	    PROD_PRUNE_CNT++;
	    return new AADDRNode(0, 0d, 0d);
	} else if (val > 0d) {
	    PROD_PRUNE_CNT++;
	    return new AADDRNode(r._nRefID, val * r._dOffset, val * r._dMult);
	}

	// Otherwise we'll have to call Apply
	AADDRNode aval = getDNode(val, true);
	return applyInt(aval, r, ARITH_PROD);	
    }

    // Gets *canonical* AADDRNode ref to return
    public int scalarAdd(int id, double val) {
	AADDRNode r = getRNode(id);
	AADDRNode ret = scalarAdd(r, val);
	return addRNodeRef(ret);
    }

    public AADD scalarAdd(double val) {
	AADD new_aadd = new AADD(this);
	new_aadd._pRoot._dOffset += val;
	return new_aadd;
    }

    public AADDRNode scalarAdd(AADDRNode r, double val) {
	return new AADDRNode(r._nRefID, r._dOffset + val, r._dMult);
    }

    // These are harder to do in place because inversion must change
    // the base/inode values... so have to do an Apply operation with the
    // ARITH_MINUS/DIV operator.  There may be an efficient way around this
    // but it is not clear to me at this point.

    public AADD negate() { 
	AADD a1 = new AADD(_alOrder);
	AADDRNode zero = a1.getDNode(0.0d, true);
	a1.setRoot(zero);
	return Apply(a1, this, ARITH_MINUS);
    }

    // Within current AADD, gets *canonical* AADDRNode ref to return
    public int negate(int rid) { 
	AADDRNode zero = getDNode(0d, true);
	AADDRNode ret = applyInt(zero, getRNode(rid), ARITH_MINUS);	
	return addRNodeRef(ret); 
    }

    public AADD invert() { 
	AADD a1 = new AADD(_alOrder);
	AADDRNode one = a1.getDNode(1.0d, true);
	a1.setRoot(one);
	return Apply(a1, this, ARITH_DIV);
    }

    // Within current AADD, gets *canonical* AADDRNode ref to return
    public int invert(int rid) { 
	AADDRNode one = getDNode(1d, true);
	AADDRNode ret = applyInt(one, getRNode(rid), ARITH_DIV);	
	return addRNodeRef(ret); 
    }

    ///////////////////////////////////////////////////////////////////////////
    //                         Approximation Algorithms
    ///////////////////////////////////////////////////////////////////////////

    // Prune and return canonical reference
    public int pruneNodes(int rid) {

	AADDRNode ret = getRNode(rid);
	if (PRUNE_PRECISION >= 0d) {
	    ret = pruneNodeDiff(ret, 1d, true);
	} 
	//if (!verifyOrder(ret)) {
	//    System.out.println("Order error in pruneNodeDiff()");
	//    System.exit(1);
	//}
	return addRNodeRef(ret); 
    }

    // Start at root
    public void pruneNodeDiff() {
	setRoot(pruneNodeDiff(_pRoot, 1d, true));
    }

    // Prunes all node structure having impact less than prune_precision.
    // Range included because need a measure of the range induced by the
    // error at the node.
    public AADDRNode pruneNodeDiff(AADDRNode r, double range, boolean recurse) {

	// Can immediately check for local ID of 0
	if (r._nRefID == 0) {
	    return r;
	}

	// Check for a range below precision 
	range *= r._dMult;
	if (range <= PRUNE_PRECISION) {

	    // This entire subtree has impact less than PRUNE_PRECISION	    
	    switch (PRUNE_TYPE) {
	    case NO_REPLACE: 
	    case REPLACE_LOW: 
	    case REPLACE_HIGH: {
	    } break;
	    case REPLACE_MIN: {
		PRECISION_PRUNES++;
		return getDNode(r._dOffset, true);
	    } 
	    case REPLACE_MAX: {
		PRECISION_PRUNES++;
		return getDNode(r._dOffset + r._dMult, true);
	    } 
	    case REPLACE_AVG: {
		PRECISION_PRUNES++;
		return getDNode((r._dOffset + r._dMult)/2d, true);
	    } 
	    default: {
		//if (PRUNE_TYPE == REPLACE_RANGE && _nWhich == 1) {
		//    PRECISION_PRUNES++;
		//    return getDNode(r._dOffset, true);
		//} else if (PRUNE_TYPE == REPLACE_RANGE && _nWhich == 2) {
		//    PRECISION_PRUNES++;
		//    return getDNode(r._dOffset + r._dMult, true);
		//} else {
		System.out.println("Illegal replacement type " + 
				   PRUNE_TYPE); // + ", " + _nWhich);
		System.exit(1);
	    }
	    }
	}

	// Check cache
	AADDRNode ret = null;
	_tmpADDRNode.set(ret._nRefID);
	if ( (ret = (AADDRNode)_hmPruneMap.get(_tmpADDRNode)) == null ) {
	    
	    // Not in cache, perform reduction on this AADDINode
	    AADDINode ni = (AADDINode)getNode(r._nRefID);
	    
	    // Get high and low branches for this INode
	    AADDRNode low  = new AADDRNode(ni._nLow,  ni._dLowOffset,  ni._dLowMult);
	    AADDRNode high = new AADDRNode(ni._nHigh, ni._dHighOffset, ni._dHighMult);

	    // Recurse
	    if (recurse) {
		low  = pruneNodeDiff(low,  range, true);
		high = pruneNodeDiff(high, range, true);
	    } 
	    
	    // Now compute diff at this level
	    double max_abs_diff = Double.POSITIVE_INFINITY;
	    if (USE_QUICK_PRUNE) {
		max_abs_diff = Math.max(high._dOffset + high._dMult - low._dOffset, 
					low._dOffset  + low._dMult  - high._dOffset);
	    } else {
		AADDRNode adiff = applyInt(low, high, AADD.ARITH_MINUS);
		max_abs_diff = Math.max(Math.abs(adiff._dOffset), 
					Math.abs(adiff._dOffset + adiff._dMult));
	    }

	    /////////////////// DEBUG ////////////////////

	    // REMOVE!!!
	    //AADDRNode adiff2 = applyInt(high, low, AADD.ARITH_MINUS);
	    //double max_abs_diff2 = Math.max(Math.abs(adiff2._dOffset), 
	    //				    Math.abs(adiff2._dOffset + adiff2._dMult));
	    //if (Math.abs(max_abs_diff - max_abs_diff2) >= 1e-9d) {
	    //	System.out.println("Error in pruning - differences not equal - ARITH_MINUS!");
	    //	System.out.println("[ " + max_abs_diff + ", " + max_abs_diff2 + " ]");
	    //	System.exit(1);
	    //}
	    //////////////////////////////////////////////

	
	    // Should we prune?
	    if ((PRUNE_PRECISION >= 0.0d) && ((range * max_abs_diff) <= PRUNE_PRECISION) ) {
		
		/////////////////// DEBUG ////////////////////
		//System.out.println("Pruning type: " + PRUNE_TYPE);
		//System.out.println("Range: " + range + " * Max_diff: " + max_abs_diff);
		//System.out.println("Pruning: \n" + r.toString(this,0));
		//System.out.println("---------------------------------");
		//////////////////////////////////////////////

		switch (PRUNE_TYPE) {
		case NO_REPLACE: {
		    ret = getINode(ni._nGlobalID, 
				   low._nRefID, high._nRefID, 
				   low._dOffset,  low._dMult, 
				   high._dOffset, high._dMult, true);
		} break;
		case REPLACE_LOW: {
		    ret = low;
		} break;
		case REPLACE_HIGH: {
		    ret = high;
		} break;
		case REPLACE_MIN: {
		    ret = applyInt(low, high, ARITH_MIN);
		} break;
		case REPLACE_MAX: {
		    ret = applyInt(low, high, ARITH_MAX);
		} break;
		case REPLACE_AVG: {
		    ret = scalarMultiply(applyInt(low, high, ARITH_SUM), 0.5d);
		} break;
		default: {
		    //if (PRUNE_TYPE == REPLACE_RANGE && _nWhich == 1) {
		    //	ret = applyInt(low, high, ARITH_MIN);
		    //} else if (PRUNE_TYPE == REPLACE_RANGE && _nWhich == 2) {
		    //	ret = applyInt(low, high, ARITH_MAX);
		    //} else {
		    System.out.println("Illegal replacement type " + 
				       PRUNE_TYPE); // + ", " + _nWhich);
		    System.exit(1);
		}
		}

		PRECISION_PRUNES++;

	    } else {

		// Retrieve the inode
		ret = getINode(ni._nGlobalID, 
			       low._nRefID, high._nRefID, 
			       low._dOffset,  low._dMult, 
			       high._dOffset, high._dMult, true);
		
	    }
	    
	    // Cache the node in canonical form
	    _hmPruneMap.put(new ADDRNode(r._nRefID), ret);
	
	} else {
	    PRUNE_CACHE_HITS++;
	}
    
	// Return cached value modified by offset
	return new AADDRNode(ret._nRefID, 
			     (r._dMult * ret._dOffset) + r._dOffset,
			     (r._dMult * ret._dMult));
    }

    ///////////////////////////////////////////////////////////////////////////
    //                             Main Algorithms
    ///////////////////////////////////////////////////////////////////////////

    // Assume already built with correct order, just needs reduction
    public void reduce() 
    {
	setRoot(reduceRestrict(_pRoot, this, -1, -1 /* Don't apply any op! */));
    }

    public int reduce(int root) {
	AADDRNode ret = reduceRestrict(getRNode(root), this, -1, -1);
	return addRNodeRef(ret); 
    }

    // Assume already built with correct order, just needs reduction
    // This also performs restriction (use op = AADD.RESTRICT_LOW/HIGH).
    public void restrict(int gid, int op) 
    {
	setRoot(reduceRestrict(_pRoot, this, gid, op));
    }

    public int restrict(int root, int gid, int op) {
	AADDRNode ret = reduceRestrict(getRNode(root), this, gid, op);	 
	return addRNodeRef(ret);
    }

    // This is really a superset of reduce().  It only adds a check for
    // a gid and a restriction if that gid is found.  Otherwise,
    // everything is the same and the rest of the code is present
    // to perform an in-line reduction.
    //
    // In reality, a full AADD package only needs reduceRestrict(), opOut(),
    // Apply(), getINode(), computeTermNode(), and evaluate() for full
    // capability / efficiency.  Note that reduceRestrict(...,-1,-1) is
    // equivalent to reduce().
    //
    // If 'src' is non-null, this will obtain the node structure
    // from the ADD given by src.  In this case, the src
    // structure will remain unchanged.
    public AADDRNode reduceRestrict(AADDRNode r, AADD src, int gid, int op)
    {
	// Can immediately check for local ID of 0
	if (r._nRefID == 0) {
	    return r;
	}

	// Check cache
	AADDRNode ret = null;
	ReduceCacheKey key = new ReduceCacheKey(src, gid, op, r._nRefID);

	if ( (ret = (AADDRNode)_hmReduceMap.get(key)) == null ) {
	    
	    // Not in cache, perform reduction on this AADDINode
	    boolean recurse = true;
	    AADDINode ni = (AADDINode)src.getNode(r._nRefID);
	    
	    // Op out, else reduce...
	    if (ni._nGlobalID == gid) {
		
		// Get high and low branches 
		AADDRNode op1 = new AADDRNode(ni._nLow,  ni._dLowOffset,  ni._dLowMult);
		AADDRNode op2 = new AADDRNode(ni._nHigh, ni._dHighOffset, ni._dHighMult);
		
		// Get application of op to low and high branches
		if (op == RESTRICT_HIGH || op == RESTRICT_LOW) {
		    ret = ((op == RESTRICT_LOW) ? 
			   reduceRestrict(op1, src, gid, op) : 
			   reduceRestrict(op2, src, gid, op));
		} else {
		    System.out.println("ERROR: op not a RESTRICT!");
		    System.exit(1);
		}
		
	    } else {
		
		// Get high and low branches for this INode
		AADDRNode op1 = new AADDRNode(ni._nLow,  ni._dLowOffset,  ni._dLowMult);
		AADDRNode op2 = new AADDRNode(ni._nHigh, ni._dHighOffset, ni._dHighMult);
		
		// Get new low and high branches
		AADDRNode low  = reduceRestrict(op1, src, gid, op);
		AADDRNode high = reduceRestrict(op2, src, gid, op);
		
		// Retrieve the inode
		ret = getINode(ni._nGlobalID, 
			       low._nRefID, high._nRefID, 
			       low._dOffset,  low._dMult, 
			       high._dOffset, high._dMult, true);
	    }
	    
	    // Cache the node in canonical form
	    _hmReduceMap.put(key, ret);
	} else {
	    REDUCE_CACHE_HITS++;
	}
	
	// Return cached value modified by offset
	return new AADDRNode(ret._nRefID, 
			     (r._dMult * ret._dOffset) + r._dOffset,
			     (r._dMult * ret._dMult));
    }

    public int opOut(int root, int gid, int op) {
		AADDRNode ret = opOut(getRNode(root), gid, op);
		return addRNodeRef(ret); 
    }

    public AADDRNode opOut( int op ) {
		AADDRNode ret = opOut(_pRoot, _pRoot._nRefID, op);
		return ret; 
    }

    // For marginalizing out a node via sum, prod, max, or min.
    public AADDRNode opOut(AADDRNode r, int gid, int op) {

	// Check for valid operator
	if (op != ARITH_SUM && op != ARITH_PROD && op != ARITH_MAX && op != ARITH_MIN) {
	    System.out.println("ERROR: opOut called without SUM/PROD/MIN/MAX");
	    System.exit(1);
	}

	// Need left and right operands... can do a quick shortcut if top node
	// has global var, i.e., just take left and right branch and perform op.
	AADDRNode high_br = null, low_br = null;
	AADDINode ni = null;
	if ( r._nRefID != 0 &&
	     ((ni = (AADDINode)getNode(r._nRefID))._nGlobalID == gid) &&
	     op == ARITH_SUM) {

	    // Get high and low branches for this INode
	    high_br = new AADDRNode(ni._nHigh, ni._dHighOffset, ni._dHighMult);
	    low_br  = new AADDRNode(ni._nLow,  ni._dLowOffset,  ni._dLowMult);
	    AADDRNode ret = applyInt(high_br, low_br, op);
	    return new AADDRNode(ret._nRefID,
				 (r._dMult * ret._dOffset) + 2d*r._dOffset,
				 (r._dMult * ret._dMult));
	    
	} else {
	    
	    // Get high and low branch restrictions for this var
	    high_br = reduceRestrict(r, this, gid, RESTRICT_HIGH);
	    low_br  = reduceRestrict(r, this, gid, RESTRICT_LOW);
	    return applyInt(high_br, low_br, op);
	}
    }

    public int remapGIDsInt(int rid, HashMap gid_map) {
	AADDRNode r = getRNode(rid);
	AADDRNode ret = new AADDRNode(remapGIDs(r._nRefID, gid_map), 
				      r._dOffset, r._dMult);
	return addRNodeRef(ret);
    }

    // Remap gids in internal nodes - map is old_id -> new_id.
    // TODO: Assuming consistent order but not checking!!!
    public void remapGIDs(HashMap gid_map) {
	setRoot(new AADDRNode(remapGIDsInt(_pRoot._nRefID, gid_map), 
			      _pRoot._dOffset, _pRoot._dMult));
    }

    public int remapGIDs(int local_id, HashMap gid_map) {
	if (local_id == 0) {
	    return 0;
	} else { // n instanceof ADDINode so recurse and update caches
	    AADDINode ni = (AADDINode)getNode(local_id);	
	    Integer old_id = new Integer(ni._nGlobalID);
	    Integer new_id = (Integer)gid_map.get(old_id);
	    if (new_id == null) {
		new_id = old_id;
	    }
	    return getINode(new_id.intValue(), 
			    remapGIDs(ni._nLow, gid_map),
			    remapGIDs(ni._nHigh, gid_map),
			    ni._dLowOffset,  ni._dLowMult, 
			    ni._dHighOffset, ni._dHighMult, true)._nRefID;
	}
    }

    public boolean verifyOrder(int id) {
	return verifyOrder(getRNode(id)._nRefID, -1);
    }

    // A quick test to verify canonical order!  Returns false if problem.
    public boolean verifyOrder() {
	return verifyOrder(_pRoot._nRefID, -1);
    }

    public boolean verifyOrder(int n, int par_gid) {
	if (n != 0) {
	    AADDINode ni = (AADDINode)getNode(n);	
	    if (par_gid != -1) {
		// Verify order
		if (par_gid == ni._nGlobalID || !comesBefore(par_gid, ni._nGlobalID)) {
		    return false;
		}
	    }
	    return verifyOrder(ni._nLow,  ni._nGlobalID) &&
		   verifyOrder(ni._nHigh, ni._nGlobalID);
	} else {
	    return true;
	}
    }

    // Assume a1 and a2 are ordered, op is +,*,max.
    // Uses root of each AADD and builds a new AADD to return.
    public static AADD Apply(AADD a1, AADD a2, int op)
    {
	// Check for invalid restrict operation
	if (op == AADD.RESTRICT_LOW || op == AADD.RESTRICT_HIGH) {
	    System.out.println("Cannot RESTRICT using Apply(...)");
	    System.exit(1);
	}

	AADD result = new AADD(a1._alOrder);
	// result._nWhich = (a1._nWhich != 0) ? a1._nWhich : a2._nWhich;

	// Now that order is correct, apply op
	result.setRoot(result.apply(a1._pRoot, a1, a2._pRoot, a2, op));

	return result;
    }

    // Nodes can be external to this, will be internalized.  Result will be within "this".
    public AADDRNode apply(AADDRNode a1, AADD ctxt1, AADDRNode a2, AADD ctxt2, int op)
    {
	//Compare.ResetTimer();
    	if (ctxt1 != this) {
	    a1 = reduceRestrict(a1, ctxt1, -1, -1);
	}

	if (ctxt2 != this) {
	    a2 = reduceRestrict(a2, ctxt2, -1, -1);
	}

	//System.out.print(" *" + Compare.GetElapsedTime() + "* ");
	//Compare.ResetTimer();
	return applyInt(a1, a2, op);
    }

    // The 'int' internal interface to apply
    public int applyInt(int a1, int a2, int op) {
	AADDRNode r1 = getRNode(a1);
	AADDRNode r2 = getRNode(a2);
	AADDRNode ret = applyInt(r1, r2, op);
	return addRNodeRef(ret); 
    }

    // Nodes must be internal!
    public AADDRNode applyInt(AADDRNode a1, AADDRNode a2, int op)
    {
	///////////////////////////////////////////////////////////////////////////
	// Debug printing
	int min_gid = 1000000;
	if (PRINT_DEBUG && PRINT_APPLY) {
	    ADDNode nt1 = getNode(a1._nRefID);
	    ADDNode nt2 = getNode(a2._nRefID);
	    if (nt1 instanceof AADDINode) { min_gid = ((AADDINode)nt1)._nGlobalID; }
	    if (nt2 instanceof AADDINode) { min_gid = Math.min(min_gid, ((AADDINode)nt2)._nGlobalID); }
	    if (min_gid == 1000000) {
		System.out.print(ADDNode.indent(((Integer)_alOrder.get(
					       _alOrder.size()-1)).intValue()-1));
	    } else {
		System.out.print(ADDNode.indent(min_gid-2));
	    }
	    System.out.println(((min_gid == 1000000) ? 0 : min_gid) + ": Apply: [a1: " + 
			       "<" + _df.format(a1._dOffset) + ", " + _df.format(a1._dMult) + 
			       ", " + a1._nRefID + ">" + ";  a2: " + 
			       "<" + _df.format(a2._dOffset) + ", " + _df.format(a2._dMult) + 
			       ", " + a2._nRefID + ">" + ";  op: " + op + "]");
	}
	///////////////////////////////////////////////////////////////////////////

	// Can we compute a result immediately?
	AADDRNode ret = null;
	if ((ret = computeTermNode(a1,a2,op)) != null) {
	    
	    // We will not cache term node computations (since they are either
	    // simple or subprocedures will cache the results).  So just return
	    // value here.
	    return ret;
	}

	// Get the normalized cache key
	boolean min_max_cache = false;
	SAINodeIndex key = null; 
	if ( (op == ARITH_SUM) || (op == ARITH_MINUS && a1._dMult != 0)) {
	    key = new SAINodeIndex(op, a1._nRefID, a2._nRefID, 
				   0d, 1d, 
				   0d, a2._dMult / a1._dMult);
	} else if (op == ARITH_PROD) {
	    key = new SAINodeIndex(op, a1._nRefID, a2._nRefID, 
				   a1._dOffset / a1._dMult, 1d, 
				   a2._dOffset / a2._dMult, 1d);
	} else if ( ((op == ARITH_MIN) || (op == ARITH_MAX)) &&
		    a1._nRefID != 0 && a2._nRefID != 0) {
	    min_max_cache = true;
	    key = new SAINodeIndex(op, a1._nRefID, a2._nRefID, 
				   0d, 1d,
				   (a2._dOffset - a1._dOffset) / a1._dMult, a2._dMult / a1._dMult);
	} else {
	    key = new SAINodeIndex(op, a1._nRefID, a2._nRefID, 
				   a1._dOffset, a1._dMult, 
				   a2._dOffset, a2._dMult);
	}

	// Check cache
	if ((ret = (AADDRNode)_hmApplyCache.get(key)) != null) {

	    // Just keep track of cache statistics
	    switch (op) {
	    case ARITH_SUM: 
	    case ARITH_MINUS:
		SUM_CACHE_HITS++;  break;
	    case ARITH_PROD: 
		PROD_CACHE_HITS++; break;
	    case ARITH_MAX:
	    case ARITH_MIN: 
		MAX_CACHE_HITS++; break;
	    default:
		APPLY_CACHE_HITS++; break;
	    }

	} else { // ret is null, must recurse

	    // Not in cache and at least one node must be internal.
	    int rvar, id_v1_low, id_v1_high;
	    int id_v2_low, id_v2_high;
	    double o_v1_low,  m_v1_low;
	    double o_v1_high, m_v1_high;
	    double o_v2_low,  m_v2_low;
	    double o_v2_high, m_v2_high;
	    
	    // Retrieve nodes 
	    ADDNode n1 = getNode(a1._nRefID);
	    ADDNode n2 = getNode(a2._nRefID);
	    
	    // Find node with min id (or only internal node)
	    if (n1 instanceof AADDINode) {
		if (n2 instanceof AADDINode) {
		    if (comesBefore( ((AADDINode)n1)._nGlobalID, 
				     ((AADDINode)n2)._nGlobalID )) {
			rvar = ((AADDINode)n1)._nGlobalID;
		    } else {
			rvar = ((AADDINode)n2)._nGlobalID;
		    }
		} else {
		    rvar = ((AADDINode)n1)._nGlobalID;
		}
	    } else {
		rvar = ((AADDINode)n2)._nGlobalID;
	    }
	    
	    // Determine next recursion for n1
	    if ( (n1 instanceof AADDINode) && (((AADDINode)n1)._nGlobalID == rvar) ) {
		id_v1_low = ((AADDINode)n1)._nLow; id_v1_high = ((AADDINode)n1)._nHigh;
		o_v1_low  = key._dOffset1 + key._dMult1 * ((AADDINode)n1)._dLowOffset;
		o_v1_high = key._dOffset1 + key._dMult1 * ((AADDINode)n1)._dHighOffset;
		m_v1_low  = key._dMult1 * ((AADDINode)n1)._dLowMult;
		m_v1_high = key._dMult1 * ((AADDINode)n1)._dHighMult;
	    } else {
		id_v1_low = id_v1_high = a1._nRefID;
		o_v1_low  = o_v1_high  = key._dOffset1;
		m_v1_low  = m_v1_high  = key._dMult1;
	    }
	    
	    // Determine next recursion for n2
	    if ( (n2 instanceof AADDINode) && (((AADDINode)n2)._nGlobalID == rvar) ) {
		id_v2_low = ((AADDINode)n2)._nLow; id_v2_high = ((AADDINode)n2)._nHigh;
		o_v2_low  = key._dOffset2 + key._dMult2 * ((AADDINode)n2)._dLowOffset;
		o_v2_high = key._dOffset2 + key._dMult2 * ((AADDINode)n2)._dHighOffset;
		m_v2_low  = key._dMult2 * ((AADDINode)n2)._dLowMult;
		m_v2_high = key._dMult2 * ((AADDINode)n2)._dHighMult;
	    } else {
		id_v2_low = id_v2_high = a2._nRefID;
		o_v2_low  = o_v2_high  = key._dOffset2;
		m_v2_low  = m_v2_high  = key._dMult2;
	    }
	    
	    // Now compute the appropriate branches
	    AADDRNode low  = applyInt(new AADDRNode(id_v1_low, o_v1_low, m_v1_low), 
				      new AADDRNode(id_v2_low, o_v2_low, m_v2_low), op);
	    
	    AADDRNode high = applyInt(new AADDRNode(id_v1_high, o_v1_high, m_v1_high),
				      new AADDRNode(id_v2_high, o_v2_high, m_v2_high), op);
	    
	    // Retrieve the AADDINode (getINode will take care of 'low==high')
	    ret = getINode(rvar, low._nRefID, high._nRefID, 
			   low._dOffset,  low._dMult, 
			   high._dOffset, high._dMult, true);
	    
	    // Cache result for previously determined key
	    _hmApplyCache.put(key, ret);
	} 
	
	// Now, modify the node as required to obtain the actual result
	if ((op == ARITH_SUM) || (op == ARITH_MINUS && a1._dMult != 0)) {
	    ret = new AADDRNode(ret._nRefID, 
				(a1._dMult * ret._dOffset) + a1._dOffset + 
				((op == ARITH_SUM) ? a2._dOffset : -a2._dOffset), 
				a1._dMult * ret._dMult);
	} else if (op == ARITH_PROD) {
	    ret = scalarMultiply(ret, a1._dMult * a2._dMult);
	} else if (min_max_cache) {
	    ret = new AADDRNode(ret._nRefID, 
				(a1._dMult * ret._dOffset) + a1._dOffset, 
				a1._dMult * ret._dMult);
	}

	///////////////////////////////////////////////////////////////////////////
	// Debug printing
	if (PRINT_DEBUG && PRINT_APPLY) {
	    if (min_gid == 1000000) {
		System.out.print(ADDNode.indent(((Integer)_alOrder.get(
					  _alOrder.size()-1)).intValue()-1));
	    } else {
		System.out.print(ADDNode.indent(min_gid-2));
	    }
	    System.out.println("-->" + ((min_gid == 1000000) ? 0 : min_gid) + ": " +
			       "<" + _df.format(ret._dOffset) + ", " + _df.format(ret._dMult) + 
			       ", " + ret._nRefID + ">");
	}
	///////////////////////////////////////////////////////////////////////////

	// Return result of apply
	return ret;
    }

    // Computes a terminal node value if possible.  Can short circuit
    // the computation in many cases!
    public AADDRNode computeTermNode(AADDRNode a1, AADDRNode a2, int op) {

	AADDRNode ret = null;

	if (a1._nRefID == 0 && a2._nRefID == 0) {

	    // Can we create a terminal node here?
	    switch (op) {
	    case ARITH_SUM: {
		ret = new AADDRNode(0,a1._dOffset + a2._dOffset,0);
	    } break;
	    case ARITH_PROD: {
		ret = new AADDRNode(0,a1._dOffset * a2._dOffset,0);
	    } break;
	    case ARITH_MAX: {
		ret = new AADDRNode(0,Math.max(a1._dOffset, a2._dOffset),0);
	    } break;
	    case ARITH_MIN: {
		ret = new AADDRNode(0,Math.min(a1._dOffset, a2._dOffset),0);
	    } break;
	    case ARITH_DIV: {
		ret = new AADDRNode(0,a1._dOffset / a2._dOffset,0);
		if (ret._dOffset == Double.POSITIVE_INFINITY ||
		    ret._dOffset == Double.NEGATIVE_INFINITY) {
		    System.out.println("\n**ERROR**: Divide by ZERO");
		}
	    } break;
	    case ARITH_MINUS: {
		ret = new AADDRNode(0,a1._dOffset - a2._dOffset,0);
	    } break;
	    default: {
		System.out.println("Unknown operation: " + op);
		System.exit(1);
	    }
	    }

	} else if (op == ARITH_MIN || op == ARITH_MAX) {

	    if (op == ARITH_MIN) {

		if ((a1._dOffset + a1._dMult) <= a2._dOffset) {
		    // max of a1 is less than min of a2
		    ret = a1;
		    MIN_PRUNE_CNT++;
		} else if ((a2._dOffset + a2._dMult) <= a1._dOffset) {
		    // max of a2 is less than min of a1
		    ret = a2;
		    MIN_PRUNE_CNT++;
		}

	    } else if (op == ARITH_MAX) {

		if ((a1._dOffset + a1._dMult) <= a2._dOffset) {
		    // max of a1 is less than min of a2
		    ret = a2;
		    MAX_PRUNE_CNT++;
		} else if ((a2._dOffset + a2._dMult) <= a1._dOffset) {
		    // max of a2 is less than min of a1
		    ret = a1;
		    MAX_PRUNE_CNT++;
		}

	    }

	} else {

	    AADDRNode tnode = null;
	    AADDRNode other = null;

	    if (a1._nRefID == 0) {
		tnode = a1;
		other = a2;
	    } else if (a2._nRefID == 0) {
		tnode = a2;
		other = a1;
	    }

	    if (tnode != null) {

		// tnode is a terminal node, other is not!
		// Can do DIV and MINUS here if keep track of order...
		switch (op) {
		case ARITH_SUM: {
		    ret = new AADDRNode(other._nRefID, 
					tnode._dOffset + other._dOffset, 
					other._dMult);

		    TERM_PRUNE_CNT++;
		} break;
		case ARITH_PROD: {
		    if (tnode._dOffset >= 0d) { // RANGE_SCALE only
		    	// Need to multiply other node by tnode._dOffset...
			// can only do this if we're normalizing, otherwise
			// cannot have non-1d multiplier.
		    	ret = scalarMultiply(other, tnode._dOffset);
			PROD_PRUNE_CNT++;
			TERM_PRUNE_CNT++;
		    }

		} break;
		case ARITH_MIN: 
		case ARITH_MAX: {
		    System.out.println("computeTermNode(): Should not get here!");
		    System.exit(1);
		} break;

		case ARITH_MINUS: {
		    if (tnode == a2) {
			ret = new AADDRNode(other._nRefID, 
					    other._dOffset - tnode._dOffset, 
					    other._dMult);
		    }
		    TERM_PRUNE_CNT++;
		} break;
		}
		
	    } 	    
	}

	// If still no result, test to see if identical pruning
	if (ret == null && (a1._nRefID == a2._nRefID) &&
	    (op == ARITH_SUM || op == ARITH_PROD || op == ARITH_MAX ||
	     op == ARITH_MIN )) { //|| op == ARITH_MINUS
	    
	    // Here we can be efficient due to the subnodes being identical
	    switch (op) {
		
	    case ARITH_SUM: {
		
		// Can always prune
		//System.out.println("Prune ident sum " + key1 + ", " + key2); // REMOVE
		ret = new AADDRNode(a1._nRefID, 
				    a1._dOffset + a2._dOffset,
				    a1._dMult   + a2._dMult);
		
	    } break;
	    
	    case ARITH_MAX: {

		// Now determine if we can prune
		//System.out.println("Prune ident max " + key1 + ", " + key2); // REMOVE
		if (a1._dOffset >= a2._dOffset && a1._dMult >= a2._dMult) {
		    ret = a1;
		} else if (a2._dOffset >= a1._dOffset && a2._dMult >= a1._dMult) {
		    ret = a2;
		} 
		
	    } break;
	    
	    case ARITH_MIN: {
		    
		// Now determine if we can prune
		if (a1._dOffset <= a2._dOffset && a1._dMult <= a2._dMult) {
		    ret = a1;
		} else if (a2._dOffset <= a1._dOffset && a2._dMult <= a1._dMult) {
		    ret = a2;
		} 
		
	    } break;
	    
	    }
	    
	    if (ret != null) { 
		IDENT_PRUNES++;
	    }
	    
	} 

	return ret;
    }

    public double evaluate(int rid, ArrayList assign) {
	return evaluate(getRNode(rid), assign);
    }

    // Takes an assignment of gvars->{T|F} (Boolean class) and returns
    // the corresponding terminal node.  
    public double evaluate(AADDRNode r, ArrayList assign) {
    	
	Boolean b;
	double offset = r._dOffset;
	double mult   = r._dMult;
	ADDNode cur = getNode(r._nRefID);
	
	while ( cur instanceof AADDINode ) {
	    AADDINode curi = (AADDINode)cur;
	    int level = ((Integer)_hmGVarToLevel.get(
    			 new Integer(((AADDINode)cur)._nGlobalID))).intValue();
	    
	    // If we need a var that is unassigned, return null
	    // System.out.print("<" + _df.format(offset) + ", " + _df.format(mult) + "> ");
	    if ( (level < assign.size()) && ( (b = (Boolean)assign.get(level)) != null) ) {
		cur     = (b.booleanValue()) ? getNode(curi._nHigh) : getNode(curi._nLow);
		offset += mult * ((b.booleanValue()) ? curi._dHighOffset : curi._dLowOffset);
		mult   *= (b.booleanValue()) ? curi._dHighMult : curi._dLowMult;
	    } else {
		return Double.NaN;
	    }
	}
	
	// If get here, cur will be an AADDINode, ADDDNode
	return offset;
    }

    /////////////////////////////////////////////////////////////////
    //                       Order maintenance
    /////////////////////////////////////////////////////////////////

    // Probably have more efficient ways to do a lot of these using
    // binary search and hash tables

    // Order check - both must occur in list!
    public boolean comesBefore(int gid1, int gid2)
    {
	// Get level for gid1 and gid2
	int l1 = ((Integer)_hmGVarToLevel.get(new Integer(gid1))).intValue();
	int l2 = ((Integer)_hmGVarToLevel.get(new Integer(gid2))).intValue();

	// Determine which comes first (i.e. earlier level)
	return (l1 <= l2);
    }

    ////////////////////////////////////////////////////////////////
    //              Construction and File I/O Routines
    ////////////////////////////////////////////////////////////////

    // Note: Following functions are identical to ADD counterparts
    // These are inefficient because they rely on the 'int'
    // interface... could update for AADDRNode interface eventually.

    /** Build an ADD from a list (node is a list, high comes first
     ** for internal nodes)
     **/
    public int buildDDFromUnorderedTree(ArrayList l, Map var2ID) {
		AADDRNode ret = buildDDFromUnorderedTreeInt(l, var2ID);
		_pRoot = ret;
		return addRNodeRef(ret); 
    }

    public AADDRNode buildDDFromUnorderedTreeInt(ArrayList l, Map var2ID) {
	Object o = l.get(0);
	if (o instanceof String && HasOnlyDigits((String)o)) {
	    double val = (new BigInteger((String)o)).doubleValue();
	    return getDNode(val, true);
	} else if (o instanceof BigDecimal) {
	    double val = ((BigDecimal)o).doubleValue();
	    return getDNode(val, true);
	} else {
	    String var = (String)o;
	    int gid = ((Integer)var2ID.get(var)).intValue();
	    
	    // Get the var ADD
	    AADDRNode high_br = getVarNodeInt(gid, 0.0d, 1.0d);
	    high_br = applyInt(high_br, 
			       buildDDFromUnorderedTreeInt((ArrayList)l.get(1), var2ID) /*high*/, 
			       ARITH_PROD);

	    // Get the !var ADD
	    AADDRNode low_br = getVarNodeInt(gid, 1.0d, 0.0d);
	    low_br = applyInt(low_br, 
			      buildDDFromUnorderedTreeInt((ArrayList)l.get(2), var2ID) /*low*/,
			      ARITH_PROD);
	    
	    return applyInt(low_br, high_br, ARITH_SUM);
	}
    }

    /** Build an ADD from a list with correct variable order
     ** (node is a list, high comes first for internal nodes)
     **/
    public int buildDDFromOrderedTree(ArrayList l, Map var2ID) {
	AADDRNode ret = buildDDFromOrderedTreeInt(l, var2ID);
	return addRNodeRef(ret); 
    }

    public AADDRNode buildDDFromOrderedTreeInt(ArrayList l, Map var2ID) {
	return reduceRestrict(buildNode(l, var2ID), this, -1, -1);
    }

    public AADDRNode buildNode(ArrayList l, Map var2ID) {

	Object o = l.get(0);
	if (o instanceof String && HasOnlyDigits((String)o)) {
	    double v = (new BigInteger((String)o)).doubleValue();
	    return getDNode(v, true);
	} else if (o instanceof BigDecimal) {
	    double v = ((BigDecimal)o).doubleValue();
	    return getDNode(v, true);
	} else {
	    String var = (String)o;
	    int gid = ((Integer)var2ID.get(var)).intValue();
	    
	    // Get the var AADD
	    AADDRNode high = buildNode((ArrayList)l.get(1), var2ID);
	    AADDRNode low  = buildNode((ArrayList)l.get(2), var2ID);

	    // Return the RNode ref to the normalized INode
	    return getINode(gid, 
			    low._nRefID, high._nRefID,
			    low._dOffset, low._dMult, 
			    high._dOffset, high._dMult, 
			    true);
	}
    }

    public static boolean HasOnlyDigits(String s) {
		for (int i=0;i<s.length();i++) {
		    if (s.charAt(i) != '-' && !Character.isDigit(s.charAt(i))) {
		    	return false;
		    }
		}
		return true;
    }

    /** Build a constant ADD **/
    public static AADD GetConstantAADD(double val, ArrayList order) {
	AADD a = new AADD(order);	
	AADDRNode n = a.getDNode(val, true);
	a.setRoot(n);	

	return a;
    }

    /** Build a var ADD **/
    public static AADD GetVarAADD(int gid, double low, double high, ArrayList order) {

	if (order == null) {
	    order = new ArrayList();
	    order.add(new Integer(gid));
	}

	AADD a = new AADD(order);
	AADDRNode n = a.getINode(gid, 0, 0, low, 0.0d, high, 0.0d, true);
	a.setRoot(n);

	return a;
    }

    /** Build a var AADD **/
    public int getVarNode(int gid, double low, double high) {
	AADDRNode ret = getINode(gid, 0, 0, low, 0d, high, 0d, true);
	return addRNodeRef(ret); 
    }

    /** Build a constant ADD */
    public int getConstantNode(double val) {
	AADDRNode ret = getDNode(val, true);
	return addRNodeRef(ret); 
    }

    /** Build a var AADD **/
    public AADDRNode getVarNodeInt(int gid, double low, double high) {
	return getINode(gid, 0, 0, low, 0d, high, 0d, true);
    }

    /** Build a constant ADD */
    public AADDRNode getConstantNodeInt(double val) {
	return getDNode(val, true);
    }

    ////////////////////////////////////////////////////////////////
    //                    Miscellaneous methods
    ////////////////////////////////////////////////////////////////

    // Helper fun for formatting value range
    public ArrayList procList(ArrayList a) {
	ArrayList ret = new ArrayList();
	Iterator i = a.iterator();
	while (i.hasNext()) {
	    ret.add(_df.format(((Double)i.next()).doubleValue()));
	}
	return ret;
    }

    public Object clone() {
	return new AADD(this);
    }

    public String toString() {
	
	StringBuffer sb = new StringBuffer();

	// Show order
	sb.append("Var order:  " + _alOrder + "\n");
	sb.append("GVar level: " + _hmGVarToLevel + "\n");
	// sb.append("Val range: " + procList(getValueRange()) + "\n");

	// Recurse from the root and show each branch
	sb.append("Structure:\n[ <" + _df.format(_pRoot._dOffset) + 
		  "," + _df.format(_pRoot._dMult) + 
		  "> " + getNode(_pRoot._nRefID).toString(this, 0) + "]\n");

	return sb.toString();
    }

    public String printNode(int rid) {
	return getRNode(rid).toString(this, 0);
    }

    public void pruneReport() {
	System.out.println("Prune Report:\n-------------");
	System.out.println("TERM: " + TERM_PRUNE_CNT++);
	System.out.println("PROD: " + PROD_PRUNE_CNT++);
	System.out.println("MIN:  " + MIN_PRUNE_CNT++);
	System.out.println("MAX:  " + MAX_PRUNE_CNT++ + "\n");
	System.out.println("IDENT PRUNES:      " + IDENT_PRUNES++);
	System.out.println("PRECISION PRUNES:  " + PRECISION_PRUNES++);
	System.out.println("REDUCE CACHE HITS: " + REDUCE_CACHE_HITS++);
	System.out.println("APPLY CACHE HITS:  " + APPLY_CACHE_HITS++ + "\n");
	System.out.println("PRUNE CACHE HITS:  " + PRUNE_CACHE_HITS++);
	System.out.println("SUM CACHE HITS:    " + SUM_CACHE_HITS++);
	System.out.println("PROD CACHE HITS:   " + PROD_CACHE_HITS++);
	System.out.println("MAX CACHE HITS:    " + MAX_CACHE_HITS++);
    }

    // Helper class for comparing IDs
    public static class IDComparator
	implements Comparator {

	// For comparing two objects
	public int compare(Object o1, Object o2) {
	    return ((Integer)o1).compareTo((Integer)o2);
	}

	// For comparing Comparators (never really used!)
	public boolean equals(Object obj) {
	    return this == obj;
	}
    }
}
