// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Trajectory.java

package solution.topological.heuristic;

import gnu.trove.*;

import java.util.*;

import solution.topological.environments.POMDP;
import solution.topological.utilities.*;
import solution.topological.utilities.graph.*;
import solution.topological.utilities.graph.utils.Couple;
import solution.topological.utilities.graph.utils.StateName;
import utils.IntHash4List;

// Referenced classes of package pomdp.heuristic:
//            TopState

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 10 juil. 2009
 *
 */
public class Trajectory extends AcyclicShortestPath
{

    public boolean checkForEnd=false;
    public Trajectory(POMDP pomdp, AcyclicShortestPath path)
    {
        super(path.getVertices(), path.getSuccessors());
        depth = 0;
        bStop = false;
        bNextStop = false;
      
        floyd();
        //TODO remove this; all what should be changes is inside floyd
        //TODO remove this we already have path of type AcyclicShortestPath which is 
        //a graph containing vector of all states and vector of all successors for those states
        maxDepth = pomdp.getStateCount();
        iSolvedScc = new TIntHashSet();
        iStartBelief = BeliefStateFactory.getInstance().getInitialBeliefState();
        MDPValueFunction mdp = MDPValueFunction.getInstance(pomdp, 0.0D);
        for(int iState : path.getVertices().toNativeArray())
        {
            aGraph.removeSuccessor(getSccID(iState), getSccID(iState)); // remove auto-transition
            
//            if( mdp.getValue(iState.intValue()) != 0.0D)
            if (! pomdp.getTerminalStates().contains(iState))
            {
                new TopState(pomdp, mdp, iState);
            } else
            {
                final TIntArrayList layer = layerAt(getSccID(iState));
                layer.remove(layer.indexOf(iState));
                if(layer.isEmpty())
                {
                    for (int l = aGraph.size()-1; l>=0; l--)
                      aGraph.removeSuccessor(l, getSccID(iState));
                    
                    iSolvedScc.add(getSccID(iState));
                }
            }
        }
    }

    public void restart()
    {
        depth = 0;
        bStop = false;
        bNextStop = false;
    }

    public void update(POMDP pomdp, int iState, int iAction, double dDelta)
    {
        TopState.getState(iState).update(pomdp, mGraphT.getSuccessors(iState), iAction, dDelta);
    }

    public void update(POMDP pomdp, int iState, double dDelta)
    {
        TopState.getState(iState).update(pomdp, mGraphT.getSuccessors(iState), dDelta);
    }

    public int getStartState()
    {
        return getStartState(true);
    }

    public int getStartState(boolean dBool)
    {
        int start = -1;
        int scc = -1;
        for(TIntDoubleIterator iterator = iStartBelief.getNonZeroStates().iterator(); iterator.hasNext();)
        {
          iterator.advance();
            int s = iterator.key();
            if(start < 0)
            {
                start = s;
                scc = getSccID(s);
            } else
            if(!dBool && scc < getSccID(s))
            {
                start = s;
                scc = getSccID(s);
            }
        }

        return start;
    }

    public int getStartState(BeliefState bs)
    {
        double max = 0.0D;
        double min = 0D;
        TopState _iState = null;
        TIntDoubleIterator iStates = bs.getNonZeroEntries();
        Vector<Couple<Integer,Double>> elements = new Vector<Couple<Integer,Double>>();
        while(iStates.hasNext()) 
        {
          iStates.advance();
            _iState = TopState.getState(iStates.key());
            double value;
            if(_iState != null)
            {
                value = iStates.value() * _iState.getValue();
                value = checkSolved(_iState) ? 0.0D : value;
            } else
            {
                value = 0.0D;
            }
            if(value > 0.0D)
            {
                max += value;
                elements.add(new Couple<Integer,Double>(iStates.key(), Double.valueOf(value)));
            } else if (value<min)
              min = value;
        }
        if (elements.isEmpty())
        {
          System.err.println("No more start state !");
          iStates = bs.getNonZeroEntries();
          while(iStates.hasNext()) 
          {
            iStates.advance();
              _iState = TopState.getState(iStates.key());
              double value;
              if(_iState != null)
              {
                  value = iStates.value() * _iState.getValue();
                  value = checkSolved(_iState) ? 0.0D : value;
              } else
              {
                  value = 0.0D;
              }
              elements.add(new Couple<Integer,Double>(iStates.key(), Double.valueOf(value-min)));
              max += value-min;
          }
        }
        return sample(elements, max);
    }

    public TopState getCurrentStateObject()
    {
        return new TopState(iCurrentState);
    }

    public int getCurrentState()
    {
        return iCurrentState.getState();
    }

    public int getNextState()
    {
        return iNextState.getState();
    }

    public int getNextAction()
    {
        return iCurrentState.getAction();
    }

    public int getNextObservation()
    {
        return iCurrentState.getObservation();
    }

    public BeliefState getStartBeliefState()
    {
        return iStartBelief;
    }

    public TopState next(POMDP m_pPOMDP, BeliefState iBelief, int iState)
    {
        iNextState = TopState.getState(iState);
       
        switch(OPTION_NEXT_STATE)
        {
        case 0: // '\0'
            return next(m_pPOMDP, iBelief, iNextState);

        case 2: // '\002'
            return next(m_pPOMDP, iBelief);

        case 3: // '\003'
            return nextML(m_pPOMDP, iBelief);

        case 1: // '\001'
        	return next(m_pPOMDP, iBelief, iNextState);
        default:
            return next(m_pPOMDP, iBelief, iNextState);
        }
    }

    private TopState next(POMDP m_pPOMDP, BeliefState iBelief)
    {
        iCurrentState = iNextState;
        iNextState = null;
        double dValue = 0.0D;
        Vector<Couple<Integer,Double>> sample = new Vector<Couple<Integer,Double>>();
        for(TIntDoubleIterator iStates = iBelief.getNonZeroEntries(); iStates.hasNext(); )
        {
          iStates.advance();
            dValue += iStates.value();
            sample.add(new Couple<Integer,Double>(iStates.key(), iStates.value()));
        }

        iNextState = next(m_pPOMDP, iBelief, TopState.getState(sample(sample, dValue)));
        return iNextState;
    }

    private TopState nextML(POMDP m_pPOMDP, BeliefState iBelief)
    {
        iCurrentState = iNextState;
        iNextState = null;
        double dValue = 0.0D;
        Vector<Couple<Integer,Double>> sample = new Vector<Couple<Integer,Double>>();
        for(TIntDoubleIterator iStates = iBelief.getNonZeroEntries(); iStates.hasNext();)
        {
          iStates.advance();
            if(dValue < iStates.value())
            {
                sample.clear();
                dValue = iStates.value();
                sample.add(new Couple<Integer,Double>(iStates.key(), iStates.value()));
            } else
            if(dValue == iStates.value())
                sample.add(new Couple<Integer,Double>(iStates.key(), iStates.value()));
        }

        iNextState = next(m_pPOMDP, iBelief, TopState.getState(sample(sample, dValue * sample.size())));
        return iNextState;
    }

    private TopState next(POMDP m_pPOMDP, BeliefState bsCurrent, TopState _iNextState)
    {
        int next_;
        iCurrentState = _iNextState != null ? _iNextState : iCurrentState;
        iNextState = null;
        switch(OPTION_GOAL)
        {
        case 0: // '\0' 
            setPrioritizedGoal();
            break;

        case 1: // '\001'
            setTopologicalGoal(m_pPOMDP);
            break;

        default:
            setTopologicalGoal(m_pPOMDP);
            break;
        }
        int layer=getSccID( iCurrentState.getState() );
        int layerEnd=getSccID( TopState.getGoalState() );
       
        if (TopSearch.DISPLAY)
        System.out.println("-*-*- iStartState:" + iCurrentState.getState() +"("+ m_pPOMDP.getStateName(iCurrentState.getState())+ ")\t iGoalState:" 
            + TopState.getGoalState()+"("+ m_pPOMDP.getStateName(TopState.getGoalState()) + ") layer start " + layer + " layer goal " + layerEnd);
//        System.out.println("-*-*- iStartState:" + m_pPOMDP.getStateName(iCurrentState.getState()) + "\t iGoalState:" + m_pPOMDP.getStateName(TopState.getGoalState()) + " layer Start  " + layer + " layer goal " + layerEnd);
        
        next_ = TopState.getGoalState() >= 0 ? next(iCurrentState.getState(), TopState.getGoalState()) : TopState.getGoalState();
          
        if (next_==-1)
        {
          if (depth==1)
          {
            removePathState();
            System.err.println("Reset trajectory!!!");
            next_ = TopState.getGoalState() >= 0 ? next(iCurrentState.getState(), TopState.getGoalState()) : TopState.getGoalState();
            checkForEnd = true;
          } else
          throw new RuntimeException("No more untested successors!");
        }
        
        iNextState = TopState.getState(next_);
//        if (iNextState == null)
//          System.err.println("Next state is not implemented!!!");
        setNextAO(m_pPOMDP, bsCurrent,next_);
        
        return iNextState;
    }
    
    private void removePathState()
    {
        pathStates.clear(); 
    }

    protected void setTopologicalGoal(POMDP m_pPOMDP)
    {
      int next_;
        if(checkGoal(iCurrentState) && TopState.getGoalState() < 0) 
            TopState.setGoalState(TopState.nextWHP(IntHash4List.iterator(layerAt(getSccID(iCurrentState.getState())))));
        if(iCurrentState.getState() == TopState.getGoalState() || checkSolved(getSccID(TopState.getGoalState())))
        {
            if(TopState.getGoalState() < 0)
                if((next_ = closestSolvableScc(m_pPOMDP, iCurrentState.getState())) == -1)
                    TopState.setGoalState(-1);
                else
                    TopState.setGoalState(next_);
            setStop();
        }
    }

    protected void setStop()
    {
        if(iCurrentState.getState() == TopState.getGoalState() && bNextStop)
        {
            TopState.setGoalState(-1);
            bStop = true;
        } else
        if(iCurrentState.getState() ==TopState.getGoalState())
        {
            bNextStop = true;
        }
    }

    protected void setPrioritizedGoal()
    {
        if(TopState.getGoalState() < 0)
            TopState.setGoalState(TopState.nextWHP(reachableStates().iterator()));
        setStop();
    }

    protected TIntHashSet reachableStates()
    {
        TIntHashSet reachableStates = new TIntHashSet();
        for(int jState : getVertices().toNativeArray())
        {
            if(next(iCurrentState.getState(), jState) != -1)
                reachableStates.add(jState);
        }

        return reachableStates;
    }

    public boolean stop()
    {
    	//depth++;
        bStop = bStop || depth > maxDepth || checkSolved(iCurrentState) || iCurrentState.getNextState() < 0 || iCurrentState.getAction() < 0 || iCurrentState.getObservation() < 0;
        return bStop;
    }

    private void setNextAO(POMDP m_pPOMDP, BeliefState bsCurrent, int nextState)
    {
        int iAction = -1;
        int iObservation = -1;
        int iEndState;
        int iStartState;
        if(iNextState == null)
        {
//            iCurrentState.setAction(iAction);
//            iCurrentState.setObservation(iObservation);
//            return;
          iEndState = nextState;
        } else
          iEndState = iNextState.getState();
        iStartState = iCurrentState.getState();
        switch(OPTION_ACTION_SELECTION)
        {
        case 0: // '\0'
            iAction = bestAction(m_pPOMDP, iStartState, iEndState);
            break;

        case 1: // '\001'
            iAction = sampleAction(m_pPOMDP, iStartState, iEndState);
            break;

        case 2: // '\002'
            iAction = bestExpectedAction(m_pPOMDP, iStartState, iEndState);
            break;

        default:
            iAction = sampleAction(m_pPOMDP, iStartState, iEndState);
            break;
        }
        iCurrentState.setNextState(iEndState);
        if(iAction < 0)
        {
            iCurrentState.setAction(iAction);
            iCurrentState.setObservation(iObservation);
            return;
        }
        switch(OPTION_OBSERVATION_SELECTION)
        {
        case 0: // '\0'
            iObservation = bestObservation(m_pPOMDP, iEndState, iAction);
            break;

        case 1: // '\001'
            iObservation = sampleObservation(m_pPOMDP, bsCurrent, iAction);
            break;

        case 2: // '\002'
            iObservation = sampleObservation(m_pPOMDP, iEndState, iAction);
            break;

        case 3: // '\003'
            iObservation = sampleObservation(m_pPOMDP, bsCurrent, iEndState, iAction);
            break;

        default:
            iObservation = sampleObservation(m_pPOMDP, iEndState, iAction);
            break;
        }
        iCurrentState.setAction(iAction);
        iCurrentState.setObservation(iObservation);
    }

    public static int sample(Vector<Couple<Integer, Double>> elements, double max)
    {
        int element = -1;
        double rnd = (new Random()).nextDouble() * max;
        for(double sum = 0.0D; rnd > sum; sum += elements.get(element).second)
            element++;

        return element < 0 ? element : elements.get(element).first;
    }

    public static int sample(TIntArrayList elements)
    {
        int element = -1;
        double rnd = (new Random()).nextDouble() * elements.size();
        for(double sum = 0.0D; rnd > sum; sum++)
            element++;

        return element < 0 ? element : elements.get(element);
    }

    protected int bestAction(POMDP m_pPOMDP, int iCurrentState, int iNextState)
    {
        int bestAction = -1;
        for(int a = 0; a < m_pPOMDP.getActionCount(); a++)
        {
            double dProb = m_pPOMDP.tr(iCurrentState, a, iNextState);
            if(bestAction < 0 || dProb > m_pPOMDP.tr(iCurrentState, bestAction, iNextState))
                bestAction = a;
        }

        return bestAction;
    }

    protected int bestExpectedAction(POMDP m_pPOMDP, int iCurrentState, int iNextState)
    {
        double dBestValue = 0.0D;
        TIntArrayList bestAction = new TIntArrayList();
        for(int a = 0; a < m_pPOMDP.getActionCount(); a++)
        {
            double dProb = m_pPOMDP.tr(iCurrentState, a, iNextState);
            if(dProb > 0.0D)
            {
                double dValue = TopState.valueAt(iCurrentState, a);
                dValue += dProb * TopState.getBestValueAt(iNextState);
                if(bestAction.isEmpty() || dValue > dBestValue)
                {
                    bestAction.clear();
                    bestAction.add(a);
                    dBestValue = dValue;
                } else
                if(dValue == dBestValue)
                    bestAction.add(a);
            }
        }

        return sample(bestAction);
    }

    protected int sampleAction(POMDP m_pPOMDP, int iCurrentState, int iNextState)
    {
        double max = 0.0D;
        Vector<Couple<Integer, Double>> elements = new Vector<Couple<Integer,Double>>();
        for(int a = 0; a < m_pPOMDP.getActionCount(); a++)
        {
            double dProb = m_pPOMDP.tr(iCurrentState, a, iNextState);
            if(dProb > 0.0D)
            {
                max += dProb;
                elements.add(new Couple<Integer, Double>(Integer.valueOf(a), Double.valueOf(dProb)));
            }
        }

        return sample(elements, max);
    }

    protected int bestObservation(POMDP m_pPOMDP, int iNextState, int iAction)
    {
        int bestObservation = -1;
        for(int o = 0; o < m_pPOMDP.getObservationCount(); o++)
        {
            double dProb = m_pPOMDP.O(iAction, iNextState, o);
            if(bestObservation < 0 || dProb > m_pPOMDP.O(iAction, iNextState, bestObservation))
                bestObservation = o;
        }

        return bestObservation;
    }

    protected int sampleObservation(POMDP m_pPOMDP, int iNextState, int iAction)
    {
        double max = 0.0D;
        Vector<Couple<Integer,Double>> elements = new Vector<Couple<Integer,Double>>();
        for(int o = 0; o < m_pPOMDP.getObservationCount(); o++)
        {
            double dProb = m_pPOMDP.O(iAction, iNextState, o);
            if(dProb > 0.0D)
            {
                max += dProb;
                elements.add(new Couple<Integer, Double>(Integer.valueOf(o), Double.valueOf(dProb)));
            }
        }

        return sample(elements, max);
    }

    protected int sampleObservation(POMDP m_pPOMDP, BeliefState bsCurrent, int iAction)
    {
        double max = 0.0D;
        Vector<Couple<Integer, Double>> elements = new Vector<Couple<Integer, Double>>();
        for(int iObservation = 0; iObservation < m_pPOMDP.getObservationCount(); iObservation++)
        {
            double dProb = bsCurrent.probabilityOGivenA(iAction, iObservation);
            if(dProb > 0.0D)
            {
                max += dProb;
                elements.add(new Couple<Integer, Double>(Integer.valueOf(iObservation), Double.valueOf(dProb)));
            }
        }

        return sample(elements, max);
    }

    protected int sampleObservation(POMDP m_pPOMDP, BeliefState bsCurrent, int iNextState, int iAction)
    {
        double max = 0.0D;
        Vector<Couple<Integer, Double>> elements = new Vector<Couple<Integer,Double>>();
        for(int o = 0; o < m_pPOMDP.getObservationCount(); o++)
        {
            double dProb = bsCurrent.valueAt(iNextState) * m_pPOMDP.O(iAction, iNextState, o);
            if(dProb > 0.0D)
            {
                max += dProb;
                elements.add(new Couple<Integer, Double>(Integer.valueOf(o), Double.valueOf(dProb)));
            }
        }

        return sample(elements, max);
    }

    protected boolean checkGoal(int iSCC)
    {
        return iSCC >= 0 ? aGraph.getSuccessors(iSCC).isEmpty() && !iSolvedScc.contains(Integer.valueOf(iSCC)) : false;
    }

    protected boolean checkGoal(TopState iState)
    {
        int iSCC = 0;
        iSCC = getSccID(iState.getState());
        return checkGoal(iSCC);
    }

    protected boolean checkSolved(int iSCC)
    {
        return iSCC >= 0 ? iSolvedScc.contains(Integer.valueOf(iSCC)) : true;
    }

    protected boolean checkSolved(TopState iState)
    {
        int iSCC = getSccID(iState.getState());
        return checkSolved(iSCC);
    }
    
    //TODO no call
    protected Integer closestSolvedScc(int s)
    {
        double maxValue = (-1.0D / 0.0D);
        TIntHashSet goals = new TIntHashSet();
        for(int i = 0; i < aGraph.size(); i++)
        {
            int scc = ((Integer)aGraph.get(i)).intValue();
            if(checkSolved(scc))
            {
                for(int s2 : layerAt(scc).toNativeArray())
                {
                    if(maxValue < TopState.getBestValueAt(s2))
                    {
                        maxValue = TopState.getBestValueAt(s2);
                        goals.clear();
                    }
                    if(maxValue == TopState.getBestValueAt(s2))
                        goals.add(s2);
                }

            }
        }
        
        return closest(s, goals);
    }

    protected int closestSolvableScc(POMDP m_pPOMDP, int s)
    {   	
        TIntHashSet goals = new TIntHashSet();
     
        for(int i = 0; i < aGraph.size(); i++)
        {
            int scc = aGraph.get(i);
            if(checkGoal(scc)){
                goals.addAll(layerAt(scc).toNativeArray());
            }
        }
// Here : goals contains one list of non-goal states that have no successors

//        goals.addAll(m_pPOMDP.getTerminalStates().toNativeArray());
//        for(int i = 0; i < aGraph.size(); i++)
//        {
//            int scc = aGraph.get(i);
//            if (iSolvedScc.contains(aGraph.get(i)))
//              goals.addAll(layerAt(scc).toNativeArray());
//        }
        
// Here : goals contains one list of goal states : terminal states + solved layer's states
        switch(OPTION_NEXT_GOAL)
        {
        case 0: // '\0'
            return closest(m_pPOMDP, s, goals);

        case 1: // '\001'
            return sample(closestSet(s, goals));

        case 2: // '\002'
            return TopState.nextWHP(IntHash4List.iterator(closestSet(s, goals)));

        case 3: // '\003'
            return closest( s, TopState.nextSetWHP(IntHash4List.iterator(closestSet(s, goals))));
        }
        return closest(s, goals);
    }

    @Override
    public void setAcyclicGraph()
    {
    	solution.topological.utilities.graph.Graph.Kosaraju kosaraju = new Kosaraju(this);
        aGraph = new AcyclicGraph(this, kosaraju.getID(), kosaraju.scc());
        
        Vector<TIntArrayList> v = kosaraju.scc();
        for (int i = 0; i<aGraph.size(); i++){
        	System.out.println("layer = " + i + " size = " +v.elementAt(i).size() + "\tLinks = " + Arrays.toString(aGraph.getSuccessors(i).toArray()));
        }
        
        for(int scc : aGraph.getVertices().toNativeArray())
          aGraph.removeSuccessor(scc, scc);
       
       
        aGraph.floyd();
        
    }

    @Override
    public void floyd()
    {
        iStateNext = new TIntObjectHashMap<TIntIntHashMap>();
        dStateDist = new TIntObjectHashMap<TIntDoubleHashMap>();
        System.out.println("################### Start setAcyclicGraph ###################");
        setAcyclicGraph();
        System.out.println("################### Start transposeGraph ###################");
        transposeGraph();
//        System.out.println("################### Start transposeAcyclicGraph ###################");
//        transposeAcyclicGraph(); // never used

        System.out.println("################### Start Floyd algorithm ###################");
        for(int iLayer = aGraph.size() - 1; iLayer >= 0; iLayer--){
        	System.out.println("Layer "+iLayer);
          floyd(layerAt(iLayer));
        }
        
        System.out.println("################### Start borderStates ###################");
        borderStates();
        freeTransposed();
       
    }
    
    public void floyd(TIntArrayList states){
        TIntIterator iStates = IntHash4List.iterator(states);
        Double M = Double.valueOf(1.7976931348623157E+308D);
        int iState;
        for(; iStates.hasNext(); addStateDist(iState, iState, 0.0D))
        {
            iState = iStates.next();
            int iSuccessor;
            
            for(TIntIterator iSuccessors = getSuccessors(iState).iterator(); iSuccessors.hasNext(); addStateNext(Integer.valueOf(iState), Integer.valueOf(iSuccessor), Integer.valueOf(iSuccessor)))
            {
            	
                iSuccessor = iSuccessors.next();
                if(iState == iSuccessor)
                    addStateDist(iState, iSuccessor, 0.0D);
                else
                  addStateDist(iState, iSuccessor, 1.0D);
            }
        }
	
        for(TIntIterator kStates = IntHash4List.iterator(states); kStates.hasNext();)
        {
            int k = kStates.next();
         
            for(iStates = IntHash4List.iterator(states); iStates.hasNext();)
            {
                int i = iStates.next();
                double dik = getDistance(i, k);
                if(dik != M.doubleValue())
                {
                
                    for(TIntIterator jStates = IntHash4List.iterator(states); jStates.hasNext();)
                    {
                        int j = jStates.next();
                        double dkj = getDistance(k, j);
                     
                        if(dkj != M.doubleValue())
                        {
                            double u = dik + dkj;
                            if(u < getDistance(i, j))
                            {
                                addStateDist(i, j, u);
                                addStateNext(i, j, getNextState(i, k));
                            }
                        }
                    } // for j
                }
            } // for i
        } // for k
    } // floyd(TIntArrayList)

    protected TopState iNextState;
    protected TopState iCurrentState;
    protected BeliefState iStartBelief;
    protected TIntHashSet iSolvedScc;
    protected int depth;
    protected int maxDepth;
    public boolean bStop;
    public boolean bNextStop;
    public static int OPTION_NEXT_GOAL = -1;
    public static final int NEXT_CLOSEST_GOAL = 0;
    public static final int NEXT_CLOSEST_SAMPLE_GOAL = 1;
    public static final int NEXT_GOAL_WITH_HIGHEST_PRIORITY = 2;
    public static final int NEXT_CLOSEST_GOAL_WITH_HIGHEST_PRIORITY = 3;
    public static final int NEXT_STATE = 0;
    public static final int BELIEF_NEXT_STATE = 2;
    public static final int ML_NEXT_STATE = 3;
    public static int OPTION_NEXT_STATE = -1;
    public static int OPTION_ACTION_SELECTION = -1;
    public static final int BEST_EXPECTED_ACTION = 2;
    public static final int SAMPLE = 1;
    public static final int BEST_OBSERVATION = 0;
    public static final int SAMPLE_OBSERVATION_2 = 2;
    public static final int SAMPLE_OBSERVATION_3 = 3;
    public static int OPTION_OBSERVATION_SELECTION = -1;
    public static int OPTION_GOAL;
    public static final int PRIORITIZED_GOAL = 0;
    public static final int TOPOLOGICAL_GOAL = 1;

}
