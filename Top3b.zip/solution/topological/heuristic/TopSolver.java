// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TopSolver.java

package solution.topological.heuristic;


import java.io.IOException;
import java.util.Vector;

import solution.topological.algorithms.ValueIteration;
import solution.topological.environments.POMDP;
import solution.topological.utilities.*;

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 9 juil. 2009
 *
 */
public class TopSolver
{

    public TopSolver()
    {//
    }

    public static double getTargetValue(String sModelName)
    {
        double dTargetADR = 100D;
        if(sModelName.equals("heaven-hell"))
            dTargetADR = 100D;
        if(sModelName.equals("cit"))
            dTargetADR = 0.80000000000000004D;
        if(sModelName.equals("fourth"))
            dTargetADR = 100D;
        if(sModelName.equals("sunysb"))
            dTargetADR = 100D;
        if(sModelName.equals("machine"))
            dTargetADR = 1.0D;
        if(sModelName.equals("baseball"))
            dTargetADR = 1.0D;
        if(sModelName.equals("aloha.30"))
            dTargetADR = 1.0D;
        if(sModelName.equals("aloha.10"))
            dTargetADR = 1.0D;
        if(sModelName.equals("GuyProblem"))
            dTargetADR = 1.0D;
        if(sModelName.equals("PineauProblem"))
            dTargetADR = 100D;
        if(sModelName.equals("three_state"))
            dTargetADR = 3D;
        if(sModelName.equals("hallway"))
            dTargetADR = 0.5D;
        if(sModelName.equals("hallway2"))
            dTargetADR = 0.29999999999999999D;
        if(sModelName.equals("tigerGrid"))
            dTargetADR = 0.60999999999999999D;
        if(sModelName.equals("tagAvoid"))
            dTargetADR = -6.4000000000000004D;
        if(sModelName.equals("RockSample_4_4"))
          dTargetADR = 17.015;//.809999999999999D;
        if(sModelName.equals("RockSample_5_5"))
            dTargetADR = 18D;
        if(sModelName.equals("NoisyRockSample_4_4"))
            dTargetADR = 10.300000000000001D;
        if(sModelName.equals("NoisyRockSample_5_5"))
            dTargetADR = 10.300000000000001D;
        if(sModelName.equals("RockSample_5_7"))
            dTargetADR = 22D;
        if(sModelName.equals("RockSample_7_8"))
            dTargetADR = 7D;
        if(sModelName.equals("RockSample_8_8"))
            dTargetADR = 19.5D;
        if(sModelName.equals("RockSample_10_3"))
            dTargetADR = 14D;
        if(sModelName.equals("HH"))
            dTargetADR = 0.56000000000000005D;
        if(sModelName.equals("network"))
            dTargetADR = 40D;
        if(sModelName.equals("Mit"))
            dTargetADR = 0.85999999999999999D;
        if(sModelName.equals("pentagon"))
            dTargetADR = 0.76000000000000001D;
        if(sModelName.equals("hallway-layered-10"))
            dTargetADR = 0.37D;
        if(sModelName.equals("hallway-layered-15"))
            dTargetADR = 0.34999999999999998D;
        if(sModelName.equals("hallway-layered-20"))
            dTargetADR = 0.22D;
        if(sModelName.equals("hallway2.10"))
            dTargetADR = 0.44D;
        if(sModelName.equals("hallway2.13"))
            dTargetADR = 0.44D;
        if(sModelName.equals("hallway2.17"))
            dTargetADR = 0.23999999999999999D;
        if(sModelName.equals("hallway2.18"))
            dTargetADR = 0.23999999999999999D;
        if(sModelName.equals("cit-layered-10"))
            dTargetADR = 0.72999999999999998D;
        if(sModelName.equals("Mit-layered-10"))
            dTargetADR = 0.90000000000000002D;
        if(sModelName.equals("pentagon-layered-10"))
            dTargetADR = 0.28999999999999998D;
        
        return dTargetADR; 
    }

    public static void main(String args[])
        throws IOException, InvalidModelFileFormatException
    {
    	String fileName = "";
    	
    	MDPValueFunction.persistQValues(true);
    	    	
		/////////////////////////////////////////////////////////////////////////////////
    	/////////////////////////////////////////////////////////////////////////////////
    	/////////in case of changing environment variables here recreate the POMDP file//
    	/////////////////////////////////////////////////////////////////////////////////

        JProf.getCurrentThreadCpuTimeSafe();
        String sMethodName = "TopSearch";
        
        String dDirectory = (new StringBuilder(String.valueOf(System.getProperty("user.dir")))).append("/").toString();
        
        if (fileName.equals(""))
          fileName = "RockSample_4_4";

        String aProblemNames[] = { fileName };
        
        String sModelName = aProblemNames[0];
        double dTargetADR = getTargetValue(sModelName);
        POMDP pomdp = new POMDP();
        
//        dTargetADR = 100;
        
        pomdp.initRandomGenerator(0L);
        pomdp.setRandomSeed(0L);
        ValueIteration.setBlindPolicyValueFunctionFileName((new StringBuilder(String.valueOf(dDirectory))).append(sModelName).append("BlindPolicy.xml").toString());
        long time = System.currentTimeMillis();
        pomdp.load((new StringBuilder(String.valueOf(dDirectory))).append(sModelName).append(".POMDP").toString());
        System.err.println("Load time is "+(System.currentTimeMillis()-time));
        
        pomdp.computeValueFunction(sMethodName, new Vector<BeliefState>(), dTargetADR);
        System.err.println("Total time is "+(System.currentTimeMillis()-time));
        
//        pomdp.setDiscountFactor(1.0d);
//        pomdp.simulateValueIteration();
       
    }
    

}
