// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TopSearch.java

package solution.topological.heuristic;

import gnu.trove.TIntDoubleIterator;
import gnu.trove.TIntHashSet;

import java.util.*;

import solution.topological.algorithms.ValueIteration;
import solution.topological.environments.LayeredPOMDP;
import solution.topological.environments.POMDP;
import solution.topological.utilities.*;
import solution.topological.utilities.datastructures.IntVectorFactory;
import solution.topological.utilities.datastructures.VectorBase;

// Referenced classes of package pomdp.heuristic:
//            Trajectory, TopState

/**
 * Converted to trove lib 
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 9 juil. 2009
 *
 */
public class TopSearch extends ValueIteration
{
  
  public static final boolean DISPLAY = false;
  public static final boolean DISPLAY_ADR = false;
  
    protected class StateBeliefPair implements Comparable<StateBeliefPair>
    {

        public int compareTo(StateBeliefPair arg0)
        {
            return iState != arg0.iState ? Integer.valueOf(iState).compareTo(arg0.iState) : iBeliefState.compareTo(arg0.iBeliefState);
        }

        int iState;
        BeliefState iBeliefState;

        public StateBeliefPair(int _iState, BeliefState _iBeliefState)
        {
            super();
            iState = _iState;
            iBeliefState = _iBeliefState;
        }
    }


    public TopSearch(POMDP pomdp)
    {
        super(pomdp);
        bDone = false;
        dDelta = 1.0D;
        pComputedADRs = new Pair<Double,Double>(new Double(0.0D), new Double(0.0D));
        m_vStates = new TIntHashSet();
        System.out.println("################### Start trajectory ###################");
        sTrajectory = new Trajectory(pomdp, pomdp.getAcyclicShortestPath());       
        
//        ValueIteration.g_cTrials = 100;
        STRATEGY_OPTIONS = STRATEGY_BACKWARD;
        UPDATE_OPTIONS = ALL_STATE_BELIEF_UPDATE;
        RUNNING_OPTIONS = ONLINE_SAMPLES;
        Trajectory.OPTION_NEXT_GOAL = Trajectory.NEXT_CLOSEST_GOAL;
        Trajectory.OPTION_NEXT_STATE = Trajectory.NEXT_STATE;
        Trajectory.OPTION_ACTION_SELECTION = 0;
        Trajectory.OPTION_OBSERVATION_SELECTION = Trajectory.SAMPLE;
        Trajectory.OPTION_OBSERVATION_SELECTION = Trajectory.BEST_OBSERVATION; // XXX .SAMPLE
        Trajectory.OPTION_GOAL = Trajectory.TOPOLOGICAL_GOAL;
        TopState.UPDATE_FUNCTION_OPTION = TopState.UPDATE_2;
    }

    @Override
    public void valueIteration(Vector<BeliefState> vBeliefPoints, int cMaxSteps, double _dEpsilon, POMDP pomdp, double _dTargetValue)
    {
        dEpsilon = _dEpsilon;
        dTargetValue = _dTargetValue;
        System.out.println("//+------------------------------------+//");
        System.out.println((new StringBuilder("//|\t   Solver.name :: ")).append(getName()).append("    |//").toString());
        System.out.println((new StringBuilder("//|\t      Scc.number ::  ")).append(sTrajectory.getAcyclicGraph().size()).append("         |//").toString());
        System.out.println((new StringBuilder("//|\t    Scc.epsilon ::  ")).append(dEpsilon).append("       |//").toString());
        System.out.println("//+------------------------------------+//");
        m_cElapsedExecutionTime = 0L;
        m_cCPUExecutionTime = 0L;
        rtRuntime = Runtime.getRuntime();
        lStartTime = System.currentTimeMillis();
        lCPUTimeBefore = JProf.getCurrentThreadCpuTimeSafe();
        AlphaVector.initCurrentDotProductCount();
        switch(RUNNING_OPTIONS)
        {
        case 0: // '\0'
            runONLINE_SAMPLES();
            break;

        case 1: // '\001'
            runOFFLINE_SAMPLES();
            break;

        default:
            runONLINE_SAMPLES();
            break;
        }
        m_cElapsedExecutionTime /= 1000L;
        m_cCPUExecutionTime /= 1000L;
        if(BeliefStateFactory.getInstance() != null)
          System.out.println((new StringBuilder("Finished ")).append(getName()).append(" - time : ").append(m_cElapsedExecutionTime).append(" |BS| = ").append(vBeliefPoints.size()).append(" |V| = ").append(m_vValueFunction.size()).append(" V(b0) = ").append(round(m_vValueFunction.valueAt(BeliefStateFactory.getInstance().getInitialBeliefState()), 2)).append(" backups = ").append(m_cBackups).append(" GComputations = ").append(AlphaVector.getGComputationsCount()).toString());
    }

    protected void runONLINE_SAMPLES()
    {
        int s = sTrajectory.getStartState();
        sTrajectory.checkForEnd = false;
        previousADR = Double.NEGATIVE_INFINITY;
        try
        {
        do
        {
            lStartTime = System.currentTimeMillis();
            lCPUTimeBefore = JProf.getCurrentThreadCpuTimeSafe();
            try
            {
            trialRecurse(s, sTrajectory.getStartBeliefState());
            s = sTrajectory.getStartState(sTrajectory.getStartBeliefState());
            } finally
            {
            lCurrentTime = System.currentTimeMillis();
            lCPUTimeAfter = JProf.getCurrentThreadCpuTimeSafe();
            m_cElapsedExecutionTime += lCurrentTime - lStartTime;
            m_cCPUExecutionTime += (lCPUTimeAfter - lCPUTimeBefore) / 0xf4240L;
            lCPUTimeTotal += lCPUTimeAfter - lCPUTimeBefore;
            rtRuntime.gc();
            }
        } while(!stoppingCriteria(s));
        } catch (OutOfMemoryError err)
        {
          MDPValueFunction.clear();
          LayeredPOMDP.clear();
          IntVectorFactory.clear();
          VectorBase.clearStatic();
          AlphaVector.clear();
          BeliefState.clearStatic();
          FunctionChange.clear();
          //BeliefStateFactory.clearStatic();
          LinearValueFunctionApproximation.clearStatic();
          QuadraticFunction.clear();
          TabularAlphaVector.clearStatic();
          err.printStackTrace();
          rtRuntime.gc();
          System.runFinalization();
          rtRuntime.gc();
        }
    }

    protected void runOFFLINE_SAMPLES()
    {
        for(TIntDoubleIterator iterator = sTrajectory.getStartBeliefState().getNonZeroStates().iterator(); iterator.hasNext(); sTrajectory.restart())
        {
          iterator.advance();
            int s = iterator.key(); 
            trialRecurse(s, sTrajectory.getStartBeliefState());
        }

label0:
        do
        {
            for(int iLayer = 0; iLayer < sTrajectory.getAcyclicGraph().size(); iLayer++)
            {
                lStartTime = System.currentTimeMillis();
                lCPUTimeBefore = JProf.getCurrentThreadCpuTimeSafe();
                double dError = improveValueFunctionPBVI(iSccBeliefStates[iLayer]);
                lCurrentTime = System.currentTimeMillis();
                lCPUTimeAfter = JProf.getCurrentThreadCpuTimeSafe();
                m_cElapsedExecutionTime += lCurrentTime - lStartTime;
                m_cCPUExecutionTime += (lCPUTimeAfter - lCPUTimeBefore) / 0xf4240L;
                lCPUTimeTotal += lCPUTimeAfter - lCPUTimeBefore;
                rtRuntime.gc();
                if(stoppingCriteria(sTrajectory.getStartState()))
                    break label0;
                System.out.println((new StringBuilder("\n-*-*-*- Layer size: ")).append(iSccBeliefStates[iLayer].size()).append("\tiLayer : ").append(iLayer).append(" dError = ").append(dError).append(" done.").toString());
            }

        } while(!stoppingCriteria(sTrajectory.getStartState()));
    }

    protected double improveValueFunctionPBVI(HashSet<BeliefState> vBeliefPoints)
    {
        int iBeliefState = 0;
        BeliefState bsCurrent = null;
        Iterator<BeliefState> m_itCurrentIterationPoints = null;
        AlphaVector avBackup = null;
        AlphaVector avNext = null;
        AlphaVector avCurrentMax = null;
        double dMaxDelta = 1.0D;
        double dDelta = 0.0D;
        double dBackupValue = 0.0D;
        double dValue = 0.0D;
        m_itCurrentIterationPoints = vBeliefPoints.iterator();
        dMaxDelta = 0.0D;
        while(m_itCurrentIterationPoints.hasNext()) 
        {
            bsCurrent = m_itCurrentIterationPoints.next();
            avCurrentMax = m_vValueFunction.getMaxAlpha(bsCurrent);
            avBackup = backup(bsCurrent);
            dBackupValue = avBackup.dotProduct(bsCurrent);
            dValue = avCurrentMax.dotProduct(bsCurrent);
            dDelta = dBackupValue - dValue;
            if(dDelta > dMaxDelta)
            {
                dMaxDelta = dDelta;
            }
            if(dDelta > 0.0D)
                avNext = avBackup;
            else
            if(m_vValueFunction.contains(avCurrentMax))
            {
                avNext = null;
            } else
            {
                avNext = avCurrentMax;
                avNext.setWitness(bsCurrent);
            }
            if(avNext != null)
                m_vValueFunction.addPrunePointwiseDominated(avNext);
            iBeliefState++;
        }
        if(!m_itCurrentIterationPoints.hasNext())
            m_itCurrentIterationPoints = null;
        return dMaxDelta;
    }

    protected void trialRecurse(int s, BeliefState bs)
    {
        switch(STRATEGY_OPTIONS)
        {
        case 0: // '\0'
            trialRecurseF(s, bs);
            break;

        case 1: // '\001'
            trialRecurseB(s, bs);
            break;

        case 2: // '\002'
            trialRecurseFB(s, bs);
            break;

        default:
            trialRecurseFB(s, bs);
            break;
        }
    }

    protected void trialRecurseFB(int s, BeliefState bs)
    {
        sTrajectory.next(m_pPOMDP, bs, s);
        TopState iCurrentState = sTrajectory.getCurrentStateObject();
        double dDelta = updateOptions(iCurrentState.getState(), iCurrentState.getAction(), bs);
        System.out.println((new StringBuilder()).append(iCurrentState).append("\t\tdDelta=").append(dDelta).toString());
        if(sTrajectory.stop())
        {
            return;
        } else
        {
            trialRecurse(iCurrentState.getNextState(), bs.nextBeliefState(iCurrentState.getAction(), iCurrentState.getObservation()));
            dDelta = updateOptions(iCurrentState.getState(), iCurrentState.getAction(), bs);
            System.out.println((new StringBuilder()).append(iCurrentState).append("\t\tdDelta=").append(dDelta).toString());
            return;
        }
    }

    protected void trialRecurseF(int s, BeliefState bs)
    {
        sTrajectory.next(m_pPOMDP, bs, s);
        TopState iCurrentState = sTrajectory.getCurrentStateObject();
        double dDelta = updateOptions(iCurrentState.getState(), iCurrentState.getAction(), bs);
        System.out.println((new StringBuilder()).append(iCurrentState).append("\t\tdDelta=").append(dDelta).toString());
        if(sTrajectory.stop())
        {
            return;
        } else
        {
            trialRecurse(iCurrentState.getNextState(), bs.nextBeliefState(iCurrentState.getAction(), iCurrentState.getObservation()));
            return;
        }
    }

    Stack<TopState> stackTS = new Stack<TopState>();
    Stack<BeliefState> stackBS = new Stack<BeliefState>();
    
  protected void trialRecurseB(int s, BeliefState bs)
  {
    TopState iCurrentState;
    double delta;
    do
    {
      try
      {
        sTrajectory.depth++;
        if (DISPLAY) //Abir print test
          if (bs.getNonZeroEntriesCount()<5)
            System.out.println("-*-*- state:" + s + "\tBeliefState=" + bs.toString() + " depth="+sTrajectory.depth);
          else
            System.out.println("-*-*- state:" + s + "\tBeliefState_size=" + bs.getNonZeroEntriesCount() + " depth="+sTrajectory.depth);
        if (m_pPOMDP.getTerminalStates().contains(s))
        {
          sTrajectory.bStop = false;
          // return; // removed with recursive call
        } else
        {
          sTrajectory.next(m_pPOMDP, bs, s);
          if (sTrajectory.stop())
          {
            sTrajectory.bStop = false;
            //return; // removed with recursive call
          } else
          {
            iCurrentState = sTrajectory.getCurrentStateObject();
            if (DISPLAY)
              System.out.println(iCurrentState.toString());
            int act = iCurrentState.getAction();
            
            //trialRecurseB(iCurrentState.getNextState(), bs.nextBeliefState(act,iCurrentState.getObservation()));
            stackTS.add(iCurrentState);
            stackBS.add(bs);
            s = iCurrentState.getNextState();
            bs = bs.nextBeliefState(act, iCurrentState.getObservation());
            continue; // Starts the while again, simulating recursive call
          } // if ! stop
        } // if ! terminal state
      } catch (RuntimeException ex)
      {
        if (ex.getMessage()!=null && !ex.getMessage().equals("No more untested successors!"))
        {
          ex.printStackTrace();
          System.exit(1);
        }
        if (DISPLAY)
          System.out.println("Up one level");
      }
      sTrajectory.depth--;
      iCurrentState = stackTS.pop();
      bs = stackBS.pop();
      delta = updateOptions(iCurrentState.getState(), iCurrentState.getAction(), bs);
      if (DISPLAY)
        System.out.println((new StringBuilder()).append(iCurrentState)
          .append("\t\tdDelta=").append(delta).append("\t\tDepth=").append(
              sTrajectory.depth).toString());
      // return; // removed with recursive call
    } while (! stackTS.empty());
  } // TrialRecurseB

    protected double updateOptions(int s, int a, BeliefState bs)
    {
        double dDelta = 0.0D;
        if(s < 0 || a < 0)
            return dDelta;
        switch(UPDATE_OPTIONS)
        {
        case 0: // '\0'
            dDelta = update(s, a, bs);
            break;

        case 1: // '\001'
            dDelta = updateOSB(s, a, bs);
            break;

        case 2: // '\002'
            dDelta = updateASB(s, a, bs);
            break;

        case 3: // '\003'
            dDelta = updateABS(s, a, bs);
            break;

        case 4: // '\004'
            dDelta = updateOBS(s, a, bs);
            break;

        case 5: // '\005'
            updateBSS(s, a, bs);
            break;

        default:
            dDelta = updateOBS(s, a, bs);
            break;
        }
        return dDelta;
    }

    protected double updateBSS(int s, int a, BeliefState bs)
    {
        if(iSccBeliefStates == null)
        {
            iBeliefStates = new HashSet<BeliefState>();
            iSccBeliefStates = new HashSet[sTrajectory.getAcyclicGraph().size()];
            for(int i = 0; i < sTrajectory.getAcyclicGraph().size(); i++)
                iSccBeliefStates[i] = new HashSet<BeliefState>();

        }
        if(bs != null && !iBeliefStates.contains(bs))
        {
            iBeliefStates.add(bs);
            iSccBeliefStates[sTrajectory.getSccID(Integer.valueOf(s))].add(bs);
            iBeliefStates.add(bs);
        }
        BeliefState bsDeterministic = getDeterministicBeliefState(s);
        if(bsDeterministic != null && !iBeliefStates.contains(bsDeterministic))
        {
            iBeliefStates.add(bs);
            iSccBeliefStates[sTrajectory.getSccID(Integer.valueOf(s))].add(bsDeterministic);
        }
        return 0.0D;
    }

    protected double updateASB(int s, int a, BeliefState bs)
    {
        AlphaVector avBackup = null;
        double dPreviousValue = 0.0D;
        double dNewValue = 0.0D;
        double delta = 0.0D;
        double mDelta = 0.0D;
        avBackup = backup(bs);
        dNewValue = avBackup.dotProduct(bs);
        dPreviousValue = m_vValueFunction.valueAt(bs);
        mDelta = dNewValue - dPreviousValue;
        if(mDelta > dEpsilon)
            m_vValueFunction.addPrunePointwiseDominated(avBackup);
        else
            avBackup.release();
        BeliefState bsDeterministic = getDeterministicBeliefState(s);
        avBackup = backup(bsDeterministic);
        dPreviousValue = m_vValueFunction.valueAt(bsDeterministic);
        dNewValue = avBackup.dotProduct(bsDeterministic);
        delta = dNewValue - dPreviousValue;
        if(delta > dEpsilon)
            m_vValueFunction.addPrunePointwiseDominated(avBackup);
        else
            avBackup.release();
        sTrajectory.update(m_pPOMDP, s, a, Math.max(mDelta, delta));
        return Math.max(mDelta, delta);
    }

    protected double updateABS(int s, int a, BeliefState bs)
    {
        AlphaVector avBackup = null;
        double dPreviousValue = 0.0D;
        double dNewValue = 0.0D;
        double delta = 0.0D;
        double mDelta = 0.0D;
        BeliefState bsDeterministic = getDeterministicBeliefState(s);
        avBackup = backup(bsDeterministic);
        dPreviousValue = m_vValueFunction.valueAt(bsDeterministic);
        dNewValue = avBackup.dotProduct(bsDeterministic);
        delta = dNewValue - dPreviousValue;
        if(delta > dEpsilon)
            m_vValueFunction.addPrunePointwiseDominated(avBackup);
        else
            avBackup.release();
        avBackup = backup(bs);
        dNewValue = avBackup.dotProduct(bs);
        dPreviousValue = m_vValueFunction.valueAt(bs);
        mDelta = dNewValue - dPreviousValue;
        if(mDelta > dEpsilon)
            m_vValueFunction.addPrunePointwiseDominated(avBackup);
        else
            avBackup.release();
        sTrajectory.update(m_pPOMDP, s, a, Math.max(mDelta, delta));
        return Math.max(mDelta, delta);
    }

    protected double updateOBS(int s, int a, BeliefState bs)
    {
        AlphaVector avBackup = null;
        double dPreviousValue = 0.0D;
        double dNewValue = 0.0D;
        double delta = 0.0D;
        double mDelta = 0.0D;
        if(TopState.getBestValueAt(s) > 0.0D)
        {
            avBackup = backup(bs);
            dNewValue = avBackup.dotProduct(bs);
            dPreviousValue = m_vValueFunction.valueAt(bs);
            mDelta = dNewValue - dPreviousValue;
            if(mDelta > dEpsilon)
                m_vValueFunction.addPrunePointwiseDominated(avBackup);
            else
                avBackup.release();
        }
        if(!m_vStates.contains(s))
        {
            m_vStates.add(s);
            BeliefState bsDeterministic = getDeterministicBeliefState(s);
            avBackup = backup(bsDeterministic);
            dPreviousValue = m_vValueFunction.valueAt(bsDeterministic);
            dNewValue = avBackup.dotProduct(bsDeterministic);
            delta = dNewValue - dPreviousValue;
            if(delta > dEpsilon)
                m_vValueFunction.addPrunePointwiseDominated(avBackup);
            else
                avBackup.release();
        }
        sTrajectory.update(m_pPOMDP, s, a, Math.max(mDelta, delta));
        return Math.max(mDelta, delta);
    }

    protected double updateOSB(int s, int a, BeliefState bs)
    {
        AlphaVector avBackup = null;
        double dPreviousValue = 0.0D;
        double dNewValue = 0.0D;
        double delta = 0.0D;
        double mDelta = 0.0D;
        if(!m_vStates.contains(s))
        {
            m_vStates.add(s);
            BeliefState bsDeterministic = getDeterministicBeliefState(s);
            avBackup = backup(bsDeterministic);
            dPreviousValue = m_vValueFunction.valueAt(bsDeterministic);
            dNewValue = avBackup.dotProduct(bsDeterministic);
            delta = dNewValue - dPreviousValue;
            if(delta > dEpsilon)
                m_vValueFunction.addPrunePointwiseDominated(avBackup);
            else
                avBackup.release();
        }
        if(TopState.getBestValueAt(s) > 0.0D)
        {
            avBackup = backup(bs);
            dNewValue = avBackup.dotProduct(bs);
            dPreviousValue = m_vValueFunction.valueAt(bs);
            mDelta = dNewValue - dPreviousValue;
            if(mDelta > dEpsilon)
                m_vValueFunction.addPrunePointwiseDominated(avBackup);
            else
                avBackup.release();
        }
        sTrajectory.update(m_pPOMDP, s, a, Math.max(mDelta, delta));
        return Math.max(mDelta, delta);
    }

    protected double update(int s, int a, BeliefState bs)
    {
        AlphaVector avBackup = null;
        double dPreviousValue = 0.0D;
        double dNewValue = 0.0D;
        double delta = 0.0D;
        double mDelta = 0.0D;
        if(TopState.getBestValueAt(s) > 0.0D)
        {
            avBackup = backup(bs);
            dNewValue = avBackup.dotProduct(bs);
            dPreviousValue = m_vValueFunction.valueAt(bs);
            mDelta = dNewValue - dPreviousValue;
            if(mDelta > dEpsilon)
                m_vValueFunction.addPrunePointwiseDominated(avBackup);
            else
                avBackup.release();
        }
        sTrajectory.update(m_pPOMDP, s, a, Math.max(mDelta, delta));
        return Math.max(mDelta, delta);
    }

    protected BeliefState getDeterministicBeliefState(int iState)
    {
        return BeliefStateFactory.getInstance().getDeterministicBeliefState(iState);
    }

    private double previousADR = Double.NEGATIVE_INFINITY;
    protected boolean stoppingCriteria(int s)
    {
        bDone = checkADRConvergence(m_pPOMDP, dTargetValue, pComputedADRs);
        sTrajectory.restart();
        if (sTrajectory.checkForEnd)
        {
          if (pComputedADRs.first()>previousADR)
            previousADR = pComputedADRs.first();
          else
            bDone = true;
          sTrajectory.checkForEnd = false;
        }
//        if(m_cElapsedExecutionTime / 1000L > 300L)
//            bDone = true;
if (DISPLAY_ADR)        
        System.out.println((new StringBuilder(" Time ")).append((lCurrentTime - lStartTime) / 1000L).append(" CPU time ").append((lCPUTimeAfter - lCPUTimeBefore) / 0x3b9aca00L).append(" CPU total ").append(lCPUTimeTotal / 0x3b9aca00L).append(" |V| ").append(m_vValueFunction.size()).append(" V(b0) ").append(round(m_vValueFunction.valueAt(BeliefStateFactory.getInstance().getInitialBeliefState()), 2)).append(" V changes ").append(m_vValueFunction.getChangesCount()).append(" #BS ").append(BeliefStateFactory.getBeliefUpdatesCount()).append(" #backups ").append(m_cBackups).append(" #usefull-backups ").append(m_cBackups - m_vValueFunction.getChangesCount()).append(" free memory ").append(rtRuntime.freeMemory() / 0xf4240L).append(" total memory ").append(rtRuntime.totalMemory() / 0xf4240L).append(" max memory ").append(rtRuntime.maxMemory() / 0xf4240L).toString());
        if (rtRuntime.freeMemory()<5000000)
          return true;
        return bDone;
    }

    @Override
    public String getName()
    {
        return "TopSearch";
    }

    protected Runtime rtRuntime;
    protected boolean bDone;
    protected Trajectory sTrajectory;
    protected TIntHashSet m_vStates;
    protected double dDelta;
    protected double dEpsilon;
    protected double dTargetValue;
    protected HashSet<BeliefState> iSccBeliefStates[];
    protected HashSet<BeliefState> iBeliefStates;
    protected Pair<Double,Double> pComputedADRs;
    protected long lCPUTimeBefore;
    protected long lCPUTimeAfter;
    protected long lCPUTimeTotal;
    protected long lStartTime;
    protected long lCurrentTime;
    public static int STRATEGY_OPTIONS;
    public static final int STRATEGY_FORWARD = 0;
    public static final int STRATEGY_BACKWARD = 1;
    public static final int STRATEGY_FORWARD_BACKWARD = 2;
    public static int UPDATE_OPTIONS;
    public static final int BELIEF_UPDATE = 0;
    public static final int ONCE_STATE_BELIEF_UPDATE = 1;
    public static final int ALL_STATE_BELIEF_UPDATE = 2;
    public static final int ALL_BELIEF_STATE_UPDATE = 3;
    public static final int ONCE_BELIEF_STATE_UPDATE = 4;
    public static final int BELIEF_STATE_SETTINGS = 5;
    public static int RUNNING_OPTIONS;
    public static final int ONLINE_SAMPLES = 0;
    public static final int OFFLINE_SAMPLES = 1;
}
