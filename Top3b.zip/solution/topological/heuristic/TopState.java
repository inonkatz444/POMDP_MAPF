// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TopState.java

package solution.topological.heuristic;

import gnu.trove.*;

import solution.topological.environments.POMDP;
import solution.topological.utilities.MDPValueFunction;

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 9 juil. 2009
 *
 */
public class TopState
{
    private static interface Update
    {

        public abstract void updateCurrentState(POMDP pomdp, int i, int j, double d);

        /**
         * Updates the specified predecessor state
         * @param pomdp the model
         * @param i the predecessor to update
         * @param j the next state
         * @param k the action that will be used in state j
         * @param d the modification of value obtained for using action k in state j 
         */
        public abstract void updatePredecessor(POMDP pomdp, int i, int j, int k, double d);
    }

    private class Update1
        implements Update
    {

        public void updateCurrentState(POMDP pomdp, int s, int a, double dDelta)
        {
            double dValue = TopState.valueAt(s, a);
            double dDiscount = pomdp.getDiscountFactor();
            double dProb = pomdp.tr(s, a, s);
            if(TopState.getState(Integer.valueOf(s)).bGoalState)
            {
                for(int act = 0; act < pomdp.getActionCount(); act++)
                {
                    dValue -= dDiscount * dProb * TopState.valueAt(s, act);
                    dValue += dDiscount * dProb * dDelta;
                    TopState.valueAt(s, act, Math.max(0.0D, dValue));
                }

                setValue();
            } else
            {
                dValue -= dDiscount * dProb * getValue();
                dValue += dDiscount * dProb * dDelta;
                TopState.valueAt(s, a, Math.max(0.0D, dValue));
                setValue();
            }
        }

        public void updatePredecessor(POMDP pomdp, int s, int s2, int a2, double dDelta)
        {
            double dDiscount = pomdp.getDiscountFactor();
            for(int a = 0; a < pomdp.getActionCount(); a++)
            {
                double dValue = TopState.valueAt(s, a);
                double dProb = pomdp.tr(s, a, s2);
                dValue -= dDiscount * dProb * (TopState.valueAt(s2, a2) + dValue);
                dValue += dDiscount * dProb * dDelta;
                TopState.valueAt(s, a, Math.max(0.0D, dValue));
            }

            setValue();
        }

        private Update1()
        {
            super();
        }

        Update1(Update1 update1)
        {
            this();
        }
    }

    private class Update2
        implements Update
    {

        public void updateCurrentState(POMDP pomdp, int s, int a, double dDelta)
        {
            if(TopState.getState(Integer.valueOf(s)).bGoalState)
            {
                for(int act = 0; act < pomdp.getActionCount(); act++)
                    TopState.addValueAt(s, act, dDelta);

                setValue();
            } else
            {
                TopState.addValueAt(s, a, dDelta);
                setValue();
            }
        }

        /* (non-Javadoc)
         * @see solution.topological.heuristic.TopState.Update#updatePredecessor(solution.topological.environments.POMDP, int, int, int, double)
         */
        public void updatePredecessor(POMDP pomdp, int s, int s2, int a2, double dDelta)
        {
            double dDiscount = pomdp.getDiscountFactor();
            for(int a = 0; a < pomdp.getActionCount(); a++)
            {
                double dValue = TopState.valueAt(s, a);
                double dProb = pomdp.tr(s, a, s2);
                if (dProb>0.0D)
                {
                  dValue += dDiscount * dProb * dDelta;
                  TopState.valueAt(s, a, Math.max(0.0D, dValue));//XXX pourquoi ce max ?
                }
            }

            setValue();
        }

        private Update2()
        {
            super();
        }

        Update2(Update2 update2)
        {
            this();
        }
    }

    private class Update3 implements Update
    {

        public void updateCurrentState(POMDP pomdp, int s, int a, double dDelta)
        {
            if(TopState.getState(Integer.valueOf(s)).bGoalState)
            {
                for(int act = 0; act < pomdp.getActionCount(); act++)
                    TopState.valueAt(s, act, dDelta);

                setValue();
            } else
            {
                TopState.valueAt(s, a, dDelta);
                setValue();
            }
        }

        public void updatePredecessor(POMDP pomdp, int s, int s2, int a2, double dDelta)
        {
            for(int a = 0; a < pomdp.getActionCount(); a++)
            {
                double dValue = TopState.valueAt(s, a);
                double dProb = pomdp.tr(s, a, s2);
                dValue += dProb * dDelta;
                TopState.valueAt(s, a, Math.max(0.0D, dValue));
            }

            setValue();
        }

        private Update3()
        {
           super();
        }

        Update3(Update3 update3)
        {
            this();
        }
    }


    public TopState(POMDP pomdp, MDPValueFunction mdp, int iState)
    {	
        if(m_vStates == null)
            m_vStates = new TIntObjectHashMap<TopState>();
        iAction = -1;
        iNextState = -1;
        iObservation = -1;
        this.iState = iState;
        dValue = mdp.getValue(iState);
        m_vHfunction = new TIntDoubleHashMap();
        for(int a = 0; a < pomdp.getActionCount(); a++)
            if(dValue == 0.0D)
                m_vHfunction.put(a, 100D);//XXX ????????????????????
            else
                m_vHfunction.put(a, mdp.getQValue(iState, a));

        m_vStates.put(iState, this);
    }

    public TopState(TopState state)
    {
        iState = state.iState;
        dValue = state.dValue;
        iAction = state.iAction;
        iNextState = state.iNextState;
        iObservation = state.iObservation;
    }

    public static void setGoalState(int goalState)
    {
        if(getState(iGoalState) != null && goalState > 0)
            getState(iGoalState).bGoalState = false;
        iGoalState = goalState;
        if(getState(iGoalState) != null)
            getState(iGoalState).bGoalState = true;
    }

    public static int getGoalState()
    {
        return iGoalState;
    }

    public static TopState getState(int iState)
    {
    	TopState t = null;
    	try{
    		t = m_vStates.get(iState);
    	} catch(Exception e){
    		System.out.println("m_vStates=" + m_vStates);
    		e.printStackTrace();
    		System.exit(-1);
    	}
    	
        return t;
    }

    public static double getBestValueAt(int iState)
    {
        return m_vStates.get(iState).getValue();
    }

    /**
     * Updates the specified QValue, setting the specified value
     * @param iState the state to modify
     * @param iAction the action to modify
     * @param dValue the value to set
     */
    public static void valueAt(int iState, int iAction, double dValue)
    {
        final TopState state = m_vStates.get(iState);
        state.setValueAt(iAction, dValue);
    }

    /**
     * Updates the specified QValue, adding the specified delta
     * @param iState the state to modify
     * @param iAction the action to modify
     * @param dValue the delta to add
     */
    public static void addValueAt(int iState, int iAction, double dValue)
    {
        final TopState state = m_vStates.get(iState);
        state.setValueAt(iAction, state.dValue+dValue);
    }

    public static double valueAt(int iState, int iAction)
    {
        return getState(iState).valueAt(iAction);
    }

    /**
     * Gets the best state in the specified collection WRT raw value
     * @param iNextStates an iterator of states
     * @return the best state
     */
    public static int nextWHP(TIntIterator iNextStates)
    {
        int iBestNextState = -1;
        int iNextState = -1;
        double dValue = (-1.0D / 0.0D);
        while(iNextStates.hasNext()) 
        {
            iNextState = iNextStates.next();
            if(getBestValueAt(iNextState) > dValue)
            {
                iBestNextState = iNextState;
                dValue = getBestValueAt(iNextState);
            }
        }
        return iBestNextState;
    }

    public static TIntHashSet nextSetWHP(TIntIterator iNextStates)
    {
        int iNextState = -1;
        double dValue = (-1.0D / 0.0D);
        TIntHashSet iBestNextState = new TIntHashSet();
        while(iNextStates.hasNext()) 
        {
            iNextState = iNextStates.next();
            if(getBestValueAt(iNextState) > dValue)
            {
                iBestNextState.clear();
                iBestNextState.add(iNextState);
                dValue = getBestValueAt(iNextState);
            }
            if(getBestValueAt(iNextState) == dValue)
            {
                iBestNextState.add(iNextState);
                dValue = getBestValueAt(iNextState);
            }
        }
        return iBestNextState;
    }

    public double valueAt(int iAction)
    {
        return m_vHfunction.get(iAction);
    }

    public void setValueAt(int iAction, double dValue)
    {
        m_vHfunction.put(iAction, dValue);
    }

    public double getValue()
    {
        return dValue;
    }

    public void setValue()
    {
      double v = Double.NEGATIVE_INFINITY;
      for (TIntDoubleIterator ite = m_vHfunction.iterator();ite.hasNext(); )
      {
        ite.advance();
        if (v < ite.value())
          v = ite.value();
      }
      dValue = v;
    }

    public void setObservation(int iObservation)
    {
        this.iObservation = iObservation;
    }

    public int getObservation()
    {
        return iObservation;
    }

    public void setAction(int iAction)
    {
        this.iAction = iAction;
    }

    public int getAction()
    {
        return iAction;
    }

    public void setState(int iState)
    {
        this.iState = iState;
    }

    public int getState()
    {
        return iState;
    }

    public int getNextState()
    {
        return iNextState;
    }

    public void setNextState(int iNextState)
    {
        this.iNextState = iNextState;
    }

    public void update(POMDP pomdp, TIntHashSet iPredecessors, double dDelta)
    {
        update(pomdp, iPredecessors, iAction, dDelta);
    }

    public void update(POMDP pomdp, TIntHashSet iPredecessors, int iAction, double dDelta)
    {
        Update update = null;
        switch(UPDATE_FUNCTION_OPTION)
        {
        case 0: // '\0'
            update = new Update1(null);
            break;

        case 1: // '\001'
            update = new Update2(null);
            break;

        case 2: // '\002'
            update = new Update3(null);
            break;

        default:
            update = new Update1(null);
            break;
        }
        for(TIntIterator iStates = iPredecessors.iterator(); iStates.hasNext() && dDelta > 0.0D; )
          update.updatePredecessor(pomdp, iStates.next(), iState, iAction, dDelta);
        update.updateCurrentState(pomdp, iState, iAction, dDelta);
    }

    @Override
    public String toString()
    {
        return (new StringBuilder("-*-*-*-  s = ")).append(iState).append(" a = ").append(iAction).append(" o = ").append(iObservation).append(" s2 = ").append(iNextState).append(" dValue = ").append(dValue).toString();
    }

    protected double dValue;
    protected boolean bGoalState;
    protected static int iGoalState = -1;
    protected TIntDoubleHashMap m_vHfunction;
    protected int iState;
    protected int iAction;
    protected int iObservation;
    protected int iNextState;
    protected static TIntObjectHashMap<TopState> m_vStates;
    public static int UPDATE_FUNCTION_OPTION;
    public static final int UPDATE_1 = 0;
    public static final int UPDATE_2 = 1;
    public static final int UPDATE_3 = 2;

    /**
     * Clears all static values 
     */
    public static void clear()
    {
      m_vStates = null;
    }
}
