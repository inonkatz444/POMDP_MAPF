// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Logger.java

package solution.topological.utilities;

import java.io.PrintStream;

public class Logger
{

    private Logger()
    {
        m_iMaximalLevel = 2;
        m_rtRuntime = Runtime.getRuntime();
        m_psOutput = System.out;
    }

    public static Logger getInstance()
    {
        if(m_lInstance == null)
            m_lInstance = new Logger();
        return m_lInstance;
    }

    public void log(String sClassName, int iLevel, String sMethodName, String sMessage)
    {
        if(iLevel <= m_iMaximalLevel)
        {
            m_psOutput.println((new StringBuilder(String.valueOf(sClassName))).append(":").append(sMethodName).append(":").append(sMessage).toString());
            m_psOutput.flush();
        }
    }

    public void log(String sClassName, int iLevel, String sMethodName, String sMessage, int value)
    {
        if(iLevel <= m_iMaximalLevel)
        {
            m_psOutput.println((new StringBuilder(String.valueOf(sClassName))).append(":").append(sMethodName).append(":").append(sMessage).append(value).toString());
            m_psOutput.flush();
        }
    }

    public void logError(String sClassName, String sMethodName, String sMessage)
    {
        System.err.println((new StringBuilder(String.valueOf(sClassName))).append(":").append(sMethodName).append(":").append(sMessage).toString());
    }

    public void logFull(String sClassName, int iLevel, String sMethodName, String sMessage)
    {
        if(iLevel <= m_iMaximalLevel)
        {
            m_psOutput.println((new StringBuilder(String.valueOf(sClassName))).append(":").append(sMethodName).append(":").append(sMessage).append(", memory: ").append(" total ").append(m_rtRuntime.totalMemory() / 0xf4240L).append(" free ").append(m_rtRuntime.freeMemory() / 0xf4240L).append(" max ").append(m_rtRuntime.maxMemory() / 0xf4240L).toString());
            m_psOutput.flush();
        }
    }

    private int m_iMaximalLevel;
    private static Logger m_lInstance = null;
    private Runtime m_rtRuntime;
    private PrintStream m_psOutput;

}
