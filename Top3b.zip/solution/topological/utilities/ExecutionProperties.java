// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ExecutionProperties.java

package solution.topological.utilities;


public class ExecutionProperties
{

    public ExecutionProperties()
    { //
    }

    public static boolean getDebug()
    {
        return m_bDebug;
    }

    public static boolean getReportOperationTime()
    {
        return m_bReportOperationTime;
    }

    public static String getPath()
    {
        return "../freespace/POMDP/Models";
    }

    private static boolean m_bDebug = false;
    private static boolean m_bReportOperationTime = false;

}
