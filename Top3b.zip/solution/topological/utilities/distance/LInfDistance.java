// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LInfDistance.java

package solution.topological.utilities.distance;


// Referenced classes of package pomdp.utilities.distance:
//            LDistance, DistanceMetric

public class LInfDistance extends LDistance
{

    public LInfDistance()
    { //
    }

    @Override
    protected double applyDistanceMetric(double dAccumulated, double dValue1, double dValue2)
    {
        double dDiff = Math.abs(dValue1 - dValue2);
        if(dDiff > dAccumulated)
            return dDiff;
        else
            return dAccumulated;
    }

    @Override
    protected double applyFinal(double dAccumulated)
    {
        return dAccumulated;
    }

    public static DistanceMetric getInstance()
    {
        if(m_lifDistance == null)
            m_lifDistance = new LInfDistance();
        return m_lifDistance;
    }

    protected static LInfDistance m_lifDistance = null;

}
