// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LMinDistance.java

package solution.topological.utilities.distance;


// Referenced classes of package pomdp.utilities.distance:
//            LDistance, DistanceMetric

public class LMinDistance extends LDistance
{

    protected LMinDistance()
    { //
    }

    @Override
    protected double getInitialDistance()
    {
        return 1.0D;
    }

    @Override
    protected double applyDistanceMetric(double dAccumulated, double dValue1, double dValue2)
    {
        if(dValue1 == 0.0D && dValue2 == 0.0D)
            return dAccumulated;
        double dDiff = Math.abs(dValue1 - dValue2);
        if(dDiff < dAccumulated)
            return dDiff;
        else
            return dAccumulated;
    }

    @Override
    protected double applyFinal(double dAccumulated)
    {
        return dAccumulated;
    }

    public static DistanceMetric getInstance()
    {
        if(m_lmDistance == null)
            m_lmDistance = new LMinDistance();
        return m_lmDistance;
    }

    protected static LMinDistance m_lmDistance = null;

}
