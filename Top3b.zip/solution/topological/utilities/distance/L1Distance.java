// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   L1Distance.java

package solution.topological.utilities.distance;


// Referenced classes of package pomdp.utilities.distance:
//            LDistance, DistanceMetric

public class L1Distance extends LDistance
{

    protected L1Distance()
    { //
    }

    @Override
    protected double applyDistanceMetric(double dAccumulated, double dValue1, double dValue2)
    {
        return dAccumulated + Math.abs(dValue1 - dValue2);
    }

    @Override
    protected double applyFinal(double dAccumulated)
    {
        return dAccumulated;
    }

    public static DistanceMetric getInstance()
    {
        if(m_l1Distance == null)
            m_l1Distance = new L1Distance();
        return m_l1Distance;
    }

    protected static L1Distance m_l1Distance;
}
