// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LDistance.java

package solution.topological.utilities.distance;

import gnu.trove.*;

import solution.topological.utilities.BeliefState;

// Referenced classes of package pomdp.utilities.distance:
//            DistanceMetric

/**
 * Converted to trove lib 
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 10 juil. 2009
 *
 */
public abstract class LDistance
    implements DistanceMetric
{
    public class Belief
    {

        public int iState;
        public double dValue;

        public Belief(TIntDoubleIterator it)
        {
            super();
            if(it.hasNext())
            {
              it.advance();
                iState = it.key();
                dValue = it.value();
            } else
            {
                iState = 0x7fffffff;
                dValue = -1D;
            }
        }
    }


    public LDistance()
    {
        m_tmCache = new TIntObjectHashMap<TIntDoubleHashMap>();
    }

    protected double getInitialDistance()
    {
        return 0.0D;
    }

    protected double getCachedDistance(BeliefState bs1, BeliefState bs2)
    {
        try
        {
            TIntDoubleHashMap tmSingle = m_tmCache.get(bs1.getId());
            if(tmSingle != null)
            {
              if (tmSingle.containsKey(bs2.getId()))
                return tmSingle.get(bs2.getId());
            }
        }
        catch(NullPointerException e)
        {
            System.out.println(e);
            return getCachedDistance(bs1, bs2);
        }
        return -1D;
    }

    protected void cacheDistance(BeliefState bs1, BeliefState bs2, double dDistance)
    {
        TIntDoubleHashMap tmSingle1 = m_tmCache.get(bs1.getId());
        TIntDoubleHashMap tmSingle2 = m_tmCache.get(bs2.getId());
        if(tmSingle1 == null)
        {
            tmSingle1 = new TIntDoubleHashMap();
            m_tmCache.put(bs1.getId(), tmSingle1);
        }
        if(tmSingle2 == null)
        {
            tmSingle2 = new TIntDoubleHashMap();
            m_tmCache.put(bs2.getId(), tmSingle2);
        }
        tmSingle1.put(bs2.getId(),dDistance);
        tmSingle2.put(bs1.getId(), dDistance);
    }

    public double distance(BeliefState bs1, BeliefState bs2)
    {
        double dDistance = -1D;
        if(dDistance != -1D)
            return dDistance;
        if(bs1 == bs2)
        {
            dDistance = 0.0D;
        } else
        {
            TIntDoubleIterator itFirstNonZero = bs1.getNonZeroEntries();
            TIntDoubleIterator itSecondNonZero = bs2.getNonZeroEntries();
            dDistance = 0.0D;
            int iState1 = -1;
            int iState2 = -1;
            double dValue1 = 0.0D;
            double dValue2 = 0.0D;
            Belief b = null;
            dDistance = getInitialDistance();
            while(iState1 < 0x7fffffff || iState2 < 0x7fffffff) 
                if(iState1 == iState2)
                {
                    dDistance = applyDistanceMetric(dDistance, dValue1, dValue2);
                    b = new Belief(itFirstNonZero);
                    iState1 = b.iState;
                    dValue1 = b.dValue;
                    b = new Belief(itSecondNonZero);
                    iState2 = b.iState;
                    dValue2 = b.dValue;
                } else
                if(iState1 < iState2)
                {
                    dDistance = applyDistanceMetric(dDistance, dValue1, 0.0D);
                    b = new Belief(itFirstNonZero);
                    iState1 = b.iState;
                    dValue1 = b.dValue;
                } else
                if(iState2 < iState1)
                {
                    dDistance = applyDistanceMetric(dDistance, dValue2, 0.0D);
                    b = new Belief(itSecondNonZero);
                    iState2 = b.iState;
                    dValue2 = b.dValue;
                }
        }
        dDistance = applyFinal(dDistance);
        return dDistance;
    }

    protected abstract double applyDistanceMetric(double d, double d1, double d2);

    protected abstract double applyFinal(double d);

    protected TIntObjectHashMap<TIntDoubleHashMap> m_tmCache;
}
