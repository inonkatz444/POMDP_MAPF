// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ArrayComparator.java

package solution.topological.utilities;

import java.util.Comparator;

public class ArrayComparator
    implements Comparator<long[]>
{

    private ArrayComparator()
    { //
    }

    public static ArrayComparator getInstance()
    {
        return g_sInstance;
    }

    public int compare(long a1[], long a2[])
    {
        if(a1.length != a2.length)
            return a1.length - a2.length;
        int i = 0;
        for(i = a1.length - 1; i >= 0; i--)
            if(a1[i] != a2[i])
                return (int)(a1[i] - a2[i]);

        return 0;
    }

    private static ArrayComparator g_sInstance = new ArrayComparator();

}
