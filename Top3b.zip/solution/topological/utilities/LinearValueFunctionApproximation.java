// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LinearValueFunctionApproximation.java

package solution.topological.utilities;

import gnu.trove.TLongObjectHashMap;
import gnu.trove.TLongObjectIterator;

import java.io.*;
import java.util.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;

import solution.topological.environments.POMDP;

// Referenced classes of package pomdp.utilities:
//            AlphaVector, TabularAlphaVector, BeliefState, RandomGenerator

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 10 juil. 2009
 *
 */
public class LinearValueFunctionApproximation
{

    public LinearValueFunctionApproximation(double dEpsilon, boolean bCacheValues)
    {
        m_vAlphaVectors = new Vector<AlphaVector>();
        m_dEpsilon = dEpsilon;
        m_bCacheValues = bCacheValues;
        m_dMaxValue = 0.0D;
        m_vLastAlphaVectors = new Vector<AlphaVector>();
        m_vComplementaryPolicyVectors = new TLongObjectHashMap<AlphaVector>();
    }

    public LinearValueFunctionApproximation(LinearValueFunctionApproximation vOtherValueFunction)
    {
        copy(vOtherValueFunction);
        m_bCacheValues = vOtherValueFunction.m_bCacheValues;
    }

    public double valueAt(BeliefState bs)
    {
        if(m_vAlphaVectors.size() == 0)
            return (-1.0D / 0.0D);
        int iTime = bs.getMaxValueTime();
        double dValue = bs.getMaxValue();
        if(iTime < m_cValueFunctionChanges || !m_bCacheValues)
        {
            AlphaVector avMaxAlpha = getMaxAlpha(bs);
            dValue = avMaxAlpha.dotProduct(bs);
            if(m_bCacheValues)
                bs.setMaxValue(dValue, m_cValueFunctionChanges);
        }
        return dValue;
    }

    /**
     * Gets the best alpha-vector for the specified belief-state
     * @param bs the belief-state to test for
     * @return the best alpha-vector
     */
    public AlphaVector getMaxAlpha(BeliefState bs)
    {
        int cElements = m_vAlphaVectors.size();
        if(cElements == 0)
            return null;
        Iterator<AlphaVector> it = m_vAlphaVectors.iterator();
        AlphaVector avMaxAlpha = bs.getMaxAlpha();
        AlphaVector avCurrent = null;
        double dMaxValue = bs.getMaxValue();
        double dValue = 0.0D;
        int iBeliefStateMaxAlphaTime = bs.getMaxAlphaTime();
        if(!m_vAlphaVectors.contains(avMaxAlpha))
        {
            avMaxAlpha = null;
            dMaxValue = -1.7976931348623157E+308D;
            iBeliefStateMaxAlphaTime = -1;
        }
        while(it.hasNext()) 
        {
            avCurrent = it.next();
            if(!m_bCacheValues || avCurrent.getInsertionTime() > iBeliefStateMaxAlphaTime)
            {
                dValue = avCurrent.dotProduct(bs);
                if(dValue > dMaxValue)
                {
                    dMaxValue = dValue;
                    avMaxAlpha = avCurrent;
                }
            }
        }
        if(m_bCacheValues)
        {
            bs.setMaxAlpha(avMaxAlpha, m_cValueFunctionChanges);
            bs.setMaxValue(dMaxValue, m_cValueFunctionChanges);
        }
        avMaxAlpha.incrementHitCount();
        return avMaxAlpha;
    }

    public int getBestAction(BeliefState bs)
    {
        AlphaVector avMaxAlpha = getMaxAlpha(bs);
        if(avMaxAlpha == null)
            return -1;
        else
            return avMaxAlpha.getAction();
    }

    public Iterator<AlphaVector> iterator()
    {
        return m_vAlphaVectors.iterator();
    }

    public AlphaVector elementAt(int iElement)
    {
        return m_vAlphaVectors.elementAt(iElement);
    }

    public void addAllPrunePointwiseDominated(LinearValueFunctionApproximation vValueFunction)
    {
        AlphaVector alpha;
        for(Iterator<AlphaVector> ialpha = vValueFunction.iterator(); ialpha.hasNext(); addPrunePointwiseDominated(alpha))
            alpha = ialpha.next();

    }

    public void addPrunePointwiseDominated(AlphaVector avNew)
    {
        Iterator<AlphaVector> it = m_vAlphaVectors.iterator();
        AlphaVector avExisting = null;
        BeliefState bsWitness = null;
        double dNewValue = 0.0D;
        while(it.hasNext()) 
        {
            avExisting = it.next();
            if(avExisting.dominates(avNew))
                return;
            if(avNew.dominates(avExisting))
                it.remove();
        }
        m_cValueFunctionChanges++;
        m_vAlphaVectors.add(avNew);
        if(m_bCacheValues)
        {
            avNew.setInsertionTime(m_cValueFunctionChanges);
            bsWitness = avNew.getWitness();
            dNewValue = avNew.dotProduct(bsWitness);
            if(bsWitness != null)
            {
                bsWitness.setMaxAlpha(avNew, m_cValueFunctionChanges);
                bsWitness.setMaxValue(dNewValue, m_cValueFunctionChanges);
            }
        }
        if(avNew.getMaxValue() > m_dMaxValue)
            m_dMaxValue = avNew.getMaxValue();
    }

    public void initHitCounts()
    {
        AlphaVector av;
        for(Iterator<AlphaVector> iterator1 = m_vAlphaVectors.iterator(); iterator1.hasNext(); av.initHitCount())
            av = iterator1.next();

    }

    public void pruneLowHitCountVectors(int cMinimalHitCount)
    {
        Vector<AlphaVector> vPruned = new Vector<AlphaVector>();
        for(Iterator<AlphaVector> iterator1 = m_vAlphaVectors.iterator(); iterator1.hasNext();)
        {
            AlphaVector av = iterator1.next();
            if(av.getHitCount() > cMinimalHitCount)
                vPruned.add(av);
        }

        System.out.println((new StringBuilder("Pruned from ")).append(m_vAlphaVectors.size()).append(" to ").append(vPruned.size()).toString());
        m_vAlphaVectors = vPruned;
    }

    public void addBounded(AlphaVector avNew, int cMaxVectors)
    {
        addPrunePointwiseDominated(avNew);
        if(m_vAlphaVectors.size() > cMaxVectors)
        {
            int i = m_rndGenerator.nextInt(m_vAlphaVectors.size());
            m_vAlphaVectors.remove(i);
        }
    }

    public void add(AlphaVector avNew, boolean bPruneDominated)
    {
        Iterator<AlphaVector> it = m_vAlphaVectors.iterator();
        AlphaVector avExisting = null;
        BeliefState bsWitness = null;
        double dPreviousValue = 0.0D;
        double dNewValue = 0.0D;
        m_cValueFunctionChanges++;
        if(bPruneDominated)
            while(it.hasNext()) 
            {
                avExisting = it.next();
                bsWitness = avExisting.getWitness();
                if(bsWitness != null)
                {
                    dPreviousValue = avExisting.dotProduct(bsWitness);
                    dNewValue = avNew.dotProduct(bsWitness);
                    if(dNewValue > dPreviousValue)
                        it.remove();
                } else
                {
                    it.remove();
                }
            }
        m_vAlphaVectors.add(avNew);
        if(m_bCacheValues)
        {
            avNew.setInsertionTime(m_cValueFunctionChanges);
            bsWitness = avNew.getWitness();
            if(bsWitness != null)
            {
                dNewValue = avNew.dotProduct(bsWitness);
                bsWitness.setMaxAlpha(avNew, m_cValueFunctionChanges);
                bsWitness.setMaxValue(dNewValue, m_cValueFunctionChanges);
            }
        }
        if(avNew.getMaxValue() > m_dMaxValue)
            m_dMaxValue = avNew.getMaxValue();
    }

    public void clear()
    {
        AlphaVector av;
        for(Iterator<AlphaVector> iterator1 = m_vAlphaVectors.iterator(); iterator1.hasNext(); av.release())
            av = iterator1.next();

        m_vAlphaVectors.clear();
        m_cValueFunctionChanges = 0;
    }

    public void addAll(LinearValueFunctionApproximation vOtherValueFunction)
    {
        m_vAlphaVectors.addAll(vOtherValueFunction.m_vAlphaVectors);
    }

    public int size()
    {
        return m_vAlphaVectors.size();
    }

    public TLongObjectHashMap<AlphaVector> getComplementaryPolicyVectors()
    {
        return m_vComplementaryPolicyVectors;
    }

    private void preliminaries(LinearValueFunctionApproximation vValueFunctions[], int m_cActions)
    {
        m_vAlphaVectors.removeAllElements();
        for (TLongObjectIterator<AlphaVector> it = m_vComplementaryPolicyVectors.iterator(); it.hasNext(); it.advance())
          m_vAlphaVectors.add(it.value());
        for(int iAction = 0; iAction < m_cActions; iAction++)
            m_vAlphaVectors.addAll(vValueFunctions[iAction].m_vAlphaVectors);

        m_vAlphaVectors.addAll(m_vLastAlphaVectors);
        m_vLastAlphaVectors.removeAllElements();
        m_vComplementaryPolicyVectors = new TLongObjectHashMap<AlphaVector>();
    }

    public void transformation(LinearValueFunctionApproximation vOtherValueFunction, LinearValueFunctionApproximation vValueFunctions[], LinearValueFunctionApproximation vNextValueFunctions[])
    {
        int m_cActions = vOtherValueFunction.m_vAlphaVectors.firstElement().m_cActions;
        preliminaries(vValueFunctions, m_cActions);
        for(Iterator<AlphaVector> iterator1 = m_vAlphaVectors.iterator(); iterator1.hasNext();)
        {
            AlphaVector avLast = iterator1.next();
label0:
            for(Iterator<AlphaVector> iterator3 = vOtherValueFunction.m_vAlphaVectors.iterator(); iterator3.hasNext();)
            {
                AlphaVector avCurrent = iterator3.next();
                for(int iObservation = 0; iObservation < avLast.m_cObservations; iObservation++)
                {
                    if(avCurrent.m_aCachedSuccessorLinks[iObservation] != avLast.m_iID)
                        continue;
                    m_vComplementaryPolicyVectors.put(avLast.getId(), avLast);
                    break label0;
                }

            }

        }

        for(Iterator<AlphaVector> iterator2 = m_vAlphaVectors.iterator(); iterator2.hasNext();)
        {
            AlphaVector avLast = iterator2.next();
label1:
            for(TLongObjectIterator<AlphaVector> iterator4 = m_vComplementaryPolicyVectors.iterator(); iterator4.hasNext();)
            {
                AlphaVector avCurrent = iterator4.value(); iterator4.advance();
                for(int iObservation = 0; iObservation < avLast.m_cObservations; iObservation++)
                {
                    if(avCurrent.m_aCachedSuccessorLinks[iObservation] != avLast.m_iID)
                        continue;
                    m_vComplementaryPolicyVectors.put(Long.valueOf(avLast.getId()), avLast);
                    break label1;
                }

            }

        }

        m_vLastAlphaVectors.addAll(m_vAlphaVectors);
        m_vAlphaVectors = vOtherValueFunction.m_vAlphaVectors;
    }

    public boolean equals(LinearValueFunctionApproximation vOther)
    {
        return vOther.m_vAlphaVectors.containsAll(m_vAlphaVectors) && m_vAlphaVectors.containsAll(vOther.m_vAlphaVectors);
    }

    public void copy(LinearValueFunctionApproximation vOtherValueFunction)
    {
        m_vAlphaVectors = new Vector<AlphaVector>(vOtherValueFunction.m_vAlphaVectors);
        m_dEpsilon = vOtherValueFunction.m_dEpsilon;
    }

    public void add(AlphaVector avNew)
    {
        add(avNew, true);
    }

    public void remove(AlphaVector av)
    {
        m_vAlphaVectors.remove(av);
    }

    public void removeAll()
    {
        m_vAlphaVectors = new Vector<AlphaVector>();
    }

    public double approximateValueAt(BeliefState bs)
    {
        if(m_vAlphaVectors.size() == 0)
            return -1.7976931348623157E+308D;
        int iBeliefStateMaxAlphaTime = bs.getApproximateValueTime();
        double dMaxValue = bs.getApproximateValue();
        double dValue = 0.0D;
        Iterator<AlphaVector> it = m_vAlphaVectors.iterator();
        AlphaVector avCurrent = null;
        if(iBeliefStateMaxAlphaTime < m_cValueFunctionChanges)
        {
            while(it.hasNext()) 
            {
                avCurrent = it.next();
                if(avCurrent.getInsertionTime() > iBeliefStateMaxAlphaTime)
                {
                    dValue = avCurrent.approximateDotProduct(bs);
                    if(dValue > dMaxValue)
                        dMaxValue = dValue;
                }
            }
            bs.setApproximateValue(dMaxValue, m_cValueFunctionChanges);
        }
        return dMaxValue;
    }

    public int getChangesCount()
    {
        return m_cValueFunctionChanges;
    }

    public void setCaching(boolean bCache)
    {
        m_bCacheValues = bCache;
    }

    public boolean contains(AlphaVector av)
    {
        return m_vAlphaVectors.contains(av);
    }

    @Override
    public String toString()
    {
        int iVector = 0;
        int cVectors = m_vAlphaVectors.size();
        AlphaVector av = null;
        String sRetVal = "<";
        for(iVector = 0; iVector < cVectors; iVector++)
        {
            av = m_vAlphaVectors.elementAt(iVector);
            sRetVal = (new StringBuilder(String.valueOf(sRetVal))).append(av.toString()).append("\n").toString();
        }

        return sRetVal;
    }

    public double getMaxValue()
    {
        return m_dMaxValue;
    }

    public AlphaVector getFirst()
    {
        return m_vAlphaVectors.get(0);
    }

    public AlphaVector getLast()
    {
        return m_vAlphaVectors.lastElement();
    }

    public void save(String sFileName)
        throws Exception
    {
        Document docValueFunction = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        Element eValueFunction = null;
        Element eAlphaVector = null;
        Iterator<AlphaVector> itVectors = m_vAlphaVectors.iterator();
        AlphaVector avCurrent = null;
        eValueFunction = docValueFunction.createElement("ValueFunction");
        eValueFunction.setAttribute("AlphaVectorCount", (new StringBuilder(String.valueOf(m_vAlphaVectors.size()))).toString());
        eValueFunction.setAttribute("Epsilon", (new StringBuilder(String.valueOf(m_dEpsilon))).toString());
        eValueFunction.setAttribute("CacheValue", (new StringBuilder(String.valueOf(m_bCacheValues))).toString());
        eValueFunction.setAttribute("MaxValue", (new StringBuilder(String.valueOf(m_dMaxValue))).toString());
        docValueFunction.appendChild(eValueFunction);
        for(; itVectors.hasNext(); eValueFunction.appendChild(eAlphaVector))
        {
            avCurrent = itVectors.next();
            eAlphaVector = avCurrent.getDOM(docValueFunction);
        }

        TransformerFactory tFactory = TransformerFactory.newInstance();
        Transformer transformer = tFactory.newTransformer();
        DOMSource source = new DOMSource(docValueFunction);
        StreamResult result = new StreamResult(new FileOutputStream(sFileName));
        transformer.transform(source, result);
    }

    public void load(String sFileName, POMDP pomdp)
        throws Exception
    {
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document docValueFunction = builder.parse(new FileInputStream(sFileName));
        Element eValueFunction = null;
        Element eVector = null;
        NodeList nlVectors = null;
        int cVectors = 0;
        int iVector = 0;
        AlphaVector avNew = null;
        eValueFunction = (Element)docValueFunction.getChildNodes().item(0);
        cVectors = Integer.parseInt(eValueFunction.getAttribute("AlphaVectorCount"));
        nlVectors = eValueFunction.getChildNodes();
        m_dEpsilon = Double.parseDouble(eValueFunction.getAttribute("Epsilon"));
        m_bCacheValues = Boolean.parseBoolean(eValueFunction.getAttribute("CacheValue"));
        m_dMaxValue = Double.parseDouble(eValueFunction.getAttribute("MaxValue"));
        for(iVector = 0; iVector < cVectors; iVector++)
        {
            eVector = (Element)nlVectors.item(iVector);
            avNew = AlphaVector.load(eVector, pomdp);
            m_vAlphaVectors.add(avNew);
        }

    }

    public void removeFirst()
    {
        m_vAlphaVectors.remove(0);
    }

    public Vector<AlphaVector> getVectors()
    {
        return m_vAlphaVectors;
    }

    public LinearValueFunctionApproximation getLinearQValueFunction(int iAction)
    {
        LinearValueFunctionApproximation function = new LinearValueFunctionApproximation(m_dEpsilon, m_bCacheValues);
        for(Iterator<AlphaVector> iter = iterator(); iter.hasNext();)
        {
            AlphaVector aVect = iter.next();
            if(aVect.getAction() == iAction)
                function.add(aVect);
        }

        return function;
    }

    public LinearValueFunctionApproximation getLinearQValueFunction(int iAction, Vector<AlphaVector> aVectors)
    {
        LinearValueFunctionApproximation function = new LinearValueFunctionApproximation(m_dEpsilon, m_bCacheValues);
        for(Iterator<AlphaVector> iter = aVectors.iterator(); iter.hasNext();)
        {
            AlphaVector aVect = iter.next();
            if(aVect.getAction() == iAction)
                function.add(aVect);
        }

        return function;
    }

    public void setVectors(Vector<AlphaVector> v)
    {
        m_vAlphaVectors = v;
    }

    public int countEntries()
    {
        Iterator<AlphaVector> it = m_vAlphaVectors.iterator();
        AlphaVector avCurrent = null;
        int cEntries;
        for(cEntries = 0; it.hasNext(); cEntries += avCurrent.countEntries())
            avCurrent = it.next();

        return cEntries;
    }

    protected TLongObjectHashMap<AlphaVector> m_vComplementaryPolicyVectors;
    protected Vector<AlphaVector> m_vAlphaVectors;
    protected Vector<AlphaVector> m_vLastAlphaVectors;
    protected RandomGenerator m_rndGenerator;
    protected static int m_cValueFunctionChanges = 0;
    protected double m_dEpsilon;
    protected boolean m_bCacheValues;
    protected double m_dMaxValue;

    /**
     * Clears all static values 
     */
    public static void clearStatic()
    {
      m_cValueFunctionChanges = 0;
    }

}
