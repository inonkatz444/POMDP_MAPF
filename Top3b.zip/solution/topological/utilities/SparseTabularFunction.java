// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SparseTabularFunction.java

package solution.topological.utilities;

import gnu.trove.TIntDoubleHashMap;
import gnu.trove.TIntDoubleIterator;
import solution.topological.utilities.datastructures.Function;

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 10 juil. 2009
 *
 */
public final class SparseTabularFunction extends Function
{

    public SparseTabularFunction(int aiDims[])
    {
        super(aiDims);
        int i = 0;
        int j = 0;
        int k = 0;
        if(aiDims.length >= 1)
        {
            m_mSingleParameterValues = new TIntDoubleHashMap();
            if(aiDims.length >= 2)
            {
                m_mDualParameterValues = new TIntDoubleHashMap[aiDims[0]];
                for(i = 0; i < aiDims[0]; i++)
                    m_mDualParameterValues[i] = new TIntDoubleHashMap();

                if(aiDims.length >= 3)
                {
                    m_mTripleParametermValues = new TIntDoubleHashMap[aiDims[0]][aiDims[1]];
                    for(i = 0; i < aiDims[0]; i++)
                        for(j = 0; j < aiDims[1]; j++)
                            m_mTripleParametermValues[i][j] = new TIntDoubleHashMap();
                } // if dim >= 3
                if(aiDims.length >= 4)
                {
                    m_mQuadrupleParametermValues = new TIntDoubleHashMap[aiDims[0]][aiDims[1]][aiDims[2]];
                    for(i = 0; i < aiDims[0]; i++)
                        for(j = 0; j < aiDims[1]; j++)
                            for(k = 0; k < aiDims[2]; k++)
                                m_mQuadrupleParametermValues[i][j][k] = new TIntDoubleHashMap();
                } // if dim >= 4
            } // if dim >= 2
        } // if dim >=1
    } // SparseTabularFunction(int[]) 

    @Override
    public double valueAt(int arg1)
    {
        return m_mSingleParameterValues.get(arg1);
    }

    @Override
    public double valueAt(int arg1, int arg2)
    {
      return m_mDualParameterValues[arg1].get(arg2);
    }

    @Override
    public final double valueAt(int arg1, int arg2, int arg3)
    {
      return m_mTripleParametermValues[arg1][arg2].get(arg3);
    }

    @Override
    public double valueAt(int arg1, int arg2, int arg3, int arg4)
    {
      return m_mQuadrupleParametermValues[arg1][arg2][arg3].get(arg4);
    }

    @Override
    public void setValue(int arg1, double dValue)
    {
        if(dValue > m_dMaxValue)
            m_dMaxValue = dValue;
        if(dValue < m_dMinValue)
            m_dMinValue = dValue;
        if(dValue != 0.0D)
            m_mSingleParameterValues.put(arg1, dValue);
        else
            m_mSingleParameterValues.remove(arg1);
    }

    @Override
    public void setValue(int arg1, int arg2, double dValue)
    {
      if(dValue > m_dMaxValue)
        m_dMaxValue = dValue;
      if(dValue < m_dMinValue)
        m_dMinValue = dValue;
        if(dValue != 0.0D)
            m_mDualParameterValues[arg1].put(arg2, dValue);
        else
            m_mDualParameterValues[arg1].remove(arg2);
    }

    @Override
    public void setValue(int arg1, int arg2, int arg3, double dValue)
    {
      if(dValue > m_dMaxValue)
        m_dMaxValue = dValue;
      if(dValue < m_dMinValue)
        m_dMinValue = dValue;
      if(dValue != 0.0D)
        m_mTripleParametermValues[arg1][arg2].put(arg3, dValue);
      else
        m_mTripleParametermValues[arg1][arg2].remove(arg3);
    }

    @Override
    public void setValue(int arg1, int arg2, int arg3, int arg4, double dValue)
    {
      if(dValue > m_dMaxValue)
        m_dMaxValue = dValue;
      if(dValue < m_dMinValue)
        m_dMinValue = dValue;
      if(dValue != 0.0D)
        m_mQuadrupleParametermValues[arg1][arg2][arg2].put(arg4, dValue);
      else
        m_mQuadrupleParametermValues[arg1][arg2][arg3].remove(arg4);
    }

    @Override
    public TIntDoubleIterator getNonZeroEntries(int arg1, int arg2, int arg3)
    {
        return m_mQuadrupleParametermValues[arg1][arg2][arg3].iterator();
    }

    @Override
    public TIntDoubleIterator getNonZeroEntries(int arg1, int arg2)
    {
        return m_mTripleParametermValues[arg1][arg2].iterator();
    }

    @Override
    public TIntDoubleIterator getNonZeroEntries()
    {
        return m_mSingleParameterValues.iterator();
    }

    @Override
    public int countNonZeroEntries(int arg1, int arg2, int arg3)
    {
        return m_mQuadrupleParametermValues[arg1][arg2][arg3].size();
    }

    @Override
    public int countNonZeroEntries(int arg1, int arg2)
    {
        return m_mTripleParametermValues[arg1][arg2].size();
    }

    @Override
    public int countEntries()
    {
        int cEntries = 0;
        int i = 0;
        int j = 0;
        for(i = 0; i < m_mTripleParametermValues.length; i++)
            for(j = 0; j < m_mTripleParametermValues[0].length; j++)
                cEntries += m_mTripleParametermValues[i][j].size();


        return cEntries;
    }

    @Override
    public int countNonZeroEntries()
    {
        return m_mSingleParameterValues.size();
    }

    private TIntDoubleHashMap m_mSingleParameterValues;
    private TIntDoubleHashMap[] m_mDualParameterValues;
    private TIntDoubleHashMap m_mTripleParametermValues[][];
    private TIntDoubleHashMap m_mQuadrupleParametermValues[][][];
}
