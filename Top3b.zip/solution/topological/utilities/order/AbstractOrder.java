// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AbstractOrder.java

package solution.topological.utilities.order;

import gnu.trove.*;

import java.util.*;

import solution.topological.utilities.BeliefState;
import solution.topological.utilities.graph.AcyclicGraph;
import solution.topological.utilities.graph.Graph;

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 10 juil. 2009
 *
 */
public abstract class AbstractOrder
{
    protected class Step
    {

        public void reInit()
        {
            next = -1;
        }

        public int getNext()
        {
            return next;
        }

        public void setNext(int s)
        {
            next = s;
            setNext();
        }

        public int getCurrentState()
        {
            return sCurrent;
        }

        public void setCurrentState(int s)
        {
            sCurrent = s;
            visited[getSccID(sCurrent)].add(sCurrent);
            setNext();
        }

        public int getNextState()
        {
            return sNext;
        }

        public void setNextState(int s)
        {
            sNext = s;
        }

        public int getNextAction()
        {
            return aNext;
        }

        public void setNextAction(int a)
        {
            aNext = a;
        }

        public int getNextObservation()
        {
            return oNext;
        }

        public void setNextObservation(int o)
        {
            oNext = o;
        }

        @Override
        public String toString()
        {
            return (new StringBuilder("sCurrent=")).append(sCurrent).append(" aNext=").append(aNext).append(" sNext=").append(sNext).append(" oNext=").append(oNext).toString();
        }

        private void setNext()
        {
            if((next < 0 || sCurrent == next) && !initialPositions.isEmpty() && initialPositions.containsKey(Integer.valueOf(sCurrent)))
            {
                int pos = initialPositions.get(sCurrent);
                next = pos >= order.size() - 2 ? -1 : order.get(pos + 1);
            }
        }

        private int next;
        private int sCurrent;
        private int sNext;
        private int aNext;
        private int oNext;

        public Step(int _sCurrent)
        {
           super();
           next = -1;
           setCurrentState(_sCurrent);
        }
    }

    private class Triplet
        implements Comparable<Triplet>
    {

        public int compareTo(Triplet arg1)
        {
            if(forward == arg1.forward)
            {
                if(backward == arg1.backward)
                    return Double.compare(value,arg1.value);
                else
                    return Double.compare(backward,arg1.backward);
            } else
            {
                return Double.compare(forward,arg1.forward);
            }
        }

        @Override
        public String toString()
        {
            return (new StringBuilder("(s:")).append(state).append(", f:").append(forward).append(", b:").append(backward).append(" v:").append(value).append(")").toString();
        }

        protected int state;
        protected double forward;
        protected double backward;
        protected double value;

        public Triplet(int _state, double _forward, double _backward, double _value)
        {
            super();
            state = _state;
            value = Double.valueOf(_value);
            forward = Double.valueOf(_forward);
            backward = Double.valueOf(_backward);
        }
    }


    public AbstractOrder()
    { //
    }

    public abstract void pickNextState();

    public abstract void pickNextAction();

    public abstract void pickNextObservation();

    protected abstract void update();

    protected abstract int getNbStates();

    protected abstract int getNbActions();

    public abstract double getValue(int i);

    protected abstract boolean checkHasConverged(int i);

    protected abstract boolean checkHasLocallyConverged(int i);

    public boolean checkGoal()
    {
        return agraph.getSuccessors(getSccID(step.getCurrentState())).isEmpty();
    }

    public boolean checkTerminal()
    {
        return step.getNextState() < 0 || step.getNextAction() < 0 || checkSolved(step.getNextState());
    }

    public int getNextAction()
    {
        return step.getNextAction();
    }

    public int getNextObservation()
    {
        return step.getNextObservation();
    }

    public int getCurrentState()
    {
        return step.getCurrentState();
    }

    public int getNext()
    {
        return step.getNext();
    }

    public void setCurrentState(int s)
    {
        step.setCurrentState(s);
    }

    public Integer getNextState()
    {
        return step.getNextState();
    }

    public void setOrder(BeliefState _start)
    {
        init();
        int start = -1;
        int scc = -1;
        for(TIntDoubleIterator iterator = _start.getNonZeroStates().iterator(); iterator.hasNext(); )
        {
          iterator.advance();
            int s = iterator.key(); 
            if(start < 0)
            {
                start = s;
                scc = getSccID(s);
            } else
            if(scc > getSccID(s))
            {
                start = s;
                scc = getSccID(s);
            }
        }

        order = new TIntArrayList();
        forward = new double[getNbStates()];
        backward = new double[getNbStates()];
        TIntStack queue = new TIntStack();
        TIntHashSet visited = new TIntHashSet();
        queue.push(start);
        forward[start] = 0.0D;
        visited.add(Integer.valueOf(start));
        do
        {
            int s = ((Integer)queue.pop()).intValue();
            for(TIntIterator iterator1 = graph.getSuccessors(s).iterator(); iterator1.hasNext();)
            {
                int s2 = iterator1.next();
                if(!visited.contains(s2))
                {
                    queue.push(s2);
                    visited.add(s2);
                    forward[s2] = forward[s] + 1.0D;
                }
            }

        } while(queue.size() != 0);
        queue.clear();
        for(TIntIterator iterator2 = visited.iterator(); iterator2.hasNext();)
        {
            int s2 = iterator2.next();
            if(agraph.getSuccessors(getSccID(s2)).isEmpty())
            {
                queue.push(s2);
                backward[s2] = getSccID(s2);
            }
        }

        visited.clear();
        visited.addAll(queue.toNativeArray());
        do
        {
            int s = ((Integer)queue.pop()).intValue();
            for(TIntIterator iterator3 = graphT.getSuccessors(s).iterator(); iterator3.hasNext();)
            {
                int s2 = iterator3.next();
                if(!visited.contains(s2))
                {
                    queue.push(s2);
                    visited.add(s2);
                }
                backward[s2] = Math.max(backward[s] - 1.0D, backward[s2]);
            }

        } while(queue.size() != 0);
        queue.clear();
        queue.push(start);
        visited.clear();
        visited.add(start);
        Vector<Triplet> orderTmp = new Vector<Triplet>();
        do
        {
            int s = queue.pop();
            initialPositions.put(s, order.size());
            order.add(s);
            orderTmp.clear();
            for(TIntIterator iterator4 = graph.getSuccessors(s).iterator(); iterator4.hasNext();)
            {
                int s2 = iterator4.next();
                if(!visited.contains(s2))
                {
                    visited.add(s2);
                    orderTmp.add(new Triplet(s2, forward[s2], backward[s2], getValue(s2)));
                }
            }

            Collections.sort(orderTmp);
            Triplet t;
            for(Iterator<Triplet> iterator5 = orderTmp.iterator(); iterator5.hasNext(); queue.push(t.state))
                t = iterator5.next();

        } while(queue.size() != 0);
        step = new Step(order.get(0));
    }

    public void setNextAction(int a)
    {
        step.setNextAction(a);
    }

    protected boolean checkSolved(Integer s)
    {
        return solved[getSccID(s)];
    }

    public boolean checkSolved()
    {
        return checkSolved(step.getCurrentState());
    }

    public int getSccID(Integer s)
    {
        return s.intValue() >= 0 ? ((AcyclicGraph)agraph).id[s.intValue()] : -1;
    }

    public int getSccID()
    {
        return ((AcyclicGraph)agraph).id[getCurrentState()];
    }

    public TIntArrayList getSccStates(Integer s)
    {
        return ((AcyclicGraph)agraph).sCCs.get(getSccID(s));
    }

    public TIntArrayList getSccStates()
    {
        return ((AcyclicGraph)agraph).sCCs.get(getSccID());
    }

    public void setDelta(double ndelta)
    {
        Integer s = Integer.valueOf(getCurrentState());
        dGo[s.intValue()] = 0.0D;
        if(ndelta <= dEpsilon)
            visited[getSccID(s)].remove(s);
        else
        if(ndelta > dEpsilon)
        {
            int pred;
            for(TIntIterator iterator = graphT.getSuccessorsNode(s).iterator(); iterator.hasNext(); visited[getSccID(pred)].add(pred))
            {
                pred = iterator.next();
                dGo[pred] += ndelta;
            }

        }
        minDelta[getSccID(step.getCurrentState())] = ndelta;
        delta[getSccID(step.getCurrentState())] = Math.max(ndelta, getDelta());
        minStateDelta[step.getCurrentState()] = Math.max(getMinStateDelta(), ndelta);
    }

    protected double getMinStateDelta(int s)
    {
        return minStateDelta[s];
    }

    public double getMinStateDelta()
    {
        return getMinStateDelta(step.getCurrentState());
    }

    public double getEpsilon()
    {
        return dEpsilon;
    }

    public void setEpsilon(double _dEpsilon)
    {
        dEpsilon = _dEpsilon;
    }

    public double getDelta(int s)
    {
        return delta[getSccID(Integer.valueOf(s))];
    }

    public double getDelta()
    {
        return getDelta(step.getCurrentState());
    }

    protected double getMinDelta(int s)
    {
        return minDelta[getSccID(Integer.valueOf(s))];
    }

    public double getMinDelta()
    {
        return getMinDelta(step.getCurrentState());
    }

    public boolean setSolved()
    {
        boolean finishedTrial = false;
        Integer s = step.getCurrentState();
        if(visited[getSccID(s)].isEmpty())
        {
            minStateDelta[s.intValue()] = -1D;
            delta[getSccID(s)] = minDelta[getSccID(s)];
            finishedTrial = true;
        }
        if(checkHasConverged(s.intValue()))
        {
            getSolved();
            finishedTrial = true;
        }
        return finishedTrial;
    }

    public void getSolved()
    {
        Integer s = step.getCurrentState();
        solved[getSccID(s)] = true;
        int pred;
        for(TIntIterator iterator = agraphT.getSuccessors(getSccID(s)).iterator(); iterator.hasNext(); remove(pred, getSccID(s)))
            pred = iterator.next();

        remove();
    }

    protected void init()
    {
        agraph = graph.getAcyclicGraph(1);
        initialPositions = new TIntIntHashMap();
        delta = new double[agraph.size()];
        solved = new boolean[agraph.size()];
        visited = new TIntHashSet[agraph.size()];
        minDelta = new double[agraph.size()];
        for(int scc : agraph.getVertices().toNativeArray())
        {
            agraph.removeSuccessor(scc, scc);
            delta[scc] = 1.0D;
            minDelta[scc] = 1.0D;
            solved[scc] = false;
            visited[scc] = new TIntHashSet(((AcyclicGraph)agraph).sCCs.get(scc).toNativeArray());
        }

        dGo = new double[graph.size()];
        minStateDelta = new double[graph.size()];
        for(int s : graph.getVertices().toNativeArray())
        {
            dGo[s] = getValue(s);
            if(dGo[s] == 0.0D)
                visited[getSccID(s)].remove(s);
            minStateDelta[s] = -1D;
        }

        rand = new Random();
        graphT = graph.transpose();
        agraphT = agraph.transpose();
    }

    protected boolean isNotTrustable(int s, int s2)
    {
        return checkSolved(s2) || s == s2 && dGo[s] < dEpsilon;
    }

    public boolean isBackupAble()
    {
        return dGo[getCurrentState()] > 0.0D;
    }

    private void remove(int arg0, int arg1)
    {
        agraph.removeSuccessor(arg0, arg1);
    }

    private void remove()
    {
        for(TIntIntIterator iterator = initialPositions.iterator(); iterator.hasNext(); iterator.advance())
        {
            int s = iterator.key();
            if(checkSolved(s))
                order.remove(s);
        }

        initialPositions.clear();
        for(int pos = 0; pos < order.size(); pos++)
            if(!initialPositions.containsKey(order.get(pos)))
                initialPositions.put(order.get(pos), pos);

        if(!order.contains(step.getNext()))
            step.setNext(-1);
    }

    protected Step step;
    protected Random rand;
    protected double dEpsilon;
    protected boolean solved[];
    protected TIntArrayList order;
    protected TIntHashSet visited[];
    protected double delta[];
    protected double minDelta[];
    protected double minStateDelta[];
    protected double dGo[];
    protected TIntIntHashMap initialPositions;
    protected Graph graph;
    protected Graph graphT;
    protected Graph agraph;
    protected Graph agraphT;
    protected double forward[];
    protected double backward[];
}
