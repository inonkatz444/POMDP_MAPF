// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Pair.java

package solution.topological.utilities;


public class Pair<E,F>
    implements java.util.Map.Entry<Object, Object>
{

    public Pair(E first, F second)
    {
        m_first = first;
        m_second = second;
    }

    public Pair()
    {
        this(null, null);
    }

    public E first()
    {
        return m_first;
    }

    public F second()
    {
        return m_second;
    }

    @Override
    public String toString()
    {
        return (new StringBuilder("<")).append(m_first).append(",").append(m_second).append(">").toString();
    }

    public E getKey()
    {
        return first();
    }

    public F getValue()
    {
        return second();
    }

    public F setValue(Object F)
    {
        return null;
    }

    public void setFirst(E o)
    {
        m_first = o;
    }

    public void setSecond(F o)
    {
        m_second = o;
    }

    protected E m_first;
    protected F m_second;
}
