// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   SparseAlphaVector.java

package solution.topological.utilities;

import gnu.trove.*;
import solution.topological.environments.POMDP;

// Referenced classes of package pomdp.utilities:
//            AlphaVector, BeliefState

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 10 juil. 2009
 *
 */
public class SparseAlphaVector extends AlphaVector
{

    public SparseAlphaVector(BeliefState bsWitness, int iAction, POMDP pomdp)
    {
        super(bsWitness, iAction, pomdp);
        m_mValues = new TIntDoubleHashMap();
    }

    @Override
    public double valueAt(int iState)
    {
      if (m_mValues.containsKey(iState))
        return m_mValues.get(iState) - m_dOffset;
      return 0;
    }

    @Override
    public void setValue(int iState, double dValue)
    {
        Integer iKey = new Integer(iState);
        Double dDoubleValue = m_mValues.remove(iKey);
        if(dValue != 0.0D)
        {
            dDoubleValue = new Double(dValue);
            m_mValues.put(iKey, dDoubleValue);
            if(dValue > m_dMaxValue)
                m_dMaxValue = dValue;
            m_dAvgValue += dValue / m_cStates;
        }
    }

    @Override
    public TIntDoubleIterator getNonZeroEntries()
    {
        return m_mValues.iterator();
    }

    @Override
    public void finalizeValues()
    {//
    }

    @Override
    public AlphaVector newAlphaVector()
    {
        AlphaVector avResult = new SparseAlphaVector(null, 0, m_pPOMDP);
        return avResult;
    }

    @Override
    public void accumulate(AlphaVector av)
    {
        int iState = 0;
        double dValue = 0.0D;
        double dLocalValue = 0.0D;
        TIntDoubleIterator itNonZero = av.getNonZeroEntries();
        if(itNonZero != null)
        {
            for(; itNonZero.hasNext(); setValue(iState, dValue + dLocalValue))
            {
              itNonZero.advance();
                iState = itNonZero.key();
                dValue = itNonZero.value();
                dLocalValue = valueAt(iState);
            }

        } else
        {
            for(iState = 0; iState < m_cStates; iState++)
                setValue(iState, valueAt(iState) + av.valueAt(iState));

        }
    }

    @Override
    public int getNonZeroEntriesCount()
    {
        return m_mValues.size();
    }

    @Override
    public long countLocalEntries()
    {
        return m_mValues.size();
    }

    @Override
    public long size()
    {
        return m_mValues.size();
    }

    @Override
    public void setSize(int i)
    {//
    }

    @Override
    public void accumulate(AlphaVector av, TIntHashSet iStates)
    {
        int iState = 0;
        double dValue = 0.0D;
        double dLocalValue = 0.0D;
        TIntIterator itNonZero = iStates.iterator();
        if(itNonZero != null)
        {
            for(; itNonZero.hasNext(); setValue(iState, dValue + dLocalValue))
            {
                iState = itNonZero.next();
                dValue = av.valueAt(iState);
                dLocalValue = valueAt(iState);
            }

        } else
        {
            for(iState = 0; iState < m_cStates; iState++)
                setValue(iState, valueAt(iState) + av.valueAt(iState));

        }
    }

    protected TIntDoubleHashMap m_mValues;
}
