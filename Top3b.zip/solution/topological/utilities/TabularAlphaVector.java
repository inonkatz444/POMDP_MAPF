// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   TabularAlphaVector.java

package solution.topological.utilities;

import gnu.trove.*;
import solution.topological.environments.POMDP;

// Referenced classes of package pomdp.utilities:
//            AlphaVector, Pair, BeliefState

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 10 juil. 2009
 *
 */
public class TabularAlphaVector extends AlphaVector
{

    public TabularAlphaVector(BeliefState bsWitness, double dDefaultValue, POMDP pomdp)
    {
        this(bsWitness, 0, pomdp);
        int iState = 0;
        if (dDefaultValue!=0.0D)
          for(iState = 0; iState < m_cStates; iState++)
            m_aValues[iState] = dDefaultValue;

        m_dOffset = 0.0D;
        m_mValues = null;
    }

    public TabularAlphaVector(BeliefState bsWitness, int iAction, POMDP pomdp)
    {
        super(bsWitness, iAction, pomdp);
        m_aValues = new double[m_cStates];
        m_mValues = null;
    }

    @Override
    public double valueAt(int iState)
    {
        if(m_aValues != null)
            return m_aValues[iState] - m_dOffset;
        else
            return m_mValues.get(iState) - m_dOffset;
    }

    @Override
    public void setValue(int iState, double dValue)
    {
        if(dValue > m_dMaxValue)
            m_dMaxValue = dValue;
        m_dAvgValue += dValue / m_cStates;
        m_aValues[iState] = dValue;
    }

    
	@Override
  public TIntDoubleIterator getNonZeroEntries()
    {
        if(m_mValues == null)
            finalizeValues();
        return m_mValues.iterator();
    }

    @Override
    public void finalizeValues()
    {
        m_mValues = new TIntDoubleHashMap();
        int i=0;
        for (double v : m_aValues)
        {
          if (Math.abs(v)>0.001D)
            m_mValues.put(i, v);
          i++;
        }
        g_cGain += m_aValues.length - m_mValues.size() * 2;
        g_cFinalized++;
        m_aValues = null;
    }

    @Override
    public AlphaVector newAlphaVector()
    {
        AlphaVector avResult = new TabularAlphaVector(null, getAction(), m_pPOMDP);
        return avResult;
    }

    @Override
    public void accumulate(AlphaVector av)
    {
        int iState = 0;
        double dValue = 0.0D;
        double dLocalValue = 0.0D;
        TIntDoubleIterator itNonZero = av.getNonZeroEntries();
        if(itNonZero != null)
        {
            for(; itNonZero.hasNext(); setValue(iState, dValue + dLocalValue))
            {
                itNonZero.advance();
                iState = itNonZero.key();
                dValue = itNonZero.value();
                dLocalValue = valueAt(iState);
            }

        } else
        {
            for(iState = 0; iState < m_cStates; iState++)
                setValue(iState, valueAt(iState) + av.valueAt(iState));

        }
    }

    @Override
    public int getNonZeroEntriesCount()
    {
        return m_mValues.size();
    }

    @Override
    public long countLocalEntries()
    {
        return m_mValues.size();
    }

    @Override
    public long size()
    {
        return m_mValues.size();
    }

    @Override
    public void setSize(int cStates)
    {
        m_cStates = cStates;
        m_aValues = new double[m_cStates];
        m_mValues = null;
    }

    @Override
    public void accumulate(AlphaVector av, TIntHashSet iStates)
    {
        int iState = 0;
        double dValue = 0.0D;
        double dLocalValue = 0.0D;
        TIntDoubleIterator itNonZero = av.getNonZeroEntries();
        if(itNonZero != null)
        {
            while(itNonZero.hasNext()) 
            {
              itNonZero.advance();
                iState = itNonZero.key();
                if(iStates.contains(Integer.valueOf(iState)))
                {
                    dValue = itNonZero.value();
                    dLocalValue = valueAt(iState);
                    setValue(iState, dValue + dLocalValue);
                }
            }
        } else
        {
            for(iState = 0; iState < m_cStates; iState++)
                setValue(iState, valueAt(iState) + av.valueAt(iState));

        }
    }

    private double[] m_aValues;
    private TIntDoubleHashMap m_mValues;
    private static int g_cGain = 0;
    private static int g_cFinalized = 0;

    /**
     * Clears all static values 
     */
    public static void clearStatic()
    {
      g_cFinalized = 0;
      g_cGain = 0;
    }

}
