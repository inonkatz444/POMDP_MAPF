// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LineReader.java

package solution.topological.utilities;

import java.io.*;

// Referenced classes of package pomdp.utilities:
//            EndOfFileException

public class LineReader
{

    public LineReader(String sFileName)
        throws IOException
    {
    	System.out.println(sFileName);
        m_fosInput = new BufferedReader(new FileReader(sFileName));
    }

    public String readLine()
        throws IOException, EndOfFileException
    {
        String sLine = m_fosInput.readLine();
        return sLine;
    }

    public boolean endOfFile()
        throws IOException
    {
        return !m_fosInput.ready();
    }

    BufferedReader m_fosInput;
}
