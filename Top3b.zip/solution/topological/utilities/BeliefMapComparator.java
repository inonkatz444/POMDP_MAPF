// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BeliefMapComparator.java

package solution.topological.utilities;

import gnu.trove.TIntDoubleHashMap;
import gnu.trove.TIntDoubleIterator;

import java.util.*;

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 10 juil. 2009
 *
 */
public class BeliefMapComparator
    implements Comparator<TIntDoubleHashMap>
{
    public class Belief
    {

        public int iState;
        public double dValue;

        public Belief(TIntDoubleIterator it)
        {
            if(it.hasNext())
            {
              it.advance();
                iState = it.key();
                dValue = it.value();
            } else
            {
                iState = 0x7fffffff;
                dValue = -1D;
            }
        }
    }


    private BeliefMapComparator()
    { //
    }

    public static BeliefMapComparator getInstance()
    {
        if(m_bmcComparator == null)
            m_bmcComparator = new BeliefMapComparator();
        return m_bmcComparator;
    }

    protected double diff(double d1, double d2)
    {
        double dResult = d1 - d2;
        if(dResult < 0.0D)
            dResult *= -1D;
        return dResult;
    }

    public int compare(TIntDoubleHashMap mEntries1, TIntDoubleHashMap mEntries2)
    {
        if(mEntries1.size() != mEntries2.size())
            return mEntries1.size() - mEntries2.size();
        TIntDoubleIterator itFirstNonZero = mEntries1.iterator();
        TIntDoubleIterator itSecondNonZero = mEntries2.iterator();
        int iState1 = -1;
        int iState2 = -1;
        double dValue1 = 0.0D;
        double dValue2 = 0.0D;
        Belief b = null;
        while(iState1 < 0x7fffffff || iState2 < 0x7fffffff) 
            if(iState1 == iState2)
            {
                if(diff(dValue1, dValue2) > 1E-08D)
                    return dValue1 <= dValue2 ? -1 : 1;
                b = new Belief(itFirstNonZero);
                iState1 = b.iState;
                dValue1 = b.dValue;
                b = new Belief(itSecondNonZero);
                iState2 = b.iState;
                dValue2 = b.dValue;
            } else
            {
                if(iState1 < iState2)
                    return 1;
                if(iState2 < iState1)
                    return -1;
            }
        return 0;
    }

    protected static BeliefMapComparator m_bmcComparator = null;

}
