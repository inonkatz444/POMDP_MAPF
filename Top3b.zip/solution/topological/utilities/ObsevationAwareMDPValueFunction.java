// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ObsevationAwareMDPValueFunction.java

package solution.topological.utilities;

import gnu.trove.*;
import solution.topological.environments.POMDP;
import solution.topological.utilities.datastructures.DoubleVector;

// Referenced classes of package pomdp.utilities:
//            MDPValueFunction, AlphaVector, Logger

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 10 juil. 2009
 *
 */
public class ObsevationAwareMDPValueFunction extends MDPValueFunction
{

    public ObsevationAwareMDPValueFunction(POMDP pomdp, double dExplorationRate)
    {
        super(pomdp, dExplorationRate);
        m_dObservationReward = 10D;
        m_vObservationStates = pomdp.getObservationRelevantStates();
        m_cObservationStates = m_vObservationStates.size();
        m_cStates = pomdp.getStateCount() * (int)Math.pow(2D, m_cObservationStates);
        m_adValues = new DoubleVector(m_cStates);
        computeValidStates();
    }

    private int[] getObservationAwareState(int iState)
    {
        int aiState[] = new int[m_cObservationStates + 1];
        int i = 0;
        for(i = 0; i < m_cObservationStates; i++)
        {
            aiState[i] = iState % 2;
            iState /= 2;
        }

        aiState[m_cObservationStates] = iState;
        return aiState;
    }

    private int getFullState(int aiState[])
    {
        int i = 0;
        int iState = 0;
        for(i = m_cObservationStates; i >= 0; i--)
        {
            iState *= 2;
            iState += aiState[i];
        }

        return iState;
    }

    private int countObservationVariableChanges(int aiS1[], int aiS2[])
    {
        int i = 0;
        int cChanges = 0;
        for(i = 0; i < m_cObservationStates; i++)
            if(aiS1[i] != aiS2[i])
                cChanges++;

        return cChanges;
    }

    private int firstObservationVariableChange(int aiS1[], int aiS2[])
    {
        int i = 0;
        for(i = 0; i < m_cObservationStates; i++)
            if(aiS1[i] != aiS2[i])
                return i;

        return -1;
    }

    private int getObservationStateIndex(int iState)
    {
        return m_vObservationStates.indexOf(Integer.valueOf(iState));
    }

    @Override
    protected double tr(int iS1, int iAction, int iS2)
    {
        int aiS1[] = getObservationAwareState(iS1);
        int aiS2[] = getObservationAwareState(iS2);
        int iUnderlyingS1 = aiS1[m_cObservationStates];
        int iUnderlyingS2 = aiS2[m_cObservationStates];
        int iObservationIndex = getObservationStateIndex(iUnderlyingS1);
        int cObservationVariablesChanges = countObservationVariableChanges(aiS1, aiS2);
        int iObservationVariableChange = firstObservationVariableChange(aiS1, aiS2);
        if(cObservationVariablesChanges == 0)
        {
            if(iObservationIndex == -1)
                return m_pPOMDP.tr(iUnderlyingS1, iAction, iUnderlyingS2);
            if(aiS2[iObservationIndex] == 0)
                return m_pPOMDP.tr(iUnderlyingS1, iAction, iUnderlyingS2);
            if(aiS2[iObservationIndex] == 1)
                return m_pPOMDP.tr(iUnderlyingS1, iAction, iUnderlyingS2);
            else
                return 0.0D;
        }
        if(cObservationVariablesChanges > 1)
            return 0.0D;
        if(aiS2[iObservationVariableChange] == 1)
            return 0.0D;
        else
            return m_pPOMDP.tr(iUnderlyingS1, iAction, iUnderlyingS2);
    }

    @Override
    protected double O(int iAction, int iState, int iObservation)
    {
        int aiState[] = getObservationAwareState(iState);
        int iUnderlyingState = aiState[m_cObservationStates];
        return m_pPOMDP.O(iAction, iUnderlyingState, iObservation);
    }

    @Override
    protected double R(int iState, int iAction)
    {
        int aiState[] = getObservationAwareState(iState);
        int iUnderlyingState = aiState[m_cObservationStates];
        int iObservationIndex = getObservationStateIndex(iUnderlyingState);
        double dR = m_pPOMDP.R(iUnderlyingState, iAction);
        if(iObservationIndex > -1 && aiState[iObservationIndex] == 1)
            dR += m_dObservationReward;
        return dR;
    }

    @Override
    protected TIntDoubleIterator getNonZeroTransitions(int iState, int iAction)
    {
        TIntDoubleHashMap mTransitions = new TIntDoubleHashMap();
        int aiState[] = getObservationAwareState(iState);
        int iUnderlyingState = aiState[m_cObservationStates];
        int iFullState = 0;
        int iObservationIndex = getObservationStateIndex(iState);
        TIntDoubleIterator itUnderlying = m_pPOMDP.getNonZeroTransitions(iUnderlyingState, iAction);
        double v;
        if(iObservationIndex != -1)
            aiState[iObservationIndex] = 0;
        for(; itUnderlying.hasNext(); mTransitions.put(Integer.valueOf(iFullState), v))
        {
          itUnderlying.advance();
            aiState[m_cObservationStates] = itUnderlying.key();
            v = itUnderlying.value();
            iFullState = getFullState(aiState);
        }

        return mTransitions.iterator();
    }

    protected TIntArrayList getValidStates()
    {
        return m_colValidStates;
    }

    protected void computeValidStates()
    {
      m_colValidStates = new TIntArrayList(m_cStates);
      for (int i=0; i<m_cStates; i++)
        m_colValidStates.add(i);
      

//        Collection<Integer> colValidStates = m_pPOMDP.getValidStates();
//        Collection<Integer> colAddObservation = new Vector<Integer>(2*colValidStates.size());
//        int i = 0;
//        for(i = 0; i < m_cObservationStates; i++)
//        {
//            int iState;
//            for(Iterator<Integer> iterator = colValidStates.iterator(); iterator.hasNext(); )
//            {
//                iState = iterator.next().intValue();
//                colAddObservation.add(Integer.valueOf(iState * 2 + 0));
//                colAddObservation.add(Integer.valueOf(iState * 2 + 1));
//            }
//
//            colValidStates = colAddObservation;
//            colAddObservation = new Vector<Integer>(2*colValidStates.size());
//        }
//
//        m_colValidStates = colValidStates;
    }

    public int getIntialState(int iState)
    {
        int aiState[] = new int[m_cObservationStates + 1];
        int i = 0;
        for(i = 0; i < m_cObservationStates; i++)
            aiState[i] = 1;

        aiState[m_cObservationStates] = iState;
        return getFullState(aiState);
    }

    @Override
    protected AlphaVector newAlphaVector()
    {
        AlphaVector av = m_pPOMDP.newAlphaVector();
        av.setSize(m_cStates);
        return av;
    }

    @Override
    public void valueIteration(int cMaxIterations, double dEpsilon)
    {
        int cMDPBackups = 0;
        double dMaxDelta = 1.7976931348623157E+308D;
        Logger.getInstance().logFull("OAMDPVF", 0, "VI", "Starting MDP value iteration");
        try
        {
            dMaxDelta = computeValueFunction(cMaxIterations, dEpsilon, false);
        }
        catch(Error e)
        {
            Logger.getInstance().logError("OAMDPVF", "VI", (new StringBuilder("Error in computeVN: ")).append(e).toString());
            throw e;
        }
        makeVectors();
        Logger.getInstance().logFull("OAMDPVF", 0, "VI", (new StringBuilder("MDP value iteration done - iterations ")).append(cMDPBackups).append(" delta ").append(dMaxDelta).toString());
    }

    public int execute(int iState, int iAction)
    {
        int aiState[] = getObservationAwareState(iState);
        int aiNewState[] = aiState.clone();
        int iUnderlyingState = aiState[m_cObservationStates];
        int iNewState = -1;
        int iNewUnderlyingState = -1;
        int iObservationIndex = getObservationStateIndex(iUnderlyingState);
        if(iObservationIndex != -1)
            aiNewState[iObservationIndex] = 0;
        iNewUnderlyingState = m_pPOMDP.execute(iAction, iUnderlyingState);
        aiNewState[m_cObservationStates] = iNewUnderlyingState;
        iNewState = getFullState(aiNewState);
        return iNewState;
    }

    public int observe(int iAction, int iState)
    {
        int aiState[] = getObservationAwareState(iState);
        int iUnderlyingState = aiState[m_cObservationStates];
        return m_pPOMDP.observe(iAction, iUnderlyingState);
    }

    public int getUnderlyingState(int iState)
    {
        int aiState[] = getObservationAwareState(iState);
        int iUnderlyingState = aiState[m_cObservationStates];
        return iUnderlyingState;
    }

    private TIntArrayList m_vObservationStates;
    private int m_cObservationStates;
    private double m_dObservationReward;
    private TIntArrayList m_colValidStates;
}
