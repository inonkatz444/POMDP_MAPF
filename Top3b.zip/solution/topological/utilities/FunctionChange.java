// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   FunctionChange.java

package solution.topological.utilities;

import gnu.trove.TIntDoubleIterator;
import solution.topological.utilities.datastructures.Function;

/**
 * Converted to trove lib 
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 10 juil. 2009
 *
 */
public class FunctionChange
{

    public FunctionChange(Function fChangeFunction, int aiParameters[], double dTargetValue, int cSteps, boolean bNormalize, String sType)
    {
        m_fChangedFunction = fChangeFunction;
        m_aiParameters = aiParameters;
        m_dTargetValue = dTargetValue;
        m_dInitialValue = m_fChangedFunction.valueAt(m_aiParameters);
        if(m_dTargetValue > m_dInitialValue)
            m_iChangeDirection = 1;
        else
            m_iChangeDirection = -1;
        m_bNormalize = bNormalize;
        m_iID = m_cChanges++;
        m_sType = sType;
        m_cSteps = cSteps;
    }

    public void init()
    {
        m_dInitialValue = m_fChangedFunction.valueAt(m_aiParameters);
        if(m_dTargetValue > m_dInitialValue)
            m_iChangeDirection = 1;
        else
            m_iChangeDirection = -1;
        m_dChangeStep = Math.abs(m_dTargetValue - m_dInitialValue) / m_cSteps;
    }

    public boolean verify()
    {
        TIntDoubleIterator itNonZero = m_fChangedFunction.getNonZeroEntries(m_aiParameters[0], m_aiParameters[1]);
       
        //int cEntries = m_fChangedFunction.countNonZeroEntries(m_aiParameters[0], m_aiParameters[1]);
        double dEntryValue = 0.0D;
        double dSum;
        for(dSum = 0.0D; itNonZero.hasNext(); dSum += dEntryValue)
        {
          itNonZero.advance();
            //int iArg3 = ((Integer)e.getKey()).intValue();
            dEntryValue = itNonZero.value();
            if(dEntryValue > 1.0009999999999999D || dEntryValue < -0.001D)
            {
                System.out.println("verify: BUGBUG - prob out of range");
                return false;
            }
        }

        if(dSum < 0.98999999999999999D || dSum > 1.01D)
        {
            System.out.println("verify: BUGBUG - probs don't sum up to 1");
            return false;
        } else
        {
            return true;
        }
    }

    public boolean done()
    {
        double dCurrentValue = m_fChangedFunction.valueAt(m_aiParameters);
        return Math.abs(m_dTargetValue - dCurrentValue) < m_dChangeStep;
    }

    public double executeStep()
    {
        if(done())
            return 1.0D;
        double dCurrentValue = m_fChangedFunction.valueAt(m_aiParameters);
        boolean bDone = false;
        if(Math.abs(m_dTargetValue - dCurrentValue) < m_dChangeStep)
        {
            dCurrentValue = m_dTargetValue;
            bDone = true;
        } else
        {
            dCurrentValue += m_dChangeStep * m_iChangeDirection;
        }
        m_fChangedFunction.setValue(m_aiParameters, dCurrentValue);
        if(m_bNormalize)
        {
            TIntDoubleIterator itNonZero = m_fChangedFunction.getNonZeroEntries(m_aiParameters[0], m_aiParameters[1]);
            int iArg3 = 0;
            int cEntries = m_fChangedFunction.countNonZeroEntries(m_aiParameters[0], m_aiParameters[1]);
            double dChange = m_dChangeStep / (cEntries - 1);
            double dEntryValue = 0.0D;
            double dSum = dCurrentValue;
            while(itNonZero.hasNext()) 
            {
              itNonZero.advance();
                iArg3 = itNonZero.key();
                if(iArg3 != m_aiParameters[2])
                {
                    dEntryValue = itNonZero.value();
                    dEntryValue -= m_iChangeDirection * dChange;
                    if(dEntryValue < 0.0001D)
                        dEntryValue = 0.0001D;
                    else
                    if(dEntryValue > 1.0001D)
                        dEntryValue = 1.0D;
                    dSum += dEntryValue;
                    m_fChangedFunction.setValue(m_aiParameters[0], m_aiParameters[1], iArg3, dEntryValue);
                }
            }
            m_fChangedFunction.setValue(m_aiParameters, (dCurrentValue + 1.0D) - dSum);
        }
        if(bDone)
            return 1.0D;
        else
            return (m_dTargetValue - dCurrentValue) / (m_dInitialValue - dCurrentValue);
    }

    public String getXMLString(int iStartStep)
    {
        String sInfo = "";
        String sParameter = "";
        sInfo = (new StringBuilder("<FunctionChange type = \"")).append(m_sType).append("\" start = \"").append(iStartStep).append("\" length = \"").append(m_cSteps).append("\" target = \"").append(m_dTargetValue).append("\">").toString();
        int iParameter = 0;
        sInfo = (new StringBuilder(String.valueOf(sInfo))).append("<Parameters>").toString();
        for(iParameter = 0; iParameter < m_aiParameters.length; iParameter++)
        {
            sParameter = (new StringBuilder("<Parameter value = \"")).append(m_aiParameters[iParameter]).append("\"/>").toString();
            sInfo = (new StringBuilder(String.valueOf(sInfo))).append(sParameter).toString();
        }

        sInfo = (new StringBuilder(String.valueOf(sInfo))).append("</Parameters>").toString();
        sInfo = (new StringBuilder(String.valueOf(sInfo))).append("</FunctionChange>").toString();
        return sInfo;
    }

    protected Function m_fChangedFunction;
    protected int m_aiParameters[];
    protected double m_dInitialValue;
    protected double m_dTargetValue;
    protected double m_dChangeStep;
    protected int m_iChangeDirection;
    protected boolean m_bNormalize;
    protected static int m_cChanges = 0;
    protected int m_iID;
    protected String m_sType;
    protected int m_cSteps;

    /**
     * Clears all static values 
     */
    public static void clear()
    {
      m_cChanges = 0;
    }

}
