// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   MDPValueFunction.java

package solution.topological.utilities;

import gnu.trove.TIntDoubleIterator;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.*;

import solution.topological.algorithms.PolicyStrategy;
import solution.topological.environments.POMDP;
import solution.topological.utilities.datastructures.DoubleVector;
import solution.topological.utilities.datastructures.IntVector;

// Referenced classes of package pomdp.utilities:
//            LinearValueFunctionApproximation, RandomGenerator, BeliefState, BeliefStateFactory, 
//            Logger, AlphaVector, TabularAlphaVector

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 10 juil. 2009
 *
 */
public class MDPValueFunction extends PolicyStrategy
{

    public static MDPValueFunction getInstance()
    {
        return g_vMDP;
    }

    public static MDPValueFunction getInstance(POMDP pomdp, double dExplorationRate)
    {
        if(g_vMDP == null)
            g_vMDP = new MDPValueFunction(pomdp, dExplorationRate);
        return g_vMDP;
    }

    protected MDPValueFunction(POMDP pomdp, double dExplorationRate)
    {
        m_pPOMDP = pomdp;
        m_vValueFunction = new LinearValueFunctionApproximation(0.0001D, false);
        m_cStates = m_pPOMDP.getStateCount();
        m_cActions = m_pPOMDP.getActionCount();
        m_cObservations = m_pPOMDP.getObservationCount();
        m_dGamma = m_pPOMDP.getDiscountFactor();
        m_adValues = new DoubleVector(m_cStates);
        m_ivBestActions = null;
        m_avBestActions = null;
        m_dExplorationRate = dExplorationRate;
        m_bConverged = false;
        m_bFirst = true;
        m_rndGenerator = new RandomGenerator("MDPVI", 0L);
    }

    protected double computeStateActionValue(int iState, int iAction)
    {
        int iEndState = 0;
        double dValue = 0.0D;
        double dTr = 0.0D;
        double dSumValues = 0.0D;
        double dQValue = 0.0D;
        TIntDoubleIterator itNonZeroTransitions = null;
        dSumValues = 0.0D;
        double dSumTr = 0.0D;
        for(itNonZeroTransitions = getNonZeroTransitions(iState, iAction); itNonZeroTransitions.hasNext();)
        {
          itNonZeroTransitions.advance();
            iEndState = itNonZeroTransitions.key();
            dTr = itNonZeroTransitions.value();
            dSumTr += dTr;
            dValue = getValue(iEndState);
            dSumValues += dTr * dValue;
        }

        dQValue = R(iState, iAction) + m_dGamma * dSumValues;
        return dQValue;
    }

    protected double updateState(int iStartState)
    {
        int iAction = 0;
        int iMaxAction = -1;
        double dMaxQValue = 0.0D;
        double dQValue = 0.0D;
        double dDelta = 0.0D;
        dMaxQValue = (-1.0D / 0.0D);
        for(iAction = 0; iAction < m_cActions; iAction++)
        {
            dQValue = computeStateActionValue(iStartState, iAction);
            if(dQValue > dMaxQValue)
            {
                iMaxAction = iAction;
                dMaxQValue = dQValue;
            }
        }

        dDelta = diff(dMaxQValue, getValue(iStartState));
        setValue(iStartState, dMaxQValue);
        m_ivBestActions.set(iStartState, iMaxAction);
        return dDelta;
    }

    public double getQValue(int iState, int iAction)
    {
        int iEndState = 0;
        TIntDoubleIterator itNonZero = null;
        double dValue = R(iState, iAction);
        double dTr = 0.0D;
        double dNextValue = 0.0D;
        for(itNonZero = getNonZeroTransitions(iState, iAction); itNonZero.hasNext();)
        {
          itNonZero.advance();
            iEndState = itNonZero.key();
            dTr = itNonZero.value();
            dNextValue = getValue(iEndState);
            dValue += m_dGamma * dTr * dNextValue;
        }

        return dValue;
    }

    public double getQValue(BeliefState bs, int iAction)
    {
        int iStartState = 0;
        TIntDoubleIterator itStates = bs.getNonZeroEntries();
        double dPr = 0.0D;
        double dValue = 0.0D;
        double dSum = 0.0D;
        while(itStates.hasNext()) 
        {
          itStates.advance();
            iStartState = itStates.key();
            dPr = itStates.value();
            dValue = getQValue(iStartState, iAction);
            dSum += dPr * dValue;
        }
        return dSum;
    }

    protected double getMaxImmediateReward(int iState)
    {
        double dMaxReward = 0.0D;
        int iAction = 0;
        for(iAction = 0; iAction < m_cActions; iAction++)
            if(R(iState, iAction) > dMaxReward)
                dMaxReward = R(iState, iAction);

        return dMaxReward;
    }

    protected void makeVectors()
    {
        int iAction = 0;
        int iMaxAction = 0;
        AlphaVector av = null;
        m_vValueFunction.clear();
        double dQValue = 0.0D;
        double dMaxQValue = 0.0D;
        BeliefState bsUniform = BeliefStateFactory.getInstance().getUniformBeliefState();
        if(m_bFullQFunction)
        {
            Logger.getInstance().logFull("MDPVF", 0, "makeVectors", "Started creating Q function vectors");
            for(iAction = 0; iAction < m_cActions; iAction++)
            {
                av = newAlphaVector();
                av.setAction(iAction);
                for (int iState=0; iState < m_cStates; iState++)
                {
//              for(Iterator<Integer> iterator = getValidStates().iterator(); iterator.hasNext();)
//              {
//                  int iState = iterator.next().intValue();
                  dQValue = getQValue(iState, iAction);
                  if(dQValue != 0.0D)
                      av.setValue(iState, dQValue);
                }

                av.finalizeValues();
                av.setWitness(bsUniform);
                m_vValueFunction.add(av, false);
                Logger.getInstance().logFull("MDPVF", 0, "makeVectors", (new StringBuilder("Done creating for action ")).append(iAction).toString());
            }

        } else
        {
            Logger.getInstance().logFull("MDPVF", 0, "makeVectors", "Started creating policy mapping");
            m_avBestActions = newAlphaVector();
            if(m_ivBestActions != null)
            {
              for (int iState=0; iState < m_cStates; iState++)
              {
//            for(Iterator<Integer> iterator1 = getValidStates().iterator(); iterator1.hasNext();)
//            {
//                int iState = iterator1.next().intValue();
                iAction = m_ivBestActions.elementAt(iState);
                m_avBestActions.setValue(iState, iAction);
                if(iState > 0 && iState % 10000 == 0)
                    Logger.getInstance().logFull("MDPVF", 0, "makeVectors", (new StringBuilder("Done computing ")).append(iState).append(" states").toString());
              }

            } else
            {
              for (int iState=0; iState < m_cStates; iState++)
              {
//            for(Iterator<Integer> iterator2 = getValidStates().iterator(); iterator2.hasNext();)
//            {
//                int iState = iterator2.next().intValue();
                dMaxQValue = Double.NEGATIVE_INFINITY;
                iMaxAction = -1;
                for(iAction = 0; iAction < m_cActions; iAction++)
                {
                    dQValue = getQValue(iState, iAction);
                    if(dQValue > dMaxQValue)
                    {
                        dMaxQValue = dQValue;
                        iMaxAction = iAction;
                    }
                }

                m_avBestActions.setValue(iState, iMaxAction);
                if(iState > 0 && iState % 10000 == 0)
                    Logger.getInstance().logFull("MDPVF", 0, "makeVectors", (new StringBuilder("Done computing ")).append(iState).append(" states").toString());
              }
            }
            m_avBestActions.finalizeValues();
            Logger.getInstance().logFull("MDPVF", 0, "makeVectors", (new StringBuilder("Done creating policy, |S| = ")).append(m_cStates).append(", vertex count = ").append(m_avBestActions.countEntries()).toString());
        }
    }

    protected void improveVectors(int cMaxIterations)
    {
        int iIteration = 0;
        int iObservation = 0;
        int iAction = 0;
        int iNextAction = 0;
        int iNextState = 0;
        LinearValueFunctionApproximation vNextValueFunction = null;
        double dTr = 0.0D;
        double dObservation = 0.0D;
        double dValue = 0.0D;
        double dNextValue = 0.0D;
        double dMaxActionValue = 0.0D;
        double dObservationValue = 0.0D;
        AlphaVector avNext = null;
        AlphaVector avCurrent = null;
        TIntDoubleIterator itNonZeroStates = null;
        System.out.println("Started improving the vectors");
        for(iIteration = 0; iIteration < cMaxIterations; iIteration++)
        {
            vNextValueFunction = new LinearValueFunctionApproximation(0.0001D, false);
            for(iAction = 0; iAction < m_cActions; iAction++)
            {
                avNext = new TabularAlphaVector(null, iAction, m_pPOMDP);
                avNext.setAction(iAction);
                dNextValue = 0.0D;
                for (int iState=0; iState < m_cStates; iState++)
                {
R(iState, iAction);
                    dObservationValue = 0.0D;
                    for(iObservation = 0; iObservation < m_cObservations; iObservation++)
                    {
                        dMaxActionValue = -1.7976931348623157E+308D;
                        for(iNextAction = 0; iNextAction < m_cActions; iNextAction++)
                        {
                            dNextValue = 0.0D;
                            for(itNonZeroStates = getNonZeroTransitions(iState, iAction); itNonZeroStates.hasNext();)
                            {
                              itNonZeroStates.advance();
                                iNextState = itNonZeroStates.key();
                                dTr = itNonZeroStates.value();
                                dObservation = O(iNextAction, iNextState, iObservation);
                                if(dObservation > 0.0D)
                                {
                                    avCurrent = m_vValueFunction.elementAt(iNextAction);
                                    dValue = avCurrent.valueAt(iNextState);
                                    dNextValue += dValue * dObservation * dTr;
                                }
                            }

                            if(dNextValue > dMaxActionValue)
                                dMaxActionValue = dNextValue;
                        }

                        dObservationValue += dMaxActionValue;
                    }
                }

                vNextValueFunction.add(avNext);
            }

            m_vValueFunction.clear();
            m_vValueFunction = vNextValueFunction;
            System.out.println((new StringBuilder("After ")).append(iIteration).append(" iterations: V = ").append(m_vValueFunction).toString());
        }

    }

    @Override
    public LinearValueFunctionApproximation getValueFunction()
    {
        return m_vValueFunction;
    }

    public double computeValueFunction(int cMaxIterations, double dEpsilon, boolean bFixedPolicy)
    {
        int iIteration = 0;
        int iMaxState = 0;
        int iMinState = 0;
        double dDelta = 0.0D;
        double dMaxDelta = 1000D;
        double dMaxValue = 0.0D;
        double dMinValue = 0.0D;
        double dValue = 0.0D;
        int iAction = 0;
        int iMaxAction = 0;
        int iState;
        m_ivBestActions = new IntVector(m_cStates);
        long cpt=System.currentTimeMillis()+1000; //XXX added
//        for(Iterator iterator = getValidStates().iterator(); 
//            iterator.hasNext(); 
//            setValue(iState, dMaxValue))
//        {
//        iState = ((Integer)iterator.next()).intValue();
        for (iState=0; iState<m_cStates; setValue(iState++, dMaxValue))
        {
            long tmp = System.currentTimeMillis();
            
            if (tmp>cpt)
            {
              System.out.println(iState);
              cpt = tmp+1000;
            }
            dMaxValue = (-1.0D / 0.0D);
            if(bFixedPolicy)
            {
                iMaxAction = (int)m_avBestActions.valueAt(iState);
                dMaxValue = R(iState, iAction);
            } else
            {
                for(iAction = 0; iAction < m_cActions; iAction++)
                {
                    dValue = R(iState, iAction);
                    if(dValue > dMaxValue)
                    {
                        dMaxValue = dValue;
                        iMaxAction = iAction;
                    }
                }

            }
        }

        Logger.getInstance().logFull("MDPVI", 0, "ComputeV", "Starting to compute value function");
        for(iIteration = 0; iIteration < cMaxIterations && dMaxDelta > dEpsilon; iIteration++)
        {
            dMaxDelta = 0.0D;
            iMaxState = -1;
            iMinState = -1;
            dMaxValue = -1000D;
            dMinValue = 1000D;
            Logger.getInstance().logFull("MDPVI", 0, "ComputeV", (new StringBuilder("Start iteration ")).append(iIteration).toString());
//            for(Iterator<Integer> iterator1 = getValidStates().iterator(); iterator1.hasNext();)
//            {
//                iState = iterator1.next().intValue();
            for (iState=0; iState<m_cStates; iState++)
            {
                if(bFixedPolicy)
                {
                    iMaxAction = (int)m_avBestActions.valueAt(iState);
                    dMaxValue = computeStateActionValue(iState, iMaxAction);
                    dValue = getValue(iState);
                    dDelta = dMaxValue - dValue;
                    setValue(iState, dMaxValue);
                } else
                {
                    dDelta = updateState(iState);
                }
                if(iState % 0x186a0 == 0 && iState > 0)
                    Logger.getInstance().logFull("MDPVI", 0, "ComputeV", (new StringBuilder("Iteration ")).append(iIteration).append(" done ").append(iState).append(" states").toString());
                if(dDelta > dMaxDelta)
                    dMaxDelta = dDelta;
                dValue = getValue(iState);
                if(dValue > dMaxValue)
                {
                    dMaxValue = dValue;
                    iMaxState = iState;
                } else
                if(dValue < dMinValue)
                {
                    dMinValue = dValue;
                    iMinState = iState;
                }
            }

            if(iIteration % 100 == 0 || dMaxDelta <= dEpsilon)
                Logger.getInstance().logFull("MDPVF", 0, "computeValueFunction", (new StringBuilder("After ")).append(iIteration).append(" iterations, delta = ").append(dMaxDelta).append(" min ").append(iMinState).append(" = ").append(dMinValue).append(" max ").append(iMaxState).append(" = ").append(dMaxValue).toString());
        }

        return dMaxDelta;
    }

    public void valueIteration(int cMaxIterations, double dEpsilon)
    {
        int cMDPBackups = 0;
        double dMaxDelta = Double.MAX_VALUE;
        String sFileName = new StringBuilder(String.valueOf(System.getProperty("user.dir"))).append("/").append(m_pPOMDP.getName()).append("QMDP.xml").toString();
        if(m_bFirst && !sFileName.equals(""))
            try
            {
                Logger.getInstance().logFull("MDPVF", 0, "VI", "Started loading QMDP value function");
                load(sFileName);
                Logger.getInstance().logFull("MDPVF", 0, "VI", "QMDP value function loaded successfully");
                m_bFirst = false;
                return;
            }
            catch(Exception e)
            {
                System.out.println((new StringBuilder("Unable to load QMDP value function: ")).append(e).toString());
            }
            catch(Error e)
            {
                System.out.println((new StringBuilder("Unable to load QMDP value function: ")).append(e).toString());
            }
        if(m_bFirst)
        {
            System.out.println("Starting MDP value iteration");
            try
            {
                dMaxDelta = computeValueFunction(cMaxIterations, dEpsilon, false);
            }
            catch(Error e)
            {
                System.out.println((new StringBuilder("Error in computeVN: ")).append(e).toString());
                throw e;
            }
            makeVectors();
            Logger.getInstance().logFull("MDPVF", 0, "VI", (new StringBuilder("MDP value iteration done - iterations ")).append(cMDPBackups).append(" delta ").append(dMaxDelta).toString());
        }
        if(m_bFirst && !sFileName.equals(""))
            try
            {
                m_bFirst = false;
                save(sFileName);
            }
            catch(Exception e)
            {
              e.printStackTrace();
                System.out.println((new StringBuilder("Unable to save QMDP value function: ")).append(e).toString());
            }
            catch(Error e)
            {
              e.printStackTrace();
                System.out.println((new StringBuilder("Unable to save QMDP value function: ")).append(e).toString());
            }
        m_bFirst = false;
    }

    protected String getQTable()
    {
        String sRetVal = "";
        int iState = 0;
        int iAction = 0;
        for(iState = 0; iState < m_cStates; iState++)
            for(iAction = 0; iAction < m_cActions; iAction++)
                sRetVal = (new StringBuilder(String.valueOf(sRetVal))).append("Q( ").append(iState).append(", ").append(iAction).append(" ) = ").append(getQValue(iState, iAction)).append("\n").toString();


        return sRetVal;
    }

    public int getBestAction(BeliefState bs)
    {
        AlphaVector avMaxAlpha = getMaxAlpha(bs);
        return avMaxAlpha.getAction();
    }

    public AlphaVector getMaxAlpha(BeliefState bs)
    {
        return m_vValueFunction.getMaxAlpha(bs);
    }

    /**
     * Computes the absolute difference of two values
     * @param d1 the first value
     * @param d2 the second value
     * @return abs(d1-d2)
     */
    protected double diff(double d1, double d2)
    {
        if(d1 > d2)
            return d1 - d2;
        else
            return d2 - d1;
    }

    @Override
    public int getAction(BeliefState bsCurrent)
    {
        double dRand = m_rndGenerator.nextDouble();
        if(dRand > m_dExplorationRate)
            return getBestAction(bsCurrent);
        else
            return m_rndGenerator.nextInt(m_cActions);
    }

    @Override
    public double getValue(BeliefState bsCurrent)
    {
        AlphaVector avMaxAlpha = getMaxAlpha(bsCurrent);
        return avMaxAlpha.dotProduct(bsCurrent);
    }

    @Override
    public boolean hasConverged()
    {
        return m_bConverged;
    }

    @Override
    public String getStatus()
    {
        return "N/A";
    }

    public void load(String sFileName)
        throws Exception
    {
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document docValueFunction = builder.parse(new FileInputStream(sFileName));
//        docValueFunction.getDomConfig().s
        docValueFunction.normalize();
        Element eMDPFunction = null;
        Element eState = null;
        Element eADD = null;
        int iState = 0;
        int iAction = 0;
        double dVValue = 0.0D;
        NodeList nlStates = null;
        int cStates = 0;
        int cActions = 0;
        int iStateItem = 0;
        String sType = "";
        eMDPFunction = (Element)docValueFunction.getChildNodes().item(0);
        cStates = Integer.parseInt(eMDPFunction.getAttribute("StateCount"));
        cActions = Integer.parseInt(eMDPFunction.getAttribute("ActionCount"));
        if(cStates != m_cStates || cActions != m_cActions)
            throw new Exception((new StringBuilder("Unmatching state or action count. Expected <")).append(m_cStates).append(",").append(m_cActions).append("> found <").append(cStates).append(",").append(cActions).append(">").toString());
        sType = eMDPFunction.getAttribute("type");
        nlStates = eMDPFunction.getChildNodes();
        if(sType.equals("ValueFunction"))
        {
            for(iStateItem = 0; iStateItem < nlStates.getLength(); iStateItem++)
            {
                final Node node = nlStates.item(iStateItem);
                if (node instanceof Element)
                {
                  eState = (Element)node;
                  dVValue = Double.parseDouble(eState.getAttribute("Value"));
                  iState = Integer.parseInt(eState.getAttribute("Id"));
                  setValue(iState, dVValue);
                } // else text (\n) --> skip
            }

            makeVectors();
        } else
        if(sType.equals("Policy"))
        {
            m_avBestActions = newAlphaVector();
            eADD = (Element)eMDPFunction.getFirstChild();
            if(eADD.getNodeName().equals("ADD"))
            {
                m_avBestActions.readValues(eADD);
            } else
            {
                for(iStateItem = 0; iStateItem < nlStates.getLength(); iStateItem++)
                {
                  final Node node = nlStates.item(iStateItem);
                  if (node instanceof Element)
                  {
                    eState = (Element)node;
                    //if (!eState.getAttribute("Action").equals(""))
                    	iAction = Integer.parseInt(eState.getAttribute("Action"));
                    iState = Integer.parseInt(eState.getAttribute("Id"));
                    m_avBestActions.setValue(iState, iAction);
                  }
                }

                m_avBestActions.finalizeValues();
            }
            if(m_bFullQFunction)
            {
                computeValueFunction(1000, 0.0001D, true);
                makeVectors();
            }
            Logger.getInstance().logFull("MDPVF", 0, "load", (new StringBuilder("Done loading best actions, |S| = ")).append(m_cStates).append(", vertex count = ").append(m_avBestActions.countEntries()).toString());
        } else
        {
            throw new Exception("Wrong file format");
        }
    }

    protected void save(String sFileName)
        throws Exception
    {
        Document docValueFunction = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        Element eMDPFunction = null;
        Element eState = null;
        double dVValue = 0.0D;
        eMDPFunction = docValueFunction.createElement("MDPFunction");
        if(m_bFullQFunction)
        {
            eMDPFunction.setAttribute("type", "ValueFunction");
            eMDPFunction.setAttribute("StateCount", (new StringBuilder(String.valueOf(m_cStates))).toString());
            eMDPFunction.setAttribute("ActionCount", (new StringBuilder(String.valueOf(m_cActions))).toString());
            docValueFunction.appendChild(eMDPFunction);
//            for(Iterator iterator = getValidStates().iterator(); iterator.hasNext(); eMDPFunction.appendChild(eState))
//            {
//                int iState = ((Integer)iterator.next()).intValue();
            for (int iState=0; iState<m_cStates; iState++)
            {
                eState = docValueFunction.createElement("State");
                dVValue = getValue(iState);
                eState.setAttribute("Id", (new StringBuilder(String.valueOf(iState))).toString());
                eState.setAttribute("Value", (new StringBuilder(String.valueOf(dVValue))).toString());
                eMDPFunction.appendChild(eState);//XXX extracted from if
            }

        } else
        {
            eMDPFunction.setAttribute("type", "Policy");
            eMDPFunction.setAttribute("StateCount", (new StringBuilder(String.valueOf(m_cStates))).toString());
            eMDPFunction.setAttribute("ActionCount", (new StringBuilder(String.valueOf(m_cActions))).toString());
            docValueFunction.appendChild(eMDPFunction);
            m_avBestActions.writeValues(eMDPFunction, docValueFunction);
        }
        TransformerFactory tFactory = TransformerFactory.newInstance();
        Transformer transformer = tFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        transformer.setOutputProperty(OutputKeys.STANDALONE, "yes");
        DOMSource source = new DOMSource(docValueFunction);
        FileOutputStream fos = new FileOutputStream(sFileName);
        StreamResult result = new StreamResult(fos);
        transformer.transform(source, result);
    }

    public int getAction(int iState)
    {
        int iAction = 0;
        int iMaxAction = 0;
        double dMaxQValue = -1.7976931348623157E+308D;
        double dQValue = 0.0D;
        if(m_bExploring && m_dExplorationRate > 0.0D && m_rndGenerator.nextDouble() < m_dExplorationRate)
            return m_rndGenerator.nextInt(m_cActions);
        if(m_bFullQFunction)
            for(iAction = 0; iAction < m_cActions; iAction++)
            {
                dQValue = getQValue(iState, iAction);
                if(dQValue > dMaxQValue)
                {
                    dMaxQValue = dQValue;
                    iMaxAction = iAction;
                }
            }

        else
            iMaxAction = (int)m_avBestActions.valueAt(iState);
        return iMaxAction;
    }

    public double getValue(int iState)
    {
        return m_adValues.elementAt(iState);
    }

    public void setValue(int iState, double dValue)
    {
        m_adValues.set(iState, dValue);
    }

    public int countEntries()
    {
        return m_vValueFunction.countEntries();
    }

    public static void persistQValues(boolean bPersist)
    {
        m_bFullQFunction = bPersist;
    }

    protected double tr(int iS1, int iAction, int iS2)
    {
        return m_pPOMDP.tr(iS1, iAction, iS2);
    }

    protected double O(int iAction, int iState, int iObservation)
    {
        return m_pPOMDP.O(iAction, iState, iObservation);
    }

    protected double R(int iState, int iAction)
    {
        return m_pPOMDP.R(iState, iAction);
    }

    protected TIntDoubleIterator getNonZeroTransitions(int iState, int iAction)
    {
        return m_pPOMDP.getNonZeroTransitions(iState, iAction);
    }

//    protected Collection<Integer> getValidStates()
//    {
//        return m_pPOMDP.getValidStates();
//    }

    protected AlphaVector newAlphaVector()
    {
        return m_pPOMDP.newAlphaVector();
    }

    protected LinearValueFunctionApproximation m_vValueFunction;
    protected POMDP m_pPOMDP;
    protected int m_cObservations;
    protected int m_cStates;
    protected int m_cActions;
    protected double m_dGamma;
    public DoubleVector m_adValues;
    protected IntVector m_ivBestActions;
    protected AlphaVector m_avBestActions;
    protected double m_dExplorationRate;
    protected boolean m_bConverged;
    protected boolean m_bFirst;
    protected RandomGenerator m_rndGenerator;
    private static MDPValueFunction g_vMDP = null;
    private static boolean m_bFullQFunction = false;

    /**
     * Clears all static values
     */
    public static void clear()
    {
      g_vMDP = null;
      m_bFullQFunction = false;
    }
}
