// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   JProf.java

package solution.topological.utilities;

public class JProf
{

    public JProf()
    { //
    }

    private static native long getCurrentThreadCpuTime();

    public static long getCurrentThreadCpuTimeSafe()
    {
        if(m_bEnabled)
        {
            long iTime = getCurrentThreadCpuTime();
            return iTime;
        } else
        {
            return System.nanoTime();
        }
    }

    protected static boolean m_bEnabled = false;

    static 
    {
        try
        {
            System.loadLibrary("capjprof");
            System.out.println("capjprof loaded");
            m_bEnabled = true;
        }
        catch(UnsatisfiedLinkError err)
        {
            m_bEnabled = false;
            System.out.println((new StringBuilder("unable to load capjprof ")).append(err).toString());
        }
    }
}
