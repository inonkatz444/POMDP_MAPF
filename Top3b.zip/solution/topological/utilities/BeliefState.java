// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BeliefState.java

package solution.topological.utilities;

import gnu.trove.*;

import java.util.*;

import org.w3c.dom.*;

import solution.topological.utilities.datastructures.PriorityQueueElement;

// Referenced classes of package pomdp.utilities:
//            BeliefStateFactory, BeliefStateComparator, Pair, AlphaVector

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 8 juil. 2009
 */
public class BeliefState extends PriorityQueueElement implements Comparable<BeliefState>
{
    private class ReversePairComparator
        implements Comparator<Pair<?,Double>>
    {

        public int compare(Pair<?,Double> p1, Pair<?,Double> p2)
        {
          return p1.second().compareTo(p2.second());
        }

        private ReversePairComparator()
        { //
        }

        ReversePairComparator(ReversePairComparator reversepaircomparator)
        {
            this();
        }
    }


    public BeliefState(int cStates, int cActions, int cObservations, int id, boolean bSparse, boolean bCacheBelifStates)
    {
        m_bSparse = bSparse;
        m_bCacheBelifStates = bCacheBelifStates;
        m_cStates = cStates;
        m_cActions = cActions;
        m_cObservations = cObservations;
        m_cBackups = 0;
        if(!m_bSparse)
            m_aStateProbabilities = new double[m_cStates];
        else
            m_aStateProbabilities = null;
        if(m_bCacheBelifStates)
        {
            m_amSuccessors = new TIntObjectHashMap[m_cActions];
            m_sSortedSuccessors = new TreeSet[m_cActions];
            for(int iAction = 0; iAction < m_cActions; iAction++)
            {
                m_amSuccessors[iAction] = new TIntObjectHashMap<Pair<BeliefState,Double>>();
                m_sSortedSuccessors[iAction] = new TreeSet<Pair<BeliefState,Double>>(new ReversePairComparator(null));
            }
        } else
        {
            m_amSuccessors = null;
        }
        m_mCachedObservationProbabilitis = new TObjectDoubleHashMap<String>();
        m_vPredecessors = new Vector<BeliefState>();
        m_vNeighbors = new Vector<BeliefState>();
        m_cVisits = 0;
        m_bsDiscretized = null;
        m_iID = id;
        m_bDeterministic = false;
        m_mNonZeroEntries = new TIntDoubleHashMap();
        m_mDominatingNonZeroEntries = new TIntDoubleHashMap();
        m_iDeterministicIndex = -1;
        m_dComputedValue = 0.0D;
        m_mProbCurrentGivenPred = new TreeMap<BeliefState, Pair<Double,Integer>>(getComparator());
        m_mProbCurrentGivenPred = Collections.synchronizedMap(m_mProbCurrentGivenPred);
        m_dLastMaxValue = 0.0D;
        m_iLastMaxValueTime = -1;
        m_iLastMaxAlphaTime = -1;
        m_avLastMaxAlpha = null;
        m_dLastApproximateValue = 0.0D;
        m_iLastApproximateValueTime = -1;
        m_iLastApproximateAlphaTime = -1;
        m_avLastApproximateAlpha = null;
        m_bPersistedBeliefState = false;
        m_adActionImmediateReward = new double[m_cActions];
        m_adPotentialActionValue = new double[m_cActions];
        for(int iAction = 0; iAction < m_cActions; iAction++)
        {
            m_adActionImmediateReward[iAction] = -1.7976931348623157E+308D;
            m_adPotentialActionValue[iAction] = -1.7976931348623157E+308D;
        }

        m_dImmediateReward = -1.7976931348623157E+308D;
        m_iGridResolution = 0;
        m_vAllSuccessors = null;
        m_bAllSuccessorsInGrid = false;
        m_cGridInterpolations = 0;
        m_iMaxErrorAction = -1;
        m_adActionError = new double[m_cActions];
        m_bPersistedInFactory = false;
        g_cBS++;
        g_cLiveBS++;
    }

    protected Comparator<BeliefState> getComparator()
    {
        return BeliefStateComparator.getInstance();
    }

    public double valueAt(int iState)
    {
        if(!m_bSparse)
            return m_aStateProbabilities[iState];
        return m_mNonZeroEntries.get(iState);
    }

    public void setValueAt(int iState, double dValue)
    {
        if(!m_bSparse)
            m_aStateProbabilities[iState] = dValue;
        if(dValue != 0.0D)
        {
            m_mNonZeroEntries.put(iState, dValue);
            if(dValue == 1.0D)
            {
                m_bDeterministic = true;
                m_iDeterministicIndex = iState;
            }
        } else
        {
            m_mNonZeroEntries.remove(iState);
        }
    }

    public TIntDoubleIterator getNonZeroEntries()
    {
        return m_mNonZeroEntries.iterator();
    }

    public TIntDoubleIterator getDominatingNonZeroEntries()
    {
        if(m_mDominatingNonZeroEntries == null)
        {
            TIntDoubleIterator itNonZero = getNonZeroEntries();
            double dMaxProb = 0.0D;
            int iState = 0;
            double dProb = 0.0D;
            m_mDominatingNonZeroEntries = new TIntDoubleHashMap();
            while(itNonZero.hasNext()) 
            {
              itNonZero.advance();
                iState = itNonZero.key();
                dProb = itNonZero.value();
                if(dProb > 0.01D)
                    m_mDominatingNonZeroEntries.put(iState, dProb);
                if(dProb > dMaxProb)
                    dMaxProb = dProb;
            }
            if(m_mDominatingNonZeroEntries.size() == 0)
                for(itNonZero = getNonZeroEntries(); itNonZero.hasNext();)
                {
                  itNonZero.advance();
                    iState = itNonZero.key();
                    dProb = itNonZero.value();
                    if(dProb > dMaxProb / 2D)
                        m_mDominatingNonZeroEntries.put(iState, dProb);
                }

        }
        return m_mDominatingNonZeroEntries.iterator();
    }

    public int getNonZeroEntriesCount()
    {
        return m_mNonZeroEntries.size();
    }

    public void addSuccessor(int iAction, int iObservation, BeliefState bsSuccessor)
    {
        double dProb = probabilityOGivenA(iAction, iObservation);
        Pair<BeliefState,Double> pEntry = new Pair<BeliefState,Double>(bsSuccessor, new Double(dProb));
        m_amSuccessors[iAction].put(iObservation, pEntry);
    }

    public BeliefState nextBeliefState(int iAction, int iObservation)
    {
        BeliefState bsNext = null;
        m_cVisits++;
        if(m_bCountBeliefUpdates)
            g_cBeliefStateUpdates++;
        if(m_bCacheBelifStates && BeliefStateFactory.getInstance().isCachingBeliefStates())
        {
            Pair<BeliefState,Double> pEntry = m_amSuccessors[iAction].get(iObservation);
            if(pEntry == null)
            {
                bsNext = BeliefStateFactory.getInstance().nextBeliefState(this, iAction, iObservation);
                //System.out.println("************************ belief state = " + bsNext);
                if(bsNext != null && BeliefStateFactory.getInstance().isCachingBeliefStates())
                    addSuccessor(iAction, iObservation, bsNext);
            } else
            {
                bsNext = pEntry.m_first;
            }
            return bsNext;
        } else
        {
            return BeliefStateFactory.getInstance().nextBeliefState(this, iAction, iObservation);
        }
    }

    public double probabilityOGivenA(int iAction, int iObservation)
    {
        if(!m_bCacheBelifStates)
            return BeliefStateFactory.getInstance().calcNormalizingFactor(this, iAction, iObservation);
        String sKey = (new StringBuilder(String.valueOf(iAction))).append(",").append(iObservation).toString();
        double dValue;
        if(m_mCachedObservationProbabilitis.containsKey(sKey))
          dValue = m_mCachedObservationProbabilitis.get(sKey);
        else
        {
            dValue = BeliefStateFactory.getInstance().calcNormalizingFactor(this, iAction, iObservation);
            m_mCachedObservationProbabilitis.put(sKey, dValue);
        }
        return dValue;
    }

    @Override
    public String toString()
    {
        return toString(0.01D);
    }

    @Override
    public int hashCode()
    {
        int iState = 0;
        int iShortValue = 0;
        int iFullValue = 0;
        double dValue = 0.0D;
        TIntDoubleIterator it = getNonZeroEntries();
        while(it.hasNext()) 
        {
          it.advance();
            iState = it.key();
            dValue = it.value();
            iShortValue = (int)(dValue * 10000D);
            iFullValue += iShortValue * iState;
        }
        return iFullValue;
    }

    private double diff(double d1, double d2)
    {
        double d = d1 - d2;
        if(d < 0.0D)
            d *= -1D;
        return d;
    }

    private boolean equals(BeliefState bsOther)
    {
        return BeliefStateComparator.getInstance().compare(this, bsOther) == 0;
    }

    @Override
    public boolean equals(Object oOther)
    {
        if(oOther == this)
            return true;
        if(oOther instanceof BeliefState)
        {
            BeliefState bs = (BeliefState)oOther;
            return equals(bs);
        } else
        {
            return false;
        }
    }

    public double distance(BeliefState bsOther)
    {
        int iState = 0;
        double dSum = 0.0D;
        for(iState = 0; iState < m_cStates; iState++)
            dSum += diff(valueAt(iState), bsOther.valueAt(iState));

        return dSum;
    }

    public TIntObjectIterator<Pair<BeliefState,Double>> getSuccessors(int iAction)
    {
        return m_amSuccessors[iAction].iterator();
    }

    public Iterator<Pair<BeliefState, Double>> getSortedSuccessors(int iAction)
    {
        if(m_sSortedSuccessors[iAction].size() == 0)
            computeAllSuccessors(iAction);
        return m_sSortedSuccessors[iAction].iterator();
    }

    public void addPredecessor(BeliefState bs, double dProb, int iAction)
    {
        if(m_bCacheBelifStates && !m_vPredecessors.contains(bs))
        {
            m_vPredecessors.add(bs);
            m_mProbCurrentGivenPred.put(bs, new Pair<Double,Integer>(new Double(dProb), new Integer(iAction)));
        }
    }

    public Iterator<BeliefState> getPredecessors()
    {
        return m_vPredecessors.iterator();
    }

    public int countPredecessors()
    {
        return m_vPredecessors.size();
    }

    public double[] toArray()
    {
        return m_aStateProbabilities.clone();
    }

    public BeliefState discretize()
    {
        if(m_bsDiscretized == null)
            m_bsDiscretized = BeliefStateFactory.getInstance().discretize(this);
        return m_bsDiscretized;
    }

    public boolean validate()
    {
        double dSum = 0.0D;
        double dValue = 0.0D;
        int iState = 0;
        boolean bValid = true;
        for(iState = 0; iState < m_cStates; iState++)
        {
            dValue = valueAt(iState);
            if(dValue < 0.0D || dValue > 1.0D)
                bValid = false;
            dSum += dValue;
        }

        return bValid || dSum != 1.0D;
    }

    public void normalize()
    {
        double dSum = 0.0D;
        double dValue = 0.0D;
        double dNormalizedSum = 0.0D;
        int iState = 0;
        for(iState = 0; iState < m_cStates; iState++)
            dSum += valueAt(iState);

        for(iState = 0; iState < m_cStates; iState++)
        {
            dValue = valueAt(iState) / dSum;
            setValueAt(iState, dValue);
            dNormalizedSum += dValue;
        }

    }

    public boolean isDeterministic()
    {
        return m_bDeterministic;
    }

    public int getDeterministicIndex()
    {
        return m_iDeterministicIndex;
    }

    public String toString(double dMin)
    {
        String sVector = (new StringBuilder("bs")).append(m_iID).append("[").toString();
        String sValue = "";
        int iState = 0;
        int iEndState = 0;
      
        double dValue = -1D;
        double dNextValue = -1D;
        double dSum = 0.0D;
    
        int cEntries = 0;
        for(iState = 0; iState < m_cStates; iState++)
        {
            dValue = valueAt(iState);
            dSum += dValue;
            if(dValue >= dMin)
            {
                cEntries++;
                sValue = (new StringBuilder(String.valueOf(dValue))).toString();
                if(sValue.length() > 8)
                    sValue = sValue.substring(0, 8);
                if(iState < m_cStates - 1)
                {
                    iEndState = iState;
                    do
                    {
                        iEndState++;
                        dNextValue = valueAt(iEndState);
                    } while(iEndState < m_cStates && dValue == dNextValue);
                    if(dValue != dNextValue)
                        iEndState--;
                    if(iEndState == iState)
                    {
                        sVector = (new StringBuilder(String.valueOf(sVector))).append(iState).append("=").append(sValue).append(",").toString();
                    } else
                    {
                        sVector = (new StringBuilder(String.valueOf(sVector))).append("(").append(iState).append("-").append(iEndState).append(")=").append(sValue).append(",").toString();
                        dSum += dValue * (iEndState - iState);
                        iState = iEndState;
                    }
                } else
                {
                    sVector = (new StringBuilder(String.valueOf(sVector))).append(iState).append("=").append(sValue).append(",").toString();
                }
            }
        }

        if(cEntries > 0)
            sVector = (new StringBuilder(String.valueOf(sVector.substring(0, sVector.length() - 1)))).append("]").toString();
        else
            sVector = (new StringBuilder(String.valueOf(sVector))).append("]").toString();
        return sVector;
    }

    public int countStates()
    {
        return m_cStates;
    }

    public double getComputedValue()
    {
        return m_dComputedValue;
    }

    public void setComputedValue(double computedValue)
    {
        m_dComputedValue = computedValue;
    }

    public int countSuccessors()
    {
        int cSuccessors = 0;
        for(int iAction = 0; iAction < m_cActions; iAction++)
            cSuccessors += m_amSuccessors[iAction].size();

        return cSuccessors;
    }

    public int getId()
    {
        return m_iID;
    }

    protected Element getPreds(Document docBeliefSpace)
    {
        Element ePreds = null;
        Element ePred = null;
        Iterator<BeliefState> itPreds = m_vPredecessors.iterator();
        BeliefState bsPred = null;
        double dProb = 0.0D;
        ePreds = docBeliefSpace.createElement("Predecessors");
        ePreds.setAttribute("size", (new StringBuilder(String.valueOf(m_vPredecessors.size()))).toString());
        for(; itPreds.hasNext(); ePreds.appendChild(ePred))
        {
            bsPred = itPreds.next();
            ePred = docBeliefSpace.createElement("Predecessor");
            ePred.setAttribute("Id", (new StringBuilder(String.valueOf(bsPred.getId()))).toString());
            dProb = getProbCurrentGivenPredecessor(bsPred);
            ePred.setAttribute("Probability", (new StringBuilder(String.valueOf(dProb))).toString());
        }

        return ePreds;
    }

    public Pair<Double, Integer> getCurrentGivenPredecessorDetails(BeliefState bsPredecessor)
    {
        return m_mProbCurrentGivenPred.get(bsPredecessor);
    }

    public double getProbCurrentGivenPredecessor(BeliefState bsPredecessor)
    {
        Pair<Double,Integer> p = getCurrentGivenPredecessorDetails(bsPredecessor);
        if(p == null)
            return 0.0D;
        Double dProb = p.m_first;
        if(dProb == null)
            return 0.0D;
        else
            return dProb.doubleValue();
    }

    public int getActionCurrentGivenPredecessor(BeliefState bsPredecessor)
    {
        Pair<Double,Integer> p = getCurrentGivenPredecessorDetails(bsPredecessor);
        if(p == null)
            return -1;
        Integer iAction = p.m_second;
        if(iAction == null)
            return -1;
        else
            return iAction.intValue();
    }

    protected Element getSuccessors(Document docBeliefSpace)
    {
        Element eSuccessors = null;
        Element eSuccessor = null;
        TIntObjectIterator<Pair<BeliefState,Double>> itSuccessors = null;
        BeliefState bsSuccessor = null;
        int iAction = 0;
        int iObservation = -1;
        int cSuccessors = 0;
        Pair<BeliefState,Double> pEntry = null;
        eSuccessors = docBeliefSpace.createElement("Successors");
        for(iAction = 0; iAction < m_cActions; iAction++)
            if(m_amSuccessors[iAction] != null)
                for(itSuccessors = m_amSuccessors[iAction].iterator(); itSuccessors.hasNext();)
                {
                    pEntry = itSuccessors.value();
                    bsSuccessor = pEntry.first();
                    if(bsSuccessor == null)
                        System.out.println((new StringBuilder(String.valueOf(getId()))).append(",").append(iAction).append(",").append(pEntry).toString());
                    iObservation = itSuccessors.key();
                    itSuccessors.advance();
                    eSuccessor = docBeliefSpace.createElement("Successor");
                    eSuccessor.setAttribute("Action", (new StringBuilder(String.valueOf(iAction))).toString());
                    eSuccessor.setAttribute("Observation", (new StringBuilder()).append(iObservation).toString());
                    eSuccessor.setAttribute("Id", (new StringBuilder(String.valueOf(bsSuccessor.getId()))).toString());
                    eSuccessors.appendChild(eSuccessor);
                    cSuccessors++;
                }


        eSuccessors.setAttribute("size", (new StringBuilder(String.valueOf(cSuccessors))).toString());
        return eSuccessors;
    }

    protected Element getBeliefValues(Document docBeliefSpace)
    {
        Element eBeliefValues = null;
        Element eStateBelief = null;
        TIntDoubleIterator itBeliefStateEntries = getNonZeroEntries();
        double dValue = 0.0D;
        int iState = 0;
        eBeliefValues = docBeliefSpace.createElement("BeliefValues");
        eBeliefValues.setAttribute("size", (new StringBuilder(String.valueOf(m_mNonZeroEntries.size()))).toString());
        for(; itBeliefStateEntries.hasNext(); eBeliefValues.appendChild(eStateBelief))
        {
          itBeliefStateEntries.advance();
            iState = itBeliefStateEntries.key();
            dValue = itBeliefStateEntries.value();
            eStateBelief = docBeliefSpace.createElement("StateBelief");
            eStateBelief.setAttribute("Id", (new StringBuilder(String.valueOf(iState))).toString());
            eStateBelief.setAttribute("Belief", (new StringBuilder(String.valueOf(dValue))).toString());
        }

        return eBeliefValues;
    }

    public Element getDom(Document docBeliefSpace)
    {
        Element eBeliefState = null;
        Element eBeliefValues = null;
        Element eSuccessors = null;
        Element ePreds = null;
        eBeliefState = docBeliefSpace.createElement("BeliefState");
        eBeliefState.setAttribute("Id", (new StringBuilder(String.valueOf(getId()))).toString());
        eBeliefValues = getBeliefValues(docBeliefSpace);
        eBeliefState.appendChild(eBeliefValues);
        eSuccessors = getSuccessors(docBeliefSpace);
        eBeliefState.appendChild(eSuccessors);
        ePreds = getPreds(docBeliefSpace);
        eBeliefState.appendChild(ePreds);
        return eBeliefState;
    }

    public void loadBeliefValues(Element eBeliefValues)
    {
        Element eStateBelief = null;
        int iState = 0;
        int iStateItem = 0;
        double dValue = 0.0D;
        NodeList nlStates = null;
        nlStates = eBeliefValues.getChildNodes();
        for(iStateItem = 0; iStateItem < nlStates.getLength(); iStateItem++)
        {
            eStateBelief = (Element)nlStates.item(iStateItem);
            iState = Integer.parseInt(eStateBelief.getAttribute("Id"));
            dValue = Double.parseDouble(eStateBelief.getAttribute("Belief"));
            setValueAt(iState, dValue);
        }

        m_bPersistedBeliefState = true;
    }

    public void addBeliefValues(BeliefState belief)
    {
        int iState = 0;

        double dValue = 0.0D;
        TIntDoubleIterator nlStates = null;
        for(nlStates = belief.getNonZeroEntries(); nlStates.hasNext(); setValueAt(iState, dValue))
        {
          nlStates.advance();
            iState = nlStates.key();
            dValue = nlStates.value();
        }

    }

    public void loadPredecessors(Element ePredecessors, TIntObjectHashMap<BeliefState> mId2BeliefState)
    {
        NodeList nlPreds = ePredecessors.getChildNodes();
        Element ePred = null;
        String sId = "";
        String sProb = "";
        String sAction = "";
        int iPred = 0;
        int cPreds = nlPreds.getLength();
        int iId = -1;
        BeliefState bsPred = null;
        double dProb = 0.0D;
        int iAction = -1;
        for(iPred = 0; iPred < cPreds; iPred++)
        {
            ePred = (Element)nlPreds.item(iPred);
            sId = ePred.getAttribute("Id");
            iId = Integer.parseInt(sId);
            sProb = ePred.getAttribute("Probability");
            if(sProb.equals(""))
                dProb = 0.0D;
            else
                dProb = Double.parseDouble(sProb);
            sAction = ePred.getAttribute("Action");
            if(sAction.equals(""))
                iAction = -1;
            else
                iAction = Integer.parseInt(sAction);
            bsPred = mId2BeliefState.get(iId);
            if(bsPred != null)
                addPredecessor(bsPred, dProb, iAction);
        }

    }

    public void loadSuccessors(Element eSuccessors, TIntObjectHashMap<BeliefState> mId2BeliefState)
    {
        NodeList nlSuccessors = eSuccessors.getChildNodes();
        Element eSuccessor = null;
        String sId = "";
        String sAction = "";
        String sObservation = "";
        int iSuccessor = 0;
        int cSuccessors = nlSuccessors.getLength();
        int iId = -1;
        int iAction = 0;
        int iObservation = 0;
        BeliefState bsSuccessor = null;
        for(iSuccessor = 0; iSuccessor < cSuccessors; iSuccessor++)
        {
            eSuccessor = (Element)nlSuccessors.item(iSuccessor);
            sId = eSuccessor.getAttribute("Id");
            sAction = eSuccessor.getAttribute("Action");
            sObservation = eSuccessor.getAttribute("Observation");
            iId = Integer.parseInt(sId);
            iAction = Integer.parseInt(sAction);
            iObservation = Integer.parseInt(sObservation);
            bsSuccessor = mId2BeliefState.get(iId);
            if(bsSuccessor != null)
                addSuccessor(iAction, iObservation, bsSuccessor);
        }

    }

    public static void countBeliefUpdates(boolean bCount)
    {
        m_bCountBeliefUpdates = bCount;
    }

    public static void clearBeliefStatsUpdate()
    {
        g_cBeliefStateUpdates = 0;
    }

    public void addNeighbor(BeliefState bsNeighbor)
    {
        m_vNeighbors.add(bsNeighbor);
    }

    public Iterator<BeliefState> getNeighbors()
    {
        return m_vNeighbors.iterator();
    }

    public int getNeighborsCount()
    {
        return m_vNeighbors.size();
    }

    public void setMaxValue(double dMaxValue, int iTime)
    {
        m_dLastMaxValue = dMaxValue;
        m_iLastMaxValueTime = iTime;
        if(m_iLastMaxValueTime >= m_iLastApproximateValueTime)
        {
            m_dLastApproximateValue = m_dLastMaxValue;
            m_iLastApproximateValueTime = m_iLastMaxValueTime;
        }
    }

    public void setApproximateValue(double dApproximateValue, int iTime)
    {
        m_dLastApproximateValue = dApproximateValue;
        m_iLastApproximateValueTime = iTime;
    }

    public double getMaxValue()
    {
        return m_dLastMaxValue;
    }

    public int getMaxValueTime()
    {
        return m_iLastMaxValueTime;
    }

    public double getApproximateValue()
    {
        return m_dLastApproximateValue;
    }

    public int getApproximateValueTime()
    {
        return m_iLastApproximateValueTime;
    }

    public void setMaxAlpha(AlphaVector avMax, int iTime)
    {
        m_avLastMaxAlpha = avMax;
        m_iLastMaxAlphaTime = iTime;
        BeliefState bsWitness = avMax.getWitness();
        if(bsWitness != null && bsWitness != this && persistedInFactory())
        {
            double dWitnessValue = avMax.dotProduct(bsWitness);
            double dValue = avMax.dotProduct(this);
            if(dValue > dWitnessValue + 0.0001D)
                avMax.setWitness(this);
        }
    }

    public AlphaVector getMaxAlpha()
    {
        return m_avLastMaxAlpha;
    }

    public int getMaxAlphaTime()
    {
        return m_iLastMaxAlphaTime;
    }

    public void clearInternalCache()
    {
        m_dComputedValue = 0.0D;
        m_dLastMaxValue = 0.0D;
        m_iLastMaxValueTime = -1;
        m_avLastMaxAlpha = null;
        m_iLastMaxAlphaTime = -1;
    }

    public double getImmediateReward()
    {
        return m_dImmediateReward;
    }

    public double getActionImmediateReward(int iAction)
    {
        return m_adActionImmediateReward[iAction];
    }

    public void setImmediateReward(double dReward)
    {
        m_dImmediateReward = dReward;
    }

    public void setActionImmediateReward(int iAction, double dReward)
    {
        m_adActionImmediateReward[iAction] = dReward;
    }

    public void computeAllSuccessors(int iAction)
    {
        int iObservation = 0;
        BeliefState bsNext = null;
        double dProb = 0.0D;
        double dSumProbs = 0.0D;
        Pair<BeliefState,Double> pEntry = null;
        int cEntries = 0;
        for(iObservation = 0; iObservation < m_cObservations; iObservation++)
        {
            dProb = probabilityOGivenA(iAction, iObservation);
            if(dProb > 0.0D)
            {
                bsNext = nextBeliefState(iAction, iObservation);
                pEntry = new Pair<BeliefState,Double>(bsNext, new Double(dProb));
                cEntries++;
                m_sSortedSuccessors[iAction].add(pEntry);
                if(m_sSortedSuccessors[iAction].size() != cEntries)
                    System.out.println((new StringBuilder("Real entries ")).append(m_sSortedSuccessors[iAction].size()).append(", intended ").append(cEntries).toString());
                dSumProbs += dProb;
            }
        }

    }

    public TIntDoubleHashMap getNonZeroEntriesMap()
    {
        return m_mNonZeroEntries;
    }

    public TIntDoubleHashMap getNonZeroStates()
    {
        return m_mNonZeroEntries;
    }

    public int getGridResolution()
    {
        return m_iGridResolution;
    }

    public void setGridResolution(int iGridResolution)
    {
        m_iGridResolution = iGridResolution;
    }

    public Iterator<BeliefState> getSuccessors()
    {
        int iAction = 0;
        int iObservation = 0;
        BeliefState bsSuccessor = null;
        double dProb = 0.0D;
        if(m_vAllSuccessors == null)
        {
            m_vAllSuccessors = new Vector<BeliefState>();
            for(iAction = 0; iAction < m_cActions; iAction++)
                for(iObservation = 0; iObservation < m_cObservations; iObservation++)
                {
                    dProb = probabilityOGivenA(iAction, iObservation);
                    if(dProb > 0.0D)
                    {
                        bsSuccessor = nextBeliefState(iAction, iObservation);
                        if(!m_vAllSuccessors.contains(bsSuccessor))
                            m_vAllSuccessors.add(bsSuccessor);
                    }
                }


        }
        return m_vAllSuccessors.iterator();
    }

    public void setSuccessorsInGrid()
    {
        m_bAllSuccessorsInGrid = true;
    }

    public boolean allSuccessorsInGrid()
    {
        return m_bAllSuccessorsInGrid;
    }

    public int getGridInterpolations()
    {
        return m_cGridInterpolations;
    }

    public void clearGridInterpolations()
    {
        m_cGridInterpolations = 0;
    }

    public void incrementGridInterploations()
    {
        m_cGridInterpolations++;
    }

    public void setMaxErrorAction(int iAction)
    {
        m_iMaxErrorAction = iAction;
    }

    public int getMaxErrorAction()
    {
        return m_iMaxErrorAction;
    }

    public void setActionError(int iAction, double dError)
    {
        if(m_adActionError[iAction] > dError && iAction == m_iMaxErrorAction)
        {
            int i = 0;
            m_adActionError[iAction] = dError;
            for(i = 0; i < m_cActions; i++)
                if(m_adActionError[i] > m_adActionError[m_iMaxErrorAction])
                    m_iMaxErrorAction = i;

        } else
        {
            m_adActionError[iAction] = dError;
            if(m_iMaxErrorAction == -1 || dError > m_adActionError[m_iMaxErrorAction])
                m_iMaxErrorAction = iAction;
        }
    }

    public double getActionError(int iAction)
    {
        return m_adActionError[iAction];
    }

    public void setPotentialActionValue(int iAction, double dNewValue)
    {
        m_adPotentialActionValue[iAction] = dNewValue;
    }

    public void incrementPotentialActionValue(int iAction, double dDeltaValue)
    {
        m_adPotentialActionValue[iAction] += dDeltaValue;
    }

    public double getPotentialActionValue(int iAction)
    {
        return m_adPotentialActionValue[iAction];
    }

    public int countBackups()
    {
        return m_cBackups;
    }

    public void addBackup()
    {
        m_cBackups++;
    }

    public void clearBackups()
    {
        m_cBackups = 0;
    }

    public int countEntries()
    {
        return m_mNonZeroEntries.size();
    }

    private boolean releasing = false;
    public void release()
    { //
    }
    public void releaseMemory()
    { //
      if (releasing)
        return;
      try
      {
      releasing = true;
      m_bsDiscretized = null;
      for (BeliefState b:m_vPredecessors)
        b.releaseMemory();
      m_vPredecessors.clear();
      
      for (BeliefState b:m_mProbCurrentGivenPred.keySet())
        b.releaseMemory();
      m_mProbCurrentGivenPred.clear();

      for (BeliefState b:m_vNeighbors)
        b.releaseMemory();
      m_vNeighbors.clear();

      for (TIntObjectHashMap<Pair<BeliefState, Double>> m_amSuccessor : m_amSuccessors)
      {
        for (Object b:m_amSuccessor.getValues())
          ((Pair<BeliefState,Double>)b).first().release();
        m_amSuccessor.clear();
      }
      
      if (m_vAllSuccessors != null)
      {
        for (BeliefState b:m_vAllSuccessors)
          b.releaseMemory();
        m_vAllSuccessors.clear();
      }
      
      for (SortedSet<Pair<BeliefState, Double>> m_amSuccessor : m_sSortedSuccessors)
      {
        for (Pair<BeliefState,Double> b:m_amSuccessor)
          b.first().releaseMemory();
        m_amSuccessor.clear();
      }
      } catch (Throwable t)
      {
        t.printStackTrace();
      }
      releasing = false;
    }

    public void setFactoryPersistence(boolean bPersisted)
    {
        m_bPersistedInFactory = bPersisted;
    }

    public boolean persistedInFactory()
    {
        return m_bPersistedInFactory;
    }

    public long size()
    {
        if(m_bSparse)
            return m_mNonZeroEntries.size();
        else
            return m_cStates;
    }

    public int compareTo(BeliefState o)
    {
        if(getNonZeroStates().size() == o.getNonZeroStates().size())
        {
            for(TIntDoubleIterator iter = getNonZeroEntries(); iter.hasNext();)
            {
              iter.advance(); 
                if(iter.value() == o.valueAt(iter.key()))
                    return 0;
            }

        }
        return 1;
    }

    protected double m_aStateProbabilities[];
    protected TIntDoubleHashMap m_mNonZeroEntries;
    private TIntDoubleHashMap m_mDominatingNonZeroEntries;
    protected TObjectDoubleHashMap<String> m_mCachedObservationProbabilitis;
    protected int m_cStates;
    private BeliefState m_bsDiscretized;
    private Vector<BeliefState> m_vPredecessors;
    protected Map<BeliefState, Pair<Double,Integer>> m_mProbCurrentGivenPred;
    private Vector<BeliefState> m_vNeighbors;
    private TIntObjectHashMap<Pair<BeliefState,Double>> m_amSuccessors[];
    private Vector<BeliefState> m_vAllSuccessors;
    private SortedSet<Pair<BeliefState,Double>> m_sSortedSuccessors[];
    private int m_cVisits;
    protected int m_cActions;
    private int m_cObservations;
    protected int m_iID;
    protected boolean m_bDeterministic;
    protected int m_iDeterministicIndex;
    protected boolean m_bSparse;
    protected boolean m_bCacheBelifStates;
    public static int g_cBeliefStateUpdates = 0;
    protected double m_dComputedValue;
    protected double m_dLastMaxValue;
    protected int m_iLastMaxValueTime;
    protected AlphaVector m_avLastMaxAlpha;
    protected int m_iLastMaxAlphaTime;
    protected double m_dLastApproximateValue;
    protected int m_iLastApproximateValueTime;
    protected AlphaVector m_avLastApproximateAlpha;
    protected int m_iLastApproximateAlphaTime;
    protected boolean m_bPersistedBeliefState;
    private static boolean m_bCountBeliefUpdates = true;
    protected double m_dImmediateReward;
    protected double m_adActionImmediateReward[];
    protected int m_iGridResolution;
    protected boolean m_bAllSuccessorsInGrid;
    protected int m_cGridInterpolations;
    protected int m_iMaxErrorAction;
    protected double m_adActionError[];
    protected double m_adPotentialActionValue[];
    private int m_cBackups;
    private boolean m_bPersistedInFactory;
    public static int g_cBS = 0;
    public static int g_cLiveBS = 0;
    
    /**
     * Clears all static values 
     */
    public static void clearStatic()
    {
      g_cBeliefStateUpdates = 0;
      m_bCountBeliefUpdates = true;
      g_cBS = 0;
      g_cLiveBS = 0;
    }
}
