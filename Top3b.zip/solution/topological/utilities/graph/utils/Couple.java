// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Couple.java

package solution.topological.utilities.graph.utils;


public class Couple<K,V>
{

    public Couple()
    { //
    }

    public Couple(K _first, V _second)
    {
        first = _first;
        second = _second;
    }

    public K fst()
    {
        return first;
    }

    public void fst(K _first)
    {
        this.first = _first;
    }

    public V snd()
    {
        return second;
    }

    public void snd(V _second)
    {
        this.second = _second;
    }

    @Override
    public Couple<K, V> clone()
    {
        return new Couple<K, V>(first, second);
    }

    public boolean equals(Couple<K, V> o)
    {
        return o != null ? first.equals(o.first) && second.equals(o.second) : false;
    }

    public Couple<V,K> inverse()
    {
        return new Couple<V,K>(second, first);
    }

    @Override
    public String toString()
    {
        return (new StringBuilder("(")).append(first).append(", ").append(second).append(")").toString();
    }

    public K first;
    public V second;
}
