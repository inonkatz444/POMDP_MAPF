// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Pairs.java

package solution.topological.utilities.graph.utils;


// Referenced classes of package pomdp.utilities.graph.utils:
//            Couple

/**
 * Converted to generics
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 10 juil. 2009
 *
 */
public class Pairs extends Couple<Integer,Couple<Integer,Double>>
    implements Comparable<Pairs>
{

    public Pairs(Integer f, Couple<Integer,Double> s)
    {
        super(f, s);
    }

    public int compareTo(Pairs o)
    {
        if(second.first.compareTo(o.second.first) == 0)
            return second.second.compareTo(o.second.second);
        else
            return second.first.compareTo(o.second.first);
    }
}
