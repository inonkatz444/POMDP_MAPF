// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AcyclicShortestPath.java

package solution.topological.utilities.graph;

import gnu.trove.*;
import java.util.*;

import solution.topological.environments.POMDP;
import solution.topological.heuristic.TopSolver;

// Referenced classes of package pomdp.utilities.graph:
//            Graph, AcyclicGraph

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 9 juil. 2009
 *
 */
public class AcyclicShortestPath extends Graph{
	

    public AcyclicShortestPath(TIntArrayList states, Vector<TIntHashSet> succs)
    {
        super(states, succs);
    }

    public Vector<TIntHashSet> getSuccessors()
    {
        return successors;
    }

    @Override
    public AcyclicGraph getAcyclicGraph()
    {
        return aGraph;
    }

    public Graph getTransposeAcyclicGraph()
    {
        return aGraphT;
    }

    public Graph getTransposeGraph()
    {
        return mGraphT;
    }

    public int getSccID(int iState)
    {
        return iState >= 0 ? id[iState] : -1;
    }

    public boolean isEndState(int s){
    	return aGraph.getSuccessors(getSccID(s)).isEmpty();
    }
    
    /**
     * Gets the next state to go from first to second, or -1 if none
     * @param first the initial state
     * @param second the final state
     * @return the intermediate state
     */
    public int getNextState(int first, int second ){
        return iStateNext.get(first).containsKey(second) ? iStateNext.get(first).get(second) : -1;
    }
    
    public double getDistance(int first, int second){
        return dStateDist.get(first).containsKey(second) ? dStateDist.get(first).get(second) : 1.7976931348623157E+308D;
    }
    
    public boolean noObjects_exist(String state){
		for (int i = 0; i < state.length()-7; i++){
			if (state.charAt(4+i+1)=='1')//dont forget the s char
				return false;
		}
		return true;
	}
    
    //check all successors of first, check the ones who are not in the trajectory, check the one with minimum distance from second
        
    @Override
    public int next(int iState, int jState)
    {
        int bestNextState = -1;
        
        //get next layer for trajectory from isState to jState
        int nextLayer = aGraph.next(id[iState], id[jState]);
        
        //no next layer => no next state  return -1
        if(nextLayer < 0)  return bestNextState;
        
        
        if(nextLayer == id[iState] || getNextState(iState, jState) != -1){
            bestNextState = jState;
        } 
        else{
        	//not same later and no path between iState and jState
        
            double shortestDistance = 1.7976931348623157E+308D;
            if(borderStates.get(id[iState]).get(nextLayer).contains(iState))
            {
                for(TIntIterator nextStates = getSuccessorsNode(iState).iterator(); nextStates.hasNext();)
                {
                    int nextState = nextStates.next();
                    if(id[nextState] == nextLayer)
                    {
                        bestNextState = nextState;
                        break;
                    }
                }

            } else
            {
                for(TIntIterator nextStates = borderStates.get(id[iState]).get(nextLayer).iterator(); nextStates.hasNext();)
                {
                    int nextState = nextStates.next();
                    if(getDistance(iState, nextState) < shortestDistance)
                    {
                        shortestDistance = getDistance(iState, nextState);
                        bestNextState = nextState;
                    }
                }

                bestNextState = getNextState(iState, bestNextState);
            }
        }
        
        return getNextState(iState, bestNextState);
    }

    //TODO added with POMDP
    /** Looks for the state (in iStates) closest from iState 
     * @param m_pPOMDP the model
     * @param iState the initial state
     * @param iStates the set of goal states
     * @return the goal state closest from iState
     */
    public int closest(POMDP m_pPOMDP, int iState, TIntHashSet iStates)
    {
        int iClosest = -1;
        double M = 1.7976931348623157E+308D;
        for(TIntIterator inodes = iStates.iterator(); inodes.hasNext();)
        {
            int yState = inodes.next();
            if(getDistance(iState, yState) < M || iClosest < 0)
            {
                iClosest = yState;
                M = getDistance(iState, yState);
            }
        }

        return iClosest >= 0 ? iClosest : null;
    }
    
    public Integer closest(Integer iState, TIntHashSet iStates)
    {
        int iClosest = -1;
        double M = 1.7976931348623157E+308D;
        for(TIntIterator inodes = iStates.iterator(); inodes.hasNext();)
        {
            int yState = inodes.next();
            if(getDistance(iState, yState) < M || iClosest < 0)
            {
                iClosest = yState;
                M = getDistance(iState, yState);
            }
        }

        return iClosest >= 0 ? Integer.valueOf(iClosest) : null;
    }
    
    //TODO added with pomdp
    public TIntArrayList closestSet(POMDP m_pPOMDP, int iState, TIntHashSet iStates)
    {
        double M = 1.7976931348623157E+308D;
        double N;
        int yState;
        TIntArrayList iClosest = new TIntArrayList();
        for(TIntIterator inodes = iStates.iterator(); inodes.hasNext();)
        {
            yState = inodes.next();
            N = getDistance(iState, yState);
            if(N < M || iClosest.isEmpty())
            {
                iClosest.clear();
                iClosest.add(yState);
                M = N;
            } else if(N == M)
                iClosest.add(yState);
        }

        return iClosest;
    }
    
    public TIntArrayList closestSet(int iState, TIntHashSet iStates)
    {
        double M = 1.7976931348623157E+308D;
        double N;
        int yState;
        TIntArrayList iClosest = new TIntArrayList();
        for(TIntIterator inodes = iStates.iterator(); inodes.hasNext();)
        {
            yState = inodes.next();
            N = getDistance(iState, yState);
            if(N < M || iClosest.isEmpty())
            {
                iClosest.clear();
                iClosest.add(yState);
                M = N;
            } else
            if(N == M)
                iClosest.add(yState);
        }

        return iClosest;
    }

    public TIntArrayList layerAt(int iLayer)
    {
        return aGraph.sCCs.get(iLayer);
    }
    
    //TODO no call put this back
    public void floyd(TIntHashSet iLayer, double epsilon)
    {
        TIntIterator iStates = iLayer.iterator();
        Double M = Double.valueOf(1.7976931348623157E+308D);
        int iState,iSuccessor;
        for(; iStates.hasNext(); addStateDist(iState, iState, Double.valueOf(0.0D)))
        {
            iState = iStates.next();
            for(TIntIterator iSuccessors = getSuccessorsNode(iState).iterator(); iSuccessors.hasNext(); addStateNext(iState, iSuccessor, iSuccessor))
            {
                iSuccessor = iSuccessors.next();
                addStateDist(iState, iSuccessor, 1.0D);
            }
        }

        for(TIntIterator kStates = iLayer.iterator(); kStates.hasNext();)
        {
            int k = kStates.next();
            for(iStates = iLayer.iterator(); iStates.hasNext();)
            {
                int i = iStates.next();
                double dik = getDistance(i, k);
                if(dik != M.doubleValue())
                {
                    for(TIntIterator jStates = iLayer.iterator(); jStates.hasNext();)
                    {
                        int j = jStates.next();
                        double dkj = getDistance(k, j);
                        if(dkj != M.doubleValue())
                        {
                            double u = dik + dkj;
                            if(u < getDistance(i, j))
                            {
                                addStateDist(i, j, u);
                                addStateNext(i, j, getNextState(i, k));
                            }
                        }
                    }

                }
            }

        }

    }

    protected void transposeGraph()
    {
        mGraphT = transpose();
    }

    protected void transposeAcyclicGraph()
    {
        aGraphT = aGraph.transpose();
        aGraph.freeTransposed();
    }

    protected void borderStates()
    {
      TIntObjectHashMap<TIntHashSet> t;
        borderStates = new TIntObjectHashMap<TIntObjectHashMap<TIntHashSet>>();
        for(int iLayer = aGraph.size() - 1; iLayer >= 0; iLayer--)
        {
          borderStates.put(iLayer, t = new TIntObjectHashMap<TIntHashSet>());
          for(int jLayer = aGraph.size() - 1; jLayer >= 0; jLayer--)
          {
            t.put(jLayer, new TIntHashSet());
          }
          for(int kState : layerAt(iLayer).toNativeArray())
          {
              int layer = getSccID(kState);
              for(TIntIterator kSuccessors = getSuccessorsNode(kState).iterator(); kSuccessors.hasNext();)
              {
                  Integer kSuccessor = kSuccessors.next();
                  borderStates.get(layer).get(getSccID(kSuccessor)).add(kState);
              }
          }
        }
    }

    protected void addStateDist(int first, int second, double value)
    {
        if(dStateDist.get(first) == null)
            dStateDist.put(first, new TIntDoubleHashMap());
        dStateDist.get(first).put(second, value);
    }

    protected void addStateNext(int first, int second, int next_)
    {
        if(iStateNext.get(first) == null)
            iStateNext.put(first, new TIntIntHashMap());
        iStateNext.get(first).put(second, next_);
    }
    
    //TODO added
    protected void addPathState(int state){
    	if(!pathStates.contains(state))
    		pathStates.add(state);
    }
    
    //TODO added
    protected void removePathState(int state){
      int idx = pathStates.indexOf(state);
      if (idx>=0)
        pathStates.remove(idx);    			
    }

    //TODO no call
    protected void setAcyclicGraph()
    {
        Graph.Kosaraju kosaraju = new Kosaraju(this);
      
        aGraph = new AcyclicGraph(this, kosaraju.getID(), kosaraju.scc());
        aGraph.floyd();
     
    }

    public Object nextNode(Object obj, Object obj1)
    {
        return next((Integer)obj, (Integer)obj1);
    }

    protected Graph aGraphT;
    protected Graph mGraphT;
    protected AcyclicGraph aGraph;
    protected TIntObjectHashMap<TIntDoubleHashMap> dStateDist;
    protected TIntObjectHashMap<TIntIntHashMap> iStateNext;
    /**
     * A table of Layer1 to a table of Layer2 to the set of states S from layer Layer1 that have at least a successor in Layer2.
     */
    protected TIntObjectHashMap<TIntObjectHashMap<TIntHashSet>> borderStates;
    //TODO added
    public TIntArrayList pathStates = new TIntArrayList();
}
