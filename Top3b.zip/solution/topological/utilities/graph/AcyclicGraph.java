// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AcyclicGraph.java

package solution.topological.utilities.graph;

import gnu.trove.*;

import java.util.*;

import utils.TIntQueue;

// Referenced classes of package pomdp.utilities.graph:
//            Graph

/**
 *  Converted to trove lib.
 *  Still the topological sort to convert !
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 9 juil. 2009
 *
 */
public class AcyclicGraph extends Graph
{
    public class IndependantSort
    {
        Vector<TIntHashSet> indenpendants;
        Vector<Integer> relevantComponents;

        public IndependantSort()
        {
            super();
            indenpendants = cc();
        }

        public IndependantSort(TIntHashSet starting, TIntHashSet terminal)
        {
            this();
            topologicalSort();
            relevantComponents = new Vector<Integer>();
            for(int i = 0; i < indenpendants.size(); i++)
            {
                boolean begin = false;
                boolean end = false;
                for(TIntIterator jindex = indenpendants.get(i).iterator(); jindex.hasNext();)
                {
                    int j = jindex.next();
                    if(starting.contains(j))
                        begin = true;
                    if(terminal.contains(j))
                        end = true;
                }

                if(begin && end)
                  for (int c : indenpendants.get(i).toArray())
                    relevantComponents.add (new Integer(c));
                begin = false;
                end = false;
            }

            Collections.sort(relevantComponents, new TopologicalSort());
        }
    }

    public class TopologicalSort
        implements Comparator<Integer>
    {

        public int compare(Integer arg0, Integer arg1)
        {
            return (new Integer(topologicalSort.indexOf(arg0))).compareTo(new Integer(topologicalSort.indexOf(arg1)));
        }

        public TopologicalSort()
        {
            super();
        }
    }


    public AcyclicGraph(TIntArrayList vertices, Vector<TIntHashSet> successors)
    {
        super(vertices, successors);
    }

    public AcyclicGraph(Graph _g, int _id[], Vector<TIntArrayList> _sCCs)
    {
        id = _id;
        sCCs = _sCCs;
        size = sCCs.size();
        vertices = new TIntArrayList();
        successors = new Vector<TIntHashSet>();
        for(int scc = 0; scc < sCCs.size(); scc++)
        {
            vertices.add(scc);
            successors.add(scc, new TIntHashSet());
            for(int s : sCCs.get(scc).toNativeArray())
            {
                int s2;
                for(TIntIterator iterator1 = _g.getSuccessorsNode(s).iterator(); iterator1.hasNext(); )
                {
                    s2 = iterator1.next();
                    successors.get(scc).add(id[_g.getIndex(s2)]);
                }

            }

        }

    }

    public TIntArrayList topologicalSort()
    {
      if (dual == null)
        dual = transpose();
        int deg[] = new int[vertices.size()];
        topologicalSort = new TIntArrayList();
        TIntQueue fifo = new TIntQueue();
        
        for(int i = 0; i < vertices.size(); i++)
        {
            int neigh = dual.getSuccessors(i).size();
            deg[i] = dual.getSuccessors(i).contains(vertices.get(i)) ? neigh - 1 : neigh;
        }

        while(topologicalSort.size() != vertices.size()) 
        {
            int index = -1;
            do
            {
              index++;
              for(int i = 0; i < vertices.size(); i++)
                  if(deg[i] == index && !topologicalSort.contains(vertices.get(i)))
                      fifo.add(i);
            } while (fifo.isEmpty());
            while(!fifo.isEmpty()) 
            {
                int first = fifo.get();
                if(!topologicalSort.contains(vertices.get(first)))
                    topologicalSort.add(vertices.get(first));
                for(TIntIterator i = getSuccessors(first).iterator(); i.hasNext();)
                {
                    int vertice = i.next();
                    int _index = vertices.indexOf(vertice);
                    deg[_index]--;
                    if(deg[_index] <= 0 && !topologicalSort.contains(vertice) && !fifo.contains(_index))
                        fifo.add(Integer.valueOf(_index));
                }

            }
        }
        return topologicalSort;
    }

    public TIntArrayList reTopologicalSort()
    {
        TIntArrayList topo = topologicalSort();
        topo.reverse();
        return topo;
    }

    public int[] reverseTopologicalSort()
    {
      TIntArrayList topo = topologicalSort();
        int reversedtopologicalSort[] = new int[topo.size()];
        for(int i = 1; i <= topo.size(); i++)
            reversedtopologicalSort[i - 1] = ((Integer)topo.get(topo.size() - i)).intValue();

        return reversedtopologicalSort;
    }

    public LinkedList<TIntHashSet> get()
    {
        if (dual == null)
          dual = transpose();
        int solved = 0;
        int index = 0;
        int deg[] = new int[vertices.size()];
        LinkedList<TIntQueue> fifo = new LinkedList<TIntQueue>();
        LinkedList<TIntHashSet> _fifo = new LinkedList<TIntHashSet>();
        
        fifo.add(index, new TIntQueue());
        for(int i = 0; i < vertices.size(); i++)
        {
            deg[i] = dual.getSuccessors(i).contains(i) ? dual.getSuccessors(i).size() - 1 : dual.getSuccessors(i).size();
            if(deg[i] == 0)
                fifo.get(index).add(i);
        }

        do
        {
            _fifo.add(index, new TIntHashSet());
            fifo.add(index + 1, new TIntQueue());
            while(!fifo.get(index).isEmpty()) 
            {
                int first = fifo.get(index).get();
                _fifo.get(index).add(first);
                solved++;
                for(TIntIterator iter = getSuccessors(first).iterator(); iter.hasNext();)
                {
                    int _index = iter.next();
                    deg[_index]--;
                    if(deg[_index] == 0)
                        fifo.get(index + 1).add(_index);
                }
            }
            index++;
        } while(solved != vertices.size());
        return _fifo;
    }

    public TIntArrayList getRelevantComponentsOnly(int start, int goal)
    {
        boolean _goal = false;
        LinkedList<TIntHashSet> fifo = get();
        TIntHashSet in = new TIntHashSet();
        TIntArrayList relevant = new TIntArrayList();
        TIntHashSet _fifo;
        for(; !fifo.isEmpty(); fifo.remove(_fifo))
        {
            TIntHashSet _in = new TIntHashSet();
            _fifo = fifo.getLast();
            if(_goal)
            {
                for(TIntIterator iter = in.iterator(); iter.hasNext();)
                {
                    int current = iter.next();
                    if(_fifo.contains(current))
                    {
                        relevant.add(current);
                        _in.addAll(dual.getSuccessors(current).toArray());
                        if(current == start)
                            return relevant;
                    }
                }

                in = new TIntHashSet(_in);
            } else
            if(_fifo.contains(goal))
            {
                _goal = true;
                relevant.add(goal);
                in = dual.getSuccessors(goal);
            } else
            if(_fifo.contains(start))
                return new TIntArrayList();
        }

        return relevant;
    }

    public int[] relevantComponentsOnly(int start, int goal)
    {
        TIntArrayList v = getRelevantComponentsOnly(start, goal);
        int results[] = v.toNativeArray();

        return results;
    }

    public void relevantComponents(TIntArrayList startStates, TIntArrayList terminalStates)
    {
        TIntHashSet starting = new TIntHashSet();
        TIntHashSet terminal = new TIntHashSet();
        for(int i = 0; i < startStates.size(); i++)
            starting.add(id[startStates.get(i)]);

        for(int i = 0; i < terminalStates.size(); i++)
            terminal.add(id[terminalStates.get(i)]);

        Vector<Integer> topological = (new IndependantSort(starting, terminal)).relevantComponents;   //TODO Change that !!!!!!!!!!!!!
        this.topologicalSort = new TIntArrayList(topological.size());
        for (Object v : topological)
          this.topologicalSort.add(((Integer)v).intValue());
    }

    protected void relevantComponents(int startState, int terminalState)
    {
    	assert(topologicalSort.indexOf(startState) >= topologicalSort.indexOf(terminalState));
    	
        TIntArrayList top = new TIntArrayList();
        int i = topologicalSort.indexOf(terminalState);
        for(int j = 0; i <= topologicalSort.indexOf(startState); j++)
        {
            top.add(topologicalSort.get(i));
            i++;
        }

        topologicalSort = top;
    }

    public int id[];
    Graph dual;
    public Vector<TIntArrayList> sCCs;
    public TIntArrayList topologicalSort;
}
