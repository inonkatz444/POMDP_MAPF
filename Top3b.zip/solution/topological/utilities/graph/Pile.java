// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   Graph.java

package solution.topological.utilities.graph;


// Referenced classes of package pomdp.utilities.graph:
//            Liste

class Pile
{

    Pile()
    {
        sommet = null;
    }

    Pile(int x)
    {
        sommet = new Liste(x);
    }

    static boolean nonVide(Pile p)
    {
        return p.sommet != null;
    }

    static void empiler(Pile p, int x)
    {
        p.sommet = new Liste(x, p.sommet);
    }

    static int depiler(Pile p)
    {
        if(p.sommet == null)
        {
            throw new Error("Pile vide.");
        } else
        {
            int res = p.sommet.contenu;
            p.sommet = p.sommet.suivant;
            return res;
        }
    }

    Liste sommet;
}
