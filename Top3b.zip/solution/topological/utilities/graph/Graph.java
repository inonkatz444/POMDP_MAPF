package solution.topological.utilities.graph;

import gnu.trove.*;

import java.io.PrintStream;
import java.util.*;

import solution.topological.utilities.graph.utils.Couple;

// Referenced classes of package pomdp.utilities.graph:
//            AcyclicGraph, Liste, Pile

/**
 * Converted to trove lib (to check)
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 9 juil. 2009
 *
 */
public class Graph
{
    protected class Kosaraju
    {

        public int[] getID()
        {
            return id;
        }

        public Vector<TIntArrayList> scc()
        {
            int i = 0;
            int j = 0;
            Vector<TIntArrayList> v = new Vector<TIntArrayList>(scc);
            for(i = 0; i < scc; i++)
                v.add(i, new TIntArrayList());

            for(j = 0; j < id.length; j++)
                v.get(id[j]).add(g.get(j));

            return v;
        }

        protected void dfs(Graph g, int w)
        {
            id[w] = scc;
            visit[w] = 0;
            TIntHashSet suc = g.getSuccessors(w);
            for(TIntIterator i = suc.iterator(); i.hasNext();)
            {
                int index = g.getIndex(i.next());
                if(visit[index] == -1)
                    dfs(g, index);
            }

            visit[w] = cnt;
            cnt++;
        }

        protected TIntStack bfs(Graph g, TIntArrayList w)
        {
            TIntStack open = new TIntStack();
            TIntStack closed = new TIntStack();
            for (int v :w.toNativeArray())
              open.push(v);
            do
            {
                int current = open.pop();
                closed.push(current);
                TIntHashSet suc = g.getSuccessors(current);
                LOOK:for(TIntIterator i = suc.iterator(); i.hasNext();)
                {
                    int index = g.getIndex(i.next());
                    for (int v : closed.toNativeArray())
                      if (v==index)
                        continue LOOK;
                    open.push(index);
                }

            } while(open.size()!=0);
            return closed;
        }

        private void reinit(int os[], int o)
        {
            for(int i = 0; i < g.size(); i++)
                os[i] = o;

        }

        Graph g;
//        HashSet finalSCC;
        protected int visit[];
        int cnt;
        int scc;
        int posit[];

        public Kosaraju(Graph g)
        {
            super();
            cnt = 0;
            scc = 0;
            this.g = g;
            id = new int[g.size()];
            posit = new int[g.size()];
            visit = new int[g.size()];
            reinit(visit, -1);
            cnt = scc = 0;
            for(int i = 0; i < g.size(); i++)
                if(visit[i] == -1)
                {
                  System.out.print(i);System.out.print(' ');
                    dfs(g, i);
                }
            System.out.println("\nTransposing...");
            Graph gt = g.transpose();
            System.out.println("Done!");
            for(int i = 0; i < gt.size(); i++)
                posit[visit[i]] = i;

            reinit(visit, -1);
            cnt = scc = 0;
            for(int i = gt.size() - 1; i >= 0; i--)
                if(visit[posit[i]] == -1)
                {
                  System.out.print(i);System.out.print(' ');
                    dfs(gt, posit[i]);
                    scc++;
                }
            System.out.println("\nFinished!");
        }
    }

    class Tarjan
    {

        private void getBiConnected(int x)
        {
            bics.add(new TIntHashSet());
            int y;
            do
            {
                y = Pile.depiler(g.pileVisite);
                bics.lastElement().add(g.get(y));
            } while(y != x);
            Pile.empiler(g.pileVisite, x);
        }

        protected void sccinit()
        {
            id = new int[g.size()];
            num = new int[g.size()];
            stack = new TIntStack();
            for(int i = 0; i < g.size(); i++)
            {
                id[i] = -1;
                num[i] = -1;
            }

            for(int i = 0; i < g.size(); i++)
                if(num[i] == -1)
                    sccsearch(i);

        }

        private int sccsearch(int i)
        {
            int min = num[i] = cnt;
            cnt++;
            stack.push(i);
            for(TIntIterator j = g.getSuccessors(i).iterator(); j.hasNext();)
            {
                int x = g.getIndex(j.next());
                int minx;
                if(num[x] == -1)
                    minx = sccsearch(x);
                else
                    minx = num[x];
                if(minx < min)
                    min = minx;
            }

            if(min == num[i])
            {
                int k = stack.pop();
                do
                    k = id[k] = scc;
                while(k != i);
                scc++;
            }
            return min;
        }

        public int[] getID()
        {
            return id;
        }

        public Vector<TIntArrayList> scc()
        {
            Vector<TIntArrayList> v = new Vector<TIntArrayList>(g.size);
            for(int i = 0; i < id.length; i++)
                v.add(id[i], new TIntArrayList());

            for(int i = 0; i < id.length; i++)
                v.get(id[i]).add(g.get(i));

            return v;
        }

        public Vector<TIntHashSet> bcc()
        {
            g.numCourant = 0;
            g.pileVisite = new Pile();
            g.dejaVu = new boolean[g.size];
            g.attache = new int[g.size];
            g.num = new int[g.size];
            bics = new Vector<TIntHashSet>();
            for(int x = 0; x < g.size; x++)
            {
                g.dejaVu[x] = false;
                g.num[x] = -1;
                g.attache[x] = -1;
            }

            int num_comp = 1;
            for(int x = 0; x < g.size; x++)
                if(!g.dejaVu[x])
                {
                    num_comp++;
                    dfs(g, x, true);
                }

            return bics;
        }

        private void dfs(Graph g, int x, boolean depart)
        {
            g.dejaVu[x] = true;
            g.num[x] = g.numCourant;
            g.numCourant++;
            Pile.empiler(g.pileVisite, x);
            g.attache[x] = g.num[x];
            int nbFils = 0;
            boolean articulation = false;
            for(TIntIterator listeSucc = g.getSuccessors(x).iterator(); listeSucc.hasNext();)
            {
                int y = g.getIndex(listeSucc.next());
                if(!g.dejaVu[y])
                {
                    nbFils++;
                    dfs(g, y, false);
                    if(g.attache[y] < g.attache[x])
                        g.attache[x] = g.attache[y];
                    articulation = articulation || !depart && g.attache[y] == g.num[x];
                    if(depart || g.attache[y] == g.num[x])
                        getBiConnected(x);
                } else
                if(g.num[y] < g.attache[x])
                    g.attache[x] = g.num[y];
            }

            articulation = articulation || depart && nbFils > 1;
            if(depart && nbFils == 0)
                getBiConnected(x);
            if(depart)
                Pile.depiler(g.pileVisite);
        }

        final int STRONGLY_CONNECTED_COMPONENTS = 0;
        final int BICONNECTED_COMPONENTS = 1;
        TIntStack stack;
//        Stack tree;
        Vector<TIntHashSet> bics;
//        int dejaVu[];
        Graph g;
        int cnt;
        int scc;
        protected int num[];

        public Tarjan(Graph g)
        {
            super();
            cnt = 0;
            scc = 0;
            this.g = g;
        }
    }


    public Graph()
    {
        size = 0;
        size = 0;
    }

    public Graph(TIntArrayList vertices, Vector<TIntHashSet> successors)
    {
        size = 0;
        this.vertices = vertices;
        this.successors = successors;
        size = vertices.size();
    }

    public Vector<TIntArrayList> scc(int method)
    {
        switch(method)
        {
        case 0: // '\0'
            return (new Tarjan(this)).scc();
        }
        return (new Kosaraju(this)).scc();
    }

    public Vector<TIntHashSet> bcc()
    {
        return (new Tarjan(this)).bcc();
    }

    public Vector<TIntArrayList> scc()
    {
        return scc(1);
    }

    public Graph getSubGraph(TIntArrayList vertices)
    {
        Vector<TIntHashSet> successors = new Vector<TIntHashSet>(vertices.size());
        for(int i = 0; i < vertices.size(); i++)
        {
            successors.add(i, new TIntHashSet());
            for(TIntIterator j = getSuccessors(vertices.get(i)).iterator(); j.hasNext();)
            {
                int node = j.next();
                if(vertices.contains(node))
                    successors.get(i).add(node);
            }

        }

        return new Graph(vertices, successors);
    }

    public Graph transpose()
    {
      if (transposed!=null)
        return transposed;
      
        Vector<TIntHashSet> w = new Vector<TIntHashSet>();
        for(int i = 0; i < vertices.size(); i++)
            w.add(i, new TIntHashSet());

        for(int i = 0; i < vertices.size(); i++)
        {
            int index;
            for(TIntIterator j = successors.get(i).iterator(); j.hasNext(); w.get(index).add(vertices.get(i)))
            {
                int node = j.next();
                index = vertices.indexOf(node);
            }

        }

        return transposed = new Graph(vertices, w);
    }

    public AcyclicGraph getAcyclicGraph(int method)
    {
        switch(method)
        {
        case 0: // '\0'
            Tarjan t = new Tarjan(this);
            new AcyclicGraph(this, t.getID(), t.scc());
            break;
        }
        Kosaraju k = new Kosaraju(this);
        AcyclicGraph result = new AcyclicGraph(this, k.getID(), k.scc());
        return result;
    }

    public AcyclicGraph getAcyclicGraph()
    {
        Kosaraju k = new Kosaraju(this);
        AcyclicGraph result = new AcyclicGraph(this, k.getID(), k.scc());
        return result;
    }

    public Vector<TIntHashSet> cc()
    {
        Graph dual = transpose();
        Vector<TIntHashSet> ccs = new Vector<TIntHashSet>();
        Vector<Boolean> nodes = new Vector<Boolean>();
        for(int i = 0; i < vertices.size(); i++)
            nodes.add(Boolean.TRUE);

        for(int _index = 0; _index < vertices.size(); _index++)
        {
            TIntHashSet visit = new TIntHashSet();
            if(nodes.get(_index).booleanValue())
            {
                visit.add(vertices.get(_index));
                nodes.set(_index, Boolean.FALSE);
                TIntHashSet succs = getSuccessors(_index);
                succs.addAll(dual.getSuccessors(_index).toArray());
                while(!succs.isEmpty()) 
                {
                    for(TIntIterator j = succs.iterator(); j.hasNext(); succs.removeAll(visit.toArray()))
                    {
                        int index = getIndex(j.next());
                        nodes.set(index, Boolean.FALSE);
                        if(!visit.contains(index))
                        {
                            succs.addAll(getSuccessors(index).toArray());
                            succs.addAll(dual.getSuccessors(index).toArray());
                            visit.add(vertices.get(index));
                        }
                    }

                }
                ccs.add(visit);
            }
        }

        return ccs;
    }

    public void addSuccessor(int node, int successor)
    {
        successors.get(vertices.indexOf(node)).add(successor);
    }

    public void removeSuccessor(int node, int successor)
    {
        successors.get(vertices.indexOf(node)).remove(successor);
    }

    public TIntHashSet getSuccessorsNode(int node)
    {
//      return new HashSet((Collection)successors.get(vertices.indexOf(node)));
      return successors.get(vertices.indexOf(node)); //XXX removed the clone since never modified anywhere
    }

    public TIntHashSet getSuccessors(int index)
    {
//      return new HashSet(successors.get(index));
      return successors.get(index); 
    }

    public TIntArrayList getVertices()
    {
//      return new Vector(vertices);
      return vertices; //XXX removed the clone since never modified anywhere
    }

    public int getIndex(int node)
    {
        return vertices.indexOf(node);
    }

    public int get(int index)
    {
        return vertices.get(index);
    }

    public int size()
    {
        size = vertices.size();
        return size;
    }

    public String toString()
    {
        String str = "Graphe::\n";
        for(int i = 0; i < vertices.size(); i++)
            str = (new StringBuilder(String.valueOf(str))).append(vertices.get(i)).append(" : ").append(successors.get(i)).append("\n").toString();

        return str;
    }

    //TODO no call
    public void FloydWarshall(Vector<TIntDoubleHashMap> values, double epsilon)
    {
        double M = 1.7976931348623157E+308D;
        costNodes = new Vector<TIntDoubleHashMap>();
        nextNodes = new Vector<TIntIntHashMap>();
        distNodes = new Vector<TIntDoubleHashMap>();
        for(int i = 0; i < size(); i++)
        {
            costNodes.add(i, new TIntDoubleHashMap());
            distNodes.add(i, new TIntDoubleHashMap());
            nextNodes.add(i, new TIntIntHashMap());
            int j;
            for(TIntIterator iStates = getSuccessors(i).iterator(); iStates.hasNext(); distNodes.get(i).put(j, getCost(i, j)))
            {
                j = getIndex(iStates.next());
                double v = i != j ? 1 : 0;
                costNodes.get(i).put(j, v);
                if(values != null)
                {
                    v = values.get(i).get(j) >= epsilon ? costNodes.get(i).get(j) + (1.0D - values.get(i).get(j)) : M;
                    costNodes.get(i).put(j, v);
                }
                nextNodes.get(i).put(j, j);
            }
        }
    }
/*
    private Integer getNext(Integer node0, Integer node1)
    {
        return (Integer)nextNodes.get(node0).getIndex(node1);
    }
*/
    private double getCost(int node0, int node1)
    {
        return costNodes.get(node0).containsKey(node1) ? costNodes.get(node0).get(node1) : 1.7976931348623157E+308D;
    }

    private Double getDist(int node0, int node1)
    {
      return distNodes.get(node0).containsKey(node1) ? distNodes.get(node0).get(node1) : 1.7976931348623157E+308D;
    }

    public void floyd(double values[][], double epsilon)
    {
    	
        double M = 1.7976931348623157E+308D;
        int n = size();
        System.out.println("############ aGraph.floyd cost new Double[] ##########"+ "size = " +n*n);
        cost = new double[n][n];
        
        
        System.out.println("############ aGraph.floyd next new Integer[] ##########" + "size = " +(n+1)*(n+1));
        next = new int[n + 1][n + 1];
        
        for(int i = 0; i < size(); i++)
        {
            for(int j = 0; j < size(); j++)
            {
                if(getSuccessors(i).contains(get(j)))
                {
                    if(values == null)
                    {
                        cost[i][j] = (i != j ? 1.0D : 0.0D);
                    } else
                    {
                        cost[i][j] = (values[i][j] >= epsilon ? (i != j ? 1.0D : 0.0D) + (1.0D - values[i][j]) : M);
                    }
                    next[i][j] = j;
                } else
                {
                    cost[i][j] = M;
                    next[i][j] = -1;
                }
            }
            cost[i][i] = 0D;
            next[i][i] = i;
        }

        dist = new double[n][n];

        for(int i = 0; i < n; i++)
        {
            for(int j = 0; j < n; j++)
                dist[i][j] = cost[i][j];

        }

        for(int k = 0; k < n; k++)
        {
            for(int i = 0; i < n; i++)
            {
                double dik = dist[i][k];
                if(dik != M)
                {
                    for(int j = 0; j < n; j++)
                    {
                        double dkj = dist[k][j];
                        if(dkj != M)
                        {
                            double u = dik + dkj;
                            if(u < dist[i][j])
                            {
                                dist[i][j] = u;
                                next[i][j] = next[i][k];
                            }
                        } // if finite distance k->j
                    } // for j
                } // if finite distance i->k
            } // for i
        } // for k
    } // floyd(double[][],double)

   
    public void floyd()
    {
        floyd(null, 0.0D);
    }

  //TODO no call
    public double walk(int node0, int node1, double values[], boolean show)
    {
        int u = getIndex(node0);
        int v = getIndex(node1);
        int w = u;
        double sum = 0.0D;
        if(show)
            System.out.println(get(w));
        while(w != v) 
        {
            if(next[w][v] == -1)
            {
                if(show)
                    System.out.println("@@@ no walk find @@@");
                sum = (-1.0D / 0.0D);
                break;
            }
            w = next[w][v];
            sum += values[w];
            if(show)
                System.out.println((new StringBuilder()).append(get(w)).append(" dist=").append(dist[w][v]).append(" sum=").append(sum).toString());
        }
        return sum;
    }
    
  //TODO no call
    public double walk(int node0, int node1, double values[], double prob[][], double lastBelief, boolean show)
    {
        int u = getIndex(node0);
        int v = getIndex(node1);
        int w = u;
        double sum = 0.0D;
        if(show)
            System.out.println(get(w));
        while(w != v) 
        {
            if(next[w][v] == -1)
            {
                if(show)
                    System.out.println("@@@ no walk find @@@");
                sum = (-1.0D / 0.0D);
                break;
            }
            lastBelief *= prob[w][next[w][v]];
            sum += values[w] * lastBelief;
            w = next[w][v];
            if(show)
                System.out.println((new StringBuilder()).append(get(w)).append(" dist=").append(dist[w][v]).append(" sum=").append(sum).toString());
        }
        return sum;
    }

    //TODO no call
    public void walk(int node0, int node1)
    {
        int u = getIndex(node0);
        int v = getIndex(node1);
        int w = u;
        System.out.println(get(w));
        while(w != v) 
        {
            if(next[w][v] == -1)
            {
                System.out.println("@@@ no walk find @@@");
                break;
            }
            w = next[w][v];
            System.out.println((new StringBuilder()).append(get(w)).append(" dist=").append(dist[w][v]).toString());
        }
    }

    public int nextNode (int node0, int node1){
        int n = next[getIndex(node0)][getIndex(node1)];
        return n==-1 ? -1 : get(n);
    }
   
    /**
     * Gets the next layer to cross to go from a layer to the other
     * @param arg0 the origin layer
     * @param arg1 the destination layer
     * @return the next layer
     */
    public int next(int arg0, int arg1){
        return next[arg0][arg1];
    }

    public Object closest(int node0, HashSet<Couple<Integer,Double>> nodes)
    {
        int j = -1;
        double dM = (-1.0D / 0.0D);
        double M = 1.7976931348623157E+308D;
        for(Iterator<Couple<Integer,Double>> inodes = nodes.iterator(); inodes.hasNext();)
        {
            Couple<Integer,Double> _node = inodes.next();
            if(dist[getIndex(node0)][getIndex(_node.first)] < M)
            {
                dM = _node.second.doubleValue();
                j = getIndex(_node.first);
                M = dist[getIndex(node0)][getIndex(_node.first)];
            } else
            if(dist[getIndex(node0)][getIndex(_node.first)] == M && _node.second.doubleValue() > dM)
            {
                dM = _node.second.doubleValue();
                j = getIndex(_node.first);
                M = dist[getIndex(node0)][getIndex(_node.first)];
            }
        }

        return j >= 0 ? get(j) : null;
    }

    public void freeTransposed()
    {
      transposed = null;
    }
    
    public int id[];
    public int next[][];
    public double cost[][];
    public double dist[][];
    public Vector<TIntIntHashMap> nextNodes;
    public Vector<TIntDoubleHashMap> costNodes;
    public Vector<TIntDoubleHashMap> distNodes;
    Liste listeSucc[];
    boolean dejaVu[];
    int numCourant;
    int num[];
    int attache[];
    Pile pileVisite;
    public static final int TARJAN = 0;
    public static final int KOSARAJU = 1;
    protected int size;
    protected Vector<TIntHashSet> successors;
    protected TIntArrayList vertices;
    
    private Graph transposed = null;
}
