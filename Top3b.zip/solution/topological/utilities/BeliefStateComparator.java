// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BeliefStateComparator.java

package solution.topological.utilities;

import gnu.trove.TIntDoubleIterator;

import java.util.*;

// Referenced classes of package pomdp.utilities:
//            BeliefState

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.1, 10 juil. 2009 - Removed the useless Belief inner-class
 *
 */
public class BeliefStateComparator  implements Comparator<BeliefState>
{
    public BeliefStateComparator(double dEpsilon)
    {
        m_dEpsilon = dEpsilon;
    }

    public static BeliefStateComparator getInstance(double dEpsilon)
    {
        if(m_bscComparator == null)
            m_bscComparator = new BeliefStateComparator(dEpsilon);
        return m_bscComparator;
    }

    public static BeliefStateComparator getInstance()
    {
        if(m_bscComparator == null)
            return null;
        else
            return m_bscComparator;
    }

    public int compare(BeliefState bs1, BeliefState bs2)
    {
        if(bs1.isDeterministic())
            if(bs2.isDeterministic())
                return bs1.getDeterministicIndex() - bs2.getDeterministicIndex();
            else
                return 1;
        if(bs2.isDeterministic())
            return -1;
        TIntDoubleIterator itFirstNonZero = bs1.getNonZeroEntries();
        TIntDoubleIterator itSecondNonZero = bs2.getNonZeroEntries();
        int iState1 = -1;
        int iState2 = -1;
        double dValue1 = 0.0D;
        double dValue2 = 0.0D;
        while(iState1 < 0x7fffffff || iState2 < 0x7fffffff) 
            if(iState1 == iState2)
            {
                if(Math.abs(dValue1 - dValue2) >= m_dEpsilon)
                    return dValue1 <= dValue2 ? -1 : 1;
                if(itFirstNonZero.hasNext())
                {
                  itFirstNonZero.advance();
                    iState1 = itFirstNonZero.key();
                    dValue1 = itFirstNonZero.value();
                } else
                {
                    iState1 = 0x7fffffff;
                    dValue1 = -1D;
                }
                if(itSecondNonZero.hasNext())
                {
                  itSecondNonZero.advance();
                    iState2 = itSecondNonZero.key();
                    dValue2 = itSecondNonZero.value();
                } else
                {
                    iState2 = 0x7fffffff;
                    dValue2 = -1D;
                }
            } else
            if(iState1 < iState2)
            {
                if(dValue1 >= m_dEpsilon)
                    return 1;
                if(itFirstNonZero.hasNext())
                {
                  itFirstNonZero.advance();
                    iState1 = itFirstNonZero.key();
                    dValue1 = itFirstNonZero.value();
                } else
                {
                    iState1 = 0x7fffffff;
                    dValue1 = -1D;
                }
            } else
            if(iState2 < iState1)
            {
                if(dValue2 >= m_dEpsilon)
                    return -1;
                if(itSecondNonZero.hasNext())
                {
                  itSecondNonZero.advance();
                    iState2 = itSecondNonZero.key();
                    dValue2 = itSecondNonZero.value();
                } else
                {
                    iState2 = 0x7fffffff;
                    dValue2 = -1D;
                }
            }
        return 0;
    }

    protected double m_dEpsilon;
    protected static BeliefStateComparator m_bscComparator = null;

}
