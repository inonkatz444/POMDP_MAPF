// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LongVector.java

package solution.topological.utilities.datastructures;


// Referenced classes of package pomdp.utilities.datastructures:
//            VectorBase, VectorFactory

public class LongVector extends VectorBase
{

    public LongVector(long iSize, VectorFactory vFactory, boolean bSmall)
    {
        super(iSize, vFactory, bSmall);
        setSize(iSize);
    }

    public LongVector(long iSize)
    {
        super(iSize, null, true);
        setSize(iSize);
    }

    public void add(long iElement)
    {
        if(m_cElements == m_iSize)
            expand();
        int iFirstIndex = getFirstIndex(m_cElements);
        int iSecondIndex = getSecondIndex(m_cElements);
        m_aData[iFirstIndex][iSecondIndex] = iElement;
        m_cElements++;
    }

    public void setSize(long iSize)
    {
        int cRows = (int)(iSize / MAX_ARRAY_SIZE);
        int iLastRow = (int)(iSize % MAX_ARRAY_SIZE);
        int iRow = 0;
        m_aData = new long[cRows + 1][];
        for(iRow = 0; iRow < cRows; iRow++)
            m_aData[iRow] = new long[MAX_ARRAY_SIZE];

        m_aData[cRows] = new long[iLastRow];
        m_iSize = iSize;
        m_cElements = 0L;
    }

    @Override
    public void clear()
    {
        m_cElements = 0L;
    }

    public void set(long iIndex, long iElement)
    {
        m_aData[getFirstIndex(iIndex)][getSecondIndex(iIndex)] = iElement;
    }

    public void removeElement(long iElement)
    {
        long iIndex = indexOf(iElement);
        set(iIndex, elementAt(m_cElements - 1L));
        m_cElements--;
    }

    public long elementAt(long iIndex)
    {
        if(iIndex < 0L || iIndex >= m_cElements)
            return -1L;
        else
            return m_aData[getFirstIndex(iIndex)][getSecondIndex(iIndex)];
    }

    private void expand()
    {
        if(m_iSize < MAX_ARRAY_SIZE)
        {
            int iNewSize = 0;
            int i = 0;
            if(m_iSize * 2L > MAX_ARRAY_SIZE)
                iNewSize = MAX_ARRAY_SIZE;
            else
                iNewSize = (int)m_iSize * 2;
            long aData[] = new long[iNewSize];
            for(i = 0; i < m_cElements; i++)
                aData[i] = m_aData[0][i];

            m_iSize = iNewSize;
            m_aData[0] = aData;
        } else
        {
            int iOldSize = m_aData.length;
            int iNewSize = iOldSize + 1;
            int i = 0;
            long aData[][] = new long[iNewSize][];
            for(i = 0; i < iOldSize; i++)
                aData[i] = m_aData[i];

            for(i = iOldSize; i < iNewSize; i++)
                aData[i] = new long[MAX_ARRAY_SIZE];

            m_iSize = iNewSize * MAX_ARRAY_SIZE;
            m_aData = aData;
        }
    }

    public void reduce()
    { //
    }

    public long indexOf(long iElement)
    {
        int i = 0;
        int j = 0;
        int cRows = (int)(m_cElements / MAX_ARRAY_SIZE);
        int cCols = (int)(m_cElements % MAX_ARRAY_SIZE);
        for(j = 0; j < cRows; j++)
            for(i = 0; i < MAX_ARRAY_SIZE; i++)
                if(m_aData[j][i] == iElement)
                    return (long)j * (long)MAX_ARRAY_SIZE + i;


        for(i = 0; i < cCols; i++)
            if(m_aData[cRows][i] == iElement)
                return (long)cRows * (long)MAX_ARRAY_SIZE + i;

        return -1L;
    }

    public boolean contains(long iElement)
    {
        return indexOf(iElement) != -1L;
    }

    public void addAll(LongVector v)
    {
        long iIndex = 0L;
        for(iIndex = 0L; iIndex < v.m_cElements; iIndex++)
            add(v.elementAt(iIndex));

    }

    public static VectorBase newInstance(long iSize, VectorFactory vFactory, boolean bSmall)
    {
        return new LongVector(iSize, vFactory, bSmall);
    }

    private long m_aData[][];
}
