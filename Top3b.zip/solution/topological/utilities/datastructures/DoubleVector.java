// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   DoubleVector.java

package solution.topological.utilities.datastructures;

import solution.topological.utilities.Logger;

// Referenced classes of package pomdp.utilities.datastructures:
//            VectorBase, VectorFactory

public class DoubleVector extends VectorBase
{
//    public DoubleVector(long iSize, VectorFactory vFactory, boolean bSmall)
//    {
//        super(iSize, vFactory, bSmall);
//        setSize(iSize);
//    }

    public DoubleVector(long iSize)
    {
        super(iSize, null, false);
        setSize(iSize);
    }

    private void set(int i, int j, double v)
    {
        m_aData[i][j] = (float)v;
    }

    public void add(double dElement)
    {
        if(m_cElements == m_iSize)
            expand();
        set(getFirstIndex(m_cElements), getSecondIndex(m_cElements), dElement);
        m_cElements++;
    }

    public void setSize(long iSize)
    {
        int cRows = (int)(iSize / MAX_ARRAY_SIZE);
        int iLastRow = (int)(iSize % MAX_ARRAY_SIZE);
        int iRow = 0;
        m_aData = new float[cRows + 1][];
        for(iRow = 0; iRow < cRows; iRow++)
            m_aData[iRow] = new float[MAX_ARRAY_SIZE];

        m_aData[cRows] = new float[iLastRow];
        m_iSize = iSize;
        m_cElements = 0L;
    }

    @Override
    public void clear()
    {
        m_cElements = 0L;
    }

    public void set(long iIndex, double dElement)
    {
        set(getFirstIndex(iIndex), getSecondIndex(iIndex), dElement);
        if(iIndex >= m_cElements)
            m_cElements = iIndex + 1L;
    }

    public void removeElement(long iElement)
    {
        long iIndex = indexOf(iElement);
        set(iIndex, elementAt(m_cElements - 1L));
        m_cElements--;
    }

    public double elementAt(long iIndex)
    {
        if(iIndex < 0L || iIndex >= m_cElements)
            return -1D;
        else
            return m_aData[getFirstIndex(iIndex)][getSecondIndex(iIndex)];
    }

    private void expand()
    {
        if(m_iSize < MAX_ARRAY_SIZE)
        {
            int iNewSize = 0;
            int i = 0;
            if(m_iSize * 2L > MAX_ARRAY_SIZE)
                iNewSize = MAX_ARRAY_SIZE;
            else
                iNewSize = (int)m_iSize * 2;
            float aData[] = new float[iNewSize];
            for(i = 0; i < m_cElements; i++)
                aData[i] = m_aData[0][i];

            m_iSize = iNewSize;
            m_aData[0] = aData;
        } else
        {
            int iOldSize = m_aData.length;
            int iNewSize = iOldSize + 1;
            int i = 0;
            float aData[][] = new float[iNewSize][];
            for(i = 0; i < iOldSize; i++)
                aData[i] = m_aData[i];

            for(i = iOldSize; i < iNewSize; i++)
                aData[i] = new float[MAX_ARRAY_SIZE];

            m_iSize = iNewSize * MAX_ARRAY_SIZE;
            m_aData = aData;
        }
    }

    public void reduce()
    {//
    }

    public long indexOf(long iElement)
    {
        int i = 0;
        int j = 0;
        int cRows = (int)(m_cElements / MAX_ARRAY_SIZE);
        int cCols = (int)(m_cElements % MAX_ARRAY_SIZE);
        for(j = 0; j < cRows; j++)
            for(i = 0; i < MAX_ARRAY_SIZE; i++)
                if(m_aData[j][i] == iElement)
                    return (long)j * (long)MAX_ARRAY_SIZE + i;


        for(i = 0; i < cCols; i++)
            if(m_aData[cRows][i] == iElement)
                return (long)cRows * (long)MAX_ARRAY_SIZE + i;

        return -1L;
    }

    public boolean contains(long iElement)
    {
        return indexOf(iElement) != -1L;
    }

    public void addAll(DoubleVector v)
    {
        long iIndex = 0L;
        for(iIndex = 0L; iIndex < v.m_cElements; iIndex++)
            add(v.elementAt(iIndex));

    }

    public void validateSize(long cVertexes)
    {
        if(m_iSize > cVertexes)
            Logger.getInstance().log("DV", 0, "validateSize", (new StringBuilder("Expected ")).append(cVertexes).append(" real size ").append(m_iSize).append(", elements ").append(m_cElements).toString());
    }

    private float m_aData[][];
}
