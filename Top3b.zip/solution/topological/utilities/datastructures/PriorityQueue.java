// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PriorityQueue.java

package solution.topological.utilities.datastructures;

import java.util.Iterator;

// Referenced classes of package pomdp.utilities.datastructures:
//            PriorityQueueElement

public interface PriorityQueue
{

    public abstract PriorityQueueElement extractMax();

    public abstract void insert(PriorityQueueElement priorityqueueelement);

    public abstract void adjust(PriorityQueueElement priorityqueueelement);

    public abstract Iterator<PriorityQueueElement> iterator();

    public abstract boolean isEmpty();

    public abstract int size();

    public abstract void clear();

    public abstract int swapCount();
}
