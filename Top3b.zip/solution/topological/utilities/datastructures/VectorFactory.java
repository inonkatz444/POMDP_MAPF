// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   VectorFactory.java

package solution.topological.utilities.datastructures;

import java.util.Stack;

// Referenced classes of package pomdp.utilities.datastructures:
//            VectorBase

public abstract class VectorFactory<VType extends VectorBase>
{

    public VectorFactory()
    {
        ITERATION_SIZE = 10000;
        m_sLargeVectors = new Stack<VType>();
        m_sSmallVectors = new Stack<VType>();
    }

    public abstract VType newInstance(int i, boolean flag);

    public VType getSmallVector()
    {
    	VType v = newInstance(16, true);
        return v;
    }

    public VType getLargeVector()
    {
    	VType v = newInstance(256, false);
        return v;
    }

    public void recycleSmall(VType vectorbase)
    { //
    }

    public void recycleLarge(VType vectorbase)
    { //
    }

    public void clear()
    {
    	for(VType v : m_sSmallVectors)
    		v.clearFactory();
    	
    	m_sSmallVectors.clear();
        
        m_sSmallVectors.clear();
        for(VType v : m_sLargeVectors)
        	v.clearFactory();
        m_sLargeVectors.clear();
    }

    private Stack<VType> m_sLargeVectors;
    private Stack<VType> m_sSmallVectors;
    protected int ITERATION_SIZE;
}
