// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LongVectorFactory.java

package solution.topological.utilities.datastructures;


// Referenced classes of package pomdp.utilities.datastructures:
//            VectorFactory, LongVector, VectorBase

public class LongVectorFactory extends VectorFactory{

    public LongVectorFactory()
    {
    	super();
        ITERATION_SIZE = 0x186a0;
    }

    @Override
    public LongVector newInstance(int iSize, boolean bSmall)
    {
        return new LongVector(iSize, this, bSmall);
    }
}
