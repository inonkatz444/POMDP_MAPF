// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   StaticMap.java

package solution.topological.utilities.datastructures;

import java.util.Iterator;

import solution.topological.utilities.Pair;

public class StaticMap
{
    private class StaticMapIterator
        implements Iterator<Pair<Integer,Double>>
    {

        public boolean hasNext()
        {
            return m_iCurrent < m_cNonZeroValues;
        }

        public Pair<Integer,Double> next()
        {
            if(hasNext())
            {
                m_iCurrent++;
                return new Pair<Integer,Double>(new Integer(m_aiIndexes[m_iCurrent - 1]), new Double(m_adValues[m_iCurrent - 1]));
            } else
            {
                return null;
            }
        }

        public void remove()
        { //
        }

        private int m_aiIndexes[];
        private double m_adValues[];
        private int m_cNonZeroValues;
        private int m_iCurrent;

        public StaticMapIterator(int aiIndexes[], double adValues[], int cNonZeroValues)
        {
            super();
            m_aiIndexes = aiIndexes;
            m_adValues = adValues;
            m_cNonZeroValues = cNonZeroValues;
            m_iCurrent = 0;
        }
    }


    public StaticMap(double adAllValues[], double dEpsilon)
    {
        countNonZeroEntries(adAllValues, dEpsilon);
        initArrays(adAllValues, dEpsilon);
    }

    private void initArrays(double adAllValues[], double dEpsilon)
    {
        int idx = 0;
        int realIdx = 0;
        m_aiIndexes = new int[m_cNonZeroValues];
        m_adValues = new double[m_cNonZeroValues];
        for(idx = 0; idx < adAllValues.length; idx++)
            if(Math.abs(adAllValues[idx]) > dEpsilon)
            {
                m_aiIndexes[realIdx] = idx;
                m_adValues[realIdx] = adAllValues[idx];
                realIdx++;
            }

    }

    private void countNonZeroEntries(double adAllValues[], double dEpsilon)
    {
        int idx = 0;
        m_cNonZeroValues = 0;
        for(idx = 0; idx < adAllValues.length; idx++)
            if(Math.abs(adAllValues[idx]) > dEpsilon)
                m_cNonZeroValues++;

    }

    private int find(int iRealIdx)
    {
        int iStart = 0;
        int iEnd = m_cNonZeroValues;
        int iMedian = 0;
        while(iEnd - iStart > 1) 
        {
            iMedian = (iStart + iEnd) / 2;
            if(m_aiIndexes[iMedian] == iRealIdx)
                return iMedian;
            if(m_aiIndexes[iMedian] > iRealIdx)
                iEnd = iMedian;
            else
                iStart = iMedian + 1;
        }
        if(iEnd == iStart + 1 && m_aiIndexes[iStart] == iRealIdx)
            return iStart;
        else
            return -1;
    }

    public double get(int idx)
    {
        int iMapIdx = find(idx);
        if(iMapIdx == -1)
            return 0.0D;
        else
            return m_adValues[iMapIdx];
    }

    public void set(int idx, double dValue)
    {
        m_adValues[idx] = dValue;
    }

    public int countEntries()
    {
        return m_cNonZeroValues;
    }

    public Iterator<Pair<Integer,Double>> iterator()
    {
        return new StaticMapIterator(m_aiIndexes, m_adValues, m_cNonZeroValues);
    }

    public int size()
    {
        return m_cNonZeroValues;
    }

    private int m_aiIndexes[];
    private double m_adValues[];
    private int m_cNonZeroValues;
}
