// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   LongArrayVectorFactory.java

package solution.topological.utilities.datastructures;


// Referenced classes of package pomdp.utilities.datastructures:
//            VectorFactory, LongArrayVector, VectorBase

public class LongArrayVectorFactory extends VectorFactory
{

    public LongArrayVectorFactory()
    {
    	super();
        ITERATION_SIZE = 10000;
    }

    @Override
    public LongArrayVector newInstance(int iSize, boolean bSmall)
    {
        return new LongArrayVector(iSize, this, bSmall);
    }
}
