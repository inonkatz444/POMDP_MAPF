// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   VectorBase.java

package solution.topological.utilities.datastructures;


// Referenced classes of package pomdp.utilities.datastructures:
//            VectorFactory

public abstract class VectorBase
{

    public VectorBase(long iSize, VectorFactory vFactory, boolean bSmall)
    {
        m_iSize = iSize;
        m_vFactory = vFactory;
        m_bSmall = bSmall;
    }

    public static VectorBase newInstance(long iSize, VectorFactory ivFactory, boolean bSmall)
    {
        return null;
    }

    protected int getFirstIndex(long iIndex)
    {
        return (int)(iIndex / MAX_ARRAY_SIZE);
    }

    protected int getSecondIndex(long iIndex)
    {
        return (int)(iIndex % MAX_ARRAY_SIZE);
    }

    public long size()
    {
        return m_cElements;
    }

    public void clear()
    {
        m_cElements = 0L;
    }

    public void release()
    { //
    }

    public long getID()
    {
        return m_iID;
    }

    public void addUse()
    {
        m_cUses++;
    }

    public int getUseCount()
    {
        return m_cUses;
    }

    @Override
    public String toString()
    {
        return (new StringBuilder("V")).append(getID()).toString();
    }

    public void clearFactory()
    {
        m_vFactory = null;
    }

    protected long m_cElements;
    protected VectorFactory m_vFactory;
    protected boolean m_bSmall;
    protected long m_iSize;
    private long m_iID;
    protected int m_cUses;
    private static long m_cIDs = 0L;
    public static int MAX_ARRAY_SIZE = 0xf4240;
    
    /**
     * Clears all static values 
     */
    public static void clearStatic()
    {
      m_cIDs = 0L;
    }

}
