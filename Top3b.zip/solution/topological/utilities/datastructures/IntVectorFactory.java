// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   IntVectorFactory.java

package solution.topological.utilities.datastructures;

import java.util.Stack;

// Referenced classes of package pomdp.utilities.datastructures:
//            IntVector

public class IntVectorFactory
{

    private IntVectorFactory()
    {
        m_sLargeVectors = new Stack<IntVector>();
        m_sSmallVectors = new Stack<IntVector>();
    }

    public static IntVectorFactory getInstance()
    {
        if(g_ivFactory == null)
            g_ivFactory = new IntVectorFactory();
        return g_ivFactory;
    }

    public IntVector getSmallVector()
    {
        if(m_sSmallVectors.size() != 0)
            return m_sSmallVectors.pop();
        else
            return new IntVector(16, this, true);
    }

    public IntVector getLargeVector()
    {
        if(m_sLargeVectors.size() != 0)
            return m_sLargeVectors.pop();
        else
            return new IntVector(256, this, false);
    }

    public void recycleSmall(IntVector v)
    {
        m_sSmallVectors.push(v);
    }

    public void recycleLarge(IntVector v)
    {
        m_sLargeVectors.push(v);
    }

    private Stack<IntVector> m_sLargeVectors;
    private Stack<IntVector> m_sSmallVectors;
    private static IntVectorFactory g_ivFactory = null;

    /**
     * Clears all static values 
     */
    public static void clear()
    {
      g_ivFactory = null;
    }
}
