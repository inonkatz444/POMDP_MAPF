// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PriorityQueueElement.java

package solution.topological.utilities.datastructures;


// Referenced classes of package pomdp.utilities.datastructures:
//            PriorityQueue

public class PriorityQueueElement
{

    public PriorityQueueElement()
    {
        m_dPriority = 0.0D;
        m_iLocation = -1;
        m_pqContainer = null;
    }

    public PriorityQueueElement(PriorityQueue pqContainer, double dPriority, int iLocation)
    {
        m_dPriority = dPriority;
        m_iLocation = iLocation;
        m_pqContainer = pqContainer;
    }

    public void setContainer(PriorityQueue pqContainer)
    {
        m_pqContainer = pqContainer;
    }

    public void increasePriority(double dPriority)
    {
        if(m_dPriority < dPriority)
        {
            m_dPriority = dPriority;
            if(m_pqContainer != null)
                m_pqContainer.adjust(this);
        }
    }

    public void addPriority(double dPriority)
    {
        m_dPriority += dPriority;
        if(m_pqContainer != null)
            m_pqContainer.adjust(this);
    }

    public void setPriority(double dPriority)
    {
        if(m_dPriority != dPriority)
        {
            m_dPriority = dPriority;
            if(m_pqContainer != null)
                m_pqContainer.adjust(this);
        }
    }

    public double getPriority()
    {
        return m_dPriority;
    }

    public void setLocation(int iLocation)
    {
        m_iLocation = iLocation;
    }

    public int getLocation()
    {
        return m_iLocation;
    }

    public void clear()
    {
        m_iLocation = -1;
        setContainer(null);
    }

    private double m_dPriority;
    private int m_iLocation;
    private PriorityQueue m_pqContainer;
}
