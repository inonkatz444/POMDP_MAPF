// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   RandomGenerator.java

package solution.topological.utilities;

import java.util.Random;

public class RandomGenerator
{

    public RandomGenerator(String sName)
    {
        this(sName, System.currentTimeMillis());
    }

    public RandomGenerator(String sName, long iSeed)
    {
        m_rndGenerator = new Random(iSeed);
        m_sName = sName;
//        System.out.println((new StringBuilder("Initializing generator ")).append(m_sName).append(" with random seed ").append(iSeed).toString());
    }

    public void init(long iSeed, boolean bNotify)
    {
        m_rndGenerator = new Random(iSeed);
        if(bNotify)
            System.out.println((new StringBuilder("Initializing generator ")).append(m_sName).append(" with random seed ").append(iSeed).toString());
    }

    public void init(long iSeed)
    {
        m_rndGenerator = new Random(iSeed);
        System.out.println((new StringBuilder("Initializing generator ")).append(m_sName).append(" with random seed ").append(iSeed).toString());
    }

    public int nextInt(int iMax)
    {
        return m_rndGenerator.nextInt(iMax);
    }

    public int nextInt()
    {
        return m_rndGenerator.nextInt();
    }

    public double nextDouble()
    {
        return m_rndGenerator.nextDouble();
    }

    public double nextDouble(double dMax)
    {
        return m_rndGenerator.nextDouble() * dMax;
    }

    public double nextDouble(double dLowerBound, double dUpperBound)
    {
        return m_rndGenerator.nextDouble() * (dUpperBound - dLowerBound) + dLowerBound;
    }

    public static void main(String args[])
    {
        int ac[] = new int[5];
        int i = 0;
        int rnd = 0;
        for(i = 0; i < 5; i++)
            ac[i] = 0;

        RandomGenerator rndGen = new RandomGenerator("General", 1L);
        for(i = 0; i < 0xf4240; i++)
        {
            rnd = Math.abs(rndGen.nextInt()) % 5;
            ac[rnd]++;
        }

        for(i = 0; i < 5; i++)
            System.out.println((new StringBuilder(String.valueOf(i))).append("=").append(ac[i]).append(", ").toString());

        Random rnd0 = new Random(0L);
        Random rnd1 = new Random(1L);
        String sOutput0 = "Rnd( 0 ) = ";
        for(i = 0; i < 10; i++)
            sOutput0 = (new StringBuilder(String.valueOf(sOutput0))).append(rnd0.nextInt(9)).append(", ").toString();

        System.out.println(sOutput0);
        String sOutput1 = "Rnd( 1 ) = ";
        for(i = 0; i < 10; i++)
            sOutput1 = (new StringBuilder(String.valueOf(sOutput1))).append(rnd1.nextInt(9)).append(", ").toString();

        System.out.println(sOutput1);
        rnd0 = new Random(0L);
        rnd1 = new Random(1L);
        sOutput0 = "Rnd( 0 ) = ";
        sOutput1 = "Rnd( 1 ) = ";
        for(i = 0; i < 10; i++)
        {
            sOutput0 = (new StringBuilder(String.valueOf(sOutput0))).append(rnd0.nextInt(9)).append(", ").toString();
            sOutput1 = (new StringBuilder(String.valueOf(sOutput1))).append(rnd1.nextInt(9)).append(", ").toString();
        }

        System.out.println(sOutput0);
        System.out.println(sOutput1);
    }

    private Random m_rndGenerator;
    private String m_sName;
}
