// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   BeliefStateFactory.java

package solution.topological.utilities;

import gnu.trove.TIntDoubleIterator;
import gnu.trove.TIntObjectHashMap;

import java.io.*;
import java.util.*;

import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

import solution.topological.environments.POMDP;
import solution.topological.utilities.distance.DistanceMetric;
import solution.topological.utilities.distance.L1Distance;

// Referenced classes of package pomdp.utilities:
//            BeliefState, BeliefStateComparator, Logger, ExecutionProperties, 
//            JProf

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 10 juil. 2009
 *
 */
public class BeliefStateFactory
{

    public void clear()
    {
        s_bsFactory = new BeliefStateFactory(s_bsFactory.m_pPOMDP, s_bsFactory.m_cDiscretizationLevels);
        Runtime.getRuntime().gc();
    }

    public static BeliefStateFactory getInstance(POMDP pomdp, int cDiscretizationLevels)
    {
        s_bsFactory = new BeliefStateFactory(pomdp, cDiscretizationLevels);
        return s_bsFactory;
    }

    public static BeliefStateFactory getInstance(POMDP pomdp)
    {
        s_bsFactory = new BeliefStateFactory(pomdp);
        return s_bsFactory;
    }

    public static BeliefStateFactory getInstance()
    {
        return s_bsFactory;
    }

    protected BeliefStateFactory(POMDP pomdp, int cDiscretizationLevels)
    {
        m_cBeliefUpdates = 0;
        m_bSparseBeliefStates = true;
        m_bCacheDeterministicBeliefStates = false;
        m_pPOMDP = pomdp;
        m_hmCachedBeliefStates = new TreeMap<BeliefState,BeliefState>(getBeliefStateComparator(0.001D));
        m_hmCachedBeliefStates = Collections.synchronizedMap(m_hmCachedBeliefStates);
        m_cDiscretizationLevels = cDiscretizationLevels;
        m_cBeliefPoints = 0;
        m_bCacheBelifStates = true;
        BeliefState.g_cBeliefStateUpdates = 0;
        m_bsInitialState = null;
        m_bCountBeliefUpdates = true;
        m_bsUniformState = null;
        m_cTimeInTau = 0;
        m_abDeterministic = null;
        m_cBeliefStateSize = 0L;
    }

    protected Comparator<BeliefState> getBeliefStateComparator(double dEpsilon)
    {
        return BeliefStateComparator.getInstance(dEpsilon);
    }

    protected BeliefStateFactory(POMDP pomdp)
    {
        this(pomdp, -1);
    }

    protected double nextBeliefValue(BeliefState bs, int iAction, int iEndState, int iObservation)
    {
        double dProb = 0.0D;
        double dO = 0.0D;
        double dTr = 0.0D;
        double dBelief = 0.0D;
        int iStartState = 0;
        Logger.getInstance().log("BeliefStateFactory", 11, "nextBeliefValue", " s' = ", iEndState);
        dO = m_pPOMDP.O(iAction, iEndState, iObservation);
        if(dO == 0.0D)
            return 0.0D;
        TIntDoubleIterator it = bs.getNonZeroEntries();
        while(it.hasNext()) 
        {
          it.advance();
            iStartState = it.key();
            dBelief = it.value();
            dTr = m_pPOMDP.tr(iStartState, iAction, iEndState);
            dProb += dTr * dBelief;
        }
        dProb *= dO;
        return dProb;
    }

    public double calcNormalizingFactor(BeliefState bs, int iAction, int iObservation)
    {
        double dProb = 0.0D;
        double dO = 0.0D;
        double dBelief = 0.0D;
        double dTr = 0.0D;
        double dSum = 0.0D;
        int iStartState = 0;
        int iEndState = 0;
        TIntDoubleIterator itNonNegativeTransitions = null;
        TIntDoubleIterator itNonZeroBeliefs = bs.getNonZeroEntries();
        while(itNonZeroBeliefs.hasNext()) 
        {
          itNonZeroBeliefs.advance();
            iStartState = itNonZeroBeliefs.key();
            dBelief = itNonZeroBeliefs.value();
            dSum = 0.0D;
            for(itNonNegativeTransitions = m_pPOMDP.getNonZeroTransitions(iStartState, iAction); itNonNegativeTransitions.hasNext();)
            {
              itNonNegativeTransitions.advance();
                iEndState = itNonNegativeTransitions.key();
                dTr = itNonNegativeTransitions.value();
                dO = m_pPOMDP.O(iAction, iEndState, iObservation);
                dSum += dO * dTr;
            }

            dProb += dSum * dBelief;
        }
        return dProb;
    }

    public BeliefState nextBeliefState(BeliefState bs, int iAction, int iObservation)
    {
        BeliefState bsNext;
        double dNormalizingFactor;
        double dSum;
        long lTimeBefore;
        bsNext = newBeliefState();
        dNormalizingFactor = 0.0D;
        double dNextValue = 0.0D;
        dSum = 0.0D;
        int iEndState = 0;
        int cStates = m_pPOMDP.getStateCount();
        lTimeBefore = 0L;
        long lTimeAfter = 0L;
        if(ExecutionProperties.getReportOperationTime())
            lTimeBefore = JProf.getCurrentThreadCpuTimeSafe();
        if(m_bCountBeliefUpdates)
            m_cBeliefUpdates++;
        dNormalizingFactor = 0.0D;
        for(iEndState = 0; iEndState < cStates; iEndState++)
        {
            dNextValue = nextBeliefValue(bs, iAction, iEndState, iObservation);
            bsNext.setValueAt(iEndState, dNextValue);
            dNormalizingFactor += dNextValue;
        }

        if(dNormalizingFactor == 0.0D)
            return null;
        try
        {
            TIntDoubleIterator itNonZeroEntries = bsNext.getNonZeroEntries();
            while(itNonZeroEntries.hasNext()) 
            {
              itNonZeroEntries.advance();
                iEndState = itNonZeroEntries.key();
                dNextValue = itNonZeroEntries.value();
                bsNext.setValueAt(iEndState, dNextValue / dNormalizingFactor);
                dSum += dNextValue / dNormalizingFactor;
            }
            g_cNext++;
            if(ExecutionProperties.getReportOperationTime())
            {
                lTimeAfter = JProf.getCurrentThreadCpuTimeSafe();
                g_cTime += (lTimeAfter - lTimeBefore) / 1000L;
                m_cBeliefStateSize += bsNext.size();
                if(g_cNext % 1000L == 0L)
                {
                    Logger.getInstance().log("BeliefStateFactory", 0, "nextBeliefState", (new StringBuilder("After ")).append(g_cNext).append(" next BS computations, avg time ").append(g_cTime / 1000L).append(", avg belief state size ").append(m_cBeliefStateSize / 1000L).toString());
                    g_cTime = 0L;
                    m_cBeliefStateSize = 0L;
                }
            }
            if(m_bCacheBelifStates)
            {
                BeliefState bsExisting = m_hmCachedBeliefStates.get(bsNext);
                if(bsExisting == null)
                {
                    cacheBeliefState(bsNext);
                    m_cBeliefPoints++;
                } else
                {
                    bsNext = bsExisting;
                }
                if(bsNext != bs)
                    bsNext.addPredecessor(bs, dNormalizingFactor, iAction);
            }
            if(ExecutionProperties.getReportOperationTime() && m_bCountBeliefUpdates)
            {
                lTimeAfter = JProf.getCurrentThreadCpuTimeSafe();
                m_cTimeInTau += (lTimeAfter - lTimeBefore) / 1000L;
            }
            
//            System.out.println("************************ belief state = " + bs);
//            System.out.println("******** Action = " + iAction);
//            System.out.println("******** Observation = " + iObservation);
//            System.out.println("******** Next belief state = " + bsNext);
            return bsNext;
        }
        catch(Error err)
        {
            Runtime rtRuntime = Runtime.getRuntime();
            System.out.println((new StringBuilder("|BeliefSpace| ")).append(m_cBeliefPoints).append(", ").append(err).append(" allocated ").append((rtRuntime.totalMemory() - rtRuntime.freeMemory()) / 0xf4240L).append(" free ").append(rtRuntime.freeMemory() / 0xf4240L).append(" max ").append(rtRuntime.maxMemory() / 0xf4240L).toString());
            err.printStackTrace();
            System.exit(0);
            return null;
        }
    }

    protected void cacheBeliefState(BeliefState bs)
    {
        m_hmCachedBeliefStates.put(bs, bs);
    }

    public BeliefState getInitialBeliefState()
    {
        if(m_bsInitialState == null)
        {
            m_bsInitialState = newBeliefState();
            m_cBeliefPoints++;
            int iState = 0;
            int cStates = m_pPOMDP.getStateCount();
            double dSum = 0.0D;
            double dValue = 0.0D;
            for(iState = 0; iState < cStates; iState++)
            {
                dValue = m_pPOMDP.probStartState(iState);
                m_bsInitialState.setValueAt(iState, dValue);
                dSum += dValue;
            }

            if(dSum < 0.999D || dSum > 1.0001D)
                Logger.getInstance().log("BeliefStateFactory", 0, "getInitialBeliefState", (new StringBuilder("Corrupted intial belief state ")).append(m_bsInitialState.toString()).toString());
            cacheBeliefState(m_bsInitialState);
            Logger.getInstance().log("BeliefStateFactory", 11, "getInitialBeliefState", m_bsInitialState.toString());
        }
        return m_bsInitialState;
    }

    public static int getBeliefUpdatesCount()
    {
        return getInstance().m_cBeliefUpdates;
    }

    public BeliefState getDeterministicBeliefState(int iState)
    {
        if(m_bCacheDeterministicBeliefStates)
        {
            if(m_abDeterministic == null)
                m_abDeterministic = new BeliefState[m_pPOMDP.getStateCount()];
            if(m_abDeterministic[iState] != null)
                return m_abDeterministic[iState];
        }
        BeliefState bs = newBeliefState();
        bs.setValueAt(iState, 1.0D);
        if(m_bCacheDeterministicBeliefStates)
        {
            BeliefState bsExisting = m_hmCachedBeliefStates.get(bs);
            if(bsExisting == null && isCachingBeliefStates())
            {
                cacheBeliefState(bs);
                Logger.getInstance().log("BeliefStateFactory", 11, "getDeterministicBeliefState", bs.toString());
                m_cBeliefPoints++;
            } else
            if(bsExisting != null)
                bs = bsExisting;
            m_abDeterministic[iState] = bs;
        }
        return bs;
    }

    protected int roundToNearest(double dNumber)
    {
        int iNumber = (int)dNumber;
        double dDiff = dNumber - iNumber;
        if(dDiff > 0.5D)
            return iNumber + 1;
        else
            return iNumber;
    }

    public void setDiscretizationLevels(int cDiscretizationLevels)
    {
        m_cDiscretizationLevels = cDiscretizationLevels;
    }

    public int getDiscretizationLevels()
    {
        return m_cDiscretizationLevels;
    }

    protected double discretize(double dPr)
    {
        double dScaledPr = dPr * m_cDiscretizationLevels;
        int iPr = roundToNearest(dScaledPr);
        return (iPr / m_cDiscretizationLevels);
    }

    public BeliefState discretize(BeliefState bs)
    {
        BeliefState bsDiscretized = newBeliefState();
        int iState = 0;
        double dPr = 0.0D;
        double dDiscPr = 0.0D;
        TIntDoubleIterator it = bs.getNonZeroEntries();
        for(; it.hasNext(); bsDiscretized.setValueAt(iState, dDiscPr))
        {
          it.advance();
            iState = it.key();
            dPr = it.value();
            dDiscPr = discretize(dPr);
        }

        BeliefState bsExisting = m_hmCachedBeliefStates.get(bsDiscretized);
        if(bsExisting == null)
        {
            cacheBeliefState(bsDiscretized);
            m_cBeliefPoints++;
        } else
        {
            bsDiscretized = bsExisting;
        }
        return bsDiscretized;
    }

    public int getBeliefStateCount()
    {
        return m_hmCachedBeliefStates.size();
    }

    public void cacheBeliefStates(boolean bCache)
    {
        m_bCacheBelifStates = bCache;
    }

    public boolean isCachingBeliefStates()
    {
        return m_bCacheBelifStates;
    }

    public void saveBeliefSpace(String sFileName)
        throws IOException, TransformerException, ParserConfigurationException
    {
        save(sFileName, m_hmCachedBeliefStates.keySet());
    }

    public static void saveBeliefPoints(String sFileName, Vector<BeliefState> vBeliefPoints)
        throws IOException, TransformerException, ParserConfigurationException
    {
        getInstance().save(sFileName, vBeliefPoints);
    }

    protected void save(String sFileName, Collection<BeliefState> colPoints)
        throws IOException, TransformerException, ParserConfigurationException
    {
        System.out.println((new StringBuilder("Saving Belief space to ")).append(sFileName).toString());
        Document docBeliefSpace = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
        Element eBeliefSpace = null;
        Element eBeliefState = null;
        Iterator<BeliefState> itBeliefSpace = null;
        BeliefState bsCurrent = null;
        eBeliefSpace = docBeliefSpace.createElement("BeliefSpace");
        eBeliefSpace.setAttribute("size", (new StringBuilder(String.valueOf(colPoints.size()))).toString());
        docBeliefSpace.appendChild(eBeliefSpace);
        for(itBeliefSpace = colPoints.iterator(); itBeliefSpace.hasNext(); eBeliefSpace.appendChild(eBeliefState))
        {
            bsCurrent = itBeliefSpace.next();
            eBeliefState = bsCurrent.getDom(docBeliefSpace);
        }

        TransformerFactory tFactory = TransformerFactory.newInstance();
        Transformer transformer = tFactory.newTransformer();
        DOMSource source = new DOMSource(docBeliefSpace);
        StreamResult result = new StreamResult(new FileOutputStream(sFileName));
        transformer.transform(source, result);
    }

    public static Vector<BeliefState> loadBeliefSpace(String sFileName)
        throws IOException, ParserConfigurationException, SAXException
    {
        getInstance().clear();
        return getInstance().load(sFileName);
    }

    protected Vector<BeliefState> load(String sFileName)
        throws IOException, ParserConfigurationException, SAXException
    {
        System.out.println((new StringBuilder("Loading Belief space from ")).append(sFileName).toString());
        Runtime rtRuntime = Runtime.getRuntime();
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document docBeliefSpace = builder.parse(new FileInputStream(sFileName));
        Element eBeliefSpace = null;
        Element eBeliefState = null;
        Element eChild = null;
        int iBeliefStateId = 0;
        NodeList nlBeliefStates = null;
        NodeList nlChildren = null;
        int cBeliefStates = 0;
        int iBeliefState = 0;
        int iChild = 0;
        BeliefState bsCurrent = null;
        Vector<BeliefState> vBeliefPoints = new Vector<BeliefState>();
        TIntObjectHashMap<BeliefState> mId2BeliefState = new TIntObjectHashMap<BeliefState>();
        eBeliefSpace = (Element)docBeliefSpace.getChildNodes().item(0);
        cBeliefStates = Integer.parseInt(eBeliefSpace.getAttribute("size"));
        m_cBeliefPoints = cBeliefStates;
        nlBeliefStates = eBeliefSpace.getChildNodes();
        for(iBeliefState = 0; iBeliefState < cBeliefStates; iBeliefState++)
        {
            eBeliefState = (Element)nlBeliefStates.item(iBeliefState);
            iBeliefStateId = Integer.parseInt(eBeliefState.getAttribute("Id"));
            if(iBeliefStateId >= m_cBeliefPoints)
                m_cBeliefPoints = iBeliefStateId + 1;
            bsCurrent = newBeliefState(iBeliefStateId);
            nlChildren = eBeliefState.getChildNodes();
            for(iChild = 0; iChild < nlChildren.getLength(); iChild++)
            {
                eChild = (Element)nlChildren.item(iChild);
                if(eChild.getNodeName().equals("BeliefValues"))
                    bsCurrent.loadBeliefValues(eChild);
            }

            vBeliefPoints.add(bsCurrent);
            mId2BeliefState.put(iBeliefStateId, bsCurrent);
            cacheBeliefState(bsCurrent);
            if(cBeliefStates > 100 && iBeliefState > 0 && iBeliefState % (cBeliefStates / 10) == 0)
                System.out.println((new StringBuilder("Loaded ")).append(iBeliefState).append(" belief states").append(" max memory ").append(rtRuntime.maxMemory() / 0xf4240L).append(" actual memory ").append((rtRuntime.totalMemory() - rtRuntime.freeMemory()) / 0xf4240L).append(" free memory ").append(rtRuntime.freeMemory() / 0xf4240L).toString());
        }

        for(iBeliefState = 0; iBeliefState < cBeliefStates; iBeliefState++)
        {
            eBeliefState = (Element)nlBeliefStates.item(iBeliefState);
            iBeliefStateId = Integer.parseInt(eBeliefState.getAttribute("Id"));
            bsCurrent = mId2BeliefState.get(iBeliefStateId);
            nlChildren = eBeliefState.getChildNodes();
            for(iChild = 0; iChild < nlChildren.getLength(); iChild++)
            {
                eChild = (Element)nlChildren.item(iChild);
                if(eChild.getNodeName().equals("Predecessors"))
                    bsCurrent.loadPredecessors(eChild, mId2BeliefState);
                if(eChild.getNodeName().equals("Successors"))
                    bsCurrent.loadSuccessors(eChild, mId2BeliefState);
            }

            mId2BeliefState.put(iBeliefStateId, bsCurrent);
        }

        System.out.println((new StringBuilder("Done loading belief space max memory ")).append(rtRuntime.maxMemory() / 0xf4240L).append(" actual memory ").append((rtRuntime.totalMemory() - rtRuntime.freeMemory()) / 0xf4240L).append(" free memory ").append(rtRuntime.freeMemory() / 0xf4240L).toString());
        return vBeliefPoints;
    }

    public Iterator<BeliefState> getAllBeliefStates()
    {
        return m_hmCachedBeliefStates.keySet().iterator();
    }

    public static void countBeliefUpdates(boolean bCount)
    {
        BeliefState.countBeliefUpdates(bCount);
        getInstance();
        m_bCountBeliefUpdates = bCount;
    }

    public static void clearBeliefUpdateCount()
    {
        BeliefState.clearBeliefStatsUpdate();
        getInstance().m_cBeliefUpdates = 0;
    }

    public static void clearInternalBeliefStateCache()
    {
        Iterator<BeliefState> itBeliefPoints = getInstance().m_hmCachedBeliefStates.keySet().iterator();
        BeliefState bs = null;
        for(; itBeliefPoints.hasNext(); bs.clearInternalCache())
            bs = itBeliefPoints.next();

    }

    public void computeNeighbors(double dMaxDistance, DistanceMetric dmDistance)
    {
        Vector<BeliefState> vBeliefStates = new Vector<BeliefState>(m_hmCachedBeliefStates.keySet());
        computeNeighbors(vBeliefStates, dMaxDistance, dmDistance);
    }

    public static void computeNeighbors(Vector<BeliefState> vBeliefStates, double dMaxDistance, DistanceMetric dmDistance)
    {
        int cElements = vBeliefStates.size();
        int iElement1 = 0;
        int iElement2 = 0;
        BeliefState bs1 = null;
        BeliefState bs2 = null;
        int cNeighbors = 0;
        double dDistance = 0.0D;
        System.out.println("Started computing belief state neighbors");
        for(iElement1 = 0; iElement1 < cElements; iElement1++)
        {
            bs1 = vBeliefStates.elementAt(iElement1);
            for(iElement2 = iElement1 + 1; iElement2 < cElements; iElement2++)
            {
                bs2 = vBeliefStates.elementAt(iElement2);
                dDistance = dmDistance.distance(bs1, bs2);
                if(dDistance < dMaxDistance)
                {
                    bs1.addNeighbor(bs2);
                    bs2.addNeighbor(bs1);
                }
            }

            if(iElement1 % (cElements / 10) == 0)
                System.out.println((new StringBuilder("Done ")).append(iElement1).append(" belief states").toString());
        }

        for(iElement1 = 0; iElement1 < cElements; iElement1++)
        {
            bs1 = vBeliefStates.elementAt(iElement1);
            cNeighbors += bs1.getNeighborsCount();
        }

        System.out.println((new StringBuilder("Done computing belief state neighbors. avg ")).append(cNeighbors / cElements).toString());
    }

    public BeliefState getUniformBeliefState()
    {
        if(m_bsUniformState == null)
        {
            int iState = 0;
            int cStates = m_pPOMDP.getStateCount();
            double dUnifomValue = 1.0D / cStates;
            m_bsUniformState = newBeliefState();
            for(iState = 0; iState < cStates; iState++)
                m_bsUniformState.setValueAt(iState, dUnifomValue);

            BeliefState bsExisting = m_hmCachedBeliefStates.get(m_bsUniformState);
            if(bsExisting == null)
            {
                cacheBeliefState(m_bsUniformState);
                m_cBeliefPoints++;
            } else
            {
                m_bsUniformState = bsExisting;
            }
        }
        return m_bsUniformState;
    }

    public double distance(Vector<BeliefState> vBeliefStates, BeliefState bs)
    {
        Iterator<BeliefState> it = vBeliefStates.iterator();
        double dDist = 0.0D;
        double dMinDist = 10000D;
        BeliefState bsCurrent = null;
        DistanceMetric dmDistance = L1Distance.getInstance();
        while(it.hasNext()) 
        {
            bsCurrent = it.next();
            dDist = dmDistance.distance(bs, bsCurrent);
            if(dDist < dMinDist)
                dMinDist = dDist;
        }
        return dMinDist;
    }

    public BeliefState computeFarthestSuccessor(Vector<BeliefState> vBeliefPoints, BeliefState bs)
    {
        int cActions = m_pPOMDP.getActionCount();
        int cObservations = m_pPOMDP.getObservationCount();
        int iAction = 0;
        int iObservation = 0;
        BeliefState bsMaxDist = null;
        BeliefState bsNext = null;
        double dMaxDist = 0.0D;
        double dDist = 0.0D;
        for(iAction = 0; iAction < cActions; iAction++)
            for(iObservation = 0; iObservation < cObservations; iObservation++)
            {
                bsNext = bs.nextBeliefState(iAction, iObservation);
                if(bsNext != null)
                {
                    dDist = distance(vBeliefPoints, bsNext);
                    if(dDist > dMaxDist)
                    {
                        dMaxDist = dDist;
                        bsMaxDist = bsNext;
                    }
                }
            }


        if(dMaxDist == 0.0D)
            return null;
        else
            return bsMaxDist;
    }

    public BeliefState computeFarthestSuccessor(Vector<BeliefState> vBeliefPoints)
    {
        BeliefState bsMaxDist = null;
        BeliefState bsNext = null;
        double dMaxDist = 0.0D;
        double dDist = 0.0D;
        BeliefState bsCurrent = null;
        for(Iterator<BeliefState> it = vBeliefPoints.iterator(); it.hasNext();)
        {
            bsCurrent = it.next();
            bsNext = computeFarthestSuccessor(vBeliefPoints, bsCurrent);
            if(bsNext != null)
            {
                dDist = distance(vBeliefPoints, bsNext);
                if(dDist > dMaxDist)
                {
                    dMaxDist = dDist;
                    bsMaxDist = bsNext;
                }
            }
        }

        if(dMaxDist == 0.0D)
            return null;
        else
            return bsMaxDist;
    }

    protected BeliefState newBeliefState()
    {
        return newBeliefState(m_cBeliefPoints);
    }

    protected BeliefState newBeliefState(int id)
    {
        if(!m_bCacheBelifStates)
            id = -1;
        BeliefState bs = new BeliefState(m_pPOMDP.getStateCount(), m_pPOMDP.getActionCount(), m_pPOMDP.getObservationCount(), id, m_bSparseBeliefStates, m_bCacheBelifStates);
        return bs;
    }

    public BeliefState getBeliefState(double adEntries[])
    {
        BeliefState bs = newBeliefState();
        int iState = 0;
        int cStates = m_pPOMDP.getStateCount();
        double dSum = 0.0D;
        for(iState = 0; iState < cStates; iState++)
        {
            bs.setValueAt(iState, adEntries[iState]);
            dSum += adEntries[iState];
        }

        if(dSum < 0.98999999999999999D || dSum > 1.01D)
        {
            System.out.println((new StringBuilder("getBeliefState: BUGBUG for bs ")).append(bs).append(" sum is ").append(dSum).toString());
            return null;
        }
        if(m_bCacheBelifStates)
        {
            BeliefState bsExisting = m_hmCachedBeliefStates.get(bs);
            if(bsExisting == null)
            {
                cacheBeliefState(bs);
                m_cBeliefPoints++;
            } else
            {
                bs = bsExisting;
            }
        }
        return bs;
    }

    public static long getTauComputationCount()
    {
        return getInstance().m_cBeliefUpdates;
    }

    public static double getAvgTauTime()
    {
        return (getInstance().m_cTimeInTau * 1.0D) / getInstance().m_cBeliefUpdates;
    }

    public static double getAvgBeliefStateSize()
    {
        return (getInstance().m_cBeliefStateSize * 1.0D) / getInstance().m_cBeliefUpdates;
    }

    public int countEntries()
    {
        int cEntries = 0;
        for(Iterator<BeliefState> iterator = m_hmCachedBeliefStates.keySet().iterator(); iterator.hasNext();)
        {
            BeliefState bs = iterator.next();
            cEntries += bs.countEntries();
        }

        return cEntries;
    }

    protected POMDP m_pPOMDP;
    public int m_cBeliefUpdates;
    protected static BeliefStateFactory s_bsFactory;
    protected Map<BeliefState,BeliefState> m_hmCachedBeliefStates;
    protected int m_cDiscretizationLevels;
    protected int m_cBeliefPoints;
    protected boolean m_bCacheBelifStates;
    protected boolean m_bSparseBeliefStates;
    protected BeliefState m_bsInitialState;
    public static double m_dEpsilon = 1.0000000000000001E-09D;
    protected static boolean m_bCountBeliefUpdates;
    protected BeliefState m_bsUniformState;
    protected BeliefState m_abDeterministic[];
    protected boolean m_bCacheDeterministicBeliefStates;
    public int m_cTimeInTau;
    public long m_cBeliefStateSize;
    private static long g_cNext = 0L;
    private static long g_cTime = 0L;

    /**
     * Clears all static values 
     */
    public static void clearStatic()
    {
      if (s_bsFactory != null)
      {
        for (BeliefState bs : s_bsFactory.m_hmCachedBeliefStates.values())
          bs.releaseMemory();
        s_bsFactory.m_hmCachedBeliefStates.clear();
        s_bsFactory = null;
      }
      g_cNext = 0L;
      g_cTime = 0L;
    }
}
