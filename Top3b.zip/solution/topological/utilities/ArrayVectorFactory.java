// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ArrayVectorFactory.java

package solution.topological.utilities;

import solution.topological.utilities.datastructures.VectorFactory;

// Referenced classes of package pomdp.utilities:
//            ArrayVector

public class ArrayVectorFactory<VType> extends VectorFactory<ArrayVector<VType>>
{

    public ArrayVectorFactory()
    {
    	super();
        ITERATION_SIZE = 10000;
    }

    @Override
    public ArrayVector<VType> newInstance(int iSize, boolean bSmall)
    {
        return new ArrayVector<VType>(iSize, this, bSmall);
    }
}
