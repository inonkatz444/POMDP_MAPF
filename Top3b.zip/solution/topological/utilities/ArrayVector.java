// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ArrayVector.java

package solution.topological.utilities;

import solution.topological.utilities.datastructures.LongVector;
import solution.topological.utilities.datastructures.VectorBase;
import solution.topological.utilities.datastructures.VectorFactory;

// Referenced classes of package pomdp.utilities:
//            Logger

public class ArrayVector<VType> extends VectorBase
{

    public ArrayVector(long iSize, VectorFactory<ArrayVector<VType>> vFactory, boolean bSmall)
    {
        super(iSize, vFactory, bSmall);
        setSize(iSize);
    }

    public void add(VType aElement)
    {
        if(m_cElements == m_iSize)
            expand();
        int iFirstIndex = getFirstIndex(m_cElements);
        int iSecondIndex = getSecondIndex(m_cElements);
        m_aData[iFirstIndex][iSecondIndex] = aElement;
        m_cElements++;
    }

    public void setSize(long iSize)
    {
        int cRows = (int)(iSize / MAX_ARRAY_SIZE);
        int iLastRow = (int)(iSize % MAX_ARRAY_SIZE);
        int iRow = 0;
        m_aData = (VType[][])new Object[cRows + 1][];
        for(iRow = 0; iRow < cRows; iRow++)
            m_aData[iRow] = (VType[])new Object[MAX_ARRAY_SIZE];

        m_aData[cRows] = (VType[])new Object[iLastRow];
        m_iSize = iSize;
        m_cElements = 0L;
    }

    @Override
    public void clear()
    {
        int iElement = 0;
        for(iElement = 0; iElement < m_cElements; iElement++)
            if(elementAt(iElement) instanceof LongVector)
            {
                LongVector lv = (LongVector)elementAt(iElement);
                lv.release();
                set(iElement, null);
            }

        m_cElements = 0L;
    }

    public void set(long iIndex, VType vElement)
    {
        m_aData[getFirstIndex(iIndex)][getSecondIndex(iIndex)] = vElement;
    }

    public void removeElement(VType vElement)
    {
        long iIndex = indexOf(vElement);
        set(iIndex, elementAt(m_cElements - 1L));
        m_cElements--;
    }

    public VType elementAt(long iIndex)
    {
        if(iIndex < 0L || iIndex >= m_cElements)
            return null;
        else
            return m_aData[getFirstIndex(iIndex)][getSecondIndex(iIndex)];
    }

    private void expand()
    {
        if(m_iSize < MAX_ARRAY_SIZE)
        {
            int iNewSize = 0;
            int i = 0;
            if(m_iSize * 2L > MAX_ARRAY_SIZE)
                iNewSize = MAX_ARRAY_SIZE;
            else
                iNewSize = (int)m_iSize * 2;
            VType aData[] = (VType[])new Object[iNewSize];
            for(i = 0; i < m_cElements; i++)
                aData[i] = m_aData[0][i];

            m_iSize = iNewSize;
            m_aData[0] = aData;
        } else
        {
            int iOldSize = m_aData.length;
            int iNewSize = iOldSize + 1;
            int i = 0;
            VType aData[][] = (VType[][])new Object[iNewSize][];
            for(i = 0; i < iOldSize; i++)
                aData[i] = m_aData[i];

            for(i = iOldSize; i < iNewSize; i++)
                aData[i] = (VType[])new Object[MAX_ARRAY_SIZE];

            m_iSize = iNewSize * MAX_ARRAY_SIZE;
            m_aData = aData;
        }
    }

    public void reduce()
    { //
    }

    public long indexOf(VType vElement)
    {
        int i = 0;
        int j = 0;
        int cRows = (int)(m_cElements / MAX_ARRAY_SIZE);
        int cCols = (int)(m_cElements % MAX_ARRAY_SIZE);
        for(j = 0; j < cRows; j++)
            for(i = 0; i < MAX_ARRAY_SIZE; i++)
                if(vElement.equals(m_aData[j][i]))
                    return (long)j * (long)MAX_ARRAY_SIZE + i;


        for(i = 0; i < cCols; i++)
            if(vElement.equals(m_aData[cRows][i]))
                return (long)cRows * (long)MAX_ARRAY_SIZE + i;

        return -1L;
    }

    public boolean contains(VType vElement)
    {
        return indexOf(vElement) != -1L;
    }

    public void addAll(ArrayVector<VType> v)
    {
        long iIndex = 0L;
        for(iIndex = 0L; iIndex < v.m_cElements; iIndex++)
            add(v.elementAt(iIndex));

    }

    public void validateSize(long cVertexes)
    {
        if(m_iSize > cVertexes)
            Logger.getInstance().log("AV", 0, "validateSize", (new StringBuilder("Expected ")).append(cVertexes).append(" real size ").append(m_iSize).append(", elements ").append(m_cElements).toString());
    }

    private VType m_aData[][];
}
