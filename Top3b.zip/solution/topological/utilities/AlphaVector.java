// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   AlphaVector.java

package solution.topological.utilities;

import gnu.trove.*;

import java.text.MessageFormat;

import org.w3c.dom.*;

import solution.topological.environments.POMDP;

// Referenced classes of package pomdp.utilities:
//            ExecutionProperties, JProf, BeliefState, Logger, 
//            Pair, TabularAlphaVector, LinearValueFunctionApproximation

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 10 juil. 2009
 *
 */
public abstract class AlphaVector
{

    public AlphaVector(BeliefState bsWitness, int iAction, POMDP pomdp)
    {
        m_bMaintainWitness = false;
        m_pPOMDP = pomdp;
        m_bsWitness = bsWitness;
        m_cStates = m_pPOMDP.getStateCount();
        m_cActions = m_pPOMDP.getActionCount();
        m_cObservations = m_pPOMDP.getObservationCount();
        m_iAction = iAction;
        m_aCachedG = new AlphaVector[m_cActions][m_cObservations];
        m_iAge = 0;
        m_iID = s_cAlphaVectors++;
        m_dOffset = 0.0D;
        m_iValueFunctionInsertionTime = 0;
        m_cReferenceCounter = 0;
        m_vfContainer = null;
        m_dMaxValue = 0.0D;
        m_dAvgValue = 0.0D;
        m_aiSumIds = new long[2];
        setSumIds(-1L, -1L);
        m_aCachedSuccessorLinks = new long[m_cObservations];
        for(int iObservation = 0; iObservation < m_cObservations; iObservation++)
            m_aCachedSuccessorLinks[iObservation] = -1L;

    }

    public abstract double valueAt(int i);

    public abstract void setValue(int i, double d);

    public void decay(double dDelta)
    {
        m_dOffset += dDelta;
    }

    public int getAction()
    {
        return m_iAction;
    }

    public void setAction(int iAction)
    {
        m_iAction = iAction;
    }

    public double dotProduct(BeliefState bs)
    {
        int iState = 0;
        double dValue = 0.0D;
        double dProb = 0.0D;
        double dSum = 0.0D;
        if(bs == null)
            return 0.0D;
        long lTimeBefore = 0L;
        long lTimeAfter = 0L;
        if(ExecutionProperties.getReportOperationTime())
            lTimeBefore = JProf.getCurrentThreadCpuTimeSafe();
        TIntDoubleIterator it = bs.getNonZeroEntries();
        if(it != null)
            while(it.hasNext()) 
            {
              it.advance();
                iState = it.key();
                dProb = it.value();
                dValue = valueAt(iState);
                dSum += dValue * dProb;
            }
        else
            for(iState = 0; iState < m_cStates; iState++)
            {
                dProb = bs.valueAt(iState);
                dValue = valueAt(iState);
                dSum += dValue * dProb;
            }

        if(s_bCountDotProduct)
        {
            s_cDotProducts++;
            s_cCurrentDotProducts++;
            if(ExecutionProperties.getReportOperationTime())
            {
                lTimeAfter = JProf.getCurrentThreadCpuTimeSafe();
                s_cCurrentTimeInDotProduct += (lTimeAfter - lTimeBefore) / 1000L;
                s_cTotalTimeInDotProduct += (lTimeAfter - lTimeBefore) / 1000L;
                if(s_cCurrentDotProducts == TIME_INTERVAL * 100L)
                {
                    String sMsg = (new StringBuilder("After ")).append(s_cDotProducts).append(" dot product - avg time = ").append(s_cCurrentTimeInDotProduct / (TIME_INTERVAL * 100L)).toString();
                    s_cCurrentTimeInDotProduct = 0L;
                    s_cCurrentDotProducts = 0L;
                    Logger.getInstance().log("AlphaVector", 0, "dotProduct", sMsg);
                }
            }
        }
        return dSum;
    }

    public double approximateDotProduct(BeliefState bs)
    {
        int iState = 0;
        double dValue = 0.0D;
        double dProb = 0.0D;
        double dSum = 0.0D;
        if(bs == null)
            return 0.0D;
        if(s_bCountDotProduct)
            s_cApproximateDotProduct++;
        TIntDoubleIterator it = bs.getDominatingNonZeroEntries();
        while(it.hasNext()) 
        {
          it.advance();
            iState = it.key();
            dProb = it.value();
            dValue = valueAt(iState);
            dSum += dValue * dProb;
        }
        return dSum;
    }

    public BeliefState getWitness()
    {
        return m_bsWitness;
    }

    public void setWitness(BeliefState bsWitness)
    {
        if(m_bMaintainWitness)
            m_bsWitness = bsWitness;
    }

    public void setSuccessorLinks(AlphaVector aNext[])
    {
        for(int o = 0; o < aNext.length; o++)
            m_aCachedSuccessorLinks[o] = aNext[o].getId();

    }

    public void translate(double dOffset)
    {
        double dValue = 0.0D;
        int iState;
        for (iState = 0; iState<m_pPOMDP.getStateCount(); iState++)
        {
            dValue = valueAt(iState);
            setValue(iState, dValue + dOffset);
        }

    }

    public void scale(double dScale)
    {
        double dValue = 0.0D;
        for (int iState = 0; iState<m_pPOMDP.getStateCount(); iState++)
        {
            dValue = valueAt(iState);
            setValue(iState, dValue * dScale);
        }

    }

    public boolean dominates(AlphaVector avOther)
    {
        double dValue = 0.0D;
        double dOtherValue = 0.0D;
        if(getMaxValue() < avOther.getMaxValue())
            return false;
        if(getAvgValue() < avOther.getAvgValue())
            return false;
        for (int iState = 0; iState<m_pPOMDP.getStateCount(); iState++)
        {
            dValue = valueAt(iState);
            dOtherValue = avOther.valueAt(iState);
            if(dOtherValue > dValue)
                return false;
        }

        return true;
    }

    /**
     * Computes the transform of this alpha-vector by the specified action and observation
     * @param iAction the action 
     * @param iObservation the observation
     * @return the vector of expected values for using the specified action/observation in each state, using this as the optimal value for the successors
     */
    protected AlphaVector computeG(int iAction, int iObservation)
    {
      TIntDoubleIterator it;
        int iStartState = 0;
        int iEndState = 0;
        double dObservation = 0.0D;
        double dTr = 0.0D;
        double dValue = 0.0D;
        double dSum = 0.0D;
        AlphaVector avResult = newAlphaVector();
        avResult.setAction(iAction);
        
        for(iStartState = 0; iStartState < m_cStates; iStartState++)
        {
          it = m_pPOMDP.getNonZeroTransitions(iStartState, iAction);
          dSum = 0D;
          while (it.hasNext())
          {
            it.advance();
            iEndState = it.key();
            dObservation = m_pPOMDP.O(iAction, iEndState, iObservation);
            if (dObservation==0.0D)
              continue;
            dTr = it.value();
            dValue = valueAt(iEndState);
            dSum += dObservation * dTr * dValue;
          }
          if(dSum != 0.0D)
          {
              avResult.setValue(iStartState, dSum);
          }
        } // for iStartState

        avResult.finalizeValues();
        return avResult;
    }

    protected AlphaVector computeG(int iAction, int iObservation, TIntHashSet iStates)
    {
        int iStartState = 0;
        int iEndState = 0;
        int cNonZeroEntries = 0;
        double dObservation = 0.0D;
        double dTr = 0.0D;
        double dValue = 0.0D;
        double dSum = 0.0D;
        AlphaVector avResult = newAlphaVector();
        avResult.setAction(iAction);
        TIntDoubleIterator itNonZeroEntries = null;
        g_cGs++;
        for(TIntIterator iState = iStates.iterator(); iState.hasNext();)
        {
            iStartState = iState.next();
            dSum = 0.0D;
            for(itNonZeroEntries = getNonZeroEntries(); itNonZeroEntries.hasNext();)
            {
              itNonZeroEntries.advance();
                iEndState = itNonZeroEntries.key();
                dValue = itNonZeroEntries.value();
                dTr = m_pPOMDP.tr(iStartState, iAction, iEndState);
                g_cTouchedVertexes++;
                if(dTr > 0.0D)
                {
                    dObservation = m_pPOMDP.O(iAction, iEndState, iObservation);
                    dSum += dObservation * dTr * dValue;
                }
            }

            if(dSum != 0.0D)
            {
                avResult.setValue(iStartState, dSum);
                cNonZeroEntries++;
            }
        }

        avResult.finalizeValues();
        return avResult;
    }

    /**
     * Computes the transform of this alpha-vector by the specified action and observation
     * @param iAction the action 
     * @param iObservation the observation
     * @return the vector of expected values for using the specified action/observation in each state, using this as the optimal value for the successors
     */
    public AlphaVector G(int iAction, int iObservation)
    {
        if(s_bAllowCaching && m_aCachedG[iAction][iObservation] != null)
            return m_aCachedG[iAction][iObservation];
        long lTimeBefore = 0L;
        long lTimeAfter = 0L;
        if(ExecutionProperties.getReportOperationTime())
            lTimeBefore = JProf.getCurrentThreadCpuTimeSafe();
        AlphaVector avResult = computeG(iAction, iObservation);
        if(s_bAllowCaching)
            m_aCachedG[iAction][iObservation] = avResult;
        s_cGComputations++;
        if(ExecutionProperties.getReportOperationTime())
        {
            lTimeAfter = JProf.getCurrentThreadCpuTimeSafe();
            s_cCurrentTimeInG += (lTimeAfter - lTimeBefore) / 0xf4240L;
            s_cTotalTimeInG += (lTimeAfter - lTimeBefore) / 0xf4240L;
            if(s_cGComputations % TIME_INTERVAL == 0L)
            {
                Logger.getInstance().log("AlphaVector", 0, "G", (new StringBuilder("avg time for computing G ")).append(s_cCurrentTimeInG / TIME_INTERVAL).toString());
                s_cCurrentTimeInG = 0L;
            }
        }
        return avResult;
    }

    public AlphaVector G(int iAction, int iObservation, TIntHashSet iStates)
    {
        if(s_bAllowCaching && m_aCachedG[iAction][iObservation] != null)
            return m_aCachedG[iAction][iObservation];
        long lTimeBefore = 0L;
        long lTimeAfter = 0L;
        if(ExecutionProperties.getReportOperationTime())
            lTimeBefore = JProf.getCurrentThreadCpuTimeSafe();
        AlphaVector avResult = computeG(iAction, iObservation, iStates);
        if(s_bAllowCaching)
            m_aCachedG[iAction][iObservation] = avResult;
        s_cGComputations++;
        if(ExecutionProperties.getReportOperationTime())
        {
            lTimeAfter = JProf.getCurrentThreadCpuTimeSafe();
            s_cCurrentTimeInG += (lTimeAfter - lTimeBefore) / 0xf4240L;
            s_cTotalTimeInG += (lTimeAfter - lTimeBefore) / 0xf4240L;
            if(s_cGComputations % TIME_INTERVAL == 0L)
            {
                Logger.getInstance().log("AlphaVector", 0, "G", (new StringBuilder("avg time for computing G ")).append(s_cCurrentTimeInG / TIME_INTERVAL).toString());
                s_cCurrentTimeInG = 0L;
            }
        }
        return avResult;
    }

    public TIntHashSet getNonZeroStates()
    {
        int iEndState = 0;
        TIntHashSet iStates = new TIntHashSet(); 
        for(TIntDoubleIterator itNonZeroEntries = getNonZeroEntries(); itNonZeroEntries.hasNext(); iStates.add(iEndState))
        {
          itNonZeroEntries.advance();
            iEndState = itNonZeroEntries.key();
        }

        return iStates;
    }

    public boolean disjoint(AlphaVector av)
    {
        if(av.getAction() != getAction())
            return false;
        TIntHashSet avStates = av.getNonZeroStates();
        TIntHashSet ourStates = getNonZeroStates();
        int initialCount = avStates.size();
        avStates.removeAll(ourStates.toArray());
        return initialCount == avStates.size();
    }

    public abstract void accumulate(AlphaVector alphavector);

    public abstract void accumulate(AlphaVector alphavector, TIntHashSet hashset);

    public AlphaVector copy()
    {
        AlphaVector avCopy = newAlphaVector();
        double dValue = 0.0D;
        TIntDoubleIterator itNonZero = getNonZeroEntries();
        if(itNonZero != null)
        {
          while (itNonZero.hasNext())
          {
            itNonZero.advance();
            avCopy.setValue(itNonZero.key(), itNonZero.value());
          }
        } else
        {
            int iValidState;
            for (iValidState=0; iValidState<m_pPOMDP.getStateCount(); iValidState++)
            {
                dValue = valueAt(iValidState);
                avCopy.setValue(iValidState, dValue);
            }

        }
        return avCopy;
    }

    public void addValue(int iState, double dDeltaValue)
    {
        setValue(iState, valueAt(iState) + dDeltaValue);
    }

    public double sumValues()
    {
        double dSum = 0.0D;
        for (int iState = 0; iState<m_pPOMDP.getStateCount(); iState++)
            dSum += valueAt(iState);

        return dSum;
    }

    public void age()
    {
        m_iAge++;
    }

    public int getAge()
    {
        return m_iAge;
    }

    public static void countDotProduct(boolean bCount)
    {
        s_bCountDotProduct = bCount;
    }

    public static long dotProductCount()
    {
        return s_cDotProducts;
    }

    public static long dotApproximateProductCount()
    {
        return s_cApproximateDotProduct;
    }

    public static void clearDotProductCount()
    {
        s_cDotProducts = 0L;
        s_cApproximateDotProduct = 0L;
    }

    public static boolean allowCaching()
    {
        return s_bAllowCaching;
    }

    public static void setAllowCaching(boolean bAllowCaching)
    {
        s_bAllowCaching = bAllowCaching;
    }

    public abstract TIntDoubleIterator getNonZeroEntries();

    public abstract void finalizeValues();

    @Override
    public String toString()
    {
        String sVector = (new StringBuilder("AV")).append(m_iID).append("(a=").append(m_iAction).append("[").toString();
        String sValue = "";
        int iEndState = 0;
        double dValue = -1D;
        double dNextValue = -1D;
        int cEntries = 0;
        for(int iState = 0; iState < m_cStates; iState++)
        {
            dValue = valueAt(iState);
            if(dValue != 0.0D)
            {
                cEntries++;
                iEndState = iState + 1;
                if(iState < m_cStates - 1)
                    for(dNextValue = valueAt(iEndState); iEndState < m_cStates - 1 && dValue == dNextValue; dNextValue = valueAt(iEndState))
                        iEndState++;

                sValue = MessageFormat.format("{0,number,0.####}", dValue);
                if(iEndState == iState + 1)
                {
                    sVector = (new StringBuilder(String.valueOf(sVector))).append(iState).append("=").append(sValue).append(",").toString();
                } else
                {
                    sVector = (new StringBuilder(String.valueOf(sVector))).append("(").append(iState).append("-").append(iEndState - 1).append(")=").append(sValue).append(",").toString();
                    iState = iEndState - 1;
                }
            }
        }

        if(cEntries > 0)
            sVector = (new StringBuilder(String.valueOf(sVector.substring(0, sVector.length() - 1)))).append("]").toString();
        else
            sVector = (new StringBuilder(String.valueOf(sVector))).append("]").toString();
        sVector = (new StringBuilder(String.valueOf(sVector))).append(" W=").append(m_bsWitness).append(")").toString();
        return sVector;
    }

    public long getId()
    {
        return m_iID;
    }

    public int getInsertionTime()
    {
        return m_iValueFunctionInsertionTime;
    }

    public void setInsertionTime(int iTime)
    {
        m_iValueFunctionInsertionTime = iTime;
    }

    public void setContainer(LinearValueFunctionApproximation vfContainer)
    {
        m_vfContainer = vfContainer;
    }

    public AlphaVector productTrA(int iAction)
    {
        AlphaVector avResult = newAlphaVector();
        int iState = 0;
        int iStartState = 0;
        double dValue = 0.0D;
        double dTr = 0.0D;
        double dPreviousValue = 0.0D;
        double dNewValue = 0.0D;
        TIntDoubleIterator itAlphaVectorNonZero = getNonZeroEntries();
        while(itAlphaVectorNonZero.hasNext()) 
        {
          itAlphaVectorNonZero.advance();
            iStartState = itAlphaVectorNonZero.key();
            dValue = itAlphaVectorNonZero.value();
            for(iStartState = 0; iStartState < m_cStates; iStartState++)
            {
                dTr = m_pPOMDP.tr(iStartState, iAction, iState);
                dPreviousValue = avResult.valueAt(iStartState);
                dNewValue = dPreviousValue + dTr * dValue;
                avResult.setValue(iStartState, dNewValue);
            }
        }
        return avResult;
    }

    public abstract AlphaVector newAlphaVector();

    public double getMaxValue()
    {
        return m_dMaxValue;
    }

    public double getAvgValue()
    {
        return m_dAvgValue;
    }

    public static AlphaVector load(Element eVector, POMDP pomdp)
        throws Exception
    {
        AlphaVector avNew = new TabularAlphaVector(null, 0.0D, pomdp);
        Element eState = null;
        NodeList nlStates = eVector.getChildNodes();
        int cEntries = nlStates.getLength();
        int iEntry = 0;
        int iState = 0;
        double dValue = 0.0D;
        avNew.setAction(Integer.parseInt(eVector.getAttribute("Action")));
        for(iEntry = 0; iEntry < cEntries; iEntry++)
        {
            eState = (Element)nlStates.item(iEntry);
            iState = Integer.parseInt(eState.getAttribute("Id"));
            dValue = Double.parseDouble(eState.getAttribute("Value"));
            avNew.setValue(iState, dValue);
        }

        return avNew;
    }

    public Element getDOM(Document docValueFunction)
        throws Exception
    {
        Element eVector = docValueFunction.createElement("AlphaVector");
        Element eState = null;
        TIntDoubleIterator itAlphaVectorNonZero = getNonZeroEntries();
        int iState = 0;
        double dValue = 0.0D;
        eVector.setAttribute("Id", (new StringBuilder(String.valueOf(m_iID))).toString());
        eVector.setAttribute("EntriesCount", (new StringBuilder(String.valueOf(getNonZeroEntriesCount()))).toString());
        eVector.setAttribute("Action", (new StringBuilder(String.valueOf(m_iAction))).toString());
        for(; itAlphaVectorNonZero.hasNext(); eVector.appendChild(eState))
        {
          itAlphaVectorNonZero.advance();
          iState = itAlphaVectorNonZero.key();
          dValue = itAlphaVectorNonZero.value();
            eState = docValueFunction.createElement("State");
            eState.setAttribute("Id", (new StringBuilder(String.valueOf(iState))).toString());
            eState.setAttribute("Value", (new StringBuilder(String.valueOf(dValue))).toString());
        }

        return eVector;
    }

    public boolean equals(AlphaVector avOther)
    {
        double dValue = 0.0D;
        double dOtherValue = 0.0D;
        for (int iState = 0; iState<m_pPOMDP.getStateCount(); iState++)
        {
            dValue = valueAt(iState);
            dOtherValue = avOther.valueAt(iState);
            if(diff(dValue, dOtherValue) > 0.001D)
                return false;
        }

        return true;
    }

    private double diff(double dValue, double dOtherValue)
    {
        if(dValue > dOtherValue)
            return dValue - dOtherValue;
        else
            return dOtherValue - dValue;
    }

    @Override
    public boolean equals(Object oOther)
    {
        if(oOther instanceof AlphaVector)
        {
            AlphaVector avOther = (AlphaVector)oOther;
            return equals(avOther);
        } else
        {
            return false;
        }
    }

    public abstract int getNonZeroEntriesCount();

    public void setSumIds(long id1, long id2)
    {
        m_aiSumIds[0] = id1;
        m_aiSumIds[1] = id2;
    }

    public long[] getSumIds()
    {
        return m_aiSumIds;
    }

    public static long getGComputationsCount()
    {
        return s_cGComputations;
    }

    public static double getAvgGTime()
    {
        return (s_cTotalTimeInG * 1.0D) / s_cGComputations;
    }

    public static double getAvgDotProductTime()
    {
        return (s_cTotalTimeInDotProduct * 1.0D) / s_cDotProducts;
    }

    public AlphaVector addReward(int iAction)
    {
        AlphaVector avResult = newAlphaVector();
        double dValue = 0.0D;
        int iState;
        for (iState=0; iState<m_pPOMDP.getStateCount();iState++)
        {
            dValue = valueAt(iState) * m_pPOMDP.getDiscountFactor() + m_pPOMDP.R(iState, iAction);
            avResult.setValue(iState, dValue);
        }

        avResult.finalizeValues();
        return avResult;
    }

    public AlphaVector addReward(int iAction, TIntHashSet iStates)
    {
        AlphaVector avResult = newAlphaVector();
        double dValue = 0.0D;
        int iState;
        for(TIntIterator iterator = iStates.iterator(); iterator.hasNext(); avResult.setValue(iState, dValue))
        {
            iState = iterator.next();
            dValue = valueAt(iState) * m_pPOMDP.getDiscountFactor() + m_pPOMDP.R(iState, iAction);
        }

        avResult.finalizeValues();
        return avResult;
    }

    public AlphaVector getReward(int iAction)
    {
        AlphaVector avResult = newAlphaVector();
        double dValue = 0.0D;
        for(int iState = 0; iState < m_cStates; iState++)
        {
            dValue = m_pPOMDP.R(iState, iAction);
            avResult.setValue(iState, dValue);
        }

        avResult.setAction(iAction);
        avResult.finalizeValues();
        return avResult;
    }

    public void setAllValues(double dValue)
    {
        for (int iState = 0; iState<m_pPOMDP.getStateCount(); iState++)
          setValue(iState, dValue);
    }

    public double dotProductMax(BeliefState bs, double dMaxValue)
    {
        TIntDoubleIterator itNonZero = bs.getNonZeroEntries();
        double dRemainingProb = 1.0D;
        double dBelief = 0.0D;
        double dValue = 0.0D;
        double dDotProductValue = 0.0D;
        int iState = 0;
        for(; itNonZero.hasNext() && dDotProductValue + dRemainingProb * m_dMaxValue > dMaxValue; dRemainingProb -= dBelief)
        {
          itNonZero.advance();
          iState = itNonZero.key();
          dBelief = itNonZero.value();
            dValue = valueAt(iState);
            dDotProductValue += dBelief * dValue;
        }

        if(itNonZero.hasNext())
            return dMaxValue;
        else
            return dDotProductValue;
    }

    public int countEntries()
    {
        int iAction = 0;
        int iObservation = 0;
        int cEntries = 0;
        for(iAction = 0; iAction < m_cActions; iAction++)
            for(iObservation = 0; iObservation < m_cObservations; iObservation++)
                if(m_aCachedG[iAction][iObservation] != null)
                    cEntries += m_aCachedG[iAction][iObservation].countEntries();


        cEntries = (int)(cEntries + countLocalEntries());
        return cEntries;
    }

    public abstract long countLocalEntries();

    public void release()
    {
        int iAction = 0;
        int iObservation = 0;
        for(iAction = 0; iAction < m_cActions; iAction++)
            for(iObservation = 0; iObservation < m_cObservations; iObservation++)
                if(m_aCachedG[iAction][iObservation] != null)
                    m_aCachedG[iAction][iObservation].release();


    }

    public void initHitCount()
    {
        m_cHitCount = 0;
    }

    public void incrementHitCount()
    {
        m_cHitCount++;
    }

    public int getHitCount()
    {
        return m_cHitCount;
    }

    public void readValues(Element eFunction)
    {
        int iStateItem = 0;
        int iState = 0;
        double dValue = 0.0D;
        Element eState = null;
        NodeList nlStates = eFunction.getChildNodes();
        for(iStateItem = 0; iStateItem < nlStates.getLength(); iStateItem++)
        {
            eState = (Element)nlStates.item(iStateItem);
            dValue = Double.parseDouble(eState.getAttribute("Value"));
            iState = Integer.parseInt(eState.getAttribute("Id"));
            setValue(iState, dValue);
        }

        finalizeValues();
    }

    public void writeValues(Element eFunction, Document doc)
    {
        Element eState = null;
        double dValue = 0.0D;
        for (int iState = 0; iState<m_pPOMDP.getStateCount(); iState++)
        {
            eState = doc.createElement("State");
            dValue = valueAt(iState);
            eState.setAttribute("Id", (new StringBuilder(String.valueOf(iState))).toString());
            eState.setAttribute("Value", (new StringBuilder(String.valueOf(dValue))).toString());
            eFunction.appendChild(eState);
        }
    }

    public abstract long size();

    public abstract void setSize(int i);

    public static void initCurrentDotProductCount()
    {
        s_cCurrentDotProducts = 0L;
        s_cCurrentTimeInDotProduct = 0L;
    }

    public long[] getSuccessorLinks()
    {
        return m_aCachedSuccessorLinks;
    }

    public static double getCurrentDotProductAvgTime()
    {
        return (double)s_cCurrentTimeInDotProduct / (double)s_cCurrentDotProducts;
    }

    protected BeliefState m_bsWitness;
    protected int m_cStates;
    protected int m_cActions;
    protected int m_cObservations;
    protected int m_iAction;
    protected double m_dMaxValue;
    protected double m_dAvgValue;
    protected long m_aCachedSuccessorLinks[];
    protected AlphaVector m_aCachedG[][];
    protected int m_iAge;
    protected long m_iID;
    protected double m_dOffset;
    //protected Map m_mDotProductCache;
    protected int m_iValueFunctionInsertionTime;
    protected int m_cReferenceCounter;
    protected int m_cHitCount;
    protected LinearValueFunctionApproximation m_vfContainer;
    protected POMDP m_pPOMDP;
    protected long m_aiSumIds[];
    public boolean m_bMaintainWitness;
    protected static long s_cGComputations = 0L;
    protected static long s_cDotProducts = 0L;
    protected static long s_cCurrentDotProducts = 0L;
    protected static long s_cApproximateDotProduct = 0L;
    protected static long s_cAlphaVectors = 0L;
    protected static long s_cTotalTimeInG = 0L;
    protected static long s_cCurrentTimeInG = 0L;
    protected static long s_cTotalTimeInDotProduct = 0L;
    protected static long s_cCurrentTimeInDotProduct = 0L;
    protected static long TIME_INTERVAL = 100L;
    protected static boolean s_bAllowCaching = false;
    private static boolean s_bCountDotProduct = true;
    private static int g_cGs = 0;
    private static int g_cTouchedVertexes = 0;

    /**
     * Clears all static values 
     */
    public static void clear()
    {
      s_cGComputations = 0L;
      s_cDotProducts = 0L;
      s_cCurrentDotProducts = 0L;
      s_cApproximateDotProduct = 0L;
      s_cAlphaVectors = 0L;
      s_cTotalTimeInG = 0L;
      s_cCurrentTimeInG = 0L;
      s_cTotalTimeInDotProduct = 0L;
      s_cCurrentTimeInDotProduct = 0L;
      TIME_INTERVAL = 100L;
      s_bAllowCaching = false;
      s_bCountDotProduct = true;
      g_cGs = 0;
      g_cTouchedVertexes = 0;
    }
}
