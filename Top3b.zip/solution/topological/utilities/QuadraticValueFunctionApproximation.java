// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   QuadraticValueFunctionApproximation.java

package solution.topological.utilities;

import java.util.Iterator;
import java.util.Vector;

// Referenced classes of package pomdp.utilities:
//            QuadraticFunction, BeliefState

public class QuadraticValueFunctionApproximation
{

    public QuadraticValueFunctionApproximation()
    {
        m_vQuadraticFunctions = new Vector<QuadraticFunction>();
    }

    public double valueAt(BeliefState bs)
    {
        QuadraticFunction qfMin = getMinQF(bs);
        if(qfMin == null)
            return 2147483647D;
        else
            return qfMin.valueAt(bs);
    }

    public QuadraticFunction getMinQF(BeliefState bs)
    {
        Iterator<QuadraticFunction> itFunctions = m_vQuadraticFunctions.iterator();
        QuadraticFunction qfCurrent = null;
        QuadraticFunction qfMin = null;
        double dValue = 0.0D;
        double dMinValue = 1.7976931348623157E+308D;
        while(itFunctions.hasNext()) 
        {
            qfCurrent = itFunctions.next();
            dValue = qfCurrent.valueAt(bs);
            if(dValue < dMinValue)
            {
                dMinValue = dValue;
                qfMin = qfCurrent;
            }
        }
        return qfMin;
    }

    public void add(QuadraticFunction qfNew)
    {
        m_vQuadraticFunctions.add(qfNew);
    }

    public int size()
    {
        return m_vQuadraticFunctions.size();
    }

    public int getBestAction(BeliefState bs)
    {
        QuadraticFunction qfMin = getMinQF(bs);
        if(qfMin == null)
            return -1;
        else
            return qfMin.getAction();
    }

    Vector<QuadraticFunction> m_vQuadraticFunctions;
}
