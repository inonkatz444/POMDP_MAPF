package solution.topological.environments;

import gnu.trove.TIntHashSet;
import gnu.trove.TIntIterator;

import java.io.IOException;

import solution.topological.utilities.InvalidModelFileFormatException;
import solution.topological.utilities.graph.Graph;

// Referenced classes of package pomdp.environments:
//            POMDP

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 8 juil. 2009
 *
 */
public class LayeredPOMDP extends POMDP
{

    public LayeredPOMDP()
    {//
    }

    public static POMDP getLayeredPOMDP(POMDP pomdp, int numberOfLayers)
    {
        m_pPOMDP = pomdp;
        m_gGraph = m_pPOMDP.getGraph();
        m_gGraphT = m_gGraph.transpose();
        currentGoals = new TIntHashSet();
        for(int s = 0; s < m_pPOMDP.getStateCount(); s++)
        {
            for(int a = 0; a < m_pPOMDP.getActionCount(); a++)
            {
                for(int s2 = 0; s2 < m_pPOMDP.getStateCount(); s2++)
                    if(m_pPOMDP.R(s, a, s2) > 0.0D)
                        currentGoals.add(s2);
            }
        }

        int numberOfStates = m_pPOMDP.getStateCount() / numberOfLayers;
        int iterations = 0;
        do
        {
            TIntHashSet nextGoals = getNextGoals(numberOfStates);
            TIntHashSet successors = currentGoals;
            for (TIntIterator ite = nextGoals.iterator(); ite.hasNext();)
              successors.add(ite.next());
            removeTransitions(successors, nextGoals);
            for (TIntIterator ite = nextGoals.iterator(); ite.hasNext();)
              currentGoals.add(ite.next());
        } while(++iterations < numberOfLayers - 1);
        return m_pPOMDP;
    }

    private static TIntHashSet getNextGoals(int numberOfStates)
    {
      int s;
        TIntHashSet nextGoals = new TIntHashSet();
        TIntHashSet _currentGoals = currentGoals;
        TIntHashSet _currentStates;
        do
        {
            _currentStates = new TIntHashSet();
            for(TIntIterator iterator = _currentGoals.iterator(); iterator.hasNext(); )
            {
                s = iterator.next();
                for (TIntIterator ite = m_gGraphT.getSuccessors(s).iterator(); ite.hasNext();)
                {
                  s = ite.next();
                  _currentStates.add(s);
                  nextGoals.add(s);
                }
            }

            _currentGoals = _currentStates;
        } while(numberOfStates > nextGoals.size());
        return nextGoals;
    }

    private static void removeTransitions(TIntHashSet successors, TIntHashSet nextGoals)
    {
        for(TIntIterator iterator = nextGoals.iterator(); iterator.hasNext();)
        {
            int s = iterator.next();
            for(int a = 0; a < m_pPOMDP.getActionCount(); a++)
            {
                double resetValue = 0.0D;
                int numberOfGoals = 0;
                for(TIntIterator iter = m_gGraph.getSuccessorsNode(s).iterator(); iter.hasNext();)
                {
                    int s2 = iter.next();
                    if(!successors.contains(s2))
                    {
                        resetValue += m_pPOMDP.m_fTransition.valueAt(s, a, s2);
                        m_pPOMDP.m_fTransition.setValue(s, a, s2, 0.0D);
                    } else
                    if(m_pPOMDP.m_fTransition.valueAt(s, a, s2) > 0.0D)
                    {
                        numberOfGoals++;
                        m_pPOMDP.m_fTransition.setValue(s, a, s2, m_pPOMDP.m_fTransition.valueAt(s, a, s2));
                    }
                }

                for(TIntIterator iter = m_gGraph.getSuccessorsNode(s).iterator(); iter.hasNext();)
                {
                    int s2 = iter.next();
                    if(successors.contains(s2) && m_pPOMDP.m_fTransition.valueAt(s, a, s2) > 0.0D)
                        m_pPOMDP.m_fTransition.setValue(s, a, s2, m_pPOMDP.m_fTransition.valueAt(s, a, s2) + resetValue / numberOfGoals);
                }

            }

        }

    }

    public static void main(String args[])
    {
        POMDP pomdp = new POMDP();
        try
        {
            pomdp.load((new StringBuilder(String.valueOf(System.getProperty("user.dir")))).append("/src/pomdp/Models/hallway2.POMDP").toString());
            getLayeredPOMDP(pomdp, 5);
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        catch(InvalidModelFileFormatException e)
        {
            e.printStackTrace();
        }
    }

    protected static POMDP m_pPOMDP;
    protected static gnu.trove.TIntHashSet currentGoals;
    protected static Graph m_gGraph;
    protected static Graph m_gGraphT;
    
    /**
     * Clears all static values 
     */
    public static void clear()
    {
      m_pPOMDP = null;
      currentGoals = null;
      m_gGraph = null;
      m_gGraphT = null;
    }
}
