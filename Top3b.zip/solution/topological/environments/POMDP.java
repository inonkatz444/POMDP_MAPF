// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   POMDP.java

package solution.topological.environments;

import gnu.trove.*;

import java.io.*;
import java.util.*;

import solution.topological.RandomWalkPolicy;
import solution.topological.algorithms.*;
import solution.topological.heuristic.TopSearch;
import solution.topological.utilities.*;
import solution.topological.utilities.datastructures.*;
import solution.topological.utilities.graph.AcyclicShortestPath;
import solution.topological.utilities.graph.Graph;

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.1, 13 Aug 2009 - Added support for {@link OutOfMemoryError}
 *
 */
public class POMDP {
    private class IntegerCollection extends AbstractCollection<Integer>
    {

        @Override
        public Iterator<Integer> iterator()
        {
            return new IntegerIterator(m_iFirst, m_iLast);
        }

        @Override
        public int size()
        {
            return m_iLast - m_iFirst;
        }

        private int m_iFirst;
        private int m_iLast;

        public IntegerCollection(int iFirst, int iLast)
        {
            super();
            m_iFirst = iFirst;
            m_iLast = iLast;
        }
    }

    private class IntegerIterator
        implements Iterator<Integer>
    {

        public boolean hasNext()
        {
            return m_iNext < m_iLast;
        }

        public Integer next()
        {
            m_iNext++;
            return Integer.valueOf(m_iNext - 1);
        }

        public void remove()
        {//
        }

        private int m_iNext;
        private int m_iLast;

        public IntegerIterator(int iFirst, int iLast)
        {
            super();
            m_iNext = iFirst;
            m_iLast = iLast;
        }
    }

    protected enum RewardType {
    	StateActionState, StateAction, State, ActionStateNextstateObservation;
    }

    public POMDP()
    {
        m_cSteps = 0;
        m_vfPolicy = null;
        m_fTransition = null;
        m_fReward = null;
        m_fObservation = null;
        m_mActionIndexes = null;
        m_mActionNames = null;
        m_mStates = null;
        m_mObservations = null;
        m_fStartState = null;
        m_sRewardType = null;
        m_cStates = 0;
        m_cActions = 0;
        m_cObservations = 0;
        m_dGamma = 0.0D;
        m_fosOutputFile = null;
        m_bExploration = true;
        m_vTerminalStates = null;
        m_vObservationStates = new TIntArrayList();
        m_adMinActionRewards = null;
        m_iRandomSeed = 0L;
        m_rndGenerator = new RandomGenerator("POMDP", m_iRandomSeed);
        m_sName = "";
        m_rtReward = RewardType.StateAction;
        m_bCountStatistics = true;
        m_bGBasedBackup = false;
    }

    public boolean useClassicBackup()
    {
        return m_bGBasedBackup;
    }

    protected void initStoredRewards()
    {
        m_adStoredRewards = new double[m_cStates][m_cActions];
        int iState = 0;
        int iAction = 0;
        for(iState = 0; iState < m_cStates; iState++)
            for(iAction = 0; iAction < m_cActions; iAction++)
                m_adStoredRewards[iState][iAction] = -1.7976931348623157E+308D;


    }

    public void setOutputFile(String sFileName)
        throws IOException
    {
        m_fosOutputFile = new FileOutputStream(sFileName);
    }

    public double tr(int iState1, int iAction, int iState2)
    {
        return m_fTransition.valueAt(iState1, iAction, iState2);
    }

    public double tr(int s, int s2)
    {
        double tr = 0.0D;
        for(int a = 0; a < getActionCount(); a++)
        {
            for(int o = 0; o < getObservationCount(); o++)
                if(tr < tr(s, a, s2) * O(a, s2, o))
                    tr = tr(s, a, s2) * O(a, s2, o);

        }

        return tr;
    }

    public double R(int iStartState, int iAction, int iEndState)
    {
        double dReward = 0.0D;
        if(m_rtReward == RewardType.StateActionState)
            dReward = m_fReward.valueAt(iStartState, iAction, iEndState);
        else
        if(m_rtReward == RewardType.StateAction)
            dReward = m_fReward.valueAt(iStartState, iAction);
        else
        if(m_rtReward == RewardType.State)
            dReward = m_fReward.valueAt(iStartState);
        return dReward;
    }

    public double R(int iStartState, int iAction)
    {
        int iEndState = 0;
        double dReward = 0.0D;
        double dSumReward = 0.0D;
        double dTr = 0.0D;
        TIntDoubleIterator itNonZeroEntries = null;
        if(m_rtReward == RewardType.StateAction)
            dReward = m_fReward.valueAt(iStartState, iAction);
        else
        if(m_rtReward == RewardType.State)
            dReward = m_fReward.valueAt(iStartState);
        else
        if(m_rtReward == RewardType.StateActionState)
        {
            dReward = m_adStoredRewards[iStartState][iAction];
            if(dReward == -1.7976931348623157E+308D)
            {
                dSumReward = m_fReward.valueAt(iStartState, iAction);
                if(dSumReward == 0.0D)
                {
                    itNonZeroEntries = m_fReward.getNonZeroEntries(iStartState, iAction);
                    if(itNonZeroEntries != null)
                        while(itNonZeroEntries.hasNext()) 
                        {
                          itNonZeroEntries.advance();
                            iEndState = itNonZeroEntries.key();
                            dReward = itNonZeroEntries.value();
                            dTr = m_fTransition.valueAt(iStartState, iAction, iEndState);
                            dSumReward += dReward * dTr;
                        }
                }
                m_adStoredRewards[iStartState][iAction] = dSumReward;
                dReward = dSumReward;
            }
        }
        return dReward;
    }

    public double O(int iAction, int iState, int iObservation)
    {
        return m_fObservation.valueAt(iAction, iState, iObservation);
    }

    public String getActionName(int iAction)
    {
        if(m_mActionNames != null)
            return m_mActionNames.get(iAction);
        else
            return (new StringBuilder()).append(iAction).toString();
    }

    public int getActionIndex(String sAction)
    {
        if(m_mActionIndexes != null)
        {
            int oIdx = m_mActionIndexes.get(sAction);
            if(oIdx <= 0)
                return -1;
            return oIdx-1;
        }
        try
        {
            return Integer.parseInt(sAction);
        }
        catch(NumberFormatException e)
        {
            return -1;
        }
    }

    public String getStateName(int iState)
    {
      if (iState==-1)
        return "none";
        if(m_vStateNames != null)
            return m_vStateNames.elementAt(iState);
        else
            return (new StringBuilder(String.valueOf(iState))).toString();
    }

    public int getStateIndex(String sState)
    {
        int oIdx=0;
        if(m_mStates != null)
            oIdx = m_mStates.get(sState);
        if(oIdx != 0)
            return oIdx-1;
        try
        {
            return Integer.parseInt(sState);
        }
        catch(NumberFormatException e)
        {
            return -1;
        }
    }
    
    public String getObservationName(int iObservation)
    {
//        if(m_mObservations != null)
//            return m_mActionNames.get(iObservation).toString();
//        else
            return (new StringBuilder()).append(iObservation).toString();
    }
    
    public int getObservationIndex(String sObservation)
    {
        int oIdx = 0;
        if(m_mObservations != null)
            oIdx = m_mObservations.get(sObservation);
        if(oIdx != 0)
            return oIdx-1;
        try
        {
            return Integer.parseInt(sObservation);
        }
        catch(NumberFormatException e)
        {
            return -1;
        }
    }

    protected void readHeader(LineReader lrInput)
        throws IOException
    {
        String sLine = "";
        String sType = "";
        int cVars = 0;
        int idx = 0;
        while(cVars < 5) 
        {
            for(sLine = ""; sLine.equals(""); sLine = sLine.trim())
                sLine = lrInput.readLine();

            StringTokenizer stLine = new StringTokenizer(sLine);
            sType = stLine.nextToken();
            if(!sType.equals("#"))
                if(sType.equals("discount:"))
                {
                    String sValue = stLine.nextToken();
                    try
                    {
                        m_dGamma = Double.parseDouble(sValue);
                    }
                    catch(Exception e)
                    {
                        System.err.println((new StringBuilder("sValue = ")).append(sValue).toString());
                        e.printStackTrace();
                    }
                    cVars++;
                } else
                if(sType.equals("values:"))
                {
                    m_sRewardType = stLine.nextToken();
                    cVars++;
                } else
                if(sType.equals("states:"))
                {
                    String sValue = stLine.nextToken();
                    try
                    {
                        m_cStates = Integer.parseInt(sValue);
                    }
                    catch(NumberFormatException e)
                    {
                        m_mStates = new TObjectIntHashMap<String>();
                        m_vStateNames = new Vector<String>();
                        idx = 0;
                        m_mStates.put(sValue, idx+1);
                        m_vStateNames.add(idx, sValue);
                        for(idx++; stLine.hasMoreTokens(); idx++)
                        {
                            sValue = stLine.nextToken();
                            m_mStates.put(sValue, idx+1);
                            m_vStateNames.add(idx, sValue);
                        }

                        m_cStates = m_mStates.size();
                    }
                    System.out.print((new StringBuilder("|S| = ")).append(m_cStates).toString());
                    cVars++;
                } else
                if(sType.equals("actions:"))
                {
                    String sValue = stLine.nextToken();
                    try
                    {
                        m_cActions = Integer.parseInt(sValue);
                    }
                    catch(NumberFormatException e)
                    {
                        m_mActionIndexes = new TObjectIntHashMap<String>();
                        m_mActionNames = new Vector<String>();
                        idx = 0;
                        m_mActionIndexes.put(sValue, idx+1);
                        m_mActionNames.add(idx, sValue);
                        for(idx++; stLine.hasMoreTokens(); idx++)
                        {
                            sValue = stLine.nextToken();
                            m_mActionIndexes.put(sValue, idx+1);
                            m_mActionNames.add(idx, sValue);
                        }

                        m_cActions = m_mActionIndexes.size();
                    }
                    System.out.print((new StringBuilder("|A| = ")).append(m_cActions).toString());
                    cVars++;
                } else
                if(sType.equals("observations:"))
                {
                    String sValue = stLine.nextToken();
                    try
                    {
                        m_cObservations = Integer.parseInt(sValue);
                    }
                    catch(NumberFormatException e)
                    {
                        m_mObservations = new TObjectIntHashMap<String>();
                        idx = 1;
                        m_mObservations.put(sValue, idx);
                        for(idx++; stLine.hasMoreTokens(); idx++)
                        {
                            sValue = stLine.nextToken();
                            m_mObservations.put(sValue, idx);
                        }

                        m_cObservations = m_mObservations.size();
                    }
                    System.out.print((new StringBuilder("|O| = ")).append(m_cObservations).toString());
                    cVars++;
                }
        }
        System.out.println();
        int aDims[] = new int[3];
        aDims[0] = m_cStates;
        aDims[1] = m_cActions;
        aDims[2] = m_cStates;
        m_fTransition = new SparseTabularFunction(aDims);
        aDims[0] = m_cActions;
        aDims[1] = m_cStates;
        aDims[2] = m_cObservations;
        m_fObservation = new SparseTabularFunction(aDims);
        aDims = new int[1];
        aDims[0] = m_cStates;
        m_fStartState = new SparseTabularFunction(aDims);
        aDims = new int[3];
        aDims[0] = m_cStates;
        aDims[1] = m_cActions;
        aDims[2] = m_cStates;
        m_fReward = new SparseTabularFunction(aDims);
        m_adMinActionRewards = new double[m_cActions];
        for(idx = 0; idx < m_cActions; idx++)
            m_adMinActionRewards[idx] = 0.0D;

    }

    public void load(String sFileName)
        throws IOException, InvalidModelFileFormatException
    {
        System.out.println((new StringBuilder("Started loading model ")).append(sFileName).toString());
        m_sName = sFileName.substring(sFileName.lastIndexOf("/") + 1, sFileName.lastIndexOf("."));
        LineReader lrInput = new LineReader(sFileName);
        String sLine = "";
        String sType = "";
        int cLines = 0;
        try
        {
            readHeader(lrInput);
        }
        catch(EndOfFileException e)
        {
            throw new InvalidModelFileFormatException("Missing header parameters");
        }
        while(!lrInput.endOfFile()) 
        {
            sLine = lrInput.readLine();
            if(++cLines % 3000 == 0)
                System.out.print(".");
            if (cLines % 500000 == 0)
              System.out.println();
            if(sLine.length() > 0 && sLine.charAt(0) != '#')
            {
                StringTokenizer stLine = new StringTokenizer(sLine);
                if(stLine.hasMoreTokens())
                {
                    sType = stLine.nextToken();
                    //TODO remove i things
                   
                    if(sType.equals("T:"))
                    {
                    	
                        String sValue = stLine.nextToken();
                        readTransition(lrInput, sValue, stLine);
                    } else
                    if(sType.equals("O:"))
                    {
                        String sValue = stLine.nextToken();
                        readObservation(lrInput, sValue, stLine);
                    } else
                    if(sType.equals("R:"))
                        readReward(lrInput, stLine);
                    else
                    if(sType.equals("start:"))
                    {
                        if(stLine.hasMoreTokens())
                            readStartState(lrInput, stLine);
                        else
                            readStartState(lrInput, null);
                    } else
                    if(sType.equals("E:"))
                    {
                        if(stLine.hasMoreTokens())
                            readTerminalStates(stLine);
                    } else
                    if(sType.equals("OS:") && stLine.hasMoreTokens())
                        readObservationStates(stLine);
                }
            }
        }
        if(m_rtReward == RewardType.StateActionState)
            initStoredRewards();
        BeliefStateFactory.getInstance(this, 20);
        System.out.println();
        verifyFunctions();
        System.out.println("Done loading model");
    }

    protected void verifyFunctions()
    {
        int iStartState = 0;
        int iAction = 0;
        int iEndState = 0;
        TIntDoubleIterator itNonZero = null;
        double dTr = 0.0D;
        double dSumTr = 0.0D;
        double dO = 0.0D;
        double dSumO = 0.0D;
        double dPr = 0.0D;
        double dSumPr = 0.0D;
        boolean bFixed = false;
        for(iStartState = 0; iStartState < m_cStates; iStartState++)
        {
            dPr = m_fStartState.valueAt(iStartState);
            dSumPr += dPr;
        }

        if(Math.abs(dSumPr - 1.0D) > 0.0001D)
            System.out.println((new StringBuilder("sum of start state probs = ")).append(dSumPr).toString());
        bFixed = false;
        for(iStartState = 0; iStartState < m_cStates; iStartState++)
            for(iAction = 0; iAction < m_cActions; iAction++)
            {
                dSumTr = 0.0D;
                for(itNonZero = m_fTransition.getNonZeroEntries(iStartState, iAction); itNonZero.hasNext();)
                {
                    itNonZero.advance();
                    iEndState = itNonZero.key();
                    dTr = itNonZero.value();
                    dSumTr += dTr;
                }

                if(dSumTr == 0.0D)
                {
                    m_fTransition.setValue(iStartState, iAction, iStartState, 1.0D);
                    dSumTr = 1.0D;
                    bFixed = true;
                    
                }
                if(Math.abs(dSumTr - 1.0D) > 0.0001D)
                    System.out.println((new StringBuilder("sum tr( ")).append(getStateName(iStartState)).append(", ").append(iAction).append(", * ) = ").append(dSumTr).toString());
            }


        if(bFixed)
            System.out.println("Model file corrupted - needed to fix some transition values");
        for(iAction = 0; iAction < m_cActions; iAction++)
            for(iEndState = 0; iEndState < m_cStates; iEndState++)
            {
                dSumO = 0.0D;
                for(itNonZero = m_fObservation.getNonZeroEntries(iAction, iEndState); itNonZero.hasNext();)
                {
                  itNonZero.advance();
                    dO = itNonZero.value();
                    dSumO += dO;
                }

                if(Math.abs(dSumO - 1.0D) > 0.0001D){
                    System.out.println((new StringBuilder("sum O( ")).append(iAction).append(", ").append(iEndState).append(", * ) = ").append(dSumO).toString());
                    System.out.println(m_vStateNames.get(iEndState));
                }
            }


        double dMdpAdr = computeMDPAverageDiscountedReward(10000, 250);
        System.out.println((new StringBuilder("MDP ADR = ")).append(dMdpAdr).toString());
    }

    private void readTerminalStates(StringTokenizer stLine)
    {
        String sTerminalState = "";
        int iTerminalState = 0;
        m_vTerminalStates = new TIntArrayList();
        for(; stLine.hasMoreElements(); m_vTerminalStates.add(iTerminalState))
        {
            sTerminalState = stLine.nextToken();
            iTerminalState = getStateIndex(sTerminalState);
        }

    }

    private void readObservationStates(StringTokenizer stLine)
    {
        String sObservationState = "";
        int iObservationState = 0;
        for(; stLine.hasMoreElements(); m_vObservationStates.add(iObservationState))
        {
            sObservationState = stLine.nextToken();
            iObservationState = getStateIndex(sObservationState);
        }

    }

    protected void readStartState(LineReader lrInput, StringTokenizer stLines)
        throws InvalidModelFileFormatException
    {
        StringTokenizer stLine = stLines;
        String sValue = "";
        int iStartState = 0;
        double dValue = 0.0D;
        if(stLine == null)
            try
            {
                String sLine = lrInput.readLine();
                stLine = new StringTokenizer(sLine);
            }
            catch(IOException e)
            {
                throw new InvalidModelFileFormatException("Start: must be followed by a line of distributions.");
            }
        try
        {
            for(iStartState = 0; iStartState < m_cStates; iStartState++)
            {
                sValue = stLine.nextToken();
                dValue = Double.parseDouble(sValue);
                m_fStartState.setValue(iStartState, dValue);
            }

        }
        catch(NoSuchElementException e)
        {
            throw new InvalidModelFileFormatException("insufficient number of distributions");
        }
    }

    protected void readTransition(LineReader lrInput, String sAction, StringTokenizer stLines)
        throws InvalidModelFileFormatException
    {
      StringTokenizer stLine = stLines;
        String sStartState = "";
        String sEndState = "";
        String sValue = "";
        String sLine = "";
        int iStartState = 0;
        int iEndState = 0;
        int iActionIdx = getActionIndex(sAction);
        int iAction = 0;
        double dValue = 0.0D;
        if(stLine.hasMoreTokens())
        {
            stLine.nextToken();
            sStartState = stLine.nextToken();
            if(sStartState.equals("*"))
                iStartState = -1;
            else
                iStartState = getStateIndex(sStartState);
            if(stLine.hasMoreTokens())
            {
                stLine.nextToken();
                sEndState = stLine.nextToken();
                sValue = stLine.nextToken();
                if(sEndState.equals("*"))
                    iEndState = -1;
                else
                    iEndState = getStateIndex(sEndState);
                dValue = Double.parseDouble(sValue);
                if(dValue == 0.0D)
                    return;
                if(sAction.equals("*"))
                    for(iAction = 0; iAction < m_cActions; iAction++)
                        m_fTransition.setValue(iStartState, iAction, iEndState, dValue);

                else
                if(sStartState.equals("*"))
                    for(iStartState = 0; iStartState < m_cStates; iStartState++)
                        m_fTransition.setValue(iStartState, iActionIdx, iEndState, dValue);

                else
                    m_fTransition.setValue(iStartState, iActionIdx, iEndState, dValue);
            } else
            {
                try
                {
                    sLine = lrInput.readLine();
                    stLine = new StringTokenizer(sLine);
                    for(iEndState = 0; iEndState < m_cStates; iEndState++)
                    {
                        sValue = stLine.nextToken();
                        dValue = Double.parseDouble(sValue);
                        if(dValue != 0.0D)
                            if(sAction.equals("*"))
                                for(iAction = 0; iAction < m_cActions; iAction++)
                                    m_fTransition.setValue(iStartState, iAction, iEndState, dValue);

                            else
                                m_fTransition.setValue(iStartState, iActionIdx, iEndState, dValue);
                    }

                }
                catch(NoSuchElementException e)
                {
                    throw new InvalidModelFileFormatException((new StringBuilder("insufficient number of transitions ")).append(sLine).toString());
                }
                catch(IOException e)
                {
                    throw new InvalidModelFileFormatException();
                }
            }
        } else
        {
            try
            {
                for(iStartState = 0; iStartState < m_cStates; iStartState++)
                {
                    sLine = lrInput.readLine();
                    stLine = new StringTokenizer(sLine);
                    for(iEndState = 0; iEndState < m_cStates; iEndState++)
                    {
                        sValue = stLine.nextToken();
                        dValue = Double.parseDouble(sValue);
                        if(dValue != 0.0D)
                            if(sAction.equals("*"))
                                for(iAction = 0; iAction < m_cActions; iAction++)
                                    m_fTransition.setValue(iStartState, iAction, iEndState, dValue);

                            else
                                m_fTransition.setValue(iStartState, iActionIdx, iEndState, dValue);
                    }

                }

            }
            catch(NoSuchElementException e)
            {
                throw new InvalidModelFileFormatException((new StringBuilder("insufficient number of transitions ")).append(sLine).toString());
            }
            catch(IOException e)
            {
                throw new InvalidModelFileFormatException();
            }
        }
    }

    protected void readReward(LineReader lrInput, StringTokenizer stLine)
        throws InvalidModelFileFormatException
    {
        String sAction;
        String sStartState;
        String sEndState;
        String sObservation;
        int iSpecifiedStartState;
        int iSpecifiedEndState;
        int iSpecifiedAction;
        double dValue;
        try
        {
            sAction = stLine.nextToken();
            stLine.nextToken();
            sStartState = stLine.nextToken();
            stLine.nextToken();
            sEndState = stLine.nextToken();
            stLine.nextToken();
            sObservation = stLine.nextToken();
            String sValue = stLine.nextToken();
            iSpecifiedStartState = -1;
            iSpecifiedEndState = -1;
            iSpecifiedAction = -1;
            dValue = Double.parseDouble(sValue);
            if(dValue == 0.0D)
                return;
        }
        catch(NoSuchElementException e)
        {
            throw new InvalidModelFileFormatException("Format must be - R: <action> : <state> : <state> : * %f");
        }
        if(!sObservation.equals("*"))
            throw new InvalidModelFileFormatException("Not supporting splitting rewards to observations");
        if(!sAction.equals("*"))
            iSpecifiedAction = getActionIndex(sAction);
        if(!sStartState.equals("*"))
            iSpecifiedStartState = getStateIndex(sStartState);
        if(!sEndState.equals("*"))
            iSpecifiedEndState = getStateIndex(sEndState);
        if(iSpecifiedEndState != -1)
        {
            m_rtReward = RewardType.StateActionState;
            for(int iStartState = 0; iStartState < m_cStates; iStartState++)
                if(iSpecifiedStartState == -1 || iStartState == iSpecifiedStartState)
                {
                    for(int iAction = 0; iAction < m_cActions; iAction++)
                        if(iSpecifiedAction == -1 || iSpecifiedAction == iAction)
                        {
                            m_fReward.setValue(iStartState, iAction, iSpecifiedEndState, dValue);
                            if(dValue < m_adMinActionRewards[iAction])
                                m_adMinActionRewards[iAction] = dValue;
                        }

                }

        } else
        if(iSpecifiedAction != -1)
        {
            m_rtReward = RewardType.StateAction;
            for(int iStartState = 0; iStartState < m_cStates; iStartState++)
                if(iSpecifiedStartState == -1 || iStartState == iSpecifiedStartState)
                {
                    m_fReward.setValue(iStartState, iSpecifiedAction, dValue);
                    if(dValue < m_adMinActionRewards[iSpecifiedAction])
                        m_adMinActionRewards[iSpecifiedAction] = dValue;
                }

        } else
        if(iSpecifiedStartState != -1)
        {
            m_rtReward = RewardType.State;
            m_fReward.setValue(iSpecifiedStartState, dValue);
            for(int iAction = 0; iAction < m_cActions; iAction++)
                if(dValue < m_adMinActionRewards[iAction])
                    m_adMinActionRewards[iAction] = dValue;

        } else
        {
            throw new InvalidModelFileFormatException("Format must be - R: <action> : <state> : <state> : * %f");
        }
    }

    protected void readObservation(LineReader lrInput, String sAction, StringTokenizer stLines)
        throws InvalidModelFileFormatException
    {
        StringTokenizer stLine = stLines;
        String sObservation = "";
        String sEndState = "";
        String sValue = "";
        String sLine = "";
        int iObservation = 0;
        int iEndState = 0;
        int iActionIdx = getActionIndex(sAction);
        double dValue = 0.0D;
        if(stLine.hasMoreTokens())
        {
            stLine.nextToken();
            sEndState = stLine.nextToken();
            if(sEndState.equals("*"))
                iEndState = -1;
            else
                iEndState = getStateIndex(sEndState);
            if(stLine.hasMoreTokens())
            {
                stLine.nextToken();
                sObservation = stLine.nextToken();
                iObservation = getObservationIndex(sObservation);
                sValue = stLine.nextToken();
                dValue = Double.parseDouble(sValue);
                if(sEndState.equals("*"))
                    iEndState = -1;
                if(sAction.equals("*"))
                    iActionIdx = -1;
                m_fObservation.setAllValues(iActionIdx, iEndState, iObservation, dValue);
            } else
            {
                try
                {
                    sLine = lrInput.readLine();
                    stLine = new StringTokenizer(sLine);
                    for(iObservation = 0; iObservation < m_cObservations; iObservation++)
                    {
                        sValue = stLine.nextToken();
                        dValue = Double.parseDouble(sValue);
                        if(sAction.equals("*"))
                            iActionIdx = -1;
                        m_fObservation.setAllValues(iActionIdx, iEndState, iObservation, dValue);
                    }

                }
                catch(NoSuchElementException e)
                {
                    throw new InvalidModelFileFormatException((new StringBuilder("insufficient number of observations ")).append(sLine).toString());
                }
                catch(IOException e)
                {
                    throw new InvalidModelFileFormatException();
                }
            }
        } else
        {
            try
            {
                for(iEndState = 0; iEndState < m_cStates; iEndState++)
                {
                    sLine = lrInput.readLine();
                    stLine = new StringTokenizer(sLine);
                    for(iObservation = 0; iObservation < m_cObservations; iObservation++)
                    {
                        sValue = stLine.nextToken();
                        dValue = Double.parseDouble(sValue);
                        if(sAction.equals("*"))
                            iActionIdx = -1;
                        m_fObservation.setAllValues(iActionIdx, iEndState, iObservation, dValue);
                    }

                }

            }
            catch(NoSuchElementException e)
            {
                throw new InvalidModelFileFormatException((new StringBuilder("insufficient number of observations ")).append(sLine).toString());
            }
            catch(IOException e)
            {
                throw new InvalidModelFileFormatException();
            }
        }
    }

    /**
     * Executes an action, using the global random generator
     * @param iAction the action to execute
     * @param iState the state where to act
     * @return the next state
     */
    public int execute(int iAction, int iState)
    {
        int iNextState = -1;
        double dProb = m_rndGenerator.nextDouble();
        double dTr = 1E-9D;
        TIntDoubleIterator itNonZero = getNonZeroTransitions(iState, iAction);
        for(; dProb > dTr && itNonZero.hasNext(); )
        {
          itNonZero.advance();
            iNextState = itNonZero.key();
            dTr += itNonZero.value();
        }

        return iNextState;
    }

    /**
     * Executes an action, using the specified random generator
     * @param iAction the action to execute
     * @param iState the state where to act
     * @param m_rndGenerator the random generator
     * @return the next state
     */
    public int execute(int iAction, int iState, RandomGenerator m_rndGenerator)
    {
        int iNextState = -1;
        double dProb = m_rndGenerator.nextDouble();
        double dTr = 0D;
        TIntDoubleIterator itNonZero = getNonZeroTransitions(iState, iAction);
        for(; dProb > dTr && itNonZero.hasNext(); )
        {
          itNonZero.advance();
            iNextState = itNonZero.key();
            dTr += itNonZero.value();
        }

        return iNextState;
    }

    /**
     * Generates an observation using the global random generator
     * @param iAction the current action
     * @param iState  the current state
     * @return a possible observation 
     */
    public int observe(int iAction, int iState)
    {
        int iObservation = -1;
        double dProb = m_rndGenerator.nextDouble();
        double dO = 0D;
        TIntDoubleIterator itNonZeroObservations = m_fObservation.getNonZeroEntries(iAction, iState);
        for(; dProb > dO && itNonZeroObservations.hasNext(); )
        {
          itNonZeroObservations.advance();
            iObservation = itNonZeroObservations.key();
            dO += itNonZeroObservations.value();
        }

        if(iObservation == m_cObservations)
            throw new Error((new StringBuilder("Corrupted observation function - O( ")).append(iAction).append(", ").append(getStateName(iState)).append(", * ) = 0").toString());
        else
            return iObservation;
    }

    /**
     * Generates an observation using the specified random generator
     * @param iAction the current action
     * @param iState  the current state
     * @param m_rndGenerator the random generator
     * @return a possible observation 
     */
    public int observe(int iAction, int iState, RandomGenerator m_rndGenerator)
    {
        int iObservation = -1;
        double dProb = m_rndGenerator.nextDouble();
        double dO = 0D;
        TIntDoubleIterator itNonZeroObservations = m_fObservation.getNonZeroEntries(iAction, iState);
        for(; dProb > dO && itNonZeroObservations.hasNext(); )
        {
          itNonZeroObservations.advance();
            iObservation = itNonZeroObservations.key();
            dO += itNonZeroObservations.value();       
        }

        if(iObservation == m_cObservations)
            throw new Error((new StringBuilder("Corrupted observation function - O( ")).append(iAction).append(", ").append(getStateName(iState)).append(", * ) = 0").toString());
        else
            return iObservation;
    }

    public double simulate(int cSteps, int iSimulationType, int cEvalInterval)
        throws IOException
    {
        return simulate(cSteps, null, 0, iSimulationType, cEvalInterval);
    }

    protected double simulate(int cSteps, Vector<BeliefState> vBeliefPoints, int cMaxBeliefPoints, int iSimulationType, int cEvalInterval)
        throws IOException
    {
      System.out.print("Simulation kind: \t");
        PolicyStrategy policy = null;
        int cMaxNoRewardSteps = 500;
        if(iSimulationType == 0)
        {
          System.out.println("Random Walk");
            policy = new RandomWalkPolicy(m_cActions);
        } else
        if(iSimulationType == 1)
        {
            m_bExploration = false;
            policy = m_vfPolicy;
            m_bExploration = true;
            System.out.println("Policy");
        } else
        if(iSimulationType == 4)
        {
            policy = MDPValueFunction.getInstance(this, 0.5D);
            ((MDPValueFunction)policy).valueIteration(1000, 0.050000000000000003D);
            cMaxNoRewardSteps = -1;
            System.out.println("MDP policy");
        } else
        {
          System.out.println("Exploration");
            m_bExploration = true;
        }
        if(policy != null)
            setEnvironmentType(policy);
        return simulate(cSteps, vBeliefPoints, cMaxBeliefPoints, policy, cEvalInterval, cMaxNoRewardSteps);
    }
private double maxADRreached = Double.NEGATIVE_INFINITY;
public double computeAverageDiscountedReward(int cTests, final int cMaxStepsToGoal, final PolicyStrategy policy)
{
    countStatistics(false);
    double dSumDiscountedRewards = 0.0D;
    double dDiscountedReward = 0.0D;
    int iTest = 0;
    int iAction = 0;
    long cCurrentMilliseconds = 0L;
    long iStartTime = System.currentTimeMillis();
    long iEndTime = 0L;
    long lTotalCPU = 0L;
    long lStartCPU = JProf.getCurrentThreadCpuTimeSafe();
    long lEndCPU = 0L;
    RandomGenerator rndGenerator = m_rndGenerator;
    m_rndGenerator = new RandomGenerator("ADR", m_iRandomSeed);
    double dCurrentSum = 0.0D;
    final int aiActionCount[] = new int[m_cActions];
    for(iTest = 0; iTest < cTests; iTest++)
    {
//      System.out.println("New run"); //TODO Laurent
        dDiscountedReward = computeDiscountedReward(cMaxStepsToGoal, policy, aiActionCount);
        if(dDiscountedReward != -1.7976931348623157E+308D)
        {
            dCurrentSum += dDiscountedReward;
            dSumDiscountedRewards += dDiscountedReward;
            if(iTest % 100 == 0)
                System.out.print((iTest / 100) % 10);
        } else
        {
            iTest--;
        }
    }
    if (dCurrentSum/cTests > maxADRreached)
    {
      maxADRreached = dCurrentSum/cTests; 
    }
    Logger.getInstance().log("POMDP", 0, "computeAverageDiscountedReward", (new StringBuilder("Last ")).append(round(dCurrentSum / cTests, 4)).append(", current overall ").append(round(dSumDiscountedRewards / iTest, 3)).append("\tMAX=").append(maxADRreached).toString());
    iEndTime = System.currentTimeMillis();
    lEndCPU = JProf.getCurrentThreadCpuTimeSafe();
    cCurrentMilliseconds = (iEndTime - iStartTime) / 1000L;
    lTotalCPU = (lEndCPU - lStartCPU) / 0x3b9aca00L;
    if (TopSearch.DISPLAY_ADR)
    {
      String sInfo = (new StringBuilder("Status: #tests = ")).append(cTests).append(": ").append(" Time: ").append(cCurrentMilliseconds).append(" CPUTime: ").append(lTotalCPU).append(" Reward: ").append(dSumDiscountedRewards / cTests).toString();
      System.out.println(sInfo);
      StringBuilder sMsg = new StringBuilder(" action execution ");
      int tot=0;
      for(iAction = 0; iAction < m_cActions; iAction++)
      {
          tot += aiActionCount[iAction];
          sMsg = sMsg.append(getActionName(iAction)).append(" = ").append(aiActionCount[iAction]).append(", ");
      }
      System.out.print(tot); System.out.println(sMsg.toString());
    }
    countStatistics(true);
    m_rndGenerator = rndGenerator;
    return dSumDiscountedRewards / cTests;
}
public double computeAverageDiscountedReward2(int cTests, final int cMaxStepsToGoal, final PolicyStrategy policy)
{
    countStatistics(false);
    double dSumDiscountedRewards = 0.0D;
    double dDiscountedReward = 0.0D;
    int iTest = 0;
    int iAction = 0;
    long cCurrentMilliseconds = 0L;
    long iStartTime = System.currentTimeMillis();
    long iEndTime = 0L;
    long lTotalCPU = 0L;
    long lStartCPU = JProf.getCurrentThreadCpuTimeSafe();
    long lEndCPU = 0L;
    RandomGenerator rndGenerator = m_rndGenerator;
    try
    {
    m_rndGenerator = null;
    double dCurrentSum = 0.0D;
    final int aiActionCount[] = new int[m_cActions];
    final int half = cTests/2;
    Thread t = new Thread() {
      @Override
      public void run()
      {
        int iTest;
        double dDiscountedReward;
        RandomGenerator rnd2 = new RandomGenerator("ADR", m_iRandomSeed);
        pdSumDiscountedRewards = pdCurrentSum = 0.0D;
        for(iTest = 0; iTest < half; iTest++)
        {
//          System.out.println("New run"); //TODO Laurent
            dDiscountedReward = computeDiscountedReward(cMaxStepsToGoal, policy, aiActionCount,rnd2);
            if(dDiscountedReward != -1.7976931348623157E+308D)
            {
                pdCurrentSum += dDiscountedReward;
                pdSumDiscountedRewards += dDiscountedReward;
                if (TopSearch.DISPLAY_ADR)
                {
                if (iTest%10==9)
                  System.out.print('.');
                if(iTest % 100 == 0)
                    System.out.print((iTest / 100) % 10);
                }
            } else
            {
                iTest--;
            }
        }
      }
    };t.start();
    RandomGenerator rnd2 = new RandomGenerator("ADR", m_iRandomSeed+1);
    for(iTest = half; iTest < cTests; iTest++)
    {
//      System.out.println("New run"); //TODO Laurent
        dDiscountedReward = computeDiscountedReward(cMaxStepsToGoal, policy, aiActionCount,rnd2);
        if(dDiscountedReward != -1.7976931348623157E+308D)
        {
            dCurrentSum += dDiscountedReward;
            dSumDiscountedRewards += dDiscountedReward;
            if (TopSearch.DISPLAY_ADR)
            if(iTest % 100 == 0)
                System.out.print((iTest / 100) % 10);
        } else
        {
            iTest--;
        }
    }
    while (t.isAlive())
      try
      {
        Thread.sleep(100);
      } catch (InterruptedException e)
      {
        e.printStackTrace();
      }
    dCurrentSum += pdCurrentSum;
    dSumDiscountedRewards += pdSumDiscountedRewards;
    if (dCurrentSum/cTests > maxADRreached)
    {
      maxADRreached = dCurrentSum/cTests; 
    }
    Logger.getInstance().log("POMDP", 0, "computeAverageDiscountedReward", (new StringBuilder("Last ")).append(round(dCurrentSum / cTests, 4)).append(", current overall ").append(round(dSumDiscountedRewards / iTest, 3)).append("\tMAX=").append(maxADRreached).toString());
    iEndTime = System.currentTimeMillis();
    lEndCPU = JProf.getCurrentThreadCpuTimeSafe();
    cCurrentMilliseconds = (iEndTime - iStartTime) / 1000L;
    lTotalCPU = (lEndCPU - lStartCPU) / 0x3b9aca00L;
    String sInfo = (new StringBuilder("Status: #tests = ")).append(cTests).append(": ").append(" Time: ").append(cCurrentMilliseconds).append(" CPUTime: ").append(lTotalCPU).append(" Reward: ").append(dSumDiscountedRewards / cTests).toString();
    System.out.println(sInfo);
    StringBuilder sMsg = new StringBuilder(" action execution ");
    int tot=0;
    for(iAction = 0; iAction < m_cActions; iAction++)
    {
        tot += aiActionCount[iAction];
        sMsg = sMsg.append(getActionName(iAction)).append(" = ").append(aiActionCount[iAction]).append(", ");
    }
    System.out.print(tot); System.out.println(sMsg.toString());
    countStatistics(true);
    } finally
    {
    m_rndGenerator = rndGenerator;
    }
    return dSumDiscountedRewards / cTests;
}
    double pdSumDiscountedRewards;
    double pdCurrentSum;

    protected double computeMDPAverageDiscountedReward(int cTests, int cMaxStepsToGoal)
    {
        MDPValueFunction vfMDP = MDPValueFunction.getInstance(this, 0.10000000000000001D);
        vfMDP.valueIteration(50, 0.001D);
        m_rndGenerator.init(m_iRandomSeed);
        double dSumDiscountedRewards = 0.0D;
        int iTest = 0;
        long cCurrentMilliseconds = 0L;
        long iStartTime = System.currentTimeMillis();
        long iEndTime = 0L;
        for(iTest = 0; iTest < cTests; iTest++)
            dSumDiscountedRewards += computeMDPDiscountedReward(cMaxStepsToGoal, vfMDP, false, null);

        iEndTime = System.currentTimeMillis();
        cCurrentMilliseconds = (iStartTime - iEndTime) / 1000L;
        String sInfo = (new StringBuilder("Status: #tests = ")).append(cTests).append(": ").append(" Time: ").append(cCurrentMilliseconds).append(" Reward: ").append(dSumDiscountedRewards / cTests).append(g_sNewline).toString();
        System.out.println(sInfo);
        return round(dSumDiscountedRewards / cTests, 3);
    }

    protected double round(double d, int cDigits)
    {
        double dPower = Math.pow(10D, cDigits);
        double d1;
        d1 = Math.round(d1 = d * dPower);
        return d1 / dPower;
    }

    protected double computeDiscountedReward(int cMaxStepsToGoal, PolicyStrategy policy, int aiActionCount[])
    {
        return computeDiscountedReward(cMaxStepsToGoal, policy, null, false, aiActionCount);
    }

    protected double computeDiscountedReward(int cMaxStepsToGoal, PolicyStrategy policy, Vector<BeliefState> vObservedBeliefPoints, int aiActionCount[])
    {
        return computeDiscountedReward(cMaxStepsToGoal, policy, vObservedBeliefPoints, false, aiActionCount);
    }

    protected double computeDiscountedReward(int cMaxStepsToGoal, PolicyStrategy policy, int aiActionCount[], RandomGenerator g)
    {
        return computeDiscountedReward(cMaxStepsToGoal, policy, null, false, aiActionCount, g);
    }

    protected double computeDiscountedReward(int cMaxStepsToGoal, PolicyStrategy policy, Vector<BeliefState> vObservedBeliefPoints, int aiActionCount[], RandomGenerator g)
    {
        return computeDiscountedReward(cMaxStepsToGoal, policy, vObservedBeliefPoints, false, aiActionCount,g);
    }
/*
    private void printArray(int a[])
    {
        System.out.print("[");
        int ai[];
        int j = (ai = a).length;
        for(int i = 0; i < j; i++)
        {
            int v = ai[i];
            System.out.print((new StringBuilder(String.valueOf(v))).append(",").toString());
        }

        System.out.println("]");
    }
  */  
    public double computeDiscountedReward(int cMaxStepsToGoal, PolicyStrategy policy, Vector<BeliefState> vObservedBeliefPoints, boolean bExplore, int aiActionCount[])
    {
      return computeDiscountedReward(cMaxStepsToGoal, policy, vObservedBeliefPoints, bExplore, aiActionCount, m_rndGenerator);
    }
    public double computeDiscountedReward(int cMaxStepsToGoal, PolicyStrategy policy, Vector<BeliefState> vObservedBeliefPoints, boolean bExplore, int aiActionCount[],RandomGenerator m_rndGenerator)
    {
        double dDiscountedReward = 0.0D;
        double dCurrentReward = 0.0D;
        double dDiscountFactor = 1.0D;
        int iStep = 0;
        int iAction = 0;
        int iObservation = 0;
        int iState = chooseStartState(m_rndGenerator);
        int iNextState = 0;
        BeliefState bsCurrentBelief = BeliefStateFactory.getInstance().getInitialBeliefState();
        BeliefState bsNext = null;
        boolean bDone = false;
        int cRewards = 0;
        int cSameStates = 0;
        for(iStep = 0; iStep < cMaxStepsToGoal && !bDone; iStep++)
        {
            m_cSteps++;
            if(bExplore)
            {
                double dRand = m_rndGenerator.nextDouble();
                if(dRand > 0.10000000000000001D)
                    iAction = policy.getAction(bsCurrentBelief);
                else
                    iAction = m_rndGenerator.nextInt(m_cActions);
            } else
            {
                iAction = policy.getAction(bsCurrentBelief);
            }
            if(aiActionCount != null)
                aiActionCount[iAction]++;
            if(vObservedBeliefPoints != null)
            {
                bsCurrentBelief.setFactoryPersistence(true);
                vObservedBeliefPoints.add(bsCurrentBelief);
            }
            iNextState = execute(iAction, iState,m_rndGenerator);
            iObservation = observe(iAction, iNextState,m_rndGenerator);
            if(m_rtReward == RewardType.StateAction)
                dCurrentReward = R(iState, iAction);
            else
            if(m_rtReward == RewardType.StateActionState)
                dCurrentReward = R(iState, iAction, iNextState);
            dDiscountedReward += dCurrentReward * dDiscountFactor;
            dDiscountFactor *= m_dGamma;
            if(dCurrentReward > 0.0D)
                cRewards++;
            bDone = endADR(iNextState, dCurrentReward);
            
            //TODO laurent
//            System.out.println(getStateName(iState) + "-"+iAction+"->" + getStateName(iNextState)+ " : R="+dCurrentReward); 
            
            bsNext = bsCurrentBelief.nextBeliefState(iAction, iObservation);
            if(tr(iState, iAction, iNextState) == 0.0D)
                System.err.println((new StringBuilder("tr(")).append(iState).append(",").append(iAction).append(",").append(iNextState).append(")=").append(tr(iState, iAction, iNextState)).toString());
            if(O(iAction, iNextState, iObservation) == 0.0D)
                System.err.println((new StringBuilder("O(")).append(iAction).append(",").append(iState).append(",").append(iObservation).append(")=").append(O(iAction, iState, iObservation)).toString());
            if(bsNext == null || bsNext.valueAt(iNextState) == 0.0D)
            {
                iNextState = iState;
                bsNext = bsCurrentBelief;
            }
            if(iState != iNextState)
                cSameStates = 0;
            else
                cSameStates++;
            if(bsNext.valueAt(iNextState) == 0.0D)
            {
                Logger.getInstance().logError("POMDP", "computeDiscountedReward", (new StringBuilder("next state is null or has zero probability at step ")).append(iStep).append(", total step count ").append(m_cSteps).toString());
                System.out.println((new StringBuilder("current ")).append(bsCurrentBelief).append(", a = ").append(iAction).append(", o = ").append(iObservation).append(", ").append(m_cSteps).toString());
                System.out.println((new StringBuilder("s = ")).append(iState).append(", pr(s) = ").append(bsCurrentBelief.valueAt(iState)).toString());
                System.out.println((new StringBuilder("next ")).append(bsNext).append(", s' = ").append(iNextState).append(", pr(s') = ").append(bsNext.valueAt(iNextState)).toString());
                BeliefStateFactory.getInstance().cacheBeliefStates(false);
                bsNext = bsCurrentBelief.nextBeliefState(iAction, iObservation);
                System.exit(0);
                return -1.7976931348623157E+308D;
            }
            iState = iNextState;
            bsCurrentBelief.release();
            bsCurrentBelief = bsNext;
        }

        bsCurrentBelief.release();
        return dDiscountedReward;
    }

    protected boolean endADR(int iState, double dReward)
    {
        return terminalStatesDefined() && isTerminalState(iState) || !terminalStatesDefined() && dReward > 0.0D;
    }

    public double computeMDPDiscountedReward(int cMaxStepsToGoal, MDPValueFunction policy, boolean bExplore, Vector<BeliefState> vBeliefPoints)
    {
        double dDiscountedReward = 0.0D;
        double dCurrentReward = 0.0D;
        double dDiscountFactor = 1.0D;
        int iStep = 0;
        int iAction = 0;
        int iObservation = 0;
        int cRewards = 0;
        int iState = chooseStartState();
        int iNextState = 0;
        boolean bDone = false;
        double dProb = 0.0D;
        double dExplorationFactor = 0.20000000000000001D;
        BeliefState bsCurrentBelief = null;
        BeliefState bsNext = null;
        if(vBeliefPoints != null)
            bsCurrentBelief = BeliefStateFactory.getInstance().getInitialBeliefState();
        policy.setExploration(false);
        for(iStep = 0; iStep < cMaxStepsToGoal && !bDone; iStep++)
        {
            iAction = policy.getAction(iState);
            if(bExplore)
            {
                dProb = m_rndGenerator.nextDouble();
                if(dProb < dExplorationFactor)
                    iAction = m_rndGenerator.nextInt(m_cActions);
            }
            iNextState = execute(iAction, iState);
            iObservation = observe(iAction, iNextState);
            if(m_rtReward == RewardType.StateAction)
                dCurrentReward = R(iState, iAction);
            else
            if(m_rtReward == RewardType.StateActionState)
                dCurrentReward = R(iState, iAction, iNextState);
            dDiscountedReward += dCurrentReward * dDiscountFactor;
            dDiscountFactor *= m_dGamma;
            if(dCurrentReward > 0.0D)
                cRewards++;
            bDone = endADR(iNextState, dCurrentReward);
            iState = iNextState;
            if(vBeliefPoints != null)
            {
              assert bsCurrentBelief != null;
                vBeliefPoints.add(bsCurrentBelief);
                bsNext = bsCurrentBelief.nextBeliefState(iAction, iObservation);
                bsCurrentBelief = bsNext;
            }
        }

        return dDiscountedReward;
    }

    public double simulate(int cMaxSteps, Vector<BeliefState> vBeliefPoints, PolicyStrategy policy)
    {
        try
        {
            return simulate(cMaxSteps, vBeliefPoints, cMaxSteps, policy, -1, cMaxSteps);
        }
        catch(IOException e)
        {
            System.out.println(e);
            e.printStackTrace();
            return 0.0D;
        }
    }

    protected double simulate(int cSteps, Vector<BeliefState> vBeliefPoints, int cMaxBeliefPoints, PolicyStrategy policy, int cEvalInterval, int cMaxNoRewardSteps)
        throws IOException
    {
        double dTotalReward = 0.0D;
        double dDiscountedReward = 0.0D;
        double dCurrentReward = 0.0D;
        double dDiscountFactor = 1.0D;
        int iStep = 0;
        int iAction = 0;
        int iObservation = 0;
        int cRewards = 0;
        double dReportRewards = 0.0D;
        double dNonExploringRewards = 0.0D;
        int iState = chooseStartState();
        int iNextState = 0;
        BeliefState bsCurrentBelief = BeliefStateFactory.getInstance().getInitialBeliefState();
        BeliefState bsNext = null;
        boolean bDone = false;
        int cSameBS = 0;
        int cNoRewardSteps = 0;
        long cCurrentMilliseconds = 0L;
        long cSeconds = 0L;
        long iStartTime = System.currentTimeMillis();
        long iEndTime = 0L;
        for(iStep = 0; iStep < cSteps && !bDone; iStep++)
        {
            iAction = policy.getAction(bsCurrentBelief);
            iNextState = execute(iAction, iState);
            iObservation = observe(iAction, iNextState);
            dCurrentReward = R(iState, iAction, iNextState);
            if(dCurrentReward > 0.0D)
            {
                cRewards++;
                cNoRewardSteps = 0;
                System.out.print('+');
            } else
            {
                cNoRewardSteps++;
                if (dCurrentReward<-1000d)
                  System.out.print('N');
                else if (dCurrentReward<0d)
                  System.out.print('-');
                else
                  System.out.print('.');
            }
            dReportRewards += dCurrentReward;
            dTotalReward += dCurrentReward;
            dDiscountedReward += dDiscountFactor * dCurrentReward;
            dDiscountFactor *= m_dGamma;
            if (getTerminalStates().contains(iNextState))
            {
              bsNext = BeliefStateFactory.getInstance().getInitialBeliefState();
              iNextState = chooseStartState();
              cNoRewardSteps = 0;
              dDiscountFactor = 1.0d;
              System.out.println();
            } else if(cMaxNoRewardSteps > 0 && cNoRewardSteps > cMaxNoRewardSteps)
            {
                bsNext = BeliefStateFactory.getInstance().getInitialBeliefState();
                iNextState = chooseStartState();
                cNoRewardSteps = 0;
//                System.out.println((new StringBuilder(String.valueOf(iStep))).append(") Unable to reach goal in ").append(cMaxNoRewardSteps).append(" steps, from state ").append(iState).append(" , reseting to state ").append(iNextState).append(" BS=").append(bsNext).toString());
            } else
            {
                if(iNextState == iState && isAbsorbing(iState))
                {
                    bsNext = BeliefStateFactory.getInstance().getInitialBeliefState();
                    iNextState = chooseStartState();
                } else
                {
                    bsNext = bsCurrentBelief.nextBeliefState(iAction, iObservation);
                    if(bsNext.valueAt(iNextState) == 0.0D)
                    {
                        System.out.println((new StringBuilder("simulate: BUGBUG next bs ")).append(bsNext).append(", next state ").append(iNextState).append(" bs ").append(bsCurrentBelief).append(",  state ").append(iState).append(" action ").append(iAction).append(" observation ").append(iObservation).toString());
                        bsNext = bsCurrentBelief.nextBeliefState(iAction, iObservation);
                    }
                }
                if(bsNext == null)
                {
                    System.out.println((new StringBuilder("Got null bs, bsCurrent = ")).append(bsCurrentBelief).append(" s = ").append(iState).append(" s' = ").append(iNextState).append(" b(s) = ").append(bsCurrentBelief.valueAt(iState)).append(" step = ").append(iStep).toString());
                    bsNext = BeliefStateFactory.getInstance().getInitialBeliefState();
                    iNextState = chooseStartState();
                    System.exit(0);
                }
                if(bsNext.equals(bsCurrentBelief))
                    cSameBS++;
                else
                    cSameBS = 0;
                if(vBeliefPoints != null && vBeliefPoints.size() < cMaxBeliefPoints && !vBeliefPoints.contains(bsCurrentBelief))
                {
                    vBeliefPoints.add(bsCurrentBelief);
                    if(cMaxBeliefPoints > 0 && vBeliefPoints.size() == cMaxBeliefPoints)
                        bDone = true;
                }
            }
            iState = iNextState;
            bsCurrentBelief = bsNext;
            if(cEvalInterval > 0 && iStep > 0 && iStep % cEvalInterval == 0)
            {
                iEndTime = System.currentTimeMillis();
                cCurrentMilliseconds = iEndTime - iStartTime;
                cSeconds += cCurrentMilliseconds / 1000L;
                policy.setExploration(false);
                m_bExploration = false;
                dNonExploringRewards = simulate(500, null, 0, policy, -1, cMaxNoRewardSteps);
                m_bExploration = true;
                policy.setExploration(true);
                String sInfo = (new StringBuilder("Status: ")).append(iStep).append(": ").append(" Time: ").append(cCurrentMilliseconds).append(" Reward: ").append(dNonExploringRewards).append(" ").append(policy.getStatus()).append(g_sNewline).toString();
                if(m_fosOutputFile != null)
                    m_fosOutputFile.write(sInfo.getBytes());
                System.out.println(sInfo);
                iStartTime = System.currentTimeMillis();
            }
        }

        System.out.println((new StringBuilder("Collected ")).append(cRewards).append(" rewards over ").append(iStep).append(" steps").toString());
        return dTotalReward / cSteps;
    }

    private boolean isAbsorbing(int iState)
    {
        int iAction = 0;
        for(iAction = 0; iAction < m_cActions; iAction++)
            if(tr(iState, iAction, iState) < 1.0D)
                return false;

        return true;
    }

    public int chooseStartState()
    {
        int iStartState = -1;
        double dInitialProb = m_rndGenerator.nextDouble();
        
        TIntDoubleIterator it = m_fStartState.getNonZeroEntries();
        double dProb = dInitialProb;
        while (it.hasNext() && dProb>0d)
        {
          it.advance();
          iStartState = it.key();
          dProb -= it.value();
        }
        
        return iStartState;
    }

    public int chooseStartState(RandomGenerator m_rndGenerator)
    {
        int iStartState = -1;
        double dInitialProb = m_rndGenerator.nextDouble();
        
        TIntDoubleIterator it = m_fStartState.getNonZeroEntries();
        double dProb = dInitialProb;
        while (it.hasNext() && dProb>0d)
        {
          it.advance();
          iStartState = it.key();
          dProb -= it.value();
        }
        
        return iStartState;
    }

    public Vector<BeliefState> computeOutlyingBeliefPoints(int cPoints)
    {
        Vector<BeliefState> vBeliefPoints = new Vector<BeliefState>();
        BeliefStateFactory bsf = BeliefStateFactory.getInstance();
        BeliefState bsNext = null;
        int iPoint = 0;
        String sDistances = "";
        vBeliefPoints.add(bsf.getInitialBeliefState());
        for(iPoint = 0; iPoint < cPoints; iPoint++)
        {
            bsNext = bsf.computeFarthestSuccessor(vBeliefPoints);
            if(bsNext != null)
            {
                String sDist = (new StringBuilder(String.valueOf(bsf.distance(vBeliefPoints, bsNext)))).toString();
                if(sDist.length() > 4)
                    sDist = sDist.substring(0, 4);
                sDistances = (new StringBuilder(String.valueOf(sDistances))).append(sDist).append(",").toString();
                vBeliefPoints.add(bsNext);
            }
            if(iPoint > 0 && iPoint % 10 == 0)
            {
                Iterator<BeliefState> it = vBeliefPoints.iterator();
                double cP = vBeliefPoints.size();
                int cPreds = 0;
                int cMaxPreds = 0;
                double dAvg = 0.0D;
                double dR = 0.0D;
                double dMaxR = 0.0D;
                BeliefState bsCur = null;
                while(it.hasNext()) 
                {
                    bsCur = it.next();
                    cPreds = bsCur.countPredecessors();
                    dAvg += cPreds / cP;
                    if(cPreds > cMaxPreds)
                        cMaxPreds = cPreds;
                    dR = immediateReward(bsCur);
                    if(dR > dMaxR)
                        dMaxR = dR;
                }
                Runtime rtRuntime = Runtime.getRuntime();
                System.out.println((new StringBuilder(String.valueOf(iPoint))).append(")").append(" |B| = ").append(vBeliefPoints.size()).append(" distances ").append(sDistances).append(" avg preds = ").append(round(dAvg, 3)).append(" max preds ").append(cMaxPreds).append(" |B| = ").append(BeliefStateFactory.getInstance().getBeliefStateCount()).append(" max memory ").append(rtRuntime.maxMemory() / 0xf4240L).append(" actual memory ").append((rtRuntime.totalMemory() - rtRuntime.freeMemory()) / 0xf4240L).append(" free memory ").append(rtRuntime.freeMemory() / 0xf4240L).toString());
                sDistances = "";
            }
        }

        return vBeliefPoints;
    }

    public void computeValueFunction(String sMethodName)
    {
        int cMaxIterations = 100;
        double dEpsilon = 0.10000000000000001D;
        Vector<BeliefState> vBeliefPoints = new Vector<BeliefState>();
        BeliefStateFactory.getInstance().clear();
        m_vfPolicy.valueIteration(vBeliefPoints, cMaxIterations, dEpsilon, this, 23.5D);
        double dDiscountedReward = computeAverageDiscountedReward(100, 500, m_vfPolicy);
        System.out.println((new StringBuilder("ADR = ")).append(dDiscountedReward).append(" status: ").append(m_vfPolicy.getStatus()).toString());
    }

    public void computeValueFunction(String sMethodName, Vector<BeliefState> vBeliefPoints, double dTargetADR)
    {
        int cMaxIterations = 25;
        double dEpsilon = 0.01D;
        if(sMethodName.equals("TopSearch"))
            m_vfPolicy = new TopSearch(this);
     
        clearStatistics();
        m_vfPolicy.initRandomGenerator(m_iRandomSeed);
        double dDiscountedReward = -10000D;
        m_rndGenerator.init(0L);
        dDiscountedReward = computeAverageDiscountedReward(150, 200, m_vfPolicy);
        System.out.println("dDiscountedReward = " + dDiscountedReward + " dTargetADR =  " + dTargetADR);
        if (dDiscountedReward>dTargetADR)
        {
          dTargetADR = dDiscountedReward + 1;
          System.out.println("dDiscountedReward = " + dDiscountedReward + " dTargetADR =  " + dTargetADR);
        }
        
        System.out.println("################### Start Value Iteration ###################");
        
        m_vfPolicy.valueIteration(vBeliefPoints, cMaxIterations, dEpsilon, this, dTargetADR);

        System.out.println("################### End Value Iteration ###################");
        
//        m_rndGenerator.init(0L);
//        dDiscountedReward = computeAverageDiscountedReward(150, 200, m_vfPolicy);
//        System.out.println("dDiscountedReward = " + dDiscountedReward + " dTargetADR =  " + dTargetADR);
//
//        System.out.println((new StringBuilder("ADR = ")).append(dDiscountedReward).append(" status: ").append(m_vfPolicy.getStatus(BeliefStateFactory.getInstance().getInitialBeliefState())).toString());
//        BufferedWriter out;
//        try
//        {
//        	out = new BufferedWriter( new FileWriter(sMethodName + ".xls", true));
//        	out.write("sProblemName: " + getName() + "ADR: "  + dDiscountedReward + " status: " + m_vfPolicy.getStatus(BeliefStateFactory.getInstance().getInitialBeliefState()));
//        	out.write('\n');
//        	out.close();
//        }
//        catch(Exception e)
//        {
//            e.printStackTrace();
//        }
    }

    public void simulateValueIteration()
        throws IOException
    {
        Vector<BeliefState> vBeliefPoints = new Vector<BeliefState>();
        int iStep = 0;
        int cSteps = 1;
        m_vfPolicy = new ValueIteration(this);
        System.out.println("Gathering belief points");
        double dTotalReward = simulate(30000, vBeliefPoints, 10000, 0, -1);
        System.out.println((new StringBuilder(String.valueOf(iStep))).append(") total = ").append(dTotalReward).toString());
        System.out.println((new StringBuilder("Done - gathered ")).append(vBeliefPoints.size()).append(" belief points").toString());
        for(iStep = 0; iStep < cSteps; iStep++)
        {
//            m_vfPolicy.valueIteration(vBeliefPoints, 1000, 0.10000000000000001D);
            dTotalReward = simulate(30000, 1, -1);
            System.out.println((new StringBuilder(String.valueOf(iStep))).append(") total = ").append(dTotalReward).toString());
            dTotalReward = simulate(30000, 4, -1);
            System.out.println((new StringBuilder(String.valueOf(iStep))).append(") total = ").append(dTotalReward).toString());
        }

    }

    protected void setEnvironmentType(PolicyStrategy policy)
    {
        policy.setEnvironmentType(true);
    }

    public void clearStatistics()
    {
        AlphaVector.clearDotProductCount();
        BeliefStateFactory.clearBeliefUpdateCount();
        BeliefStateFactory.clearInternalBeliefStateCache();
    }

    public boolean countStatistics(boolean bCount)
    {
        boolean bPrevious = m_bCountStatistics;
        m_bCountStatistics = bCount;
        AlphaVector.countDotProduct(bCount);
        BeliefStateFactory.countBeliefUpdates(bCount);
        return bPrevious;
    }

    public boolean isTerminalState(int iState)
    {
        if(terminalStatesDefined())
            return m_vTerminalStates.contains(iState);
        return maxReward(iState) > 0.0D;
    }

    protected double maxReward(int iState)
    {
        int iAction = 0;
        double dReward = 0.0D;
        double dMaxReward = -1.7976931348623157E+308D;
        for(iAction = 0; iAction < m_cActions; iAction++)
        {
            dReward = R(iState, iAction);
            if(dReward > dMaxReward)
                dMaxReward = dReward;
        }

        return dMaxReward;
    }

    public boolean terminalStatesDefined()
    {
        return m_vTerminalStates != null;
    }

    public int getStateCount()
    {
        return m_cStates;
    }

    public int getActionCount()
    {
        return m_cActions;
    }

    public int getObservationCount()
    {
        return m_cObservations;
    }

    public double getDiscountFactor()
    {
        return m_dGamma;
    }

    public void setDiscountFactor(double gamma)
    {
        m_dGamma=gamma;
    }

    public TIntDoubleIterator getNonZeroTransitions(int iStartState, int iAction)
    {
        return m_fTransition.getNonZeroEntries(iStartState, iAction);
    }

    public TIntDoubleIterator getNonZeroBackwardTransitions(int iAction, int iEndState)
    {
        return null;
    }

    public double probStartState(int iState)
    {
        return m_fStartState.valueAt(iState);
    }

    public double getMinR()
    {
        return m_fReward.getMinValue();
    }

    public double getMaxR()
    {
        return m_fReward.getMaxValue();
    }

    public double getMaxMinR()
    {
        int iAction = 0;
        double dMaxR = -1.7976931348623157E+308D;
        for(iAction = 0; iAction < m_cActions; iAction++)
            if(m_adMinActionRewards[iAction] > dMaxR)
                dMaxR = m_adMinActionRewards[iAction];

        return dMaxR;
    }

    public int getStartStateCount()
    {
        return m_fStartState.countNonZeroEntries();
    }

    public TIntDoubleIterator getStartStates()
    {
        return m_fStartState.getNonZeroEntries();
    }

    public void initRandomGenerator(long iSeed)
    {
        m_rndGenerator.init(iSeed);
    }

    public void setRandomSeed(long iSeed)
    {
        m_iRandomSeed = iSeed;
    }

    public AlphaVector newAlphaVector()
    {
        return new TabularAlphaVector(null, 0, this);
    }

    public boolean isValid(int iState)
    {
        return true;
    }

    /**
     * @return a pseudo-collection of all integers between 0 and m_cStates.
     * {@link ObsevationAwareMDPValueFunction#computeValidStates}
     * {@link MDPValueFunction#getValidStates} 
     */
    public Collection<Integer> getValidStates()
    {
        return new IntegerCollection(0, m_cStates);
    }

    public boolean isFactored()
    {
        return false;
    }

    public String getName()
    {
        return m_sName;
    }

    public int[] getBasisObservations()
    {
        return m_adBasisObservations;
    }

    public int getBasisObservationsCount()
    {
        return m_adBasisObservations.length;
    }

    public int[] getNonBasisObservations()
    {
        return m_adNonBasisObservations;
    }

    public double immediateReward(BeliefState bs)
    {
        int iAction = 0;
        double dReward = 0.0D;
        double dMaxReward = -1.7976931348623157E+308D;
        if(bs == null)
            return 0.0D;
        dReward = bs.getActionImmediateReward(iAction);
        if(dReward != -1.7976931348623157E+308D)
            return dReward;
        for(iAction = 0; iAction < m_cActions; iAction++)
        {
            dReward = immediateReward(bs, iAction);
            if(dReward > dMaxReward)
                dMaxReward = dReward;
        }

        bs.setImmediateReward(dMaxReward);
        return dMaxReward;
    }

    public double immediateReward(BeliefState bs, int iAction)
    {
        if(bs == null)
            return 0.0D;
        double dReward = bs.getActionImmediateReward(iAction);
        if(dReward != -1.7976931348623157E+308D)
        {
            return dReward;
        } else
        {
            dReward = computeImmediateReward(bs, iAction);
            bs.setActionImmediateReward(iAction, dReward);
            return dReward;
        }
    }

    protected double computeImmediateReward(BeliefState bs, int iAction)
    {
        TIntDoubleIterator it = bs.getNonZeroEntries();
        int iState = 0;
        double dReward = 0.0D;
        double dPr = 0.0D;
        double dValue = 0.0D;
        while(it.hasNext()) 
        {
            it.advance();
            iState = it.key();
            dPr = it.value();
            dValue = R(iState, iAction);
            dReward += dPr * dValue;
        }
        return dReward;
    }

    public TIntArrayList getObservationRelevantStates()
    {
        return m_vObservationStates;
    }

    public Graph getGraph()
    {
        TIntArrayList states = new TIntArrayList(m_cStates);
        Vector<TIntHashSet> succs = new Vector<TIntHashSet>(m_cStates);
        for(int s = 0; s < m_cStates; s++)
        {
            states.add(s);
            succs.add(s, new TIntHashSet());
            for(int a = 0; a < m_cActions; a++)
            {
                for(TIntDoubleIterator ientry = m_fTransition.getNonZeroEntries(s, a); ientry.hasNext(); )
                {
                  ientry.advance();
                    succs.get(s).add(ientry.key());
                }
            }
        }
        return new Graph(states, succs);
    }

    public AcyclicShortestPath getAcyclicShortestPath()
    {
        TIntArrayList states = new TIntArrayList(m_cStates);
        Vector<TIntHashSet> succs = new Vector<TIntHashSet>(m_cStates);
        for(int s = 0; s < m_cStates; s++)
        {
            states.add(s);
            succs.add(s, new TIntHashSet());
            for(int a = 0; a < m_cActions; a++)
            {
              for(TIntDoubleIterator ientry = m_fTransition.getNonZeroEntries(s, a); ientry.hasNext(); )
              {
                ientry.advance();
                  succs.get(s).add(ientry.key());
              }
            }
        }
        
        return new AcyclicShortestPath(states, succs);
    }

    protected Function m_fTransition;
    protected Function m_fReward;
    protected SparseTabularFunction m_fObservation;
    protected Function m_fStartState;
    protected Vector<String> m_vStateNames;
    protected TObjectIntHashMap<String> m_mStates;
    protected TObjectIntHashMap<String> m_mActionIndexes;
    protected Vector<String> m_mActionNames;
    protected TObjectIntHashMap<String> m_mObservations;
    protected int m_cStates;
    protected int m_cActions;
    protected int m_cObservations;
    protected double m_dGamma;
    protected String m_sRewardType;
    protected ValueIteration m_vfPolicy;
    protected FileOutputStream m_fosOutputFile;
    protected static String g_sNewline = System.getProperty("line.separator");
    protected static int g_sMaxTabularSize = 250;
    protected boolean m_bExploration;
    protected TIntArrayList m_vTerminalStates;
    protected TIntArrayList m_vObservationStates;
    protected double m_adStoredRewards[][];
    protected double m_adMinActionRewards[];
    protected int m_adBasisObservations[];
    protected int m_adNonBasisObservations[];
    protected static final double MAX_INF = 1.7976931348623157E+308D;
    protected static final double MIN_INF = -1.7976931348623157E+308D;
    protected RandomGenerator m_rndGenerator;
    protected long m_iRandomSeed;
    public boolean m_bGBasedBackup;
    protected String m_sName;
    protected RewardType m_rtReward;
    protected boolean m_bCountStatistics;
    protected int m_cSteps;
    
    public TIntArrayList getTerminalStates()
    {
      return m_vTerminalStates;
    }

}
