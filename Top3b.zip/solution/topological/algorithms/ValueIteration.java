// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   ValueIteration.java

package solution.topological.algorithms;

import gnu.trove.TIntDoubleIterator;

import java.util.Iterator;
import java.util.Vector;

import solution.topological.environments.POMDP;
import solution.topological.utilities.*;

// Referenced classes of package pomdp.algorithms:
//            PolicyStrategy

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 8 juil. 2009
 *
 */
public class ValueIteration extends PolicyStrategy
{

  static final private int QMDP = 0;
  static final private int MIN = 1;
  static final private int BLIND = 2;
  
  /**
   * The way initial value function is initialised.
   * May be QMDP, MIN or BLIND
   */
  static final public int INIT = MIN;
  
    public ValueIteration(POMDP pomdp)
    {
        m_dEpsilon = 0.01D;
        cG = 0;
        m_dMinimalProb = 0.0D;
        m_cComputations = 0L;
        m_pPOMDP = pomdp;
        m_cStates = m_pPOMDP.getStateCount();
        m_cActions = m_pPOMDP.getActionCount();
        m_cObservations = m_pPOMDP.getObservationCount();
        m_dGamma = m_pPOMDP.getDiscountFactor();
        m_cBackups = 0;
        m_avMaxValues = null;
        m_bConverged = false;
        m_cElapsedExecutionTime = 0L;
        m_cCPUExecutionTime = 0L;
        m_dFilteredADR = 0.0D;
        m_cDotProducts = 0L;
        m_cTimeInBackup = 0L;
        m_cTimeInHV = 0L;
        m_cTimeInV = 0L;
        m_cAlphaVectorNodes = 0L;
        m_rndGenerator = new RandomGenerator("ValueIteration", 0L);
        m_vValueFunction = new LinearValueFunctionApproximation(m_dEpsilon, false);
        m_vValueFunctions = new LinearValueFunctionApproximation[m_cActions];
        computeStepsPerTrial();
switch (INIT)
{
  case QMDP:
        initValueFunctionUsingQMDP(m_vValueFunction); break;
  case MIN:
        initValueFunctionToMin(); break;
  case BLIND:
        initValueFunctionUsingBlindPolicy(m_vValueFunction); break;
}
        for(int iAction = 0; iAction < m_cActions; iAction++)
            m_vValueFunctions[iAction] = m_vValueFunction.getLinearQValueFunction(iAction);

    }

    public void initRandomGenerator(long iSeed)
    {
        m_rndGenerator.init(iSeed);
    }

    protected void computeStepsPerTrial()
    {
        int cSteps = 0;
        double dTailSum = 0.0D;
        for(cSteps = 100; cSteps < 10000; cSteps++)
        {
            dTailSum = Math.pow(m_dGamma, cSteps) / (1.0D - m_dGamma);
            if(dTailSum > 0.0050000000000000001D)
                continue;
            System.out.println((new StringBuilder("#Steps per trials = ")).append(cSteps).toString());
            g_cStepsPerTrial = cSteps;
            break;
        }

    }

    public double valueAt(BeliefState bs)
    {
        return m_vValueFunction.valueAt(bs);
    }

    public int getBestAction(BeliefState bs)
    {
        return m_vValueFunction.getBestAction(bs);
    }

    public AlphaVector getMaxAlpha(BeliefState bs)
    {
        return m_vValueFunction.getMaxAlpha(bs);
    }

    protected double diff(double d1, double d2)
    {
        if(d1 > d2)
            return d1 - d2;
        else
            return d2 - d1;
    }

    @Override
    public String toString()
    {
        String sVector = "[";
        String sValue = "";
        for(Iterator<AlphaVector> it = m_vValueFunction.iterator(); it.hasNext();)
        {
            sValue = it.next().toString();
            sVector = (new StringBuilder(String.valueOf(sVector))).append(sValue).append(",").toString();
        }

        sVector = (new StringBuilder(String.valueOf(sVector.substring(0, sVector.length() - 1)))).append("]").toString();
        return sVector;
    }
/*
    protected Iterator<?> backwardIterator(Vector<?> vElements)
    {
        Vector vBackward = new Vector();
        int iElement = 0;
        int cElements = vElements.size();
        for(iElement = cElements - 1; iElement >= 0; iElement--)
            vBackward.add(vElements.get(iElement));

        return vBackward.iterator();
    }

    protected Iterator randomPermutation(Vector vElements)
    {
        Vector vOriginal = new Vector(vElements);
        Vector vPermutation = new Vector();
        int idx = 0;
        for(; vOriginal.size() > 0; vPermutation.add(vOriginal.remove(idx)))
            idx = m_rndGenerator.nextInt(vOriginal.size());

        return vPermutation.iterator();
    }

    protected void permutate(Vector vElements, int cSwaps)
    {
        int iSwap = 0;
        int iFirstElement = 0;
        int iSecondElement = 0;
        int cElements = vElements.size();
        Object oAux = null;
        for(iSwap = 0; iSwap < cSwaps; iSwap++)
        {
            iFirstElement = m_rndGenerator.nextInt(cElements);
            iSecondElement = m_rndGenerator.nextInt(cElements);
            oAux = vElements.get(iFirstElement);
            vElements.set(iFirstElement, vElements.get(iSecondElement));
            vElements.set(iSecondElement, oAux);
        }

    }
*/
    protected AlphaVector G(int iAction, BeliefState bs)
    {
        return G(iAction, bs, m_vValueFunction);
    }

    protected AlphaVector G(int iAction, BeliefState bs, LinearValueFunctionApproximation vValueFunction)
    {
        AlphaVector avAlpha = null;
        AlphaVector avMax = null;
        AlphaVector avG = null;
        AlphaVector avSum = null;
        AlphaVector avMaxOriginal = null;
        int iObservation = 0;
        Iterator<AlphaVector> it = null;
        double dMaxValue = (-1.0D / 0.0D);
        double dValue = 0.0D;
        double dProb = 0.0D;
        double dSumProbs = 0.0D;
        for(iObservation = 0; iObservation < m_cObservations; iObservation++)
        {
            dProb = bs.probabilityOGivenA(iAction, iObservation);
            dSumProbs += dProb;
            if(dProb > 0.0D)
            {
                it = vValueFunction.iterator();
                dMaxValue = (-1.0D / 0.0D);
                while(it.hasNext()) 
                {
                    avAlpha = it.next();
                    avG = avAlpha.G(iAction, iObservation);
                    dValue = avG.dotProduct(bs);
                    if(avMax == null || dValue > dMaxValue)
                    {
                        dMaxValue = dValue;
                        avMax = avG;
                        avMaxOriginal = avAlpha;
                    }
                }
            } else
            {
                dMaxValue = 0.0D;
                avMaxOriginal = vValueFunction.getLast();
                avMax = avMaxOriginal.G(iAction, iObservation);
            }
            if(avSum == null)
                avSum = avMax.copy();
            else
            if(avMax != null)
                avSum.accumulate(avMax);
            avMax = null;
        }

        if(diff(dSumProbs, 1.0D) > 0.01D)
            Logger.getInstance().log("VI", 0, "G", (new StringBuilder(String.valueOf(cG))).append(") Sum of probabilities is ").append(dSumProbs).toString());
        AlphaVector avResult = avSum.addReward(iAction);
        avResult.setAction(iAction);
        cG++;
        avSum.release();
        return avResult;
    }

    protected AlphaVector backup(BeliefState bs, int iAction)
    {
        AlphaVector avNext[] = new AlphaVector[m_cObservations];
        findMaxAlphas(iAction, bs, m_vValueFunction, avNext);
        AlphaVector avNew = G(iAction, m_vValueFunction, avNext);
        avNew.setWitness(bs);
        return avNew;
    }

    protected AlphaVector backup(BeliefState bs)
    {
        return backup(bs, m_vValueFunction);
    }

    protected AlphaVector backup(BeliefState bs, LinearValueFunctionApproximation vValueFunction)
    {
        AlphaVector avResult = null;
        long lTimeBefore = 0L;
        long lTimeAfter = 0L;
        if(ExecutionProperties.getReportOperationTime())
            lTimeBefore = JProf.getCurrentThreadCpuTimeSafe();
        if(m_pPOMDP.useClassicBackup())
            avResult = backupGBased(bs, vValueFunction);
        else
            avResult = backupTauBased(bs, vValueFunction);
        m_cBackups++;
        if(ExecutionProperties.getReportOperationTime())
        {
            lTimeAfter = JProf.getCurrentThreadCpuTimeSafe();
            m_cTimeInBackup += (lTimeAfter - lTimeBefore) / 0xf4240L;
            m_cAlphaVectorNodes += avResult.size();
            if(m_cBackups % 25 == 0)
            {
                Logger.getInstance().log("ValueIteration", 0, "backup", (new StringBuilder("After ")).append(m_cBackups).append(" backups, avg time for backup ").append(m_cTimeInBackup / m_cBackups).toString());
                Logger.getInstance().log("ValueIteration", 0, "backup", (new StringBuilder("Average alpha vector size ")).append(m_cAlphaVectorNodes / m_cBackups).toString());
            }
        }
        return avResult;
    }

    /**
     * Computes the alpha-vector for the specified belief-state, based on alpha-vectors known for horizon (t-1)
     * @param bs the belief-state to compute for
     * @param vValueFunction the (t-1) alpha-vectors
     * @return the alpha-vector
     */
    protected AlphaVector backupTauBased(BeliefState bs, LinearValueFunctionApproximation vValueFunction)
    {
        AlphaVector avMax = null;
        double dValue = 0.0D;
        double dMaxValue = -1.7976931348623157E+308D;
        int iAction = 0;
        int iMaxAction = -1;
        AlphaVector aNext[] = new AlphaVector[m_cObservations];
        AlphaVector aBest[] = null;
        for(iAction = 0; iAction < m_cActions; iAction++)
        {
            dValue = findMaxAlphas(iAction, bs, vValueFunction, aNext);
            // Here, aNext contains the best alpha-vector for each possible observation after using iAction from bs
            // dValue is the expected value of bs
            if(dValue >= dMaxValue)
            {
                dMaxValue = dValue;
                aBest = aNext.clone();
                iMaxAction = iAction;
            }
        }

        avMax = G(iMaxAction, vValueFunction, aBest);
        avMax.setWitness(bs);
        bs.addBackup();
        return avMax;
    }

    /**
     * Computes the Alpha-vector whose value is equivalent to using the specified action and then aNext depending on the received observation 
     * @param iAction the action to use
     * @param vValueFunction the current set of alpha-vectors
     * @param aNext the array[observation] of alpha-vectors to use after receiving an observation  
     * @return the Alpha-Vector
     */
    protected AlphaVector G(int iAction, LinearValueFunctionApproximation vValueFunction, AlphaVector aNext[])
    {
        AlphaVector avAlpha = null;
        AlphaVector avG = null;
        AlphaVector avSum = null;
        AlphaVector avResult = null;
        int iObservation = 0;
        for(iObservation = 0; iObservation < m_cObservations; iObservation++)
        {
            avAlpha = aNext[iObservation];
            avG = avAlpha.G(iAction, iObservation);
            if(avSum == null)
                avSum = avG.copy();
            else
                avSum.accumulate(avG);
        }

        avResult = avSum.addReward(iAction);
        avResult.setSuccessorLinks(aNext);
        avResult.setAction(iAction);
        cG++;
        avSum.release();
        return avResult;
    }

    /**
     * Considers the specified  action in the specified belief-state.
     * Fills aNext with the best alpha-vector for each observation.  
     * @param iAction the action to consider
     * @param bs the belief-state to consider
     * @param vValueFunction the current value-function
     * @param aNext the array[observation] to fill with best alpha-vectors
     * @return the expected value of this action, considering all possible observations with their probabilities.
     */
    private double findMaxAlphas(int iAction, BeliefState bs, LinearValueFunctionApproximation vValueFunction, AlphaVector aNext[])
    {
        AlphaVector avAlpha = null;
        int iObservation = 0;
        double dSumValues = 0.0D;
        double dValue = 0.0D;
        double dProb = 0.0D;
        double dSumProbs = 0.0D;
        BeliefState bsSuccessor = null;
        boolean bCache = BeliefStateFactory.getInstance().isCachingBeliefStates();
        BeliefStateFactory.getInstance().cacheBeliefStates(false);
        for(iObservation = 0; iObservation < m_cObservations; iObservation++)
        {
            dProb = bs.probabilityOGivenA(iAction, iObservation);
            dSumProbs += dProb;
            if(dProb > 0.0D)
            {
                bsSuccessor = bs.nextBeliefState(iAction, iObservation);
                avAlpha = vValueFunction.getMaxAlpha(bsSuccessor);
                try
                {
                    dValue = avAlpha.dotProduct(bsSuccessor);
                }
                catch(Exception e)
                {
                    System.err.println((new StringBuilder("vValueFunction=")).append(vValueFunction).append("\tavAlpha=").append(avAlpha).append("\tbsCurrent=").append(bs).append("\tbsSuccessor=").append(bsSuccessor).toString());
                    e.printStackTrace();
                }
                dSumValues += dValue * dProb;
            } else
            {
                avAlpha = vValueFunction.getLast();
            }
            aNext[iObservation] = avAlpha;
        }

        dSumValues /= dSumProbs;
        dSumValues *= m_pPOMDP.getDiscountFactor();
        dSumValues += m_pPOMDP.immediateReward(bs, iAction);
        BeliefStateFactory.getInstance().cacheBeliefStates(bCache);
        return dSumValues;
    }

    protected AlphaVector backupGBased(BeliefState bs, LinearValueFunctionApproximation vValueFunction)
    {
        AlphaVector avMax = null;
        AlphaVector avCurrent = null;
        double dValue = 0.0D;
        double dMaxValue = -1.7976931348623157E+308D;
        int iAction = 0;
        if(bs.getMaxErrorAction() == -1)
        {
            for(iAction = 0; iAction < m_cActions; iAction++)
            {
                avCurrent = G(iAction, bs, vValueFunction);
                dValue = avCurrent.dotProduct(bs);
                if(dValue >= dMaxValue)
                {
                    dMaxValue = dValue;
                    if(avMax != null)
                        avMax.release();
                    avMax = avCurrent;
                } else
                {
                    avCurrent.release();
                }
            }

        } else
        {
            avMax = G(bs.getMaxErrorAction(), bs, vValueFunction);
            bs.setMaxErrorAction(-1);
        }
        avMax.setWitness(bs);
        bs.addBackup();
        return avMax;
    }    

    protected double getMinReward()
    {
        double dMinValue = (1.0D / 0.0D);
        double dMinStateValue = 0.0D;
        double dValue = 0.0D;
        int iState = 0;
        int iAction = 0;
        int iNextState = 0;
        for(iState = 0; iState < m_cStates; iState++)
        {
            dMinStateValue = (1.0D / 0.0D);
            for(iAction = 0; iAction < m_cActions; iAction++)
                for(iNextState = 0; iNextState < m_cStates; iNextState++)
                {
                    dValue = m_pPOMDP.R(iState, iAction, iNextState);
                    if(dValue < dMinStateValue)
                        dMinStateValue = dValue;
                }


            if(dMinStateValue < dMinValue)
                dMinValue = dMinStateValue;
        }

        return dMinValue;
    }

    protected double getMaxReward()
    {
        double dMaxValue = (-1.0D / 0.0D);
        double dMaxStateValue = 0.0D;
        double dValue = 0.0D;
        int iState = 0;
        int iAction = 0;
        for(iState = 0; iState < m_cStates; iState++)
        {
            dMaxStateValue = (-1.0D / 0.0D);
            for(iAction = 0; iAction < m_cActions; iAction++)
            {
                for(int iNextState = 0; iNextState < m_cStates; iNextState++)
                {
                    dValue = m_pPOMDP.R(iState, iAction, iNextState);
                    if(dValue > dMaxStateValue)
                        dMaxStateValue = dValue;
                }

            }

            if(dMaxStateValue > dMaxValue)
                dMaxValue = dMaxStateValue;
        }

        return dMaxValue;
    }

    protected double getMaxMinR()
    {
        return m_pPOMDP.getMaxMinR();
    }

    protected void initValueFunctionToMin()
    {
        m_vValueFunction = new LinearValueFunctionApproximation(m_dEpsilon, false);
        initValueFunctionToMin(m_vValueFunction);
    }

    protected void initValueFunctionToMin(LinearValueFunctionApproximation vValueFunction)
    {
        System.out.println("Init value function to min");
        double dMinValue = getMaxMinR();
        double dDefaultValue = dMinValue / (1.0D - m_dGamma);
        BeliefState bsUniform = BeliefStateFactory.getInstance().getUniformBeliefState();
        System.out.println((new StringBuilder("Min R value = ")).append(dMinValue).append(" init value = ").append(dDefaultValue).toString());
        AlphaVector avMin = null;
        avMin = m_pPOMDP.newAlphaVector();
        avMin.setAllValues(dDefaultValue);
        avMin.finalizeValues();
        avMin.setWitness(bsUniform);
        vValueFunction.add(avMin);
    }

    protected void initValueFunctionUsingBlindPolicy(int cMaxIterations)
    {
        initValueFunctionUsingBlindPolicy(cMaxIterations, m_vValueFunction);
    }

    protected void initValueFunctionUsingBlindPolicy(LinearValueFunctionApproximation vValueFunction)
    {
        int iAction = 0;
        int iState = 0;
        int iEndState = 0;
        int iIteration = 0;
        double dValue = 0.0D;
        double dNewValue = 0.0D;
        double dReward = 0.0D;
        double dDiff = 0.0D;
        double dMaxDiff = 0.0D;
        double dTr = 0.0D;
        double dSum = 0.0D;
        AlphaVector av = null;
        AlphaVector avNext = null;
        double dMaxResidual = (1.0D / 0.0D);
        TIntDoubleIterator itNonZero = null;
        LinearValueFunctionApproximation vMin = new LinearValueFunctionApproximation(m_dEpsilon, false);
        BeliefState bsUniform = BeliefStateFactory.getInstance().getUniformBeliefState();
        if(m_sBlindPolicyValueFunctionFileName != null)
            try
            {
                m_vValueFunction.load(m_sBlindPolicyValueFunctionFileName, m_pPOMDP);
                System.out.println("Blind policy loaded successfully");
                return;
            }
            catch(Exception e)
            {
                System.out.println((new StringBuilder("Could not load blind policy - ")).append(e).toString());
            }
        System.out.println("Begin blind policy computation");
        initValueFunctionToMin(vMin);
        for(iAction = 0; iAction < m_cActions; iAction++)
        {
            av = vMin.elementAt(0);
            iIteration = 0;
            for(dMaxResidual = (1.0D / 0.0D); dMaxResidual > 0.10000000000000001D;)
            {
                avNext = av.newAlphaVector();
                dMaxDiff = 0.0D;
                for(iState = 0; iState < m_cStates; iState++)
                {
                    dSum = 0.0D;
                    for(itNonZero = m_pPOMDP.getNonZeroTransitions(iState, iAction); itNonZero.hasNext();)
                    {
                      itNonZero.advance();
                        iEndState = itNonZero.key();
                        dTr = itNonZero.value();
                        dValue = av.valueAt(iEndState);
                        dSum += dTr * dValue;
                    }

                    dReward = m_pPOMDP.R(iState, iAction);
                    dNewValue = dReward + dSum * m_dGamma;
                    avNext.setValue(iState, dNewValue);
                    dDiff = Math.abs(dNewValue - av.valueAt(iState));
                    if(dDiff > dMaxDiff)
                    {
                        dMaxDiff = dDiff;
                    }
                }

                dMaxResidual = dMaxDiff;
                av = avNext;
                if(++iIteration % 10 == 0)
                    System.out.print(".");
            }

            av.setWitness(bsUniform);
            av.setAction(iAction);
            m_vValueFunction.add(av, false);
            System.out.println((new StringBuilder("Done action ")).append(iAction).append(" after ").append(iIteration).append(" iterations ").append(" av = ").append(av).toString());
        }

        System.out.println("Done blind policy");
        if(m_sBlindPolicyValueFunctionFileName != null)
            try
            {
                m_vValueFunction.save(m_sBlindPolicyValueFunctionFileName);
                System.out.println("Blind policy saved successfully");
                return;
            }
            catch(Exception e)
            {
                System.out.println((new StringBuilder("Could not save blind policy - ")).append(e).toString());
            }
    }

    protected void initValueFunctionUsingBlindPolicy(int cMaxIterations, LinearValueFunctionApproximation vValueFunction)
    {
        int iIteration = 0;
        int iAction = 0;
        int iState = 0;
        int iNextState = 0;
        double dMinValue = getMaxMinR() / (1.0D - m_dGamma);
        double dTr = 0.0D;
        double dNextValue = 0.0D;
        double dReward = 0.0D;
        double dValue = 0.0D;
        AlphaVector avNext = null;
        AlphaVector avCurrent = null;
        LinearValueFunctionApproximation vNextValueFunction = null;
        TIntDoubleIterator itNonZeroStates = null;
        System.out.println("Init value function using blind policy");
        vValueFunction.clear();
        BeliefState bsUniform = BeliefStateFactory.getInstance().getUniformBeliefState();
        for(iIteration = 0; iIteration < cMaxIterations; iIteration++)
        {
            vNextValueFunction = new LinearValueFunctionApproximation(m_dEpsilon, true);
            for(iAction = 0; iAction < m_cActions; iAction++)
            {
                avNext = new TabularAlphaVector(null, 0, m_pPOMDP);
                avNext.setWitness(bsUniform);
                if(iIteration > 0)
                    avCurrent = vValueFunction.elementAt(iAction);
                avNext.setAction(iAction);
                for(iState = 0; iState < m_cStates; iState++)
                {
                    dNextValue = 0.0D;
                    dReward = 0.0D;
                    for(itNonZeroStates = m_pPOMDP.getNonZeroTransitions(iState, iAction); itNonZeroStates.hasNext();)
                    {
                      itNonZeroStates.advance();
                        iNextState = itNonZeroStates.key();
                        dTr = itNonZeroStates.value();
                        if(avCurrent != null)
                            dValue = avCurrent.valueAt(iNextState);
                        else
                            dValue = dMinValue;
                        dReward += m_pPOMDP.R(iState, iAction, iNextState) * dTr;
                        dNextValue += dValue * dTr;
                    }

                    avNext.setValue(iState, dReward + m_dGamma * dNextValue);
                }

                vNextValueFunction.add(avNext, false);
            }

            vValueFunction.copy(vNextValueFunction);
        }

        System.out.println((new StringBuilder("Done blind policy: ")).append(vValueFunction).toString());
    }

    protected void initValueFunctionUsingQMDP()
    {
        initValueFunctionUsingQMDP(m_vValueFunction);
    }

    protected void initValueFunctionUsingQMDP(LinearValueFunctionApproximation vValueFunction)
    {
        System.out.println("Init value function using Qmdp");
        MDPValueFunction vfMDP = MDPValueFunction.getInstance(m_pPOMDP, 0.0D);
        vfMDP.valueIteration(1000, 9.9999999999999995E-07D);
        vValueFunction.clear();
        vValueFunction.addAll(vfMDP.getValueFunction());
    }

    protected boolean dominated(AlphaVector avFirst, AlphaVector avSecond, double dEpsilon)
    {
        int iState = 0;
        if(avFirst == avSecond)
            return true;
        for(iState = 0; iState < m_cStates; iState++)
            if(avFirst.valueAt(iState) > avSecond.valueAt(iState) + dEpsilon)
                return false;

        return true;
    }

    protected boolean dominated(AlphaVector av, Vector<AlphaVector> vAlphaVectors, double dEpsilon)
    {
        AlphaVector avCurrent = null;
        for(Iterator<AlphaVector> it = vAlphaVectors.iterator(); it.hasNext();)
        {
            avCurrent = it.next();
            if(dominated(av, avCurrent, dEpsilon))
                return true;
        }

        return false;
    }

    protected void add(AlphaVector avNew)
    {
        m_vValueFunction.add(avNew);
    }

    protected double getMaxAlphaSum()
    {
        int iVector = 0;
        int cVectors = m_vValueFunction.size();
        double dMaxValue = -1.7976931348623157E+308D;
        double dValue = 0.0D;
        for(iVector = 0; iVector < cVectors; iVector++)
        {
            dValue = m_vValueFunction.elementAt(iVector).sumValues();
            if(dValue > dMaxValue)
            {
                dMaxValue = dValue;
            }
        }

        return dMaxValue;
    }

    public void valueIteration(Vector<BeliefState> vector, int i, double d)
    { //
    }

    public void valueIteration(Vector<BeliefState> vector, int i, double d, POMDP pomdp1, double d1)
    { //
    }

    @Override
    public int getAction(BeliefState bsCurrent)
    {
        return getBestAction(bsCurrent);
    }

    protected String toString(Vector<AlphaVector> vAlphas)
    {
        if(vAlphas == null)
            return "null";
        String sResult = "[";
        Iterator<AlphaVector> it = vAlphas.iterator();
        AlphaVector avCurrent = null;
        while(it.hasNext()) 
        {
            avCurrent = it.next();
            sResult = (new StringBuilder(String.valueOf(sResult))).append("AV").append(avCurrent.getId()).append(" max ").append(round(avCurrent.getMaxValue(), 3)).append(", ").toString();
        }
        sResult = (new StringBuilder(String.valueOf(sResult))).append("]").toString();
        return sResult;
    }

    @Override
    public double getValue(BeliefState bsCurrent)
    {
        AlphaVector avMaxAlpha = getMaxAlpha(bsCurrent);
        return avMaxAlpha.dotProduct(bsCurrent);
    }

    @Override
    public boolean hasConverged()
    {
        return m_bConverged;
    }

    @Override
    public String getStatus()
    {
        return (new StringBuilder("|V|: ")).append(m_vValueFunction.size()).append(" ElapsedTime: ").append(m_cElapsedExecutionTime).append(" CPUTime ").append(m_cCPUExecutionTime).append(" Backups: ").append(m_cBackups).append(" GComputations: ").append(AlphaVector.getGComputationsCount()).append(" ComputedBS: ").append(BeliefStateFactory.getInstance().getBeliefStateCount()).append(" RealBeliefUpdates: ").append(BeliefStateFactory.getBeliefUpdatesCount()).append(" BeliefUpdates: ").append(BeliefState.g_cBeliefStateUpdates).append(" Dot products: ").append(AlphaVector.dotProductCount()).toString();
    }

    public String getStatus(BeliefState b)
    {
        return (new StringBuilder(" |V|: ")).append(m_vValueFunction.size()).append(" FADR: ").append(m_dFilteredADR).append(" V(b0): ").append(m_vValueFunction.valueAt(b)).append(" ElapsedTime: ").append(m_cElapsedExecutionTime).append(" CPUTime ").append(m_cCPUExecutionTime).append(" Backups: ").append(m_cBackups).append(" Usefull Backups ").append(m_cBackups - m_vValueFunction.getChangesCount()).append(" GComputations: ").append(AlphaVector.getGComputationsCount()).append(" ComputedBS: ").append(BeliefStateFactory.getInstance().getBeliefStateCount()).append(" RealBeliefUpdates: ").append(BeliefStateFactory.getBeliefUpdatesCount()).append(" BeliefUpdates: ").append(BeliefState.g_cBeliefStateUpdates).append(" Dot products: ").append(AlphaVector.dotProductCount()).toString();
    }

    public void clearBackupStatistics()
    {
        m_cBackups = 0;
    }

    protected double round(double d, int cDigits)
    {
        double power = Math.pow(10D, cDigits);
        long num = Math.round(d * power);
        return (1.0D * num) / power;
    }

    @Override
    public LinearValueFunctionApproximation getValueFunction()
    {
        return m_vValueFunction;
    }

    public String getName()
    {
        return "Value Iteration";
    }

    public double computeBellmanError(BeliefState bsCurrent)
    {
        return computeBellmanError(bsCurrent, m_vValueFunction);
    }

    public double recomputeBellmanError(BeliefState bsCurrent)
    {
        return recomputeBellmanError(bsCurrent, m_vValueFunction);
    }

    public double computeBellmanError(BeliefState bsCurrent, double dMaxError)
    {
        return computeBellmanError(bsCurrent, m_vValueFunction, dMaxError);
    }

    public double computeBellmanError(BeliefState bsCurrent, LinearValueFunctionApproximation vValueFunction, double dMaxError)
    {
        double dError = 0.0D;
        int iAction = 0;
        double dActionValue = 0.0D;
        double dMaxActionValue = (-1.0D / 0.0D);
        double dValue = vValueFunction.valueAt(bsCurrent);
        for(iAction = 0; iAction < m_cActions; iAction++)
        {
            dActionValue = computePotentialActionValue(bsCurrent, vValueFunction, iAction, dMaxError, dValue);
            if(dActionValue > dMaxActionValue)
            {
                dMaxActionValue = dActionValue;
            }
        }

        dError = dMaxActionValue - dValue;
        return dError;
    }

    protected double computePotentialActionValue(BeliefState bsCurrent, LinearValueFunctionApproximation vValueFunction, int iAction, double dMaxError, double dCurrentValue)
    {
        double dImmediateReward = m_pPOMDP.immediateReward(bsCurrent, iAction);
        double dMaximalLeftover = 0.0D;
        double dActionValue = dImmediateReward;
        double dMaxValue = vValueFunction.getMaxValue();
        double dUpperBoundError = (dImmediateReward + m_dGamma * dMaxValue) - dCurrentValue;
        double dSumProbs = 0.0D;
        BeliefState bsNext = null;
        double dNextValue = 0.0D;
        double dProb = 1.0D;
        Iterator<Pair<BeliefState, Double>> itSuccssessors = bsCurrent.getSortedSuccessors(iAction);
        Pair<BeliefState, Double> pEntry = null;
        if(dUpperBoundError < dMaxError)
            return dUpperBoundError;
        while(itSuccssessors.hasNext()) 
        {
            pEntry = itSuccssessors.next();
            dProb = pEntry.second().doubleValue();
            if(dProb > 0.0D)
            {
                bsNext = pEntry.first();
                dNextValue = vValueFunction.valueAt(bsNext);
                dSumProbs += dProb;
                dActionValue += m_dGamma * dProb * dNextValue;
                dMaximalLeftover = m_dGamma * ((1.0D - dSumProbs) * dMaxValue);
                if(dActionValue + dMaximalLeftover < dMaxError)
                    return dActionValue + dMaximalLeftover;
            }
        }
        return dActionValue;
    }

    protected double computePotentialActionValue(BeliefState bsCurrent, LinearValueFunctionApproximation vValueFunction, int iAction)
    {
        double dImmediateReward = m_pPOMDP.immediateReward(bsCurrent, iAction);
        double dActionValue = dImmediateReward;
        double dSumProbs = 0.0D;
        BeliefState bsNext = null;
        double dNextValue = 0.0D;
        double dProb = 1.0D;
        Iterator<Pair<BeliefState, Double>> itSuccssessors = bsCurrent.getSortedSuccessors(iAction); 
        Pair<BeliefState, Double> pEntry = null;
        while(itSuccssessors.hasNext() && dProb > m_dMinimalProb) 
        {
            pEntry = itSuccssessors.next();
            dProb = pEntry.second().doubleValue();
            if(dProb > m_dMinimalProb)
            {
                bsNext = pEntry.first();
                dNextValue = vValueFunction.valueAt(bsNext);
                dSumProbs += dProb;
                dActionValue += m_dGamma * dProb * dNextValue;
                m_cComputations++;
            }
        }
        bsCurrent.setPotentialActionValue(iAction, dActionValue);
        return dActionValue;
    }

    public double computeBellmanError(BeliefState bsCurrent, LinearValueFunctionApproximation vValueFunction)
    {
        double dError = 0.0D;
        int iAction = 0;
        int iMaxAction = 0;
        double dActionValue = 0.0D;
        double dMaxActionValue = (-1.0D / 0.0D);
        double dValue = 0.0D;
        dValue = vValueFunction.valueAt(bsCurrent);
        for(iAction = 0; iAction < m_cActions; iAction++)
        {
            dActionValue = computePotentialActionValue(bsCurrent, vValueFunction, iAction);
            dError = dActionValue - dValue;
            bsCurrent.setActionError(iAction, dError);
            if(dActionValue > dMaxActionValue)
            {
                iMaxAction = iAction;
                dMaxActionValue = dActionValue;
            }
        }

        dError = dMaxActionValue - dValue;
        bsCurrent.setMaxErrorAction(iMaxAction);
        return dError;
    }

    public double recomputeBellmanError(BeliefState bsCurrent, LinearValueFunctionApproximation vValueFunction)
    {
        double dError = 0.0D;
        int iAction = 0;
        int iMaxAction = 0;
        double dActionValue = 0.0D;
        double dMaxActionValue = (-1.0D / 0.0D);
        double dValue = 0.0D;
        dValue = vValueFunction.valueAt(bsCurrent);
        if(bsCurrent.getMaxErrorAction() == -1)
            for(iAction = 0; iAction < m_cActions; iAction++)
            {
                dActionValue = bsCurrent.getPotentialActionValue(iAction);
                dError = dActionValue - dValue;
                bsCurrent.setActionError(iAction, dError);
                if(dActionValue > dMaxActionValue)
                {
                    iMaxAction = iAction;
                    dMaxActionValue = dActionValue;
                }
            }

        else
            for(iAction = -1; iAction != bsCurrent.getMaxErrorAction();)
            {
                iAction = bsCurrent.getMaxErrorAction();
                dActionValue = bsCurrent.getPotentialActionValue(iAction);
                dError = dActionValue - dValue;
                bsCurrent.setActionError(iAction, dError);
                if(dActionValue > dMaxActionValue)
                {
                    iMaxAction = iAction;
                    dMaxActionValue = dActionValue;
                }
            }

        dError = dMaxActionValue - dValue;
        bsCurrent.setMaxErrorAction(iMaxAction);
        return dError;
    }

    protected void initCornerPoints(Vector<BeliefState> vCornerPoints)
    {
        int iState = 0;
        BeliefState bs = null;
        for(iState = 0; iState < m_cStates; iState++)
        {
            bs = BeliefStateFactory.getInstance().getDeterministicBeliefState(iState);
            vCornerPoints.add(bs);
        }

    }

    protected boolean checkADRConvergence(POMDP pomdp, double dTargetADR, Pair<Double,Double> pComputedADRs)
    {
        double dSimulatedADR = 0.0D;
        boolean bConverged = false;
        if(pomdp == null)
        {
            pComputedADRs.setFirst(new Double(0.0D));
            pComputedADRs.setSecond(new Double(0.0D));
        } else
        {
            m_vValueFunction.initHitCounts();
//            dSimulatedADR = pomdp.computeAverageDiscountedReward(g_cTrials, g_cStepsPerTrial, this);
            dSimulatedADR = pomdp.computeAverageDiscountedReward2(g_cTrials, g_cStepsPerTrial, this);
            if(m_dFilteredADR == 0.0D)
                m_dFilteredADR = dSimulatedADR;
            else
            {
              m_dFilteredADR = (m_dFilteredADR + dSimulatedADR) / 2D;
              if(m_dFilteredADR >= dTargetADR)
                  bConverged = true;
              else if(dSimulatedADR >= dTargetADR)
                  bConverged = checkADRConvergence(pomdp, dTargetADR, pComputedADRs);
            }
            if(pComputedADRs != null)
            {
                pComputedADRs.setFirst(new Double(dSimulatedADR));
                pComputedADRs.setSecond(new Double(m_dFilteredADR));
            }
        }
        
        return bConverged;
    }

    public static void setBlindPolicyValueFunctionFileName(String sFileName)
    {
        m_sBlindPolicyValueFunctionFileName = sFileName;
    }

    protected LinearValueFunctionApproximation m_vValueFunction;
    protected LinearValueFunctionApproximation m_vCloneValueFunction;
    protected LinearValueFunctionApproximation m_InitialValueFunction;
    protected LinearValueFunctionApproximation m_vValueFunctions[];
    protected LinearValueFunctionApproximation m_vNextValueFunctions[];
    protected int m_cStates;
    protected int m_cActions;
    protected int m_cBackups;
    protected POMDP m_pPOMDP;
    protected double m_dGamma;
    protected int m_cObservations;
    protected long m_cDotProducts;
    protected boolean m_bConverged;
    protected long m_cCPUExecutionTime;
    protected double m_dEpsilon;
    protected AlphaVector m_avMaxValues;
    protected int m_cValueFunctionChanges;
    protected long m_cElapsedExecutionTime;
    protected static final double MIN_INF = (-1.0D / 0.0D);
    protected static final double MAX_INF = (1.0D / 0.0D);
    protected long m_cTimeInBackup;
    protected long m_cTimeInHV;
    protected long m_cTimeInV;
    protected long m_cAlphaVectorNodes;
    public static int g_cTrials = 200; //1000
    public static long g_cTimeExceed = 2000L;
    protected static int g_cStepsPerTrial = 1000;
    protected static String m_sBlindPolicyValueFunctionFileName = null;
    protected RandomGenerator m_rndGenerator;
    int cG;
    protected double m_dMinimalProb;
    protected long m_cComputations;
    protected double m_dFilteredADR;

}
