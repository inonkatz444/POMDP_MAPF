// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   IncrementalPruningValueIteration.java

package solution.topological.algorithms;

import java.util.Iterator;
import java.util.Vector;


import solution.topological.environments.POMDP;
import solution.topological.utilities.AlphaVector;
import solution.topological.utilities.BeliefState;
import solution.topological.utilities.BeliefStateFactory;
import solution.topological.utilities.JProf;
import solution.topological.utilities.Logger;
import solution.topological.utilities.Pair;
import solution.topological.utilities.TabularAlphaVector;

// Referenced classes of package pomdp.algorithms:
//            ValueIteration

/**
 * Converted to trove lib
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 8 juil. 2009
 *
 */
public class IncrementalPruningValueIteration extends ValueIteration
{

    public IncrementalPruningValueIteration(POMDP pomdp)
    {
        super(pomdp);
        m_vBeliefPoints = null;
    }

    protected double diff(Vector<AlphaVector> v1, Vector<AlphaVector> v2)
    {
        Iterator<BeliefState> itPoints = m_vBeliefPoints.iterator();
        BeliefState bsCurrent = null;
        double dV1 = 0.0D;
        double dV2 = 0.0D;
        double dDelta = 0.0D;
        double dMaxDelta = 0.0D;
        while(itPoints.hasNext()) 
        {
            bsCurrent = itPoints.next();
            dV1 = valueAt(bsCurrent, v1);
            dV2 = valueAt(bsCurrent, v2);
            dDelta = dV2 - dV1;
            if(dDelta < -0.01D)
                dDelta *= -1D;
            if(dDelta > dMaxDelta)
                dMaxDelta = dDelta;
        }
        return dMaxDelta;
    }

    //TODO not called
//    protected double diff(AlphaVector av, Vector v)
//    {
//        Iterator itVectors = v.iterator();
//        AlphaVector avCurrent = null;
//        double dDiff = 0.0D;
//        double dMinDiff = (1.0D / 0.0D);
//        while(itVectors.hasNext()) 
//        {
//            avCurrent = (AlphaVector)itVectors.next();
//            dDiff = diff(av, avCurrent);
//            if(dDiff < dMinDiff)
//                dMinDiff = dDiff;
//        }
//        Logger.getInstance().log(getName(), 10, "diff", (new StringBuilder("AV")).append(av.getId()).append(" - ").append("V = ").append(dMinDiff).toString());
//        return dMinDiff;
//    }

    protected double diff(AlphaVector av1, AlphaVector av2)
    {
        int iState = 0;
        double dValue1 = 0.0D;
        double dValue2 = 0.0D;
        double dDiff = 0.0D;
        double dMaxDiff = 0.0D;
        for(iState = 0; iState < m_cStates; iState++)
        {
            dValue1 = av1.valueAt(iState);
            dValue2 = av2.valueAt(iState);
            dDiff = diff(dValue1, dValue2);
            if(dDiff > dMaxDiff)
                dMaxDiff = dDiff;
        }

        Logger.getInstance().log(getName(), 10, "diff", (new StringBuilder("AV")).append(av1.getId()).append(" - ").append("AV").append(av2.getId()).append(" = ").append(dMaxDiff).toString());
        return dMaxDiff;
    }

    protected Vector<AlphaVector> combine(Vector<AlphaVector> vaOld, Vector<AlphaVector> vaNew)
    {
        Vector<AlphaVector> vCombined = new Vector<AlphaVector>();
        BeliefState bsCurrent = null;
        Iterator<BeliefState> itPoints = m_vBeliefPoints.iterator();
        AlphaVector avCurrent = null;
        double dVOld = 0.0D;
        double dVNew = 0.0D;
        while(itPoints.hasNext()) 
        {
            bsCurrent = itPoints.next();
            dVNew = valueAt(bsCurrent, vaNew);
            dVOld = valueAt(bsCurrent, vaOld);
            if(dVNew < dVOld)
                avCurrent = best(bsCurrent, vaOld);
            else
                avCurrent = best(bsCurrent, vaNew);
            if(!vCombined.contains(avCurrent))
                vCombined.add(avCurrent);
        }
        return vCombined;
    }

    protected Vector<AlphaVector> executeIteration(Vector<AlphaVector> vCurrent, int cMaxIterations, double dEpsilon)
    {
        int iIteration = 0;
        double dDiff = (1.0D / 0.0D);
        Vector<AlphaVector> vNext = null;
        Vector<AlphaVector> vPrevious = null;
        for(iIteration = 0; iIteration < cMaxIterations && dDiff >= dEpsilon; iIteration++)
        {
            vNext = dynamicProgrammingUpdate(vCurrent);
            Logger.getInstance().log(getName(), 1, "executeIteraiton", (new StringBuilder(String.valueOf(iIteration))).append(") |V| = ").append(vNext.size()).append(" diff = ").append(dDiff).toString());
            vPrevious = vCurrent;
            vCurrent = combine(vCurrent, vNext);
            dDiff = diff(vPrevious, vCurrent);
            Logger.getInstance().log(getName(), 1, "executeIteraiton", toString(vCurrent));
        }

        return vCurrent;
    }

    protected Vector<AlphaVector> dynamicProgrammingUpdate(Vector<AlphaVector> vS)
    {
        Logger.getInstance().log(getName(), 1, "DP", (new StringBuilder(" |V| = ")).append(vS.size()).toString());
        int iAction = 0;
        int iObservation = 0;
        int iVector = 0;
        Vector<AlphaVector> vSaz = null;
        Vector<AlphaVector> vStag = null;
        Vector<AlphaVector> vUnion = null;
        Vector<AlphaVector> avSaz[] = new Vector[m_cObservations];
        Vector<AlphaVector> avSa[] = new Vector[m_cActions];
        for(iAction = 0; iAction < m_cActions; iAction++)
        {
            for(iObservation = 0; iObservation < m_cObservations; iObservation++)
            {
                vSaz = next(vS, iAction, iObservation);
                avSaz[iObservation] = filter(vSaz);
            }

            avSa[iAction] = incrementalPruning(avSaz);
            for(iVector = 0; iVector < avSa[iAction].size(); iVector++)
                avSa[iAction].elementAt(iVector).setAction(iAction);

        }

        vUnion = union(avSa);
        vStag = filter(vUnion);
        return vStag;
    }

    protected Vector<AlphaVector> union(Vector<AlphaVector> avSa[])
    {
        Vector<AlphaVector> vUnion = new Vector<AlphaVector>();
        int iVector = 0;
        int cVectors = avSa.length;
        Iterator<AlphaVector> it = null;
        AlphaVector avCurrent = null;
        for(iVector = 0; iVector < cVectors; iVector++)
            for(it = avSa[iVector].iterator(); it.hasNext();)
            {
                avCurrent = it.next();
                if(!vUnion.contains(avCurrent))
                    vUnion.add(avCurrent);
            }


        return vUnion;
    }

    protected Vector<AlphaVector> union(Vector<AlphaVector> vFirst, Vector<AlphaVector> vSecond)
    {
        Vector<AlphaVector> vUnion = new Vector<AlphaVector>(vFirst);
        Iterator<AlphaVector> it = vSecond.iterator();
        AlphaVector avCurrent = null;
        while(it.hasNext()) 
        {
            avCurrent = it.next();
            if(!vUnion.contains(avCurrent))
                vUnion.add(avCurrent);
        }
        return vUnion;
    }

    protected Vector<AlphaVector> incrementalPruning(Vector<AlphaVector> avSaz[])
    {
        Logger.getInstance().log(getName(), 2, "IP", (new StringBuilder(" avSaz = ")).append(toString(avSaz)).toString());
        Vector<AlphaVector> avWinners = restrictedRegion(avSaz[0], avSaz[1]);
        int iS = 0;
        for(iS = 3; iS < avSaz.length; iS++)
            avWinners = restrictedRegion(avSaz[iS], avWinners);

        return avWinners;
    }

    protected String toString(Vector<AlphaVector> av[])
    {
        int iVector = 0;
        int cVectors = av.length;
        String sOutput = "[";
        for(iVector = 0; iVector < cVectors; iVector++)
            sOutput = (new StringBuilder(String.valueOf(sOutput))).append(av[iVector].size()).append(", ").toString();

        sOutput = (new StringBuilder(String.valueOf(sOutput))).append("]").toString();
        return sOutput;
    }

    protected Vector<AlphaVector> restrictedRegion(Vector<AlphaVector> vFirst, Vector<AlphaVector> vSecond)
    {
        Logger.getInstance().log(getName(), 3, "", (new StringBuilder("RR: ")).append(toString(vFirst)).append(" --- ").append(toString(vSecond)).toString());
        Vector<AlphaVector> vWinners = new Vector<AlphaVector>();
        Vector<AlphaVector> vDominate = null;
        Vector<AlphaVector> vaFilter = crossSum(vFirst, vSecond);
        AlphaVector avCurrent = null;
        AlphaVector avBest = null;
        BeliefState bsWitness = null;
        Vector<BeliefState> vBeliefPoints = new Vector<BeliefState>(m_vBeliefPoints);
        if(vaFilter.size() == 1)
            return vaFilter;
        while(!vaFilter.isEmpty()) 
        {
            avCurrent = vaFilter.firstElement();
            if(vFirst.size() > vSecond.size())
                vDominate = getRelevantVectors(avCurrent.getSumIds(), 1, vaFilter, avCurrent.getId());
            else
                vDominate = getRelevantVectors(avCurrent.getSumIds(), 2, vaFilter, avCurrent.getId());
            bsWitness = dominate(avCurrent, union(vDominate, vWinners), vBeliefPoints);
            if(bsWitness == null)
            {
                vaFilter.remove(0);
            } else
            {
                vBeliefPoints.remove(bsWitness);
                avBest = best(bsWitness, vaFilter);
                vaFilter.remove(avBest);
                vWinners.add(avBest);
            }
        }
        Logger.getInstance().log(getName(), 3, "RR", (new StringBuilder("end: ")).append(toString(vWinners)).toString());
        if(vWinners.size() == 0)
        {
            Logger.getInstance().logError(getName(), "RR", "end: no winners");
            restrictedRegion(vFirst, vSecond);
        }
        return vWinners;
    }

    protected Vector<AlphaVector> getRelevantVectors(long aiSumIds[], int iRelevantIndex, Vector<AlphaVector> vVectors, long iExcludeId)
    {
        Iterator<AlphaVector> itVectors = vVectors.iterator();
        AlphaVector avCurrent = null;
        Vector<AlphaVector> vaResult = new Vector<AlphaVector>();
        while(itVectors.hasNext()) 
        {
            avCurrent = itVectors.next();
            if(avCurrent.getId() != iExcludeId)
                if(iRelevantIndex == 1)
                {
                    if(avCurrent.getSumIds()[0] == aiSumIds[0])
                        vaResult.add(avCurrent);
                } else
                if(iRelevantIndex == 2 && avCurrent.getSumIds()[1] == aiSumIds[1])
                    vaResult.add(avCurrent);
        }
        return vaResult;
    }

    protected Vector<Pair<Integer,Integer>> indexCrossSum(int cElements1, int cElements2)
    {
        int iElement1 = 0;
        int iElement2 = 0;
        Pair<Integer,Integer> pNew = null;
        Vector<Pair<Integer,Integer>> vSum = new Vector<Pair<Integer,Integer>>();
        for(iElement1 = 0; iElement1 < cElements1; iElement1++)
            for(iElement2 = 0; iElement2 < cElements2; iElement2++)
            {
                pNew = new Pair<Integer,Integer>(Integer.valueOf(iElement1), Integer.valueOf(iElement2));
                vSum.add(pNew);
            }


        return vSum;
    }

    protected Vector<AlphaVector> crossSum(Vector<AlphaVector> vFirst, Vector<AlphaVector> vSecond)
    {
        Vector<AlphaVector> vSum = new Vector<AlphaVector>();
        Iterator<AlphaVector> itFirst = vFirst.iterator();
        Iterator<AlphaVector> itSecond = vSecond.iterator();
        AlphaVector avFirst = null;
        AlphaVector avSecond = null;
        AlphaVector avNew = null;
        while(itFirst.hasNext()) 
        {
            avFirst = itFirst.next();
            for(itSecond = vSecond.iterator(); itSecond.hasNext(); vSum.add(avNew))
            {
                avSecond = itSecond.next();
                avNew = sum(avFirst, avSecond);
            }

        }
        return vSum;
    }

    //TODO not called
//    protected Vector crossSum(AlphaVector avFirst, Vector vSecond)
//    {
//        Vector vSum = new Vector();
//        Iterator itSecond = vSecond.iterator();
//        AlphaVector avSecond = null;
//        AlphaVector avNew = null;
//        for(; itSecond.hasNext(); vSum.add(avNew))
//        {
//            avSecond = (AlphaVector)itSecond.next();
//            avNew = sum(avFirst, avSecond);
//        }
//
//        return vSum;
//    }

    protected AlphaVector sum(AlphaVector avFirst, AlphaVector avSecond)
    {
        TabularAlphaVector avSum = new TabularAlphaVector(null, -1, m_pPOMDP);
        int iState = 0;
        double dValue1 = 0.0D;
        double dValue2 = 0.0D;
        double dSum = 0.0D;
        for(iState = 0; iState < m_cStates; iState++)
        {
            dValue1 = avFirst.valueAt(iState);
            dValue2 = avSecond.valueAt(iState);
            dSum = dValue1 + dValue2;
            avSum.setValue(iState, dSum);
        }

        avSum.setSumIds(avFirst.getId(), avSecond.getId());
        return avSum;
    }

    protected Vector<AlphaVector> filter(Vector<AlphaVector> vFilter)
    {
        Logger.getInstance().log(getName(), 3, "", (new StringBuilder("Filter: ")).append(toString(vFilter)).toString());
        if(vFilter.size() <= 1)
        {
            Logger.getInstance().log(getName(), 3, "", "Filter - nothing to do");
            return new Vector<AlphaVector>(vFilter);
        }
        Vector<AlphaVector> vWinners = new Vector<AlphaVector>();
        AlphaVector avCurrent = null;
        AlphaVector avBest = null;
        BeliefState bsWitness = null;
        Vector<BeliefState> vBeliefPoints = new Vector<BeliefState>(m_vBeliefPoints);
        while(!vFilter.isEmpty()) 
        {
            avCurrent = vFilter.firstElement();
            bsWitness = dominate(avCurrent, vWinners, vBeliefPoints);
            if(bsWitness == null)
            {
                vFilter.removeElement(avCurrent);
            } else
            {
                avBest = best(bsWitness, vFilter);
                vWinners.add(avBest);
                vFilter.removeElement(avBest);
                vBeliefPoints.removeElement(bsWitness);
            }
        }
        Logger.getInstance().log(getName(), 3, "", (new StringBuilder("Filter end ")).append(toString(vWinners)).toString());
        return vWinners;
    }

    protected AlphaVector best(BeliefState bsWitness, Vector<AlphaVector> vVectors)
    {
        double dValue = 0.0D;
        double dMaxValue = (-1.0D / 0.0D);
        AlphaVector avCurrent = null;
        AlphaVector avBest = null;
        for(Iterator<AlphaVector> itVectors = vVectors.iterator(); itVectors.hasNext();)
        {
            avCurrent = itVectors.next();
            dValue = avCurrent.dotProduct(bsWitness);
            if(dValue > dMaxValue)
            {
                dMaxValue = dValue;
                avBest = avCurrent;
            }
        }

        return avBest;
    }

    protected double valueAt(BeliefState bs, Vector<AlphaVector> vVectors)
    {
        if(vVectors.isEmpty())
        {
            return (-1.0D / 0.0D);
        } else
        {
            AlphaVector avBest = best(bs, vVectors);
            return avBest.dotProduct(bs);
        }
    }

    protected BeliefState dominate(AlphaVector avCurrent, Vector<AlphaVector> vVectors, Vector<BeliefState> vBeliefPoints)
    {
        Logger.getInstance().log(getName(), 4, "", (new StringBuilder("dominate: AV")).append(avCurrent.getId()).append(", ").append(toString(vVectors)).toString());
        Iterator<BeliefState> itPoints = vBeliefPoints.iterator();
        BeliefState bsCurrent = null;
        double dValue = 0.0D;
        double dNewValue = 0.0D;
        while(itPoints.hasNext()) 
        {
            bsCurrent = itPoints.next();
            dValue = valueAt(bsCurrent, vVectors);
            dNewValue = avCurrent.dotProduct(bsCurrent);
            if(dNewValue >= dValue + 0.01D)
                return bsCurrent;
        }
        return null;
    }

    protected Vector<AlphaVector> next(Vector<AlphaVector> vS, int iAction, int iObservation)
    {
        Vector<AlphaVector> vNext = new Vector<AlphaVector>();
        Iterator<AlphaVector> itVectors = vS.iterator();
        AlphaVector avCurrent = null;
        AlphaVector avNext = null;
        for(; itVectors.hasNext(); vNext.add(avNext))
        {
            avCurrent = itVectors.next();
            avNext = next(avCurrent, iAction, iObservation);
        }

        return vNext;
    }

    protected AlphaVector next(AlphaVector avCurrent, int iAction, int iObservation)
    {
        int iState = 0;
        int iNextState = 0;
        double dTr = 0.0D;
        double dAlphaValue = 0.0D;
        double dO = 0.0D;
        double dR = 0.0D;
        double dSum = 0.0D;
        AlphaVector avNext = new TabularAlphaVector(null, iAction, m_pPOMDP);
        for(iState = 0; iState < m_cStates; iState++)
        {
            dSum = 0.0D;
            for(iNextState = 0; iNextState < m_cStates; iNextState++)
            {
                dTr = m_pPOMDP.tr(iState, iAction, iNextState);
                dO = m_pPOMDP.O(iAction, iNextState, iObservation);
                dAlphaValue = avCurrent.valueAt(iNextState);
                dSum += dTr * dO * dAlphaValue;
            }

            dSum *= m_dGamma;
            dR = m_pPOMDP.R(iState, iAction);
            dSum += dR / m_cObservations;
            avNext.setValue(iState, dSum);
        }

        return avNext;
    }

    protected Vector<BeliefState> expand(Vector<BeliefState> vBeliefPoints)
    {
        Vector<BeliefState> vExpanded = new Vector<BeliefState>(vBeliefPoints);
        Iterator<BeliefState> it = vBeliefPoints.iterator();
        BeliefState bsCurrent = null;
        BeliefState bsNext = null;
        while(it.hasNext()) 
        {
            bsCurrent = it.next();
            bsNext = BeliefStateFactory.getInstance().computeFarthestSuccessor(vExpanded, bsCurrent);
            if(bsNext != null && !vExpanded.contains(bsNext))
                vExpanded.add(bsNext);
        }
        return vExpanded;
    }

    @Override
    public void valueIteration(Vector<BeliefState> vBeliefPoints, int cMaxSteps, double dEpsilon, POMDP pomdp, double dTargetValue)
    {
        int iIteration = 0;
        boolean bDone = false;
        Pair<Double,Double> pComputedADRs = new Pair<Double,Double>();
        double dMaxDelta = 0.0D;
        Vector<AlphaVector> vCurrentVF = null;
        Vector<AlphaVector> vNextVF = null;
        long lStartTime = System.currentTimeMillis();
        long lCurrentTime = 0L;
        long lCPUTimeBefore = 0L;
        long lCPUTimeAfter = 0L;
        long lCPUTimeTotal = 0L;
        Runtime rtRuntime = Runtime.getRuntime();
        long cDotProducts = AlphaVector.dotProductCount();
        //long cVnChanges = 0L;
        long cStepsWithoutChanges = 0L;
        m_cElapsedExecutionTime = 0L;
        Logger.getInstance().log(getName(), 4, "", (new StringBuilder("Starting Incremental Pruning with ")).append(vBeliefPoints.size()).append(" belief points ").append(" |BS| ").append(BeliefStateFactory.getInstance().getBeliefStateCount()).toString());
        cMaxSteps = vBeliefPoints.size() * 2;
        m_vBeliefPoints = new Vector<BeliefState>();
        m_vBeliefPoints.add(BeliefStateFactory.getInstance().getInitialBeliefState());
        for(iIteration = 0; iIteration < cMaxSteps && !bDone; iIteration++)
        {
            lStartTime = System.currentTimeMillis();
            lCPUTimeBefore = JProf.getCurrentThreadCpuTimeSafe();
            if(iIteration > 0)
                m_vBeliefPoints = expand(m_vBeliefPoints);
            //cVnChanges = m_vValueFunction.getChangesCount();
            vCurrentVF = m_vValueFunction.getVectors();
            vNextVF = executeIteration(vCurrentVF, 25, 0.01D);
            m_vValueFunction.setVectors(vNextVF);
            lCPUTimeAfter = JProf.getCurrentThreadCpuTimeSafe();
            lCurrentTime = System.currentTimeMillis();
            m_cElapsedExecutionTime += lCurrentTime - lStartTime;
            m_cCPUExecutionTime += (lCPUTimeAfter - lCPUTimeBefore) / 0xf4240L;
            lCPUTimeTotal += lCPUTimeAfter - lCPUTimeBefore;
            if(lCPUTimeTotal / 0x3b9aca00L >= 0L)
            {
                cStepsWithoutChanges = 0L;
                if(!bDone)
                    bDone = checkADRConvergence(pomdp, dTargetValue, pComputedADRs);
                rtRuntime.gc();
                Logger.getInstance().log(getName(), 0, "", (new StringBuilder("Iteration ")).append(iIteration).append(" |Vn| = ").append(m_vValueFunction.size()).append(" |B| = ").append(m_vBeliefPoints.size()).append(" simulated ADR ").append(round(pComputedADRs.first().doubleValue(), 3)).append(" filtered ADR ").append(round(pComputedADRs.second().doubleValue(), 3)).append(" time ").append((lCurrentTime - lStartTime) / 1000L).append(" CPU time ").append((lCPUTimeAfter - lCPUTimeBefore) / 0x3b9aca00L).append(" CPU total ").append(lCPUTimeTotal / 0x3b9aca00L).append(" #backups ").append(m_cBackups).append(" V changes ").append(m_vValueFunction.getChangesCount()).append(" max delta ").append(round(dMaxDelta, 3)).append(" #dot product ").append(AlphaVector.dotProductCount()).append(" |BS| ").append(BeliefStateFactory.getInstance().getBeliefStateCount()).append(" memory: ").append(" total ").append(rtRuntime.totalMemory() / 0xf4240L).append(" free ").append(rtRuntime.freeMemory() / 0xf4240L).append(" max ").append(rtRuntime.maxMemory() / 0xf4240L).toString());
            } else
            {
                cStepsWithoutChanges++;
                Logger.getInstance().log(getName(), 0, "", (new StringBuilder("Iteration ")).append(iIteration).append(" |Vn| = ").append(m_vValueFunction.size()).append(" time ").append((lCurrentTime - lStartTime) / 1000L).append(" V changes ").append(m_vValueFunction.getChangesCount()).append(" max delta ").append(round(dMaxDelta, 3)).append(" CPU time ").append((lCPUTimeAfter - lCPUTimeBefore) / 0x3b9aca00L).append(" CPU total ").append(lCPUTimeTotal / 0x3b9aca00L).append(" #backups ").append(m_cBackups).toString());
            }
            if(cStepsWithoutChanges == 50L)
                bDone = true;
        }

        m_bConverged = true;
        m_cDotProducts = AlphaVector.dotProductCount() - cDotProducts;
        m_cElapsedExecutionTime /= 1000L;
        m_cCPUExecutionTime /= 1000L;
        Logger.getInstance().log(getName(), 0, "", (new StringBuilder("Finished ")).append(getName()).append(" - time : ").append(m_cElapsedExecutionTime).append(" |BS| = ").append(vBeliefPoints.size()).append(" |V| = ").append(m_vValueFunction.size()).append(" backups = ").append(m_cBackups).append(" GComputations = ").append(AlphaVector.getGComputationsCount()).append(" Dot products = ").append(AlphaVector.dotProductCount()).toString());
    }

    @Override
    public String getName()
    {
        return "IPVI";
    }

    protected Vector<BeliefState> m_vBeliefPoints;
}
