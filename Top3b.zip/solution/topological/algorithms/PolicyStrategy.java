// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   PolicyStrategy.java

package solution.topological.algorithms;

import solution.topological.utilities.BeliefState;
import solution.topological.utilities.LinearValueFunctionApproximation;

public abstract class PolicyStrategy
{

    public PolicyStrategy()
    {
        m_bExploring = true;
    }

    public abstract int getAction(BeliefState beliefstate);

    public abstract double getValue(BeliefState beliefstate);

    public abstract boolean hasConverged();

    public boolean isExploring()
    {
        return m_bExploring;
    }

    public void setExploration(boolean bActive)
    {
        m_bExploring = bActive;
    }

    public abstract String getStatus();

    public void setEnvironmentType(boolean bStationary)
    {
        m_bStationary = bStationary;
    }

    public abstract LinearValueFunctionApproximation getValueFunction();

    protected boolean m_bExploring;
    protected boolean m_bStationary;
}
