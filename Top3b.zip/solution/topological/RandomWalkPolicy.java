// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 
// Source File Name:   RandomWalkPolicy.java

package solution.topological;

import solution.topological.algorithms.PolicyStrategy;
import solution.topological.utilities.BeliefState;
import solution.topological.utilities.LinearValueFunctionApproximation;
import solution.topological.utilities.RandomGenerator;

public class RandomWalkPolicy extends PolicyStrategy
{

    public RandomWalkPolicy(int cActions)
    {
        m_cActions = cActions;
        m_rndGenerator = new RandomGenerator("RandomWalk");
    }

    @Override
    public int getAction(BeliefState bsCurrent)
    {
        return m_rndGenerator.nextInt(m_cActions);
    }

    @Override
    public double getValue(BeliefState bsCurrent)
    {
        return 0.0D;
    }

    @Override
    public boolean hasConverged()
    {
        return false;
    }

    @Override
    public String getStatus()
    {
        return "N/A";
    }

    @Override
    public LinearValueFunctionApproximation getValueFunction()
    {
        return null;
    }

    private int m_cActions;
    protected RandomGenerator m_rndGenerator;
}
