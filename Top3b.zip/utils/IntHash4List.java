package utils;

import java.util.Arrays;

import gnu.trove.*;

/**
 * a mock-up object to allow iteration of TIntArrayList
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 9 juil. 2009
 *
 */
public class IntHash4List extends TIntHash
{
  private TIntArrayList store;
  public IntHash4List(TIntArrayList values)
  {
    store = values;
    _states = new byte[store.size()];
    Arrays.fill(_states, TPrimitiveHash.FULL);
    _set = store.toNativeArray();
    for (int j=(_set.length-1), i=0; j>i; j--, i++)
    {
      int tmp = _set[i];
      _set[i] = _set[j];
      _set[j] = tmp;
    }
  }
  
  @Override
  public int size()
  {
    return store.size();
  }
  
  @Override
  protected int capacity()
  {
    return store.size();
  }
  
  /* (non-Javadoc)
   * @see gnu.trove.THash#rehash(int)
   */
  @Override
  protected void rehash(int newCapacity)
  {
    // nothing to do
  }

  public static TIntIterator iterator(TIntArrayList list)
  {
    return new TIntIterator(new IntHash4List(list)); 
  }
}
