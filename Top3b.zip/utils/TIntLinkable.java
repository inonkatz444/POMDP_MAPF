package utils;

import gnu.trove.TLinkableAdapter;

/**
 * 
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 9 juil. 2009
 *
 */
public class TIntLinkable extends TLinkableAdapter
{
  /**
   * Version number for serialisation
   */
  private static final long serialVersionUID = 1L;
  
  private int v;
  
  /**
   * Builds a new link
   * @param value the value to store
   */
  public TIntLinkable(int value)
  {
    v = value;
  }
  
  public int getValue()
  {
    return v;
  }
}
