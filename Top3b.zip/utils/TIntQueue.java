package utils;

/**
 * 
 * @author Laurent JEANPIERRE
 * @version 1.0.0, 9 juil. 2009
 *
 */
public final class TIntQueue
{
  private int[] store = new int[10];
  private int size = 0;
  private int oldest = -1; // Last element removed
  private int next = 0;    // next place where to insert 
  
  public final void add(int v)
  {
    if (size >= store.length)
      expand();
    
    store[next++] = v;
    size++;
    if (next == store.length)
      next = 0;
  }
  
  public final int get()
  {
    if (size == 0)
      throw new IndexOutOfBoundsException("Empty queue!");
    oldest++;
    if (oldest == store.length)
      oldest = 0;
    return store[oldest];
  }
  
  public final boolean isEmpty()
  {
    return size==0;
  }
  
  public final boolean contains(int value)
  {
    int i=-1;
    if (oldest==-1 || oldest<next) // a b c x y z ......
      for (i=oldest+1; i<next; i++)
        if (store[i] == value)
          return true;
    else
    { // x y z ..... a b c
      // look in the latest chunk
      for (i=0; i<next; i++)
        if (store[i] == value)
          return true;
      // look in the oldest chunk
      for (i=oldest+1; i<store.length; i++)
        if (store[i] == value)
          return true;      
    }
    return false;
  }
  
  /**
   * Increase the size of the queue 
   */
  private void expand()
  {
    int[] newStore = new int[size+10];
    int p = 0;
    while (!isEmpty())
      newStore[p++] = get();
    oldest = 0;
    next = p;
    store = newStore;
  }
} // TIntQueue
