package pomdp.utilities.skyline;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.Vector;
import java.util.Map.Entry;

import pomdp.utilities.AlphaVector;
import pomdp.valuefunction.LinearValueFunctionApproximation;

public class EquationMatrix {
	private Equation[] m_aEquations;
	private Equation m_eMaxValue;
	private int m_iDeterministicState;
	private Map<Integer, AlphaVector> m_mSlackToAlphaVector;
	private Map<Integer, Equation> m_mSlackToEquation;
	private Map<AlphaVector, Integer> m_mAlphaVectorToSlack;
	private int[] m_aRHSVariables, m_aLHSVariables;
	private int m_cStates;
	private int m_iDepth;
	//private EquationMatrix m_emParent;
	private int m_iParentInVariable, m_iParentOutVariable, m_iSubstituteEquation = -1;
	public static int m_cMatrixes = 0, m_cFinalized = 0;
	private int m_iId;
	private boolean m_bInteriorPoint;
	private boolean m_bSkyline;
	private Vector<double[]> m_vObservedBeliefs;
	private Vector<Integer> m_vValidOutgoingEdges;
	private boolean m_bCacheChildren;
	private EquationMatrix[] m_aChildren;
	private boolean m_bRemoved;
	private AlphaVector m_avMax;
	
	private EquationMatrix( Equation[] aEquations, Map<Integer, AlphaVector> mSlackToAlphaVector, 
			Map<AlphaVector, Integer> mAlphaVectorToSlack, 
			int cStates, int[] aRHSVariables, int[] aLHSVariables, int iDepth, boolean bSkyline ){
		this( aEquations, mSlackToAlphaVector, mAlphaVectorToSlack, cStates, aRHSVariables, aLHSVariables, iDepth, bSkyline, false );
	}
	
	private EquationMatrix( Equation[] aEquations, Map<Integer, AlphaVector> mSlackToAlphaVector, 
			Map<AlphaVector, Integer> mAlphaVectorToSlack,  
			int cStates, int[] aRHSVariables, int[] aLHSVariables, int iDepth, boolean bSkyline, boolean bCacheChildren ){
		m_aEquations = aEquations;
		m_bRemoved = false;
		m_mSlackToAlphaVector = mSlackToAlphaVector;
		m_mAlphaVectorToSlack = mAlphaVectorToSlack;
		m_cStates = cStates;
		m_aLHSVariables = aLHSVariables;
		m_aRHSVariables = aRHSVariables;
		m_iId = m_cMatrixes++;
		m_bInteriorPoint = true;
		m_bSkyline = bSkyline;
		
		m_mSlackToEquation = new HashMap<Integer, Equation>();
		for( Equation eq : m_aEquations ){
			m_mSlackToEquation.put( eq.getLHSVariable(), eq );
		}
		
		//if( m_iId == 10802 )
		//	System.out.println( "*" );
		
		for( int iVariable : aRHSVariables ){
			if( iVariable < m_cStates ){
				m_bInteriorPoint = false;
				break;
			}	
		}
		m_iDepth = iDepth;
		m_bCacheChildren = bCacheChildren;

		if( m_bCacheChildren ){
			m_aChildren = new EquationMatrix[cStates];
		}
	}
	
	public EquationMatrix( Collection<AlphaVector> vValueFunction, int cStates, int iDeterministicState, boolean bCacheChildren ){
		m_bSkyline = true;
		m_bRemoved = false;
		m_iDeterministicState = iDeterministicState;
		int cVectors = vValueFunction.size();
		Equation[] aInitial = new Equation[cVectors];
		m_cStates = cStates;
		m_aRHSVariables = new int[cStates];
		m_aLHSVariables = new int[cVectors];
		m_mSlackToAlphaVector = new HashMap<Integer, AlphaVector>();
		m_mSlackToEquation = new HashMap<Integer, Equation>();
		m_mAlphaVectorToSlack = new HashMap<AlphaVector, Integer>();
		int iVector = 0, iState = 0;
		double dMaxValue = Double.NEGATIVE_INFINITY;
		int iMaxValueEquation = 0;
		Equation eJoined = null;
		AlphaVector avMax = null;
		
		for( AlphaVector av : vValueFunction ){
			//x_0 = a_0 + a_1*x_1 + ... + a_n-1*x_n-1
			aInitial[iVector] = new Equation( av, cStates, cStates + iVector, iDeterministicState );
			
			//looking for the maximal alpha at <1,0,...,0>
			if( aInitial[iVector].valueAtZero() > dMaxValue ){
				dMaxValue = aInitial[iVector].valueAtZero();
				iMaxValueEquation = iVector;
				avMax = av;
			}
			m_mSlackToAlphaVector.put( cStates + iVector, av );
			m_mAlphaVectorToSlack.put( av, cStates + iVector );
			iVector++;
		}
		avMax.setDominated( false );
		m_avMax = avMax;
		
		//maximal alpha at <1,0,...,0> - cannot be dominated
		m_mSlackToAlphaVector.get( aInitial[iMaxValueEquation].getSlackVariable() ).setDominated( false );	
		m_eMaxValue = aInitial[iMaxValueEquation];
		m_eMaxValue.setShiftToMaxNoise();
		m_aEquations = new Equation[cVectors];
		for( iVector = 0 ; iVector < cVectors ; iVector++ ){
			if( iVector != iMaxValueEquation ){
				//All equations are equal to x_0 at this point
				//we can therefore combine them by doing rhs_i = rhs_min then we leave only the slack variable at the LHS
				eJoined = aInitial[iVector].join( aInitial[iMaxValueEquation] );
				m_mSlackToEquation.put( eJoined.getLHSVariable(), eJoined );
				if( iVector < iMaxValueEquation ){
					m_aEquations[iVector] = eJoined;
					m_aLHSVariables[iVector] = cStates + iVector;
				}
				else{
					m_aEquations[iVector - 1] = eJoined;
					m_aLHSVariables[iVector - 1] = cStates + iVector;
				}
			}
		}
		//now we add the equation for the constraint x_0 + x_1 + x_2 + ... + x_n-1 <= 1
		m_aEquations[cVectors - 1] = Equation.getBeliefContraintEquation( cStates, iDeterministicState );
		m_aLHSVariables[cVectors - 1] = iDeterministicState;
		
		for( iState = 0 ; iState < cStates ; iState++ ){
			if( iState < iDeterministicState )
				m_aRHSVariables[iState] = iState;
			if( iState > iDeterministicState )
				m_aRHSVariables[iState - 1] = iState;
		}
		m_aRHSVariables[cStates - 1] = cStates + iMaxValueEquation;
		m_iId = m_cMatrixes++;
		m_bInteriorPoint = false;
		m_iDepth = 0;
		
		m_bCacheChildren = bCacheChildren;

		if( m_bCacheChildren ){
			m_aChildren = new EquationMatrix[cStates];
		}
	}
	
	public EquationMatrix( Collection<AlphaVector> vValueFunction, int cStates, int iDeterministicState ){
		this( vValueFunction, cStates, iDeterministicState, false );
	}
	
	public EquationMatrix( Collection<AlphaVector> vValueFunction, int cStates, int iDeterministicState, AlphaVector avSearchVector, double dDeltaShift ){
		m_bSkyline = false;
		m_bRemoved = false;
		m_iDeterministicState = iDeterministicState;
		int cVectors = vValueFunction.size(); //all except the search vector
		Equation[] aInitial = new Equation[cVectors];
		m_cStates = cStates;
		m_aRHSVariables = new int[cStates];
		m_aLHSVariables = new int[cVectors];
		m_mSlackToAlphaVector = new HashMap<Integer, AlphaVector>();
		m_mSlackToEquation = new HashMap<Integer, Equation>();
		m_mAlphaVectorToSlack = new HashMap<AlphaVector, Integer>();
		int iVector = 0, iState = 0, iMaxVectorVariable = -1;
		double dMaxValue = Double.NEGATIVE_INFINITY;
		int iMaxValueEquation = 0;
		Equation eJoined = null;
		for( AlphaVector av : vValueFunction ){
			//x_0 = a_0 + a_1*x_1 + ... + a_n-1*x_n-1
			if( av != avSearchVector ){
				aInitial[iVector] = new Equation( av, avSearchVector, cStates, cStates + iVector, iDeterministicState, cStates + cVectors, dDeltaShift );		
				//looking for the maximal alpha at <1,0,...,0>
				if( aInitial[iVector].getShift() > dMaxValue ){
					dMaxValue = aInitial[iVector].getShift();
					iMaxValueEquation = iVector;
					iMaxVectorVariable = cStates + iVector;
				}
				m_mSlackToAlphaVector.put( cStates + iVector, av );
				m_mAlphaVectorToSlack.put( av, cStates + iVector );
				
				iVector++;
			}
		}
		m_mSlackToAlphaVector.put( cStates + cVectors, avSearchVector );
		m_mAlphaVectorToSlack.put( avSearchVector, cStates + cVectors );
		m_eMaxValue = aInitial[iMaxValueEquation];

		//maximal alpha at <1,0,...,0> - cannot be dominated
		m_aEquations = new Equation[cVectors];
		for( iVector = 0 ; iVector < cVectors - 1 ; iVector++ ){
			if( iVector != iMaxValueEquation ){
				//All equations are equal to x_0 at this point
				//we can therefore combine them by doing rhs_i = rhs_min then we leave only the slack variable at the LHS
				eJoined = aInitial[iVector].join( aInitial[iMaxValueEquation] );
				m_aEquations[iVector] = eJoined;
				m_aLHSVariables[iVector] = cStates + iVector;
			}
			else{
				m_aEquations[iVector] = aInitial[iMaxValueEquation];
				m_aLHSVariables[iVector] = cStates + cVectors;
			}
			m_mSlackToEquation.put( m_aEquations[iVector].getLHSVariable(), m_aEquations[iVector] );
		}
		//now we add the equation for the constraint x_0 + x_1 + x_2 + ... + x_n-1 <= 1
		m_aEquations[cVectors - 1] = Equation.getBeliefContraintEquation( cStates, iDeterministicState );
		m_aLHSVariables[cVectors - 1] = iDeterministicState;
		
		for( iState = 0 ; iState < cStates ; iState++ ){
			if( iState < iDeterministicState )
				m_aRHSVariables[iState] = iState;
			if( iState > iDeterministicState )
				m_aRHSVariables[iState - 1] = iState;
		}
		m_aRHSVariables[cStates - 1] = cStates + iMaxValueEquation;
		m_iId = m_cMatrixes++;
		m_bInteriorPoint = false;
		m_iDepth = 0;
	}
	
	public static boolean exists( int[] aiRHSVariables, Vector<int[]> vObservedNodes ){
		for( int[] aiObserved : vObservedNodes ){
			if( equals( aiObserved, aiRHSVariables ) )
				return true;
		}
		return false;
	}
	
	private static boolean equals( int[] aiObserved, int[] aiRHSVariables ){
		int idx = 0;
		if( aiObserved.length != aiRHSVariables.length )
			return false;
		for( idx = 0 ; idx < aiObserved.length ; idx++ ){
			if( aiObserved[idx] != aiRHSVariables[idx] )
				return false;
		}
		return true;
	}

	private boolean exists( double[] aiRHSVariables, Vector<double[]> vObservedNodes ){
		for( double[] aiObserved : vObservedNodes ){
			if( equals( aiObserved, aiRHSVariables ) )
				return true;
		}
		return false;
	}
	
	private boolean equals( double[] aiObserved, double[] aiRHSVariables ){
		int idx = 0;
		for( idx = 0 ; idx < aiObserved.length ; idx++ ){
			if( Math.abs( aiObserved[idx] - aiRHSVariables[idx] ) > 0.0001 )
				return false;
		}
		return true;
	}

	public int isValidEdge( int iVariableIdx, Vector<int[]> vObservedNodes, boolean bForceTowardsInterior ){
		int iOutVariable = m_aRHSVariables[iVariableIdx], iInVariable = -1;
		int[] aiRHSVariables = new int[m_cStates];
		int iEquation = 0, iMinEquation = -1, iVariable = 0, iIdx = 0;
		double dMinDelta = Double.POSITIVE_INFINITY, dDelta = 0.0;
		
		if( !m_bInteriorPoint && bForceTowardsInterior ){
			if( iOutVariable >= m_cStates )
				return -1;
		}
		
		for( iEquation = 0 ; iEquation < m_aEquations.length ; iEquation++ ){
			dDelta = m_aEquations[iEquation].computeDelta( iOutVariable );
			if( dDelta < dMinDelta ){
				dMinDelta = dDelta;
				iMinEquation = iEquation;
			}
		}
		if( iMinEquation == -1 )
			return -1;
		iInVariable = m_aEquations[iMinEquation].getLHSVariable();
		/*
		if( iInVariable >= m_cStates ){
			AlphaVector av = m_mSlackToAlphaVector.get( iInVariable );
			if( av.isDominated() ){
				av.setDominated( false );
			}
			else{
				return -1;
			}
		}
			*/
		Vector<Integer> vRHSVariables = new Vector<Integer>();
		int iRHSVariable = -1;
		for( iVariable = 0 ; iVariable < m_cStates ; iVariable++ ){
			if( m_aRHSVariables[iVariable] == iOutVariable ){
				iRHSVariable = iInVariable;
				//iIdx = iVariable;
				iIdx = vRHSVariables.size();
			}
			else{
				iRHSVariable = m_aRHSVariables[iVariable];
			}
			aiRHSVariables[iVariable] = iRHSVariable;
			if( iRHSVariable >= m_cStates ){
				vRHSVariables.add( iRHSVariable );
			}
		}
		aiRHSVariables = new int[vRHSVariables.size()];
		for( iVariable = 0 ; iVariable < aiRHSVariables.length ; iVariable++ ){
			aiRHSVariables[iVariable] = vRHSVariables.elementAt( iVariable );
		}
		resort( aiRHSVariables, iIdx );
		if( exists( aiRHSVariables, vObservedNodes ) )
			return -1;
		int cZeroBeliefVariables = 0;
		for( int iVar : aiRHSVariables ){
			if( iVar > 0 && iVar < m_cStates )
				cZeroBeliefVariables++;
		}
		//if( cZeroBeliefVariables == 0 )
		//	System.out.println( "*" );
		vObservedNodes.add( aiRHSVariables );
		return cZeroBeliefVariables;
	}
	
	public boolean isNewEdge( int iVariableIdx, SortedSet<int[]> sObservedEdges ){
		int iVariable = 0;
		int[] alEdge = new int[m_aRHSVariables.length - 1];
		for( iVariable = 0 ; iVariable < m_aRHSVariables.length ; iVariable++ ){
			if( iVariable < iVariableIdx ){
				alEdge[iVariable] = m_aRHSVariables[iVariable];
			}
			if( iVariable > iVariableIdx ){
				alEdge[iVariable - 1] = m_aRHSVariables[iVariable];
			}
		}		
		if( sObservedEdges.contains( alEdge ) )
			return false;

		//System.out.println( "Found valid outgoing edge " + vOutgoingEdge + " from " + toString() );
		
		sObservedEdges.add( alEdge );
		return true;
	}
	
	public EquationMatrix getNeighbor( int iVariableIdx, SortedSet<int[]> sObservedNodes ){
		int iOutVariable = m_aRHSVariables[iVariableIdx], iInVariable = -1;
		int[] aiRHSVariables = new int[m_cStates], aiLHSVariable = new int[m_aEquations.length];
		int iEquation = 0, iMinEquation = -1, iVariable = 0, iIdx = 0;
		double dMinDelta = 1000.0, dDelta = 0.0;

		//if( !m_bInteriorPoint && ( iOutVariable >= m_cStates ) )
		//	return null;
		
		for( iEquation = 0 ; iEquation < m_aEquations.length ; iEquation++ ){
			dDelta = m_aEquations[iEquation].computeDelta( iOutVariable );
			if( dDelta < dMinDelta ){
				dMinDelta = dDelta;
				iMinEquation = iEquation;
			}
		}
		if( iMinEquation == -1 )
			return null;
		iInVariable = m_aEquations[iMinEquation].getLHSVariable();
		
		if( m_bSkyline ){
			AlphaVector av = m_mSlackToAlphaVector.get( iInVariable );
			if( av != null ){
				av.setDominated( false );
			}
		}
		
		for( iVariable = 0 ; iVariable < m_cStates ; iVariable++ ){
			if( m_aRHSVariables[iVariable] == iOutVariable ){
				aiRHSVariables[iVariable] = iInVariable;
				iIdx = iVariable;
			}
			else{
				aiRHSVariables[iVariable] = m_aRHSVariables[iVariable];
			}
		}
		resort( aiRHSVariables, iIdx );

		if( sObservedNodes != null ){
			if( sObservedNodes.contains( aiRHSVariables ) ){
				return null;
			}
			sObservedNodes.add( aiRHSVariables );
		}
		Equation eqSubstitue = m_aEquations[iMinEquation].extractVariable( iOutVariable );
		Equation[] aSuccessorEquations = new Equation[m_aEquations.length];
		for( iEquation = 0 ; iEquation < m_aEquations.length ; iEquation++ ){
			if( iEquation == iMinEquation ){
				iIdx = iEquation;
				aSuccessorEquations[iEquation] = eqSubstitue;
			}
			else{				
				aSuccessorEquations[iEquation] = m_aEquations[iEquation].substitue( eqSubstitue );
			}
			if( m_aLHSVariables[iEquation] == iInVariable ){
				aiLHSVariable[iEquation] = iOutVariable;				
			}
			else{
				aiLHSVariable[iEquation] = m_aLHSVariables[iEquation];
			}
		}
		resort( aiLHSVariable, iIdx );
		EquationMatrix eqNew = new EquationMatrix( aSuccessorEquations, m_mSlackToAlphaVector, m_mAlphaVectorToSlack, m_cStates, aiRHSVariables, aiLHSVariable, m_iDepth + 1, m_bSkyline, m_bCacheChildren );
		eqNew.m_iParentInVariable = iInVariable;
		eqNew.m_iParentOutVariable = iOutVariable;
		eqNew.m_iSubstituteEquation = iMinEquation;	
		
		return eqNew;
	}
	
	public EquationMatrix getNeighbor( int iVariableIdx, Object[] aSuccessor ){
		int iOutVariable = m_aRHSVariables[iVariableIdx], iInVariable = -1;
		int[] aiRHSVariables = new int[m_cStates], aiLHSVariable = new int[m_aEquations.length];
		int iEquation = 0, iMinEquation = -1, iIdx = 0, iVariable = 0;
		
		iMinEquation = (Integer)aSuccessor[1];
		iInVariable = (Integer)aSuccessor[2];
		
		Equation eqSubstitue = (Equation)aSuccessor[3];
		Equation[] aSuccessorEquations = new Equation[m_aEquations.length];
		for( iEquation = 0 ; iEquation < m_aEquations.length ; iEquation++ ){
			if( iEquation == iMinEquation ){
				iIdx = iEquation;
				aSuccessorEquations[iEquation] = eqSubstitue;
			}
			else{				
				aSuccessorEquations[iEquation] = m_aEquations[iEquation].substitue( eqSubstitue );
			}
			if( m_aLHSVariables[iEquation] == iInVariable ){
				aiLHSVariable[iEquation] = iOutVariable;				
			}
			else{
				aiLHSVariable[iEquation] = m_aLHSVariables[iEquation];
			}
			if( aSuccessorEquations[iEquation].getLHSVariable() < m_cStates && aSuccessorEquations[iEquation].getShift() > 1.01 )
				System.out.println("BUGBUG");
			if( aSuccessorEquations[iEquation].getShift() < 0.0 )
				System.out.println("BUGBUG");
				
		}
		resort( aiLHSVariable, iIdx );
		
		for( iVariable = 0 ; iVariable < m_cStates ; iVariable++ ){
			if( m_aRHSVariables[iVariable] == iOutVariable ){
				aiRHSVariables[iVariable] = iInVariable;
				iIdx = iVariable;
			}
			else{
				aiRHSVariables[iVariable] = m_aRHSVariables[iVariable];
			}
		}
		
		resort( aiRHSVariables, iIdx );
		EquationMatrix eqNew = new EquationMatrix( aSuccessorEquations, m_mSlackToAlphaVector, m_mAlphaVectorToSlack, m_cStates, aiRHSVariables, aiLHSVariable, m_iDepth + 1, m_bSkyline, m_bCacheChildren );
		eqNew.m_iParentInVariable = iInVariable;
		eqNew.m_iParentOutVariable = iOutVariable;
		eqNew.m_avMax = m_mSlackToAlphaVector.get( iInVariable );
		eqNew.m_iSubstituteEquation = iMinEquation;
				
		return eqNew;
	}
	
	private EquationMatrix getNeighbor( int iVariableIdx, Vector<int[]> vObservedNodes, Vector<double[]> vObservedBeliefs ){
		int iOutVariable = m_aRHSVariables[iVariableIdx], iInVariable = -1;
		int[] aiRHSVariables = new int[m_cStates], aiLHSVariable = new int[m_aEquations.length];
		int iEquation = 0, iMinEquation = -1, iVariable = 0, iIdx = 0;
		double dMinDelta = Double.POSITIVE_INFINITY, dDelta = 0.0;

		//if( !m_bInteriorPoint && ( iOutVariable >= m_cStates ) )
		//	return null;
		
		for( iEquation = 0 ; iEquation < m_aEquations.length ; iEquation++ ){
			dDelta = m_aEquations[iEquation].computeDelta( iOutVariable );
			if( dDelta < dMinDelta ){
				dMinDelta = dDelta;
				iMinEquation = iEquation;
			}
		}
		if( iMinEquation == -1 )
			return null;
		iInVariable = m_aEquations[iMinEquation].getLHSVariable();
		
		if( m_bInteriorPoint && ( iInVariable < m_cStates ) )
			return null;
		
		//if( iInVariable < m_cStates )// && iOutVariable < m_cStates )
		//	return null;
		
		for( iVariable = 0 ; iVariable < m_cStates ; iVariable++ ){
			if( m_aRHSVariables[iVariable] == iOutVariable ){
				aiRHSVariables[iVariable] = iInVariable;
				iIdx = iVariable;
			}
			else{
				aiRHSVariables[iVariable] = m_aRHSVariables[iVariable];
			}
		}
		resort( aiRHSVariables, iIdx );
		if( ( vObservedNodes != null ) && exists( aiRHSVariables, vObservedNodes ) )
			return null;
		if( m_bSkyline ){
			AlphaVector av = m_mSlackToAlphaVector.get( iInVariable );
			if( av != null ){
				av.setDominated( false );
			}
		}
		if( vObservedNodes != null )
			vObservedNodes.add( aiRHSVariables );
		//if( m_cMatrixes == 167 )
		//	System.out.println("*" );
		Equation eqSubstitue = m_aEquations[iMinEquation].extractVariable( iOutVariable );
		Equation[] aSuccessorEquations = new Equation[m_aEquations.length];
		for( iEquation = 0 ; iEquation < m_aEquations.length ; iEquation++ ){
			if( iEquation == iMinEquation ){
				iIdx = iEquation;
				aSuccessorEquations[iEquation] = eqSubstitue;
			}
			else{				
				aSuccessorEquations[iEquation] = m_aEquations[iEquation].substitue( eqSubstitue );
			}
			if( m_aLHSVariables[iEquation] == iInVariable ){
				aiLHSVariable[iEquation] = iOutVariable;				
			}
			else{
				aiLHSVariable[iEquation] = m_aLHSVariables[iEquation];
			}
		}
		resort( aiLHSVariable, iIdx );
		EquationMatrix eqNew = new EquationMatrix( aSuccessorEquations, m_mSlackToAlphaVector, m_mAlphaVectorToSlack, m_cStates, aiRHSVariables, aiLHSVariable, m_iDepth + 1, m_bSkyline );
		eqNew.m_iParentInVariable = iInVariable;
		eqNew.m_iParentOutVariable = iOutVariable;
		if( vObservedBeliefs != null ){
			if( !exists( eqNew.getBeliefState(), vObservedBeliefs ) )
				vObservedBeliefs.add( eqNew.getBeliefState() );
		}
		return eqNew;
	}

	private Object[] getNeighborValueOf( int iOutVariableIdx, int iAlphaVectorVariable ){
		int iOutVariable = m_aRHSVariables[iOutVariableIdx], iInVariable = -1;
		int iEquation = 0, iMinEquation = -1;
		double dMinDelta = Double.POSITIVE_INFINITY, dDelta = 0.0;
		
		for( iEquation = 0 ; iEquation < m_aEquations.length ; iEquation++ ){
			dDelta = m_aEquations[iEquation].computeDelta( iOutVariable );
			if( dDelta < dMinDelta ){
				dMinDelta = dDelta;
				iMinEquation = iEquation;
			}
		}
		if( iMinEquation == -1 )
			return null;
		
		iInVariable = m_aEquations[iMinEquation].getLHSVariable();
		//if( iInVariable == iAlphaVectorVariable )
		//	return 0.0;
				
		if( m_bSkyline ){
			AlphaVector av = m_mSlackToAlphaVector.get( iInVariable );
			if( av != null ){
				av.setDominated( false );
			}
		}
		Equation eqSubstitue = m_aEquations[iMinEquation].extractVariable( iOutVariable );
		Equation eqSuccessor = null;
		for( iEquation = 0 ; iEquation < m_aEquations.length ; iEquation++ ){
			if( iEquation != iMinEquation ){
				if( m_aEquations[iEquation].getLHSVariable() == iAlphaVectorVariable ){
					eqSuccessor = m_aEquations[iEquation].substitue( eqSubstitue );
				}
			}
		}
		double dValue = 0.0;
		if( eqSuccessor != null ){
			dValue = eqSuccessor.getShift();
		}
		
		//return dValue;
		return new Object[]{ dValue, iMinEquation, iInVariable, eqSubstitue };
	}
	
	private void resort( int[] a, int idx ){
		if( idx >= a.length )
			return;
		while( ( idx < a.length - 1 ) && ( a[idx + 1] < a[idx] ) ){
			swap( a, idx, idx + 1 );
			idx++;
		}
		while( ( idx > 0 ) && ( a[idx - 1] > a[idx] ) ){
			swap( a, idx, idx - 1 );
			idx--;
		}	
	}

	private void swap( int[] a, int i, int j) {
		int aux = a[i];
		a[i] = a[j];
		a[j] = aux;
		
	}

	public Collection<EquationMatrix> neighbors( Vector<int[]> vObservedNodes, Vector<double[]> vObservedBeliefs ){
		int iVariable = 0;
		EquationMatrix emNeighbor = null;
		Vector<EquationMatrix> vNeighbors = new Vector<EquationMatrix>();
		for( iVariable = 0 ; iVariable < m_cStates ; iVariable++ ){
			emNeighbor = getNeighbor( iVariable, vObservedNodes, vObservedBeliefs );
			if( emNeighbor != null ){
				vNeighbors.add( emNeighbor );
			}
		}
		return vNeighbors;
	}
	
	public Collection<EquationMatrixCreator> lazyNeighbors( Vector<int[]> vObservedNodes, Vector<double[]> vObservedBeliefs ){
		int iVariable = 0, iZeroBeliefVariables = 0;
		Vector<EquationMatrixCreator> vNeighbors = new Vector<EquationMatrixCreator>();
		
		m_vObservedBeliefs = vObservedBeliefs;
		
		for( iVariable = 0 ; iVariable < m_cStates ; iVariable++ ){
			iZeroBeliefVariables = isValidEdge( iVariable, vObservedNodes, false );
			if( iZeroBeliefVariables > -1 )
				vNeighbors.add( new EquationMatrixCreator( this, iVariable, iZeroBeliefVariables ) );
		}
		/*
		if( ( vNeighbors.size() == 0 ) && !m_bInteriorPoint ){
			for( iVariable = 0 ; iVariable < m_cStates && vNeighbors.size() == 0 ; iVariable++ ){
				if( isValidEdge( iVariable, vObservedNodes, false ) ){
					vNeighbors.add( new EquationMatrixCreator( this, iVariable ) );
				}
			}
		}
		if( vNeighbors.size() == 0 ){
			for( iVariable = 0 ; iVariable < m_cStates && vNeighbors.size() == 0 ; iVariable++ ){
				if( isValidEdge( iVariable, vObservedNodes, false ) ){
					vNeighbors.add( new EquationMatrixCreator( this, iVariable ) );
				}
			}
		}
		*/
		return vNeighbors;
	}
	
	public void initOutgoingEdges( SortedSet<int[]> sObservedEdges ){
		int iVariable = 0;
		boolean bNew = true;
		
		m_vValidOutgoingEdges = new Vector<Integer>();
		for( iVariable = 0 ; iVariable < m_cStates ; iVariable++ ){
			if( sObservedEdges != null ){
				bNew = isNewEdge( iVariable, sObservedEdges );
			}
			if( bNew )
				m_vValidOutgoingEdges.add( iVariable );
		}
	}
	
	public Collection<EquationMatrix> getNeighbors( SortedSet<int[]> sObservedEdges, SortedSet<int[]> sObservedNodes ){
		Vector<EquationMatrix> vNeighbors = new Vector<EquationMatrix>();
		EquationMatrix emNeighbor = null;
		
		for( int iVariable : m_vValidOutgoingEdges ){
			emNeighbor = getNeighbor( iVariable, sObservedNodes );
			if( emNeighbor != null ){
				emNeighbor.initOutgoingEdges( sObservedEdges );
				vNeighbors.add( emNeighbor );
			}
		}
			
		return vNeighbors;
	}
	
	public AlphaVector getAlphaVector( int iVariable ){
		return m_mSlackToAlphaVector.get( iVariable );
	}

	public int[] getRHSVariables() {
		return m_aRHSVariables;
	}
	
	public String toString(){
		String s = "Id = " + m_iId + "\nRHS: ";
		for( int iVar : m_aRHSVariables )
			s += iVar + ",";
		s += "\n";
		s += "LHS: ";
		for( int iVar : m_aLHSVariables )
			s += iVar + ",";
		s += "\n";
		for( Equation eq : m_aEquations )
			s += eq + "\n";
		return s;
	}
	
	public boolean isDeterministicBelief(){
		double dSum = 0.0;
		for( Equation eq : m_aEquations ){
			if( eq.getLHSVariable() < m_cStates ){
				if( eq.getShift() == 1.0 )
					return true;
				dSum += eq.getShift();
			}
		}
		return dSum == 0.0;
	}
	
	public double[] getBeliefState(){
		double[] adBelief = new double[m_cStates];
		double dSum = 0.0;
		for( Equation eq : m_aEquations ){
			if( eq.getLHSVariable() < m_cStates ){
				if(eq.getShift() > 1.01)
					System.out.println( "BUGBUG: impossible belief point " + this);
				
				adBelief[eq.getLHSVariable()] += eq.getShift();
				dSum += eq.getShift();
			}
		}
		//adBelief[0] = 1.0 - dSum;
		return adBelief;
	}
	public String getBeliefStateString(){
		double[] adBelief = new double[m_cStates];
		double dSum = 0.0;
		for( Equation eq : m_aEquations ){
			if( eq.getLHSVariable() < m_cStates ){
				adBelief[eq.getLHSVariable()] += eq.getShift();
				dSum += eq.getShift();
			}
		}
		adBelief[0] = 1.0 - dSum;
		String sBelief = "[";
		for( int iState = 0 ; iState < m_cStates ; iState++ ){
			if( adBelief[iState] > 0.0 )
				sBelief += iState + "=" + adBelief[iState] + ", ";
		}
		sBelief += "]";
		return sBelief;
	}
	public boolean isInteriorPoint(){
		//return m_bInteriorPoint;
		/*
		for( int iVariable : m_aRHSVariables ){
			if( iVariable < m_cStates )
				return false;
		}
		return true;
		*/
		double[] adBelief = getBeliefState();
		for( double d : adBelief )
			if( d < 0.0000001 )
				return false;
		return true;
		
	}

	public int[] getIntersectingFunctions() {
		Vector<Integer> vRHSFunctions = new Vector<Integer>();
		for( int iVar : m_aRHSVariables ){
			if( iVar >= m_cStates ){
				vRHSFunctions.add( iVar );
			}
		}
		int[] aiIntersecting = new int[vRHSFunctions.size()];
		for( int iVar = 0 ; iVar < aiIntersecting.length ; iVar++ ){
			aiIntersecting[iVar] = vRHSFunctions.elementAt( iVar );
		}
		return aiIntersecting;
	}


	public static long m_cTimeInNextVertex = 0;
	
	//Returns the next node, trying to minimize the distance of the vector associated with iVectorVariable from the skyline at the related belief point
	public EquationMatrix nextVertex( int iVectorVariable ) {
		long lTimeBefore = System.currentTimeMillis();
		int iVariable = 0, iMinVariable = -1;
		double dCurrentValue = valueOf( iVectorVariable );
		double dValue = 0.0, dMinValue = dCurrentValue;
		Object[] aSuccessor = null, aBestSuccessor = null;
		
		if( m_bCacheChildren ){
			for( EquationMatrix emChild : m_aChildren ){
				if( emChild != null ){
					dValue = emChild.valueOf( iVectorVariable );
					if( dValue < dCurrentValue )
						return emChild;
				}
			}
		}		
		
		for( iVariable = 0 ; iVariable < m_cStates ; iVariable++ ){
			//dValue = getNeighborValueOf( iVariable, iVectorVariable );
			aSuccessor = getNeighborValueOf( iVariable, iVectorVariable );
			if( aSuccessor != null ){
				dValue = (Double)aSuccessor[0];
				if( dValue < dMinValue ){
					dMinValue = dValue;
					iMinVariable = iVariable;
					aBestSuccessor = aSuccessor;
				}
			}
		}
		
		EquationMatrix emNext = null;
		if( dMinValue < dCurrentValue ){
			emNext = getNeighbor( iMinVariable, aBestSuccessor );
			if( m_bCacheChildren )
				m_aChildren[iMinVariable] = emNext;
		}
		m_cTimeInNextVertex += System.currentTimeMillis() - lTimeBefore;
		return emNext;
	}
	
	public int getVariable (AlphaVector av ) {
		/*
		int iVariable = -1;
		for( Entry<Integer, AlphaVector> e : m_mSlackToAlphaVector.entrySet() ){
			if( e.getValue() == av ){
				iVariable = e.getKey();
				break;
			}
		}
		//System.out.println( "getVariable " + av + " = " + iVariable );
		return iVariable;
		*/
		return m_mAlphaVectorToSlack.get( av );
	}

	public double valueOf( int iVariable ){
		double dValue = 0.0, dValueTag = 0.0;
		/*
		for( Equation eq : m_aEquations ){
			if( eq.getLHSVariable() == iVariable ){
				dValueTag = eq.getShift();
				break;
			}
		}
		*/
		Equation eq = m_mSlackToEquation.get( iVariable );
		if( eq != null )
			dValue = eq.getShift();
			
		//if( dValueTag != dValue )
		//	System.out.println( "getVariable " + iVariable + " = " + dValue );
		return dValue;
	}

	public double valueOf( AlphaVector av ){
		int iVariable = getVariable( av );
		/*
		for( Equation eq : m_aEquations ){
			if( eq.getLHSVariable() == iVariable )
				return eq.getShift();
		}
		*/
		return valueOf( iVariable );
	}

	public void pruneEquations(Vector<Integer> vDominatedVectors ) {
		int cEquations = 0;
		for( int iVariable : m_aLHSVariables ){
			if( ( iVariable < m_cStates ) || ( !vDominatedVectors.contains( iVariable ) ) ){
				cEquations++;
			}
		}
		int iVariable = 0;
		int[] aiLHS = new int[cEquations];
		Equation[] aEquations = new Equation[cEquations];
		int iEquation = 0, iNewEquation = 0;
		for( iEquation = 0 ; iEquation < m_aEquations.length ; iEquation++ ){
			iVariable = m_aLHSVariables[iEquation];
			if( ( iVariable < m_cStates ) || ( !vDominatedVectors.contains( iVariable ) ) ){
				aiLHS[iNewEquation] = iVariable;
				aEquations[iNewEquation] = m_aEquations[iEquation];
				iNewEquation++;
			}
		}
		
		m_aLHSVariables = aiLHS;
		m_aEquations = aEquations;
	}
	
	private void removeAllDescendants(){
		for( EquationMatrix em : m_aChildren ){
			if( em != null ){
				em.removeAllDescendants();
				em.m_bRemoved = true;
			}
		}
	}
	
	private boolean addVector( Equation eParentNew, int iNewSlackVariable, 
			AlphaVector avNew, Vector<AlphaVector> vNonDominated, EquationMatrix emLast ){
		int[] aiLHSVariables = new int[m_aEquations.length + 1];
		int iEquation = 0, iIdx = 0;
		
		//System.out.println("Before: " + this);
		
		//if( m_iSubstituteEquation >= m_aEquations.length )
		//	System.out.println("***");
		
		Equation eqSubstitue = m_aEquations[m_iSubstituteEquation];
		Equation[] aEquations = new Equation[m_aEquations.length + 1];
		for( iEquation = 0 ; iEquation < m_aEquations.length ; iEquation++ ){
			aEquations[iEquation] = m_aEquations[iEquation];
			aiLHSVariables[iEquation] = m_aLHSVariables[iEquation];
		}
		Equation eNew = eParentNew.substitue( eqSubstitue );
		
		if( eNew.getShift() <= 0.001 ){
			m_bRemoved = true;
			removeAllDescendants();
			return false;
		}
		
		if( this == emLast )
			System.out.println("BUGBUG");
		
		if( m_avMax != null && !vNonDominated.contains( m_avMax ) )
			vNonDominated.add( m_avMax );
				
		aEquations[m_aEquations.length] = eNew;
		aiLHSVariables[iEquation] = iNewSlackVariable;
		m_mSlackToEquation.put( iNewSlackVariable, eNew );

		resort( aiLHSVariables, iIdx );
		
		m_aLHSVariables = aiLHSVariables;
		m_aEquations = aEquations;
		
		m_mSlackToAlphaVector.put( iNewSlackVariable, avNew );
		m_mAlphaVectorToSlack.put( avNew, iNewSlackVariable );
		
		//System.out.println("After: " + this);
		
		EquationMatrix emChild = null;
		boolean bResult = true;
		for( int i = 0 ; i < m_aChildren.length ; i++ ){
			emChild = m_aChildren[i];
			if( emChild != null ){
				bResult = emChild.addVector( eNew, iNewSlackVariable, avNew, vNonDominated, emLast );
				if( !bResult )
					m_aChildren[i] = null;			
			}
		}
		
		return true;
	}

	
	private int getNextSlackVariable(){
		int iMaxSlack = -1;
		for( int iSlack : m_mSlackToAlphaVector.keySet() ){
			if( iSlack > iMaxSlack )
				iMaxSlack = iSlack;
		}
		return iMaxSlack + 1;
	}
	
	public boolean addToTreeRoot( AlphaVector avNew, Vector<AlphaVector> vNonDominated, EquationMatrix emLast ) {
		if( m_eMaxValue == null )
			return false;
		
		//if( avNew.getId() == 8885 )
		//	System.out.println("***");
		
		if( m_mAlphaVectorToSlack.get( avNew ) != null )
			return false;
		
		//System.out.println("Before " + this);
				
		if( m_avMax != null && !vNonDominated.contains( m_avMax ) )
			vNonDominated.add( m_avMax );
		
		int cEquations = m_aEquations.length + 1;
		Equation[] aNewEquations = new Equation[cEquations];
		int iNewSlackVariable = getNextSlackVariable();
		int[] aiNewLHS = new int[m_aLHSVariables.length + 1];
		
		for( int i = 0 ; i < m_aLHSVariables.length ; i++ )
			aiNewLHS[i] = m_aLHSVariables[i];
		aiNewLHS[m_aLHSVariables.length] = iNewSlackVariable;

		for( int i = 0 ; i < m_aEquations.length ; i++ )
			aNewEquations[i] = m_aEquations[i];
		aNewEquations[m_aEquations.length] = null;
		
		m_aLHSVariables = aiNewLHS;
		m_mSlackToAlphaVector.put( iNewSlackVariable, avNew );
		m_mAlphaVectorToSlack.put( avNew, iNewSlackVariable );

		Equation eNew = new Equation( avNew, m_cStates, iNewSlackVariable, m_iDeterministicState );
		Equation eJoined = eNew.join( m_eMaxValue );
		aNewEquations[m_aEquations.length] = eJoined;		
		m_aEquations = aNewEquations;
		
		m_mSlackToEquation.put( iNewSlackVariable, eJoined );
		
		if( eJoined.getShift() < 0.00 )
			System.out.println( "BUGBUG" );
		
		EquationMatrix emChild = null;
		boolean bResult = true;
		for( int i = 0 ; i < m_aChildren.length ; i++ ){
			emChild = m_aChildren[i];
			if( emChild != null ){
				bResult = emChild.addVector( eJoined, iNewSlackVariable, avNew, vNonDominated, emLast );
				if( !bResult )
					m_aChildren[i] = null;			
				
			}
		}
		//System.out.println("After " + this);
		return true;
	}

	
	public boolean removeFromTreeRoot( AlphaVector avExisting ) {
		if( m_eMaxValue == null )
			return false;
		
		if( m_mAlphaVectorToSlack.get( avExisting ) == null )
			return false;
		
		int iRemovedSlackVariable = getVariable( avExisting );
		m_mSlackToAlphaVector.remove( iRemovedSlackVariable );
		m_mSlackToEquation.remove( iRemovedSlackVariable );
		m_mAlphaVectorToSlack.remove( avExisting );

		return removeVector( iRemovedSlackVariable );
	}
		
		
	public boolean removeVector( int iRemovedSlackVariable ) {
						
		int cEquations = m_aEquations.length - 1;
		Equation[] aNewEquations = new Equation[cEquations];
		int[] aiNewLHS = new int[m_aLHSVariables.length - 1];
		int i = 0;
		
		boolean bContains = false;
		for( int iVar : m_aRHSVariables ){
			if( iVar == iRemovedSlackVariable )
				bContains = true;
		}
		if( bContains ){
			//vector is optimal here so we must throw away the entire matrix
			m_bRemoved = true;
			removeAllDescendants();
			return false;
		}
			
			
		for( int iVar : m_aLHSVariables ){
			if( iVar != iRemovedSlackVariable ){
				aiNewLHS[i] = iVar;
				i++;
			}
		}
		i = 0;
		Equation eqSubstitute = null;
		if( m_iSubstituteEquation >= 0 )
			eqSubstitute = m_aEquations[m_iSubstituteEquation];
		for( Equation e : m_aEquations ){
			if( e.getLHSVariable() != iRemovedSlackVariable ){
				aNewEquations[i] = e;
				if( e == eqSubstitute )
					m_iSubstituteEquation = i;
				i++;
			}
		}
		
		m_aLHSVariables = aiNewLHS;

		m_aEquations = aNewEquations;
		
		EquationMatrix emChild = null;
		for( i = 0 ; i < m_aChildren.length ; i++ ){
			emChild = m_aChildren[i];
			if( emChild != null ){
				if( !emChild.removeVector( iRemovedSlackVariable ) )
					m_aChildren[i] = null;
			}
		}
		//System.out.println("After " + this);
		return true;
	}

	public boolean validate() {
		return !m_bRemoved;
	}
}
