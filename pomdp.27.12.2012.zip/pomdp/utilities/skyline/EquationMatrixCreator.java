package pomdp.utilities.skyline;

import java.util.Comparator;
import java.util.SortedSet;

public class EquationMatrixCreator {
	private EquationMatrix m_emMatrix;
	private int m_iOutVariableIdx;
	private int m_cZeroBeliefStates;
	
	public EquationMatrixCreator( EquationMatrix em, int iOutVariable, int cZeroBeliefStates ){
		m_iOutVariableIdx = iOutVariable;
		m_emMatrix = em;
		m_cZeroBeliefStates = cZeroBeliefStates;
	}
	
	public EquationMatrix getMatrix(){
		SortedSet s = null;
		return m_emMatrix.getNeighbor( m_iOutVariableIdx, s );
	}
	
	public int getZeroBeliefStates(){
		return m_cZeroBeliefStates;
	}
}
