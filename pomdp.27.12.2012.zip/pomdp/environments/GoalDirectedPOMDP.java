package pomdp.environments;

import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Vector;
import java.util.Map.Entry;

import pomdp.algorithms.PolicyStrategy;
import pomdp.environments.POMDP.RewardType;
import pomdp.utilities.AlphaVector;
import pomdp.utilities.BeliefState;
import pomdp.utilities.ExecutionProperties;
import pomdp.utilities.InvalidModelFileFormatException;
import pomdp.utilities.MDPValueFunction;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

public class GoalDirectedPOMDP extends POMDP {

	protected POMDP m_pPOMDP;
	
	public GoalDirectedPOMDP( POMDP pomdp ){
		super();
		m_pPOMDP = pomdp;
		m_cStates = m_pPOMDP.m_cStates + 1;
		m_cObservations = m_pPOMDP.m_cObservations + 1;
		m_dGamma = 1.0;
		initBeliefStateFactory();
		m_vfMDP = new MDPValueFunction( this, 0.0 );
		m_vfMDP.valueIteration( 1000, ExecutionProperties.getEpsilon() );
	}
	
	public void load( String sFileName ) throws IOException, InvalidModelFileFormatException{
		m_pPOMDP.load( sFileName );
	}
	/*
	public MDPValueFunction getMDPValueFunction(){
		//BUGBUG - there is likely a bug here
		throw new NotImplementedException();
	}
	*/
	public boolean useClassicBackup(){
		return m_pPOMDP.useClassicBackup();
	}
	/*
	protected void initStoredRewards(){
		//BUGBUG - there is likely a bug here
		throw new NotImplementedException();
	}
	*/
	public double tr( int iState1, int iAction, int iState2 ){
		if(iState1 == m_cStates - 1){
			
			if(iState2 == iState1)
				return 1;
			else
				return 0.0;
		}
		else
		{
			if(iState2 == m_cStates - 1)
				return (1 - m_pPOMDP.getDiscountFactor());
		}
			
		double dOrgTr = m_pPOMDP.tr( iState1, iAction, iState2 );
		return dOrgTr * m_pPOMDP.getDiscountFactor();
	}
	
	/**
	 * Immediate reward function of the POMDP. Checks reward type (R(s,a,s'),R(s,a) or R(s)) before accessing the reward function. 
	 * @param iStartState
	 * @param iAction
	 * @param iEndState
	 * @return immediate reward
	 */
	public double R( int iStartState, int iAction, int iEndState ){
		if( iStartState == m_cStates - 1)
			return 0.0;
		double dMaxReward = m_pPOMDP.getMaxR();
		double dOrg = m_pPOMDP.R( iStartState, iAction, iEndState );
		return dOrg - dMaxReward;
	}
	
	/**
	 * Immediate reward function of the POMDP.
	 * @param iStartState
	 * @return immediate reward
	 */
	public double R( int iStartState ){
		if( iStartState == m_cStates - 1)
			return 0.0;
		double dMaxReward = m_pPOMDP.getMaxR();
		double dOrg = m_pPOMDP.R( iStartState );
		return dOrg - dMaxReward;
	}
	
	/**
	 * Immediate reward function of the POMDP of the form R(s,a). If reward structure is of the form R(s,a,s') it sums over all possible s'. 
	 * @param iStartState
	 * @param iAction
	 * @return immediate reward
	 */
	public double R( int iStartState, int iAction ){
		if( iStartState == m_cStates - 1)
			return 0.0;
		double dMaxReward = m_pPOMDP.getMaxR();
		double dOrg = m_pPOMDP.R( iStartState, iAction );
		return dOrg - dMaxReward;
	}
	
	public double O( int iAction, int iState, int iObservation ){
		if(iObservation == m_cObservations - 1)
		{
			if( iState == m_cStates - 1 )
				return 1.0;
			else
				return 0.0;
			
		}
		if( iState == m_cStates - 1)
			return 0.0;
		return m_pPOMDP.O( iAction, iState, iObservation );
	}
	
	public double O( int iStartState, int iAction, int iEndState, int iObservation ){
		if(iObservation == m_cObservations - 1)
		{
			if( iEndState == m_cStates - 1 )
				return 1.0;
			else
				return 0.0;
			
		}
		if( iEndState == m_cStates - 1)
			return 0.0;
		return m_pPOMDP.O( iStartState, iAction, iEndState, iObservation );
	}
	
	public String getActionName( int iAction ){
		return m_pPOMDP.getActionName( iAction );
	}
	public int getActionIndex( String sAction ){
		return m_pPOMDP.getActionIndex( sAction );
	}
	
	public String getStateName( int iState ){
		if( iState == m_cStates - 1)
			return "G";
		return m_pPOMDP.getStateName( iState );
	}
	
	public int getStateIndex( String sState ){
		if(sState.equals("G"))
			return m_cStates - 1;
		return m_pPOMDP.getStateIndex( sState );
	}
	public int getObservationIndex( String sObservation ){
		if(sObservation.equals("G"))
			return m_cObservations - 1;
		return m_pPOMDP.getObservationIndex( sObservation );
	}
	/*
	public int execute( int iAction, int iState ){
		
		return m_pPOMDP.execute( iAction, iState );
	}
	*/
	public int observe( int iAction, int iState ){
		if(iState == m_cStates - 1)
			return m_cObservations - 1;
		return m_pPOMDP.observe( iAction, iState );
	}
	/*
	public int observe( BeliefState bs, int iAction ){
		return m_pPOMDP.observe( bs, iAction );
	}
	/*
	public double computeAverageDiscountedReward( int cTests, int cMaxStepsToGoal, PolicyStrategy policy, boolean bOutputMessages, boolean bUseMultiThread ){
		return m_pPOMDP.computeAverageDiscountedReward( cTests, cMaxStepsToGoal, policy, bOutputMessages, bUseMultiThread );
	}
	
	protected double computeMDPAverageDiscountedReward( int cTests, int cMaxStepsToGoal ){
		return m_pPOMDP.computeMDPAverageDiscountedReward( cTests, cMaxStepsToGoal );
	}
*/
	public int chooseStartState(){
		return m_pPOMDP.chooseStartState();
	}
	
	public boolean isTerminalState( int iState ){
		return iState == m_cStates - 1;
	}
	
	protected double maxReward( int iState ){
		return 0.0;
	}

	public double getMaxMinR(){
		int iAction = 0;
		double dMaxR = MIN_INF;
		for( iAction = 0 ; iAction < getActionCount(); iAction++ ){
			double dMin = 0.0;
			for(int iState = 0 ; iState < m_cStates ; iState++){
				if(R(iState,iAction) < dMin)
					dMin = R(iState,iAction);
			}
			if( dMin > dMaxR )
				dMaxR = dMin;
		}
		return dMaxR;
	}
	
	public boolean terminalStatesDefined(){
		return true;
	}

	public int getStateCount() {
		return m_cStates;
	}

	public int getActionCount() {
		return m_pPOMDP.getActionCount();
	}

	public int getObservationCount() {
		return m_cObservations;
	}

	public double getDiscountFactor() {
		return 1.0;
	}
 
	public Iterator<Entry<Integer,Double>> getNonZeroTransitions( int iStartState, int iAction ) {
		HashMap<Integer,Double> hmTransitions = new HashMap<Integer,Double>();
		if(iStartState == m_cStates - 1){
			hmTransitions.put(iStartState, 1.0);		
		}
		else{
			Iterator<Entry<Integer,Double>> itOrg = m_pPOMDP.getNonZeroTransitions( iStartState, iAction );
			while( itOrg.hasNext() ){
				Entry e = (Entry) itOrg.next();
				int iEndState = ((Number) e.getKey()).intValue();
				//if( iEndState == 0 )
				//	System.out.println();
				double dTr = ((Number) e.getValue()).doubleValue();
				hmTransitions.put(iEndState, dTr * m_pPOMDP.getDiscountFactor());
			}
			hmTransitions.put(m_cStates - 1, 1.0 - m_pPOMDP.getDiscountFactor());
		}
		return hmTransitions.entrySet().iterator();
	}

	public Collection<Entry<Integer,Double>> getNonZeroBackwardTransitions( int iAction, int iEndState ) {
		return m_pPOMDP.getNonZeroBackwardTransitions( iAction, iEndState );
	}

	public double probStartState( int iState ){
		if(iState == m_cStates - 1)
			return 0.0;
		return m_pPOMDP.probStartState( iState );
	}
	
	public double getMinR(){
		return m_pPOMDP.getMinR() - m_pPOMDP.getMaxR();
	}
	
	public double getMaxR(){
		return 0.0;
	}
	/*
	public double getMaxMinR(){
		return m_pPOMDP.getMaxMinR();
	}
*/
	public int getStartStateCount() {
		return m_pPOMDP.getStartStateCount();
	}

	public Iterator<Entry<Integer, Double>> getStartStates() {
		return m_pPOMDP.getStartStates();
	}

	public void initRandomGenerator( long iSeed ){
		m_rndGenerator.init( iSeed );		
	}

	public void setRandomSeed( long iSeed ){
		m_iRandomSeed = iSeed;		
	}
/*
	public AlphaVector newAlphaVector() {
		return m_pPOMDP.newAlphaVector();
	}
	
	public boolean isValid( int iState ){
		return m_pPOMDP.isValid( iState );
	}
	
	public Collection<Integer> getValidStates(){
		return m_pPOMDP.getValidStates();
	}
*/
	public boolean isFactored() {
		return m_pPOMDP.isFactored();
	}
	
	public String getName(){
		return "Goal-" + m_pPOMDP.getName();
	}
	
	/**
	 * Computes the immediate reward for a belief state over all actions
	 * @param bs
	 * @return
	 */
	/*
	public double immediateReward( BeliefState bs ){
		return m_pPOMDP.immediateReward( bs );
	}
*/
	
	/**
	 * Computes the immediate reward for a belief state and a specific action
	 * @param bs - belief state
	 * @param iAction - action index
	 * @return
	 */
	/*
	public double immediateReward( BeliefState bs, int iAction ){
		return m_pPOMDP.immediateReward( bs, iAction );
	}

	public Vector<Integer> getObservationRelevantStates() {
		return m_pPOMDP.getObservationRelevantStates();
	}
*/
	public RewardType getRewardType() {
		return m_pPOMDP.getRewardType();
	}
/*
	public void initBeliefStateFactory() {
		m_pPOMDP.initBeliefStateFactory();		
	}

	public double R( BeliefState bsCurrent, int iAction, BeliefState bsNext ){
		return m_pPOMDP.R( bsCurrent, iAction, bsNext );
	}

	public Collection<Integer> getRelevantActions( BeliefState bs ) {
		return m_pPOMDP.getRelevantActions( bs );
	}
*/
	public double computeAverageDiscountedReward( int cTests, int cMaxStepsToGoal, PolicyStrategy policy ){
		return m_pPOMDP.computeAverageDiscountedReward(cTests, cMaxStepsToGoal, policy);
	}

	public POMDP getOriginal() {
		return m_pPOMDP;
	}

}
