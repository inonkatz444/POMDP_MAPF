package pomdp.valuefunction;

import java.util.Map;

import pomdp.utilities.AlphaVector;
import pomdp.utilities.BeliefState;
import pomdp.utilities.RandomGenerator;

public class LSHVauleFunction extends LinearValueFunctionApproximation {
	private int m_cStates, m_cK;
	double m_dGamma, m_dMaxReward, m_dMinReward;
	private int[][] m_aiEmbeddingMatrix;
	private Map<Integer,AlphaVector> m_mVectors;
	private Map<Integer,double[]> m_mEmbedded;
	
	public LSHVauleFunction( int cStates,double dGamma,double dMaxReward,double dMinReward, double dEpsilon, boolean bCacheValues ){
		super(dEpsilon, bCacheValues);
		m_cStates = cStates;
		m_dMaxReward = dMaxReward;
		m_dMinReward = dMinReward;
		m_dGamma = dGamma;
		createEmbeddingMatrix(1, 0.5);
	}

	private void createEmbeddingMatrix(double dC, double dE) {
		m_cK = computeK( dC, dE );
		m_aiEmbeddingMatrix = new int[m_cK][m_cStates + 1];
		for(int i = 0 ; i < m_cStates + 1 ; i++){
			for(int j = 0 ; j < m_cK ; j++){
				if(m_rndGenerator.nextDouble() < 0.5)
					m_aiEmbeddingMatrix[j][i] = 1;
				else
					m_aiEmbeddingMatrix[j][i] = -1;
			}
		}
	}

	//k := logn (4+2C)/((E^2)/2 - (E^3)/3)
	private int computeK(double dC, double dE){
		double dDenominator = Math.pow(dE,2) / 2 - Math.pow(dE, 3) / 3;
		double dK = Math.log( m_cStates) * (4 + 2 * dC ) / dDenominator ;
		return (int)Math.ceil(dK);
	}
	
	private double[] embed(AlphaVector av){
		double[] adEmbedded = new double[m_cK];
		double dMin = m_dMinReward / (1 - m_dGamma);
		double dMax = m_dMaxReward / (1 - m_dGamma);
		double[] adNormalized = new double[m_cStates + 1];
		double dSum = 0.0;
		for(int j = 0 ; j < m_cStates ; j++)
		{
			adNormalized[j] = (av.valueAt(j) + dMin) / (dMax - dMin);
			dSum += adNormalized[j];
		}
		adNormalized[m_cStates] = 1.0 - dSum;
		for(int i = 0 ; i < m_cK ; i++)
		{
			dSum = 0.0;
			for(int j = 0 ; j < m_cStates + 1 ; j++)
			{
				dSum += adNormalized[j] * m_aiEmbeddingMatrix[i][j];
			}
			adEmbedded[i] = dSum;
		}
		return adEmbedded;
	}
	
	public void add( AlphaVector avNew ){
		double[] adEmbedded = embed(avNew);
		add( avNew, false );
	}
	public boolean addPrunePointwiseDominated( AlphaVector avNew ){
		double[] adEmbedded = embed(avNew);
		return super.addPrunePointwiseDominated(avNew);
	}

}
