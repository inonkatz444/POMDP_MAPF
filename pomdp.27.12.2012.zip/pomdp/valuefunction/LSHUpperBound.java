package pomdp.valuefunction;

import java.util.Map;

import pomdp.environments.POMDP;
import pomdp.utilities.AlphaVector;
import pomdp.utilities.BeliefState;
import pomdp.utilities.MDPValueFunction;
import pomdp.utilities.RandomGenerator;

public class LSHUpperBound extends UpperBoundValueFunctionApproximation {
	private int m_cStates, m_cK;
	//double m_dGamma, m_dMaxReward, m_dMinReward;
	private int[][] m_aiEmbeddingMatrix;
	private Map<Integer,BeliefState> m_mBeliefs;
	private Map<Integer,double[]> m_mEmbedded;
	private RandomGenerator m_rndGenerator;

	public LSHUpperBound(POMDP pomdp, MDPValueFunction vfMDP) {
		super(pomdp, vfMDP);
		m_cStates = pomdp.getStateCount();
		//m_dMaxReward = pomdp.getMaxR();
		//m_dMinReward = pomdp.getMinR();
		//m_dGamma = pomdp.getDiscountFactor();
		m_rndGenerator = new RandomGenerator("LSH",1111);
		createEmbeddingMatrix(1, 0.5);
	}

	private void createEmbeddingMatrix(double dC, double dE) {
		m_cK = computeK( dC, dE );
		m_aiEmbeddingMatrix = new int[m_cK][m_cStates + 1];
		for(int i = 0 ; i < m_cStates + 1 ; i++){
			for(int j = 0 ; j < m_cK ; j++){
				if(m_rndGenerator.nextDouble() < 0.5)
					m_aiEmbeddingMatrix[j][i] = 1;
				else
					m_aiEmbeddingMatrix[j][i] = -1;
			}
		}
	}

	//k := logn (4+2C)/((E^2)/2 - (E^3)/3)
	private int computeK(double dC, double dE){
		double dDenominator = Math.pow(dE,2) / 2 - Math.pow(dE, 3) / 3;
		double dK = Math.log( m_cStates) * (4 + 2 * dC ) / dDenominator ;
		return (int)Math.ceil(dK);
	}
	
	private double[] embed(BeliefState bs){
		double[] adEmbedded = new double[m_cK];
		for(int i = 0 ; i < m_cK ; i++)
		{
			double dSum = 0.0;
			for(int j = 0 ; j < m_cStates + 1 ; j++)
			{
				dSum += bs.valueAt(j) * m_aiEmbeddingMatrix[i][j];
			}
			adEmbedded[i] = dSum;
		}
		return adEmbedded;
	}
		
	
}
