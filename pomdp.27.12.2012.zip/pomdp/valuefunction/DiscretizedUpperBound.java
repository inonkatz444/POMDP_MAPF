package pomdp.valuefunction;

import java.util.Map;
import java.util.TreeMap;

import pomdp.environments.POMDP;
import pomdp.utilities.ArrayComparator;
import pomdp.utilities.BeliefState;
import pomdp.utilities.BeliefStateFactory;
import pomdp.utilities.MDPValueFunction;

public class DiscretizedUpperBound extends
		UpperBoundValueFunctionApproximation {

	private int m_cDiscretizationLevels;
	protected Map<int[],Double> m_mValues;
	protected int m_cStates;
	protected MDPValueFunction m_vfMDP;

	
	public DiscretizedUpperBound( POMDP pomdp, int cDiscretizationLevels, MDPValueFunction vfMDP ){
		super( pomdp, vfMDP );
		m_cDiscretizationLevels = cDiscretizationLevels;
		m_mValues = new TreeMap<int[], Double>(ArrayComparator.getIntComparator());		
		m_cStates = pomdp.getStateCount();
		m_vfMDP = vfMDP;
	}
	
	public DiscretizedUpperBound( POMDP pomdp, int cDiscretizationLevels, double dDefaultValue ){
		super( pomdp, dDefaultValue );
		m_cDiscretizationLevels = cDiscretizationLevels;
	}
	/*
	public void updateValue( BeliefState bs ) {
		BeliefState bsDiscretized = m_pPOMDP.getBeliefStateFactory().discretize( bs, m_cDiscretizationLevels );
		super.updateValue( bsDiscretized );
	}
	public double updateValue( BeliefState bs, int iAction ) {
		BeliefState bsDiscretized = m_pPOMDP.getBeliefStateFactory().discretize( bs, m_cDiscretizationLevels );
		return super.updateValue( bsDiscretized, iAction );
	}
*/
	private int[] discritize(BeliefState bs) {
		int[] aiBelief = new int[m_cStates];
		for(int iState = 0 ; iState < m_cStates ; iState++){
			double dRound = Math.ceil( bs.valueAt(iState) * m_cDiscretizationLevels );
			aiBelief[iState] = (int)dRound;
		}
		return aiBelief;
	}
	
	public void setValueAt(BeliefState bs, double dValue) {
		int[] aiBelief = discritize(bs);
		if(!m_mValues.containsKey(aiBelief) || Math.abs(m_mValues.get(aiBelief) - dValue) > 0.001)
			m_cChanges++;
		m_mValues.put(aiBelief, dValue);	
	}

	public double valueAt(BeliefState bs){
		int[] aiBelief = discritize(bs);
		if(m_mValues.containsKey(aiBelief))
			return m_mValues.get(aiBelief);
		return m_vfMDP.getValue(bs);
	}
	
	public int getUpperBoundPointCount(){
		return m_mValues.size();
	}
	/*
	public double valueAt( BeliefState bs, int iAction ) {
		BeliefState bsDiscretized = m_pPOMDP.getBeliefStateFactory().discretize( bs, m_cDiscretizationLevels );
		return super.valueAt( bsDiscretized, iAction );
	}
*/
}
