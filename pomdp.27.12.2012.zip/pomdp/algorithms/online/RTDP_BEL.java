package pomdp.algorithms.online;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.Vector;

import pomdp.algorithms.ValueIteration;


import pomdp.algorithms.ValueIteration;
import pomdp.algorithms.pointbased.HeuristicSearchValueIteration;
import pomdp.environments.POMDP;
import pomdp.utilities.AlphaVector;
import pomdp.utilities.ArrayComparator;
import pomdp.utilities.BeliefState;
import pomdp.utilities.BeliefStateFactory;
import pomdp.utilities.ExecutionProperties;
import pomdp.utilities.JProf;
import pomdp.utilities.Logger;
import pomdp.utilities.MDPValueFunction;
import pomdp.utilities.Pair;
import pomdp.valuefunction.DiscretizedUpperBound;
import pomdp.valuefunction.LinearValueFunctionApproximation;

public class RTDP_BEL extends ValueIteration {

	protected int m_cDiscretizationLevels;
	protected Map<int[],Double> m_mValues;
	
	public RTDP_BEL( POMDP pomdp ){
		this( pomdp, 10 );
	}

	public RTDP_BEL( POMDP pomdp, int cDiscretizationLevels ){
		super( pomdp );
		m_cDiscretizationLevels = cDiscretizationLevels;
		m_pPOMDP.getBeliefStateFactory().setDiscretizationLevels( cDiscretizationLevels );
		m_mValues = new TreeMap<int[], Double>(ArrayComparator.getIntComparator());		
	}
		
	protected int explore( BeliefState bsCurrent){
		int iStartState = m_pPOMDP.chooseStartState();
		return explore( bsCurrent, iStartState, 0 );
	}
		
	protected int explore( BeliefState bsCurrent, int iCurrentState, int iTime){
		int iAction = 0, iObservation = 0, iNextState = 0;
		BeliefState bsNext = null;
		int iMaxDepth = 0;

		if( m_pPOMDP.isTerminalState( iCurrentState ) )
			return iTime;		

		if( iTime > 100  )
			return iTime;
			
		double dBestActionValue = Double.NEGATIVE_INFINITY;
		Vector<Integer> vBestActions = new Vector<Integer>();
		for( iAction = 0 ; iAction < m_cActions ; iAction++)
		{
			double dActionValue = valueAt(bsCurrent, iAction);			
			if( dActionValue > dBestActionValue ){
				dBestActionValue = dActionValue;
				vBestActions.clear();
			}
			if( Math.abs(dActionValue - dBestActionValue) < 0.01 )
				vBestActions.add(iAction);
		}
		int iBestAction = vBestActions.elementAt( m_rndGenerator.nextInt(vBestActions.size() ) );
		
		setValueAt(bsCurrent, dBestActionValue);
				
		iNextState = m_pPOMDP.execute( iBestAction, iCurrentState );
		iObservation = m_pPOMDP.observe( iBestAction, iNextState );

		bsNext = bsCurrent.nextBeliefState( iBestAction, iObservation );
		
		iMaxDepth = explore( bsNext, iNextState,  iTime + 1 );

					
		return iMaxDepth;
	}
	
	private void setValueAt(BeliefState bs, double dValue) {
		int[] aiBelief = discritize(bs);
		m_mValues.put(aiBelief, dValue);	
	}

	public double valueAt(BeliefState bs){
		int[] aiBelief = discritize(bs);
		if(m_mValues.containsKey(aiBelief))
			return m_mValues.get(aiBelief);
		return m_vfMDP.getValue(bs);
	}
	
	private int[] discritize(BeliefState bs) {
		int[] aiBelief = new int[m_cStates];
		for(int iState = 0 ; iState < m_cStates ; iState++){
			double dRound = Math.ceil( bs.valueAt(iState) * m_cDiscretizationLevels );
			aiBelief[iState] = (int)dRound;
		}
		return aiBelief;
	}

	protected double valueAt(BeliefState bs, int iAction){
		double dActionValue = m_pPOMDP.immediateReward(bs, iAction);
		for( int iObservation = 0 ; iObservation < m_cObservations ; iObservation++ ){
			double dPr = bs.probabilityOGivenA(iAction, iObservation);
			if( dPr > 0 ){
				BeliefState bsSuccessor = bs.nextBeliefState(iAction, iObservation);
				double dSuccessorValue = valueAt(bsSuccessor);
				dActionValue += dPr * dSuccessorValue;		
			}
		}
		return dActionValue;
	}
	
	public int getBestAction(BeliefState bs){
		int iBestAction = -1;
		double dBestActionValue = Double.NEGATIVE_INFINITY;
		Vector<Integer> vBestActions = new Vector<Integer>();
		for( int iAction = 0 ; iAction < m_cActions ; iAction++)
		{
			double dActionValue = valueAt(bs, iAction);			
			if( dActionValue > dBestActionValue ){
				dBestActionValue = dActionValue;
				iBestAction = iAction;
				vBestActions.clear();
			}
			if( Math.abs(dActionValue - dBestActionValue) < 0.01 )
				vBestActions.add(iAction);
		}
		iBestAction = vBestActions.elementAt( m_rndGenerator.nextInt(vBestActions.size() ) );
		return iBestAction;
	}
	
	public String getName(){
		return "RTDP";
	}

	@Override
	public void valueIteration(int cMaxSteps, double dEpsilon, double dTargetValue) {
		BeliefState bsInitial = m_pPOMDP.getBeliefStateFactory().getInitialBeliefState();
		int iIteration = 0, iMaxDepth = 0;
		long lStartTime = System.currentTimeMillis(), lCurrentTime = 0;
		Runtime rtRuntime = Runtime.getRuntime();
		boolean bDone = false;
		Pair<Double, Double> pComputedADRs = new Pair<Double, Double>();
		int cNoChange = 0;
		String sMsg = "";
		
		m_cElapsedExecutionTime = 0;
		m_cCPUExecutionTime = 0;
		
		long lCPUTimeBefore = 0, lCPUTimeAfter = 0, lCPUTimeTotal = 0;
		
		int cValueFunctionChanges = 0;
		
		
		for( iIteration = 0 ; ( iIteration < cMaxSteps ) && !bDone && !m_bTerminate ; iIteration++ ){
			lStartTime = System.currentTimeMillis();
			lCPUTimeBefore = JProf.getCurrentThreadCpuTimeSafe();
			
			iMaxDepth = explore( bsInitial );
			
			lCurrentTime = System.currentTimeMillis();
			lCPUTimeAfter = JProf.getCurrentThreadCpuTimeSafe();
			m_cElapsedExecutionTime += ( lCurrentTime - lStartTime );
			m_cCPUExecutionTime += ( lCPUTimeAfter - lCPUTimeBefore ) / 1000000;
			lCPUTimeTotal += lCPUTimeAfter - lCPUTimeBefore;
			
			if( ( iIteration >= 20 ) && ( ( lCPUTimeTotal  / 1000000000 ) >= 0 ) && ( iIteration % 20 == 0 )  ){
								
				bDone = checkADRConvergence( m_pPOMDP, dTargetValue, pComputedADRs );
				
				rtRuntime.gc();
				
				sMsg = getName() + ": Iteration " + iIteration + 
									" V^(b) " + round( valueAt( m_pPOMDP.getBeliefStateFactory().getInitialBeliefState() ), 4 ) +
									//" max width bs = " + bsMaxWidth + 
									//" max width " + round( width( bsMaxWidth ), 3 ) +
									" max depth " + iMaxDepth +
									" simulated ADR " + ((Number) pComputedADRs.first()).doubleValue() +
									" filtered ADR " + round( ((Number) pComputedADRs.second()).doubleValue(), 3 ) +
									" Time " + ( lCurrentTime - lStartTime ) / 1000 +
									" CPU time " + ( lCPUTimeAfter - lCPUTimeBefore ) / 1000000000 +
									" CPU total " + lCPUTimeTotal  / 1000000000 +
									" |V^| " + m_mValues.size() +
									" V changes " + m_vValueFunction.getChangesCount() +
									" #BS " + m_pPOMDP.getBeliefStateFactory().getBeliefUpdatesCount() +
									" #backups " + m_cBackups +
									" max depth " + iMaxDepth +
									" free memory " + rtRuntime.freeMemory() / 1000000 +
									" total memory " + rtRuntime.totalMemory() / 1000000 +
									" max memory " + rtRuntime.maxMemory() / 1000000;
			}
			else{
				sMsg = getName() + ": Iteration " + iIteration + 
						" V^(b) " + round( valueAt( m_pPOMDP.getBeliefStateFactory().getInitialBeliefState() ), 4 ) +
						" max depth " + iMaxDepth +
						" Time " + ( lCurrentTime - lStartTime ) / 1000 +
						" CPU time " + ( lCPUTimeAfter - lCPUTimeBefore ) / 1000000000 +
						" CPU total " + lCPUTimeTotal  / 1000000000 +
						" |V^| " + m_mValues.size() +
						" #BS " + m_pPOMDP.getBeliefStateFactory().getBeliefUpdatesCount() +
						" #backups " + m_cBackups +
						" free memory " + rtRuntime.freeMemory() / 1000000 +
						" total memory " + rtRuntime.totalMemory() / 1000000 +
						" max memory " + rtRuntime.maxMemory() / 1000000;
			}
			Logger.getInstance().log( getName(), 0, "VI", sMsg );
			if( m_vValueFunction.getChangesCount() == cValueFunctionChanges ){
				cNoChange++;
			}
			else
				cNoChange = 0;
		}
		
		m_cElapsedExecutionTime /= 1000;
		m_cCPUExecutionTime /= 1000;
		
		sMsg = "Finished " + getName() + " - time : " + m_cElapsedExecutionTime +
				" |V| = " + m_vValueFunction.size() + 
				" backups = " + m_cBackups + 
				" GComputations = " + AlphaVector.getGComputationsCount() +
				" Dot products = " + AlphaVector.dotProductCount();
		Logger.getInstance().log( "HSVI", 0, "VI", sMsg );
		
		if( ExecutionProperties.getReportOperationTime() )
			sMsg = "Avg time: backup " + ( m_cTimeInBackup / ( m_cBackups * 1.0 ) ) + 
					" G " + AlphaVector.getAvgGTime() +
					" Tau " + m_pPOMDP.getBeliefStateFactory().getAvgTauTime() + 
					" DP " + AlphaVector.getAvgDotProductTime() 
					;
		Logger.getInstance().log( "RTDP", 0, "VI", sMsg );
	}
}
