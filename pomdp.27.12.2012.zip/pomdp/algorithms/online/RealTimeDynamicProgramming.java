package pomdp.algorithms.online;

import java.util.Vector;

import pomdp.algorithms.ValueIteration;
import pomdp.environments.POMDP;
import pomdp.utilities.AlphaVector;
import pomdp.utilities.BeliefState;
import pomdp.utilities.ExecutionProperties;
import pomdp.utilities.JProf;
import pomdp.utilities.Logger;
import pomdp.utilities.Pair;
import pomdp.valuefunction.DiscretizedUpperBound;
import pomdp.valuefunction.JigSawValueFunction;
import pomdp.valuefunction.UpperBoundValueFunctionApproximation;

public class RealTimeDynamicProgramming extends ValueIteration {

	protected int m_cDiscretizationLevels;
	protected UpperBoundValueFunctionApproximation m_dUpperBound;
	
	public RealTimeDynamicProgramming( POMDP pomdp ){
		this( pomdp, 50 );
	}

	public RealTimeDynamicProgramming( POMDP pomdp, int cDiscretizationLevels ){
		super( pomdp );
		m_cDiscretizationLevels = cDiscretizationLevels;
		m_pPOMDP.getBeliefStateFactory().setDiscretizationLevels( cDiscretizationLevels );
		//m_dUpperBound = new DiscretizedUpperBound( m_pPOMDP, cDiscretizationLevels, m_pPOMDP.getMDPValueFunction() );
		m_dUpperBound = new JigSawValueFunction(pomdp, pomdp.getMDPValueFunction());
	}
		
	protected int explore( BeliefState bsCurrent, double dEpsilon, int iTime, double dDiscount, Vector<BeliefState> vObservedBeliefStates ){
		int iStartState = m_pPOMDP.chooseStartState();
		return explore( bsCurrent, iStartState, dEpsilon, iTime, dDiscount, vObservedBeliefStates );
	}
	protected int explore( BeliefState bsCurrent, int iCurrentState, double dEpsilon, int iTime, double dDiscount, Vector<BeliefState> vObservedBeliefStates ){
		int iAction = 0, iObservation = 0, iNextState = 0;
		BeliefState bsNext = null;
		int iMaxDepth = 0;

		if( m_pPOMDP.isTerminalState( iCurrentState ) )
			return iTime;
		
		if(vObservedBeliefStates != null && !vObservedBeliefStates.contains( bsCurrent ) )
			vObservedBeliefStates.add( bsCurrent );
		
		if( iTime > 100  )
			return iTime;
			
		//m_dUpperBound.updateValue(bsCurrent);
		
		iAction = m_dUpperBound.getAction( bsCurrent );
		
		double dValue = m_dUpperBound.valueAt(bsCurrent, iAction);
		
		m_dUpperBound.setValueAt(bsCurrent, dValue);
		
		iNextState = m_pPOMDP.execute( iAction, iCurrentState );
		iObservation = m_pPOMDP.observe( iAction, iNextState );

		bsNext = bsCurrent.nextBeliefState( iAction, iObservation );
		
		iMaxDepth = explore( bsNext, iNextState, dEpsilon, iTime + 1, dDiscount * m_dGamma, vObservedBeliefStates );

		//m_dUpperBound.updateValue( bsCurrent );
					
		return iMaxDepth;
	}
/*
	public int getBestAction(BeliefState bs){
		return m_dUpperBound.getAction(bs);
	}
	
	protected double valueAt(BeliefState bs, int iAction){
		double dActionValue = m_pPOMDP.immediateReward(bs, iAction);
		for( int iObservation = 0 ; iObservation < m_cObservations ; iObservation++ ){
			double dPr = bs.probabilityOGivenA(iAction, iObservation);
			if( dPr > 0 ){
				BeliefState bsSuccessor = bs.nextBeliefState(iAction, iObservation);
				double dSuccessorValue = m_dUpperBound.valueAt(bsSuccessor);
				dActionValue += dPr * dSuccessorValue;		
			}
		}
		return dActionValue;
	}
	*/
	public int getBestAction(BeliefState bs){
		int iBestAction = -1;
		double dBestActionValue = Double.NEGATIVE_INFINITY;
		for( int iAction = 0 ; iAction < m_cActions ; iAction++)
		{
			double dActionValue = m_dUpperBound.valueAt(bs, iAction);			
			if( dActionValue > dBestActionValue ){
				dBestActionValue = dActionValue;
				iBestAction = iAction;
			}
		}
		return iBestAction;
	}
	public String getName(){
		return "RTDP";
	}

	@Override
	public void valueIteration(int cMaxSteps, double dEpsilon, double dTargetValue) {
		BeliefState bsInitial = m_pPOMDP.getBeliefStateFactory().getInitialBeliefState();
		int iIteration = 0, iMaxDepth = 0;
		long lStartTime = System.currentTimeMillis(), lCurrentTime = 0;
		Runtime rtRuntime = Runtime.getRuntime();
		boolean bDone = false;
		Pair<Double, Double> pComputedADRs = new Pair<Double, Double>();
		Vector<BeliefState> vObservedBeliefStates = new Vector<BeliefState>();
		int cNoChange = 0;
		String sMsg = "";
		
		m_cElapsedExecutionTime = 0;
		m_cCPUExecutionTime = 0;
		
		long lCPUTimeBefore = 0, lCPUTimeAfter = 0, lCPUTimeTotal = 0;
		
		int cValueFunctionChanges = 0;
		
		
		for( iIteration = 0 ; ( iIteration < cMaxSteps ) && !bDone && !m_bTerminate ; iIteration++ ){
			lStartTime = System.currentTimeMillis();
			lCPUTimeBefore = JProf.getCurrentThreadCpuTimeSafe();
			
			iMaxDepth = explore( bsInitial, dEpsilon, 0, 1.0, vObservedBeliefStates );
			
			lCurrentTime = System.currentTimeMillis();
			lCPUTimeAfter = JProf.getCurrentThreadCpuTimeSafe();
			m_cElapsedExecutionTime += ( lCurrentTime - lStartTime );
			m_cCPUExecutionTime += ( lCPUTimeAfter - lCPUTimeBefore ) / 1000000;
			lCPUTimeTotal += lCPUTimeAfter - lCPUTimeBefore;
			
			if( false && ( iIteration >= 20 ) && ( ( lCPUTimeTotal  / 1000000000 ) >= 0 ) && ( iIteration % 20 == 0 )  ){
								
				bDone = checkADRConvergence( m_pPOMDP, dTargetValue, pComputedADRs );
				
				rtRuntime.gc();
				
				sMsg = getName() + ": Iteration " + iIteration + 
									" V^(b) " + round( m_dUpperBound.valueAt( m_pPOMDP.getBeliefStateFactory().getInitialBeliefState() ), 4 ) +
									//" max width bs = " + bsMaxWidth + 
									//" max width " + round( width( bsMaxWidth ), 3 ) +
									" max depth " + iMaxDepth +
									" simulated ADR " + ((Number) pComputedADRs.first()).doubleValue() +
									" filtered ADR " + round( ((Number) pComputedADRs.second()).doubleValue(), 3 ) +
									" changes " + m_dUpperBound.getChangesCount() +
									" Time " + ( lCurrentTime - lStartTime ) / 1000 +
									" CPU time " + ( lCPUTimeAfter - lCPUTimeBefore ) / 1000000000 +
									" CPU total " + lCPUTimeTotal  / 1000000000 +
									" |V^| " + m_dUpperBound.getUpperBoundPointCount() +
									" V changes " + m_vValueFunction.getChangesCount() +
									" #ObservedBS = " + vObservedBeliefStates.size() +
									" #BS " + m_pPOMDP.getBeliefStateFactory().getBeliefUpdatesCount() +
									" #backups " + m_cBackups +
									" max depth " + iMaxDepth +
									" free memory " + rtRuntime.freeMemory() / 1000000 +
									" total memory " + rtRuntime.totalMemory() / 1000000 +
									" max memory " + rtRuntime.maxMemory() / 1000000;
			}
			else{
				sMsg = getName() + ": Iteration " + iIteration + 
						" V^(b) " + round( m_dUpperBound.valueAt( m_pPOMDP.getBeliefStateFactory().getInitialBeliefState() ), 4 ) +
						" max depth " + iMaxDepth +
						" changes " + m_dUpperBound.getChangesCount() +
						" Time " + ( lCurrentTime - lStartTime ) / 1000 +
						" CPU time " + ( lCPUTimeAfter - lCPUTimeBefore ) / 1000000000 +
						" CPU total " + lCPUTimeTotal  / 1000000000 +
						" |V| " + m_vValueFunction.size() +
						" |V^| " + m_dUpperBound.getUpperBoundPointCount() +
						" #ObservedBS = " + vObservedBeliefStates.size() +
						" #BS " + m_pPOMDP.getBeliefStateFactory().getBeliefUpdatesCount() +
						" #backups " + m_cBackups +
						" free memory " + rtRuntime.freeMemory() / 1000000 +
						" total memory " + rtRuntime.totalMemory() / 1000000 +
						" max memory " + rtRuntime.maxMemory() / 1000000;
			}
			Logger.getInstance().log( getName(), 0, "VI", sMsg );
			if( m_vValueFunction.getChangesCount() == cValueFunctionChanges ){
				cNoChange++;
			}
			else
				cNoChange = 0;
		}
		
		m_cElapsedExecutionTime /= 1000;
		m_cCPUExecutionTime /= 1000;
		
		sMsg = "Finished " + getName() + " - time : " + m_cElapsedExecutionTime +
				" |V| = " + m_vValueFunction.size() + 
				" backups = " + m_cBackups + 
				" GComputations = " + AlphaVector.getGComputationsCount() +
				" Dot products = " + AlphaVector.dotProductCount();
		Logger.getInstance().log( "HSVI", 0, "VI", sMsg );
		
		if( ExecutionProperties.getReportOperationTime() )
			sMsg = "Avg time: backup " + ( m_cTimeInBackup / ( m_cBackups * 1.0 ) ) + 
					" G " + AlphaVector.getAvgGTime() +
					" Tau " + m_pPOMDP.getBeliefStateFactory().getAvgTauTime() + 
					" DP " + AlphaVector.getAvgDotProductTime() 
					;
		Logger.getInstance().log( "RTDP", 0, "VI", sMsg );
	}
}
